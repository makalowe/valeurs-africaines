import copy
import json
import os
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from app import data
from app.sqlite_store import SQLiteStore, migrate, export_json, backup_database

PROJECT = Path(__file__).resolve().parents[1]


class MigrationTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        self.source = self.root / "source.json"
        self.db = self.root / "store.sqlite3"
        self.payload = {
            "articles": [{"id": 1, "slug": "essai", "title": "Été africain",
                          "status": "published", "views": 0, "nested": {"é": [1, None]}}],
            "subscribers": ["legacy@example.invalid"], "editions": [],
            "extension_future": {"unknown": True},
        }
        self.source.write_text(json.dumps(self.payload, ensure_ascii=False), encoding="utf-8")
        migrate(self.source, self.db)
        self.env = patch.dict(os.environ, {"VA_SQLITE_PATH": str(self.db)})
        self.env.start()
        self.addCleanup(self.env.stop)

    def test_roundtrip_and_backup_preserve_every_field(self):
        original = self.source.read_bytes()
        self.assertEqual(SQLiteStore(self.db).load(), self.payload)
        export_json(self.db, self.root / "export.json")
        self.assertEqual(json.loads((self.root / "export.json").read_text()), self.payload)
        backup_database(self.db, self.root / "backup.sqlite3")
        self.assertEqual(SQLiteStore(self.root / "backup.sqlite3").load(), self.payload)
        self.assertEqual(self.source.read_bytes(), original)
        with self.assertRaises(FileExistsError):
            migrate(self.source, self.db)
        self.assertEqual(SQLiteStore(self.db).load(), self.payload)

    def test_transactions_rollback_and_reject_unprotected_save(self):
        store = SQLiteStore(self.db)
        with self.assertRaises(RuntimeError):
            store.save(self.payload)
        with self.assertRaisesRegex(RuntimeError, "abort"):
            with store.transaction():
                changed = store.load()
                changed["articles"][0]["views"] = 900
                store.save(changed)
                raise RuntimeError("abort")
        self.assertEqual(store.load(), self.payload)

    def test_newsletter_and_editorial_operations(self):
        ok, _ = data.add_subscriber("reader@example.invalid")
        self.assertTrue(ok)
        self.assertEqual(data.find_subscriber("reader@example.invalid")["status"], "pending")
        self.assertTrue(data.set_subscriber_status("reader@example.invalid", "confirmed"))
        self.assertTrue(data.set_subscriber_status("reader@example.invalid", "unsubscribed"))
        self.assertTrue(data.add_subscriber("reader@example.invalid")[0])
        self.assertEqual(data.find_subscriber("reader@example.invalid")["status"], "pending")
        self.assertEqual(data.find_subscriber("legacy@example.invalid")["status"], "legacy")
        data.create_article("Test", "Nouveau", "Résumé", "Corps", "1 min")
        data.schedule_article(2, "2000-01-01")
        data.promote_scheduled_articles()
        data.feature_article(2)
        self.assertEqual(data.get_any_article_by_slug("nouveau")["status"], "published")
        self.assertEqual(data.featured_article()["id"], 2)

    def test_concurrent_processes_do_not_lose_views_or_subscribers(self):
        code = """
from app import data
import sys
for i in range(30): data.register_view('essai')
data.add_subscriber('same@example.invalid')
data.create_article('Test', 'Concurrent', 'Resume', 'Body', '1 min')
"""
        jobs = [subprocess.Popen([sys.executable, "-c", code], cwd=PROJECT,
                                stdout=subprocess.PIPE, stderr=subprocess.PIPE)
                for _ in range(4)]
        for job in jobs:
            out, err = job.communicate(timeout=90)
            self.assertEqual(job.returncode, 0, err.decode())
        self.assertEqual(data.get_any_article_by_slug("essai")["views"], 120)
        self.assertEqual(sum(s["email"] == "same@example.invalid" for s in data.list_subscribers()), 1)
        articles = data.list_articles()
        self.assertEqual(len({a["id"] for a in articles}), 5)
        self.assertEqual(len({a["slug"] for a in articles}), 5)

    def test_invalid_or_missing_database_never_falls_back_to_json(self):
        os.environ["VA_SQLITE_PATH"] = str(self.root / "absent.sqlite3")
        with self.assertRaises(Exception):
            data.init_store()
        self.assertFalse((self.root / "absent.sqlite3").exists())
        self.assertEqual(json.loads(self.source.read_text()), self.payload)

    def test_json_mode_unchanged(self):
        os.environ.pop("VA_SQLITE_PATH", None)
        with patch.object(data, "STORE_PATH", self.source):
            data.register_view("essai")
        self.assertEqual(json.loads(self.source.read_text())["articles"][0]["views"], 1)

    def test_flask_pages_and_admin_guard_with_isolated_store(self):
        from app import create_app
        app = create_app()
        app.config.update(TESTING=True, SECRET_KEY="isolated-test-only")
        client = app.test_client()
        for url in ["/newsletter", "/politique-confidentialite", "/admin/login"]:
            self.assertEqual(client.get(url).status_code, 200)
        self.assertEqual(client.get("/admin").status_code, 302)
        self.assertEqual(client.get("/admin/newsletter-subscribers.csv").status_code, 302)
        with client.session_transaction() as session:
            session["admin_ok"] = True
        self.assertEqual(client.get("/admin/newsletter-subscribers.csv").status_code, 200)


if __name__ == "__main__":
    unittest.main()
