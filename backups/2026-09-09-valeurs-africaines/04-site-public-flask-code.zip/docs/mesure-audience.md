# Mesure d'audience Valeurs Africaines

État : 7 septembre 2026. Stratégie en paliers. Responsable : **Samuel N.
Okafor (CTO Data & Tableaux de bord)** — dashboard « performance » : trafic
web, clics, contenus les plus lus.

## Paliers (décision Pierre, 07/09/2026)

| Palier | Outil | Effort | Quand |
|---|---|---|---|
| **1. Compteur de vues intégré** (actif) | Champ `views` par article dans `data_store.json` + vue `/admin` | ~30 min | ✅ En place depuis le 07/09 |
| **2. GoAccess sur logs Nginx** | Analyse des logs du VPS (aucune installation permanente) | ~30 min (Codex) | Dès validation Pierre |
| **3. Umami self-hosted** (VPS) | Node.js + base dédiée, tableau de bord temps réel | ~1 h (Codex) | **Quand le trafic devient conséquent** |

## ⚠️ Règle de bascule (Samuel — à retenir)

**Dès qu'il y a « pas mal de vues » sur le site, il faut passer au palier
au-dessus (Umami).**

Seuil indicatif de déclenchement (à confirmer avec Pierre) :
- le compteur intégré dépasse **~1 000 vues cumulées**, OU
- besoin de connaître les **sources de trafic** (réseaux sociaux, Google,
  direct) et les **parcours de lecture** (comment on lit : article → article),
  OU
- les écritures JSON du compteur deviennent un souci de performance
  (plusieurs centaines de requêtes/minute).

Le palier 2 (GoAccess) couvre déjà les sources approximatives sans
installation ; le palier 3 (Umami) devient prioritaire quand on veut le
temps réel et le détail par visiteur anonyme.

## Compteur de vues intégré — mode d'emploi

- Chaque vue d'un article publié (`GET /articles/<slug>`) incrémente
  `views` dans `data_store.json`.
- Les robots/crawlers connus (User-Agent contenant bot, spider, crawl,
  slurp, preview, mediapartners, bing) ne sont **pas** comptés.
- Affichage : `/admin` → KPI « Vues totales », tableau « Articles les plus
  lus » (top 5), colonne « Vues » dans le tableau des articles.
- Code : `register_view(slug)` et `most_viewed(limit)` dans `app/data.py` ;
  incrément dans `article_detail` (`app/routes.py`).
- Limite connue : comptage par requête HTTP, pas de distinction
  visiteur/visite, pas d'heure de consultation — d'où la bascule Umami à
  terme.

## RGPD

Mesure d'audience sans cookie, sans donnée personnelle : conforme CNIL
(exemption « mesure d'audience »). Ne jamais croiser avec de la publicité
ciblée. Le compteur ne stocke ni IP ni User-Agent — uniquement un entier
par article.
