# Newsletter Valeurs Africaines — configuration et flux RGPD

État : 6 septembre 2026. Module conforme RGPD (consentement explicite,
journalisation, double opt-in, désinscription 1 clic). Stockage : JSON local
(`app/data_store.json`, clé `subscribers`) — pas de SQLite à ce stade.

## Modes de fonctionnement

### Mode local (défaut, aucune variable Brevo)
- Les inscriptions sont stockées dans `data_store.json` avec journalisation
  complète (email, statut, consentement + texte, version formulaire, source,
  IP, dates UTC).
- Nouvel abonné → statut `pending` (double opt-in).
- Aucun email réel n'est envoyé : le site affiche « Un email de confirmation
  devra etre envoye pour activer l'abonnement ».
- Export des abonnés : `/admin/newsletter-subscribers.csv` (admin requis).

### Mode Brevo (recommandé pour l'envoi)
Variables d'environnement (fichier `.env` serveur, jamais commité) :
- `BREVO_API_KEY` — clé API Brevo
- `BREVO_LIST_ID` — ID numérique de la liste (contacts confirmés uniquement)
- `BREVO_SENDER_EMAIL` — expéditeur validé sur Brevo
  (défaut : `redaction@valeursafricaines.com`)
- Optionnel : `SUBSTACK_URL` — lien d'abonnement Substack affiché sur
  `/newsletter`

Flux avec Brevo :
1. Inscription sur le site → abonné `pending` + tentative d'envoi de l'email
   de confirmation (transactionnel Brevo). Échec d'envoi jamais bloquant.
2. Clic sur le lien de confirmation → statut `confirmed` (en local) puis
   ajout du contact à la liste Brevo (`subscribe_email`, non bloquant).
3. L'abonnement n'est actif qu'après confirmation : jamais de newsletter
   envoyée à un `pending`.

## Double opt-in

- Création : `POST /newsletter/subscribe` avec `consent=on` →
  `status: "pending"` (jamais `confirmed` d'office).
- Confirmation : `GET /newsletter/confirm?email=...&token=...` →
  `pending` → `confirmed`. Un `confirmed` reste confirmé si le lien est
  recliqué. Un `unsubscribed` n'est **jamais** réactivé par ce lien.
- Lien de confirmation (à insérer dans l'email Brevo) :
  généré par la route avec `make_newsletter_token(email, "confirm")` — voir
  la fonction `newsletter_links(email)` dans `app/routes.py`.

## Lien de désinscription

- Route : `GET /newsletter/unsubscribe?email=...&token=...` → statut
  `unsubscribed` (1 clic, sans login, horodaté).
- Token HMAC signé par la SECRET_KEY de l'application (fonctions
  `make_newsletter_token` / `check_newsletter_token` dans `app/data.py`).
- À insérer dans le footer de chaque newsletter (obligation RGPD/LCEN) :
  ```
  https://valeursafricaines.zionworld.fr/newsletter/unsubscribe?email={email}&token={token}
  ```
  Token généré côté serveur — jamais affiché publiquement, jamais dans un log.
- Réinscription possible ensuite via le formulaire (repart en `pending`).

## Variables d'environnement (récapitulatif)

| Variable | Rôle |
|---|---|
| `SECRET_KEY` | Signature des tokens confirm/unsubscribe (obligatoire en prod) |
| `BREVO_API_KEY` | Envoi emails confirmation + contacts (vide = mode local) |
| `BREVO_LIST_ID` | Liste Brevo des contacts confirmés |
| `BREVO_SENDER_EMAIL` | Expéditeur Brevo validé (défaut redaction@…) |
| `VA_ADMIN_PASSWORD` | Accès admin (export CSV) |
| `SUBSTACK_URL` | Lien Substack affiché sur la page newsletter |

## Limites actuelles

- Pas d'envoi automatique des newsletters elles-mêmes (l'envoi des éditions
  se fera via Brevo/Substack — décision Pierre : Brevo, configuration prévue
  le 07/09/2026).
- Pas de double opt-in réellement envoyé tant que Brevo n'est pas configuré
  (les abonnés restent `pending`, conformes mais inactifs).
- Pas de gestion des bounces côté local (dépend de Brevo).
- Stockage JSON : acceptable jusqu'à quelques centaines d'abonnés ; migrer
  vers SQLite si le volume grossit.

## Prochaine étape recommandée

1. Créer le compte Brevo (gratuit) → clé API + ID de liste + expéditeur validé.
2. Poser les variables dans le `.env` serveur (via Codex, jamais affichées).
3. Envoyer un email de test de confirmation et valider le cycle complet.
4. Rédiger le template de la newsletter (charte VA) avec liens signés
   confirm/unsubscribe dans le footer.
5. Première campagne : newsletter VA Hebdo 02 vers les abonnés `confirmed`.
