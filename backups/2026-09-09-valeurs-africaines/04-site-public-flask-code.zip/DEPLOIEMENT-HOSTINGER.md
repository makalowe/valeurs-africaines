# Valeurs Africaines — déploiement Hostinger VPS

État au 6 septembre 2026 : application publiée et vérifiée en HTTPS sur
https://valeursafricaines.zionworld.fr/. Nyllo conservé sans modification.
Pierre a validé valeursafricaines.zionworld.fr avec Nyllo inchangé.
La proposition précédente de remplacer l’accueil zionworld.fr est abandonnée.

## Cibles et accès

VPS KVM1 1367391, Ubuntu 24.04, SSH root port 22 par clé.
IPv4 : 76.13.51.187 ; IPv6 : 2a02:4780:7:8e5b::1.
Nyllo reste sur zionworld.fr, avec redirection / vers /nyllo-canela/.
Hostinger Business Web Hosting ne prend pas en charge cette application Flask.
Source : https://www.hostinger.com/support/which-programming-languages-and-frameworks-are-supported-at-hostinger/
Aucune section Python/Passenger hPanel utilisée : service Gunicorn et Nginx sur VPS.

## Archive et validations locales

Archive d’origine inchangée : deploiement-hostinger-2026-09-06.zip.
10 991 761 octets, 87 fichiers.
SHA256 : a04fba83433dd8e7b728698b7a1a15b7642c1388a32e08caf5725e059ce2ea25
passenger_wsgi.py, run.py et requirements.txt présents.
51 images, 60 références dans data_store.json, 48 distinctes : aucune manquante.
Aucun .env, credentials.json ou nom de clé privée détecté dans l’archive.
Extraction locale temporaire ; venv neuf ; pip install -r requirements.txt et
pip check réussis. python run.py sur 61307 : / et /editions HTTP 200, puis arrêt.

## Installation effectuée

- Compte système sans connexion : valeurs-africaines.
- Release : /opt/valeurs-africaines/releases/2026-09-06.
- Lien actif : /opt/valeurs-africaines/current.
- Venv : .venv dans la release ; dépendances installées, pip check OK.
- Paquet Ubuntu python3.12-venv ajouté avec ses dépendances ; mises à jour
  Python requises par apt install appliquées. Aucun redémarrage système effectué.
- Service : /etc/systemd/system/valeurs-africaines.service, activé et démarré.
- Gunicorn : 2 workers, écoute privée 127.0.0.1:8001, passenger_wsgi:application.
- Écriture autorisée au service sur app/data_store.json ; code protégé par systemd.
- Nginx dédié : /etc/nginx/sites-available/valeursafricaines.zionworld.fr,
  lien dans sites-enabled, HTTPS sur 443 et redirection HTTP vers HTTPS.
- Racine challenge ACME : /var/www/va-acme.
- ZIP transféré vérifié par SHA256 puis supprimé du dossier temporaire serveur.

## Variables serveur

.env créé exclusivement sur le VPS : /opt/valeurs-africaines/shared/.env,
mode 600, compte dédié propriétaire, lien .env dans la release.
SECRET_KEY et FLASK_SECRET_KEY générées sur serveur avec secrets.token_hex(32),
sans affichage. FLASK_ENV=production, FLASK_DEBUG=False, FLASK_PORT=8001.
VA_ADMIN_PASSWORD, BREVO_API_KEY, BREVO_LIST_ID et SUBSTACK_URL laissés vides.
Connexion admin désactivée ; intégrations newsletter non configurées.
Aucun secret lu, affiché, copié localement, archivé ou committé.
Le module passenger_wsgi charge automatiquement le .env serveur.

## Vérifications serveur et Nyllo

- / et /editions sur Gunicorn : HTTP 200.
- Les 51 fichiers image : HTTP 200.
- nginx -t : réussi ; rechargement Nginx effectué.
- Sous-domaine via résolution forcée vers le VPS, en HTTP : 200.
- Configuration Nginx zionworld.fr inchangée, SHA256 avant/après :
  0fd7c161bce7ed1aa2317132e1fd0697b69194fb2dba4d3433db26e84a461b9f
- Nyllo HTTPS : accueil 301 vers /nyllo-canela/ ; page, CSS et vidéo vérifiées : 200.
- Aucun fichier Nyllo ni enregistrement DNS existant modifié.

## Finalisation DNS et HTTPS

Enregistrement A ajouté par Pierre et vérifié sur DNS autoritaire :
valeursafricaines.zionworld.fr -> 76.13.51.187.
Certificat dédié Let's Encrypt obtenu par Certbot webroot, valable jusqu’au
5 décembre 2026. Aucun changement au certificat Nyllo.
Configuration HTTPS dédiée validée par nginx -t, puis Nginx rechargé.
Renouvellement automatique Certbot configuré ; hook de validation/rechargement
Nginx : /etc/letsencrypt/renewal-hooks/deploy/valeurs-africaines-nginx.

Recette publique avec validation normale du certificat :
- https://valeursafricaines.zionworld.fr/ : 200.
- /editions : 200.
- Les 51 images : 200.
- /.env : 404 (contenu non consulté).
- HTTP redirige en 301 vers HTTPS.
- Nyllo : accueil 301 vers /nyllo-canela/, page/CSS/vidéo 200.
- SHA256 de la configuration Nyllo identique au contrôle initial.
- Service valeurs-africaines actif.

## Retour arrière isolé

Désactiver uniquement le lien sites-enabled/valeursafricaines.zionworld.fr,
valider nginx -t puis recharger. Arrêter le service valeurs-africaines si nécessaire.
Conserver release et données ; ne toucher ni à la configuration ni aux fichiers Nyllo.
Aucun commit Git effectué. La recette HTTPS finale est réussie.

Renouvellement vérifié : certbot renew --cert-name valeursafricaines.zionworld.fr --dry-run --run-deploy-hooks --no-random-sleep-on-renew : succès, validation et rechargement Nginx réussis. Timer certbot actif.
