---
type: banque-images-editoriales
projet: Valeurs Africaines
statut: actif
---

# Banque images editoriales

## Reserve pour le prochain editorial

### Project a Black Planet - Simone Leigh

- Statut : reserve pour le prochain editorial.
- Artiste : Simone Leigh.
- Oeuvre : Dunham, 2017.
- Source : Barbican Centre, Project a Black Planet: The Art and Culture of Panafrica.
- URL source : https://www.barbican.org.uk/whats-on/2026/event/project-a-black-planet-the-art-and-culture-of-panafrica
- Fichier principal : `app/static/img/panafricanisme-culturel-simone-leigh-dunham.jpg`
- Fichier recadre horizontal : `app/static/img/panafricanisme-culturel-simone-leigh-dunham-wide.jpg`
- Credit a afficher : Image : Simone Leigh, Dunham, 2017. Courtesy de l'artiste, Matthew Marks Gallery et Luhring Augustine. Photo publiee par le Barbican Centre.
- Usage prevu : prochain editorial, en lien avec panafricanisme culturel, souverainete narrative, arts africains et diasporas.
