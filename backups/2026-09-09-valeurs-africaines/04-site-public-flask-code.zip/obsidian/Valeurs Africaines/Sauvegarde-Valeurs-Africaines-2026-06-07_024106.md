# Sauvegarde Valeurs Africaines - 2026-06-07_024106

## Etat
- Revue hebdomadaire active.
- Premiere edition : VA Hebdo 01.
- Archive publique : /editions/va-hebdo-01-juin-2026.
- Articles au format Research Brief avec notes a la francaise.

## Emplacements
- Backup local Google Drive : C:\Users\MIMBI\OneDrive\Bureau\Valeurs Africaines\_drive-miroir\99_Archives\Valeurs-Africaines_2026-06-07_024106
- Archive ZIP : C:\Users\MIMBI\OneDrive\Bureau\Valeurs Africaines\_drive-miroir\99_Archives\Valeurs-Africaines_2026-06-07_024106.zip
- Site local : http://127.0.0.1:5000/
- GitHub : https://github.com/makalowe/valeurs-africaines

## Verification avant sauvegarde
- JSON valide.
- Python compilable.
- Pages testees : accueil, /editions, edition detail, article Afrique du Sud, sitemap.
