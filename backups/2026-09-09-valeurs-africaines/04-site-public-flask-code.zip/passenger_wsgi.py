# -*- coding: utf-8 -*-
"""Passenger WSGI — point d'entrée pour l'hébergement Python Hostinger.
Hostinger exécute ce fichier (passenger_wsgi.py) à la racine de l'application.
"""
import os
import sys

# Ajouter le dossier de l'application au chemin Python
APP_DIR = os.path.dirname(os.path.abspath(__file__))
if APP_DIR not in sys.path:
    sys.path.insert(0, APP_DIR)

# Charger les variables d'environnement depuis .env si présent
try:
    from dotenv import load_dotenv
    load_dotenv(os.path.join(APP_DIR, ".env"))
except Exception:
    pass

from app import create_app

application = create_app()
