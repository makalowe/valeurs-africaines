import csv
import io
import os
import time
from collections import defaultdict
from datetime import date, datetime, timezone, timedelta
from email.utils import format_datetime
from xml.sax.saxutils import escape

from flask import Blueprint, Response, abort, flash, redirect, render_template, request, session, url_for

from .data import (
    NEWSLETTER_CONSENT_TEXT,
    NEWSLETTER_FORM_VERSION,
    add_subscriber,
    articles_for_edition,
    check_newsletter_token,
    create_article,
    current_edition,
    feature_article as set_featured,
    featured_article,
    find_subscriber,
    get_article_by_slug,
    get_any_article_by_slug,
    get_edition_by_slug,
    list_articles,
    list_editions,
    list_published,
    list_subscribers,
    make_newsletter_token,
    most_viewed,
    publish_article as set_published,
    register_view,
    schedule_article as set_scheduled,
    set_subscriber_status,
)
from .newsletter_provider import send_confirmation_email, subscribe_email
from .taxonomy import section_by_slug, slugify, taxonomy_context

bp = Blueprint("main", __name__)

COUNTRY_FLAGS = {
    "algerie": "🇩🇿",
    "angola": "🇦🇴",
    "benin": "🇧🇯",
    "burkina faso": "🇧🇫",
    "cameroun": "🇨🇲",
    "cap-vert": "🇨🇻",
    "congo": "🇨🇬",
    "cote d'ivoire": "🇨🇮",
    "cote d’ivoire": "🇨🇮",
    "egypte": "🇪🇬",
    "ethiopie": "🇪🇹",
    "gabon": "🇬🇦",
    "ghana": "🇬🇭",
    "guinee": "🇬🇳",
    "kenya": "🇰🇪",
    "libye": "🇱🇾",
    "madagascar": "🇲🇬",
    "mali": "🇲🇱",
    "maroc": "🇲🇦",
    "mauritanie": "🇲🇷",
    "niger": "🇳🇪",
    "nigeria": "🇳🇬",
    "ouganda": "🇺🇬",
    "rdc": "🇨🇩",
    "rdc congo": "🇨🇩",
    "republique democratique du congo": "🇨🇩",
    "rwanda": "🇷🇼",
    "senegal": "🇸🇳",
    "somalie": "🇸🇴",
    "soudan": "🇸🇩",
    "tchad": "🇹🇩",
    "togo": "🇹🇬",
    "tunisie": "🇹🇳",
}


def _detect_country_flag(text: str) -> str:
    hay = (text or "").lower()
    for country, flag in COUNTRY_FLAGS.items():
        if country in hay:
            return flag
    return ""



def _article_tokens(row: dict) -> set[str]:
    values = [
        row.get("rubrique", ""),
        row.get("theme", ""),
        row.get("format_label", ""),
        row.get("country", ""),
    ]
    values.extend(row.get("tags") or [])
    return {slugify(str(value)) for value in values if value}


def _matches_taxonomy(row: dict, value: str) -> bool:
    wanted = slugify(value)
    return wanted in _article_tokens(row)


def _filter_articles(rows: list[dict], rubrique: str = "", theme: str = "", format_label: str = "", country: str = "") -> list[dict]:
    filtered = rows
    if rubrique:
        filtered = [row for row in filtered if _matches_taxonomy(row, rubrique)]
    if theme:
        filtered = [row for row in filtered if _matches_taxonomy(row, theme)]
    if format_label:
        filtered = [row for row in filtered if _matches_taxonomy(row, format_label)]
    if country:
        wanted = country.strip().lower()
        filtered = [row for row in filtered if wanted in (row.get("country", "").lower())]
    return filtered

def _admin_allowed() -> bool:
    return bool(session.get("admin_ok"))


# Anti-spam : limiteur simple en mémoire (fenêtre glissante par IP).
# Limite connue : compteur par processus — avec 2 workers Gunicorn, le plafond
# effectif est doublé. Suffisant contre le spam ; Umami/Flask-Limiter plus tard
# si besoin.
_RATE_HITS: dict[str, list[float]] = defaultdict(list)

def _rate_limited(bucket: str, limit: int, window_seconds: float) -> bool:
    """True si la requête dépasse la limite (bucket:ip)."""
    now = time.monotonic()
    key = f"{bucket}:{request.remote_addr or '?'}"
    hits = [t for t in _RATE_HITS[key] if now - t < window_seconds]
    if len(hits) >= limit:
        _RATE_HITS[key] = hits
        return True
    hits.append(now)
    _RATE_HITS[key] = hits
    return False


def _kpi_snapshot() -> dict:
    rows = list_articles()
    total = len(rows)
    published = sum(1 for r in rows if r.get("status") == "published")
    scheduled = sum(1 for r in rows if r.get("status") == "scheduled")
    drafts = sum(1 for r in rows if r.get("status") == "draft")
    subscribers = len(list_subscribers())
    views_total = sum(int(r.get("views") or 0) for r in rows)
    monthly_goal = 16
    progress = min(100, int((scheduled / monthly_goal) * 100)) if monthly_goal else 0
    return {
        "total": total,
        "published": published,
        "scheduled": scheduled,
        "drafts": drafts,
        "subscribers": subscribers,
        "views_total": views_total,
        "monthly_goal": monthly_goal,
        "progress": progress,
    }


@bp.route("/")
def home():
    featured_row = featured_article()
    featured_tag = (featured_row.get("theme") or featured_row["rubrique"]) if featured_row else "Analyse de fond"
    if featured_tag.lower() == "culture":
        featured_tag = "Éditorial"
    featured = {
        "tag": featured_tag,
        "title": featured_row["title"] if featured_row else "Article a venir",
        "excerpt": featured_row["excerpt"] if featured_row else "Publication en preparation.",
        "slug": featured_row["slug"] if featured_row else "",
        "image": featured_row.get("image") if featured_row else "",
    }

    published_rows = list_published()
    edition = current_edition()
    edition_articles = articles_for_edition(edition["slug"])[:4] if edition else []

    def _card(row):
        return {
            "rubrique": row.get("theme") or row["rubrique"],
            "title": row["title"],
            "slug": row["slug"],
            "date": row["published_at"] or "A paraitre",
            "reading_time": row.get("reading_time", ""),
            "author": row.get("author", ""),
            "image": row.get("image"),
            "country_flag": _detect_country_flag(f"{row.get('title', '')} {row.get('excerpt', '')}") if "pays" in (row.get("rubrique", "").lower()) else "",
        }

    today = date.today()
    daily_cutoff = today - timedelta(days=6)

    def _published_date(row):
        try:
            return date.fromisoformat(row.get("published_at") or "")
        except ValueError:
            return None

    daily_rows = []
    for row in published_rows:
        published_at = _published_date(row)
        if not published_at:
            continue
        if not (daily_cutoff <= published_at <= today):
            continue
        if "aujourd'hui en afrique" not in (row.get("rubrique", "").lower()):
            continue
        daily_rows.append(row)
    daily_rows.sort(key=lambda row: (row.get("published_at") or "", row.get("id", 0)), reverse=True)
    today_focus = {"daily": [_card(row) for row in daily_rows], "retention_days": 7}

    headline_rows = [
        row
        for row in edition_articles
        if "aujourd'hui en afrique" not in (row.get("rubrique", "").lower())
    ]
    headlines = [_card(row) for row in headline_rows[:3]]

    return render_template(
        "home.html",
        featured=featured,
        headlines=headlines,
        today_focus=today_focus,
        current_edition=edition,
        edition_articles=edition_articles,
        meta_description="Revue geopolitique africaine: analyses de fond, diplomatie, securite, ressources et veille strategique.",
    )


@bp.route("/articles")
def articles():
    filters = {
        "rubrique": request.args.get("rubrique", "").strip(),
        "theme": request.args.get("theme", "").strip(),
        "format": request.args.get("format", "").strip(),
        "country": request.args.get("country", "").strip(),
    }
    # « Édition hebdomadaire » n'est pas une rubrique d'article : les contenus des
    # éditions portent leurs rubriques réelles et sont rattachés via edition_slug.
    # Ce filtre liste donc tous les articles appartenant à une édition publiée.
    if slugify(filters["rubrique"]) == slugify("Édition hebdomadaire"):
        rows = [row for row in list_published() if row.get("edition_slug")]
        rows.sort(key=lambda row: (row.get("published_at") or "", row.get("id", 0)), reverse=True)
    else:
        rows = _filter_articles(
            list_published(),
            rubrique=filters["rubrique"],
            theme=filters["theme"],
            format_label=filters["format"],
            country=filters["country"],
        )
    return render_template(
        "articles.html",
        rows=rows,
        filters=filters,
        meta_description="Archives et filtres de recherche de Valeurs Africaines.",
    )


@bp.route("/articles/<slug>")
def article_detail(slug: str):
    article = get_article_by_slug(slug)
    if not article:
        abort(404)
    # Compteur de vues : ignore les robots/crawlers connus pour ne pas fausser
    # la mesure d'audience (MVP intégré — voir docs/mesure-audience.md).
    ua = (request.headers.get("User-Agent") or "").lower()
    if not any(token in ua for token in ("bot", "spider", "crawl", "slurp", "preview", "mediapartners", "bing")):
        register_view(slug)
        article["views"] = int(article.get("views") or 0) + 1
    edition = get_edition_by_slug(article.get("edition_slug", "")) if article.get("edition_slug") else None
    return render_template("article_detail.html", article=article, edition=edition, meta_description=article["excerpt"])


@bp.route("/editions")
def editions():
    rows = list_editions()
    edition_counts = {row.get("slug"): len(articles_for_edition(row.get("slug", ""))) for row in rows}
    return render_template(
        "editions.html",
        rows=rows,
        edition_counts=edition_counts,
        meta_description="Archives des editions hebdomadaires de Valeurs Africaines.",
    )


@bp.route("/editions/<slug>")
def edition_detail(slug: str):
    edition = get_edition_by_slug(slug)
    if not edition:
        abort(404)
    rows = articles_for_edition(slug)
    return render_template(
        "edition_detail.html",
        edition=edition,
        rows=rows,
        meta_description=edition.get("excerpt") or edition.get("editorial", "")[:160],
    )


@bp.route("/rubriques")
def rubriques():
    return render_template(
        "rubriques.html",
        structure=taxonomy_context()["structure"],
        meta_description="Architecture editoriale de Valeurs Africaines.",
    )


@bp.route("/rubriques/<section_slug>")
def archive_section(section_slug: str):
    section = section_by_slug(section_slug)
    if not section:
        abort(404)
    rows = _filter_articles(list_published(), rubrique=section["name"])
    return render_template(
        "archive_section.html",
        section=section,
        rows=rows,
        meta_description=f"Archives {section['name']} - Valeurs Africaines.",
    )


@bp.route("/themes/<theme_slug>")
def archive_theme(theme_slug: str):
    theme = next((item for item in taxonomy_context()["themes"] if slugify(item) == theme_slug), None)
    if not theme:
        abort(404)
    rows = _filter_articles(list_published(), theme=theme)
    return render_template(
        "archive_section.html",
        section={"name": theme, "kind": "theme", "level": "tag", "themes": [], "children": []},
        rows=rows,
        meta_description=f"Articles classes dans le theme {theme}.",
    )


@bp.route("/base-connaissances")
def knowledge_base():
    rows = [section for section in taxonomy_context()["sections"] if section["level"] == 4]
    return render_template(
        "taxonomy_collection.html",
        title="Base de connaissances",
        sections=rows,
        meta_description="Fiches pays, organisations, acteurs, chronologies et bibliotheque documentaire.",
    )


@bp.route("/produits-speciaux")
def special_products():
    rows = [section for section in taxonomy_context()["sections"] if section["level"] == 5]
    return render_template(
        "taxonomy_collection.html",
        title="Produits spéciaux",
        sections=rows,
        meta_description="Dossiers strategiques, rapports, atlas, academie et observatoire Valeurs Africaines.",
    )


@bp.route("/signaux-faibles")
def weak_signals():
    rows = _filter_articles(list_published(), format_label="Signaux faibles")
    return render_template(
        "archive_section.html",
        section={"name": "Signaux faibles", "kind": "veille prospective", "level": 2, "themes": [], "children": []},
        rows=rows,
        meta_description="Page dediee aux signaux faibles africains.",
    )


@bp.route("/mediatheque")
def media_library():
    rows = _filter_articles(list_published(), format_label="Infographie / Carte")
    return render_template(
        "archive_section.html",
        section={"name": "Infographies et cartes", "kind": "mediatheque", "level": 2, "themes": [], "children": []},
        rows=rows,
        meta_description="Mediatheque des infographies et cartes strategiques.",
    )


@bp.route("/a-propos")
def about():
    return render_template("about.html", meta_description="A propos de Valeurs Africaines, revue geopolitique francophone.")


@bp.route("/methodologie")
def methodology():
    return render_template("methodology.html", meta_description="Methodologie editoriale et standards de verification de Valeurs Africaines.")


@bp.route("/politique-correction")
def correction_policy():
    return render_template("correction_policy.html", meta_description="Politique de correction et droit de signalement de Valeurs Africaines.")


@bp.route("/newsletter")
def newsletter():
    substack_url = os.getenv("SUBSTACK_URL", "").strip()
    return render_template(
        "newsletter.html",
        substack_url=substack_url,
        consent_text=NEWSLETTER_CONSENT_TEXT,
        form_version=NEWSLETTER_FORM_VERSION,
        meta_description="Inscription a la newsletter geopolitique hebdomadaire de Valeurs Africaines.",
    )


@bp.route("/politique-confidentialite")
def privacy():
    return render_template(
        "privacy.html",
        meta_description="Politique de confidentialite de Valeurs Africaines (donnees newsletter).",
    )


@bp.route("/newsletter/subscribe", methods=["POST"])
def newsletter_subscribe():
    # Anti-spam : max 5 inscriptions / 10 min / IP
    if _rate_limited("newsletter", 5, 600):
        flash("Trop de tentatives d'inscription. Reessayez dans quelques minutes.")
        return redirect(request.referrer or url_for("main.newsletter"))

    email = request.form.get("email", "").strip().lower()
    consent = request.form.get("consent", "")
    if "@" not in email:
        flash("Adresse e-mail invalide.")
        return redirect(request.referrer or url_for("main.newsletter"))

    # Consentement explicite obligatoire (case non pré-cochée)
    if consent != "on":
        flash("Consentement requis : cochez la case pour recevoir la newsletter.")
        return redirect(request.referrer or url_for("main.newsletter"))

    # Journalisation RGPD : IP + page source + version du formulaire
    ip = request.headers.get("X-Forwarded-For", "").split(",")[0].strip() or request.remote_addr or ""
    source_page = (request.referrer or "").split("?")[0] or "/newsletter"
    ok, reason = add_subscriber(
        email,
        consent_text=NEWSLETTER_CONSENT_TEXT,
        form_version=NEWSLETTER_FORM_VERSION,
        source_page=source_page,
        ip=ip,
        # Double opt-in : nouvelle inscription toujours en 'pending'
        status="pending",
    )
    if not ok:
        if reason == "duplicate":
            flash("Adresse deja inscrite.")
        else:
            flash("Adresse e-mail invalide.")
        return redirect(request.referrer or url_for("main.newsletter"))

    # Envoi (ou préparation) de l'email de confirmation — jamais bloquant
    confirm_url = url_for(
        "main.newsletter_confirm",
        email=email,
        token=make_newsletter_token(email, "confirm"),
        _external=True,
    )
    sent, send_reason = send_confirmation_email(email, confirm_url)
    if sent:
        flash("Inscription enregistree. Un email de confirmation vient de vous etre envoye : cliquez sur le lien pour activer votre abonnement.")
    else:
        if send_reason == "confirmation_email_not_configured":
            flash("Inscription enregistree. Un email de confirmation devra etre envoye pour activer l'abonnement.")
        else:
            flash("Inscription enregistree. L'envoi de l'email de confirmation est temporairement indisponible ; il sera relance.")
    return redirect(request.referrer or url_for("main.newsletter"))


@bp.route("/newsletter/confirm")
def newsletter_confirm():
    """Double opt-in : lien de confirmation reçu par email (token HMAC).
    pending -> confirmed. confirmed reste confirmé si le lien est recliqué.
    unsubscribed n'est PAS réactivé par ce lien (nouvelle inscription requise).
    """
    email = request.args.get("email", "").strip().lower()
    token = request.args.get("token", "").strip()
    meta = "Confirmation d'inscription a la newsletter."
    if not email or not check_newsletter_token(email, "confirm", token):
        return render_template("newsletter_confirm.html", ok=False, meta_description=meta)
    subscriber = find_subscriber(email)
    if subscriber is None:
        return render_template("newsletter_confirm.html", ok=False, meta_description=meta)
    status = subscriber["status"]
    if status == "unsubscribed":
        # Jamais de réactivation automatique après désinscription
        return render_template("newsletter_confirm.html", ok=False, meta_description=meta)
    if status == "confirmed":
        ok = True
    else:
        # pending ou legacy -> confirmed (confirmation explicite)
        ok = set_subscriber_status(email, "confirmed")
        if ok:
            # Abonné actif : synchronisation vers la liste Brevo (non bloquant)
            subscribe_email(email)
    return render_template("newsletter_confirm.html", ok=ok, email=email, meta_description=meta)


@bp.route("/newsletter/unsubscribe")
def newsletter_unsubscribe():
    """Désinscription en 1 clic depuis un email (token HMAC), sans login."""
    email = request.args.get("email", "").strip().lower()
    token = request.args.get("token", "").strip()
    if not email or not check_newsletter_token(email, "unsubscribe", token):
        return render_template("newsletter_unsubscribed.html", ok=False, meta_description="Desinscription de la newsletter.")
    subscriber = find_subscriber(email)
    if subscriber is None:
        return render_template("newsletter_unsubscribed.html", ok=False, meta_description="Desinscription de la newsletter.")
    ok = set_subscriber_status(email, "unsubscribed")
    return render_template("newsletter_unsubscribed.html", ok=ok, email=email, meta_description="Desinscription de la newsletter.")


def newsletter_links(email: str) -> dict:
    """Génère les liens signés confirm/unsubscribe pour un email donné.
    Usage : insertion dans chaque newsletter envoyée (footer notamment).
    """
    return {
        "confirm": url_for("main.newsletter_confirm", email=email,
                           token=make_newsletter_token(email, "confirm"), _external=True),
        "unsubscribe": url_for("main.newsletter_unsubscribe", email=email,
                               token=make_newsletter_token(email, "unsubscribe"), _external=True),
    }


@bp.route("/contact")
def contact():
    return render_template("contact.html", meta_description="Contacter la redaction de Valeurs Africaines.")


@bp.route("/mentions-legales")
def legal():
    return render_template("legal.html", meta_description="Mentions legales de Valeurs Africaines.")


@bp.route("/sitemap.xml")
def sitemap():
    base = request.url_root.rstrip("/")
    static_paths = ["", "/articles", "/editions", "/rubriques", "/base-connaissances", "/produits-speciaux", "/signaux-faibles", "/mediatheque", "/a-propos", "/methodologie", "/politique-correction", "/newsletter", "/politique-confidentialite", "/contact", "/mentions-legales"]
    article_paths = [f"/articles/{row['slug']}" for row in list_published()]
    edition_paths = [f"/editions/{row['slug']}" for row in list_editions()]
    all_paths = static_paths + edition_paths + article_paths

    xml = ['<?xml version="1.0" encoding="UTF-8"?>', '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">']
    for p in all_paths:
        xml.append("  <url>")
        xml.append(f"    <loc>{base}{p}</loc>")
        xml.append("  </url>")
    xml.append("</urlset>")
    return Response("\n".join(xml), mimetype="application/xml")


@bp.route("/feed.xml")
def feed():
    """Flux RSS 2.0 des articles publiés (diffusion, agrégateurs, lecteurs)."""
    base = request.url_root.rstrip("/")
    rows = [r for r in list_published() if r.get("published_at") or r.get("scheduled_at")]
    rows.sort(key=lambda r: r.get("published_at") or r.get("scheduled_at") or "", reverse=True)
    rows = rows[:20]

    def fmt_date(value: str) -> str:
        try:
            dt = date.fromisoformat(value[:10])
        except Exception:
            return ""
        return format_datetime(datetime.combine(dt, datetime.min.time(), tzinfo=timezone.utc), usegmt=True)

    xml = ['<?xml version="1.0" encoding="UTF-8"?>',
           '<rss version="2.0"><channel>',
           "<title>Valeurs Africaines</title>",
           f"<link>{base}</link>",
           "<description>Analyses geopolitiques, signaux faibles et rapports de force africains.</description>",
           "<language>fr</language>"]
    for row in rows:
        pub = fmt_date(str(row.get("published_at") or ""))
        url = f"{base}/articles/{row['slug']}"
        xml.append("<item>")
        xml.append(f"<title>{escape(row['title'])}</title>")
        xml.append(f"<link>{url}</link>")
        xml.append(f"<guid isPermaLink=\"true\">{url}</guid>")
        xml.append(f"<description>{escape(row.get('excerpt') or '')}</description>")
        if pub:
            xml.append(f"<pubDate>{pub}</pubDate>")
        xml.append("</item>")
    xml.append("</channel></rss>")
    return Response("\n".join(xml), mimetype="application/rss+xml")


@bp.route("/admin/login", methods=["GET", "POST"])
def admin_login():
    if request.method == "POST":
        # Anti-spam : max 10 tentatives / 10 min / IP
        if _rate_limited("admin-login", 10, 600):
            flash("Trop de tentatives de connexion. Reessayez dans quelques minutes.")
            return render_template("admin_login.html", meta_description="Connexion administration.")
        password = request.form.get("password", "")
        expected = os.getenv("VA_ADMIN_PASSWORD", "")
        if not expected or expected in {"change-me", "va-admin-2026"}:
            flash("Connexion admin désactivée: configurez VA_ADMIN_PASSWORD.")
            return render_template("admin_login.html", meta_description="Connexion administration.")
        if password == expected:
            session["admin_ok"] = True
            return redirect(url_for("main.admin"))
        flash("Mot de passe incorrect.")
    return render_template("admin_login.html", meta_description="Connexion administration.")


@bp.route("/admin/logout")
def admin_logout():
    session.pop("admin_ok", None)
    return redirect(url_for("main.admin_login"))


@bp.route("/admin", methods=["GET", "POST"])
def admin():
    if not _admin_allowed():
        return redirect(url_for("main.admin_login"))

    if request.method == "POST":
        rubrique = request.form.get("rubrique", "").strip()
        title = request.form.get("title", "").strip()
        excerpt = request.form.get("excerpt", "").strip()
        body = request.form.get("body", "").strip()
        reading_time = request.form.get("reading_time", "6 min de lecture").strip()
        author = request.form.get("author", "Redaction VA").strip()
        country = request.form.get("country", "").strip() or None
        theme = request.form.get("theme", "").strip() or None
        format_label = request.form.get("format_label", "").strip() or None
        strategic_question = request.form.get("strategic_question", "").strip() or None
        methodology = _editorial_methodology_from_form(request.form)
        key_points = _lines_from_form("key_points")
        implications = _lines_from_form("implications")
        limitations = request.form.get("limitations", "").strip() or None
        confidence_level = request.form.get("confidence_level", "").strip() or None
        edition_slug = request.form.get("edition_slug", "").strip() or None
        scheduled_at = request.form.get("scheduled_at", "").strip() or None
        sources_raw = request.form.get("sources", "").strip()
        sources = [line.strip() for line in sources_raw.splitlines() if line.strip()]
        tags = [item.strip() for item in request.form.get("tags", "").split(",") if item.strip()]

        if rubrique and title and excerpt and body and reading_time and sources:
            create_article(
                rubrique,
                title,
                excerpt,
                body,
                reading_time,
                author=author or "Redaction VA",
                scheduled_at=scheduled_at,
                sources=sources,
                country=country,
                theme=theme,
                format_label=format_label,
                strategic_question=strategic_question,
                methodology=methodology,
                key_points=key_points,
                implications=implications,
                limitations=limitations,
                confidence_level=confidence_level,
                edition_slug=edition_slug,
                tags=tags,
            )
            flash("Article cree en brouillon.")
            return redirect(url_for("main.admin"))
        flash("Tous les champs sont obligatoires, y compris les sources.")

    rows = list_articles()
    return render_template(
        "admin.html",
        rows=rows,
        editions=list_editions(),
        kpi=_kpi_snapshot(),
        top_viewed=most_viewed(5),
        meta_description="Back-office Valeurs Africaines.",
    )


def _lines_from_form(field_name: str) -> list[str]:
    return [line.strip() for line in request.form.get(field_name, "").splitlines() if line.strip()]


def _editorial_methodology_from_form(form) -> dict:
    fields = {
        "question": form.get("method_question", "").strip(),
        "scope": form.get("method_scope", "").strip(),
        "period": form.get("method_period", "").strip(),
        "sources": form.get("method_sources", "").strip(),
        "assumptions": form.get("method_assumptions", "").strip(),
        "limits": form.get("method_limits", "").strip(),
    }
    return {key: value for key, value in fields.items() if value}


@bp.route("/admin/verified-draft", methods=["POST"])
def create_verified_draft():
    if not _admin_allowed():
        return redirect(url_for("main.admin_login"))

    rubrique = request.form.get("rubrique", "").strip()
    title = request.form.get("title", "").strip()
    actor = request.form.get("actor", "").strip()
    agenda = request.form.get("agenda", "").strip()
    evidence = request.form.get("evidence", "").strip()
    contradiction = request.form.get("contradiction", "").strip()
    consequence = request.form.get("consequence", "").strip()
    angle = request.form.get("angle", "").strip()
    reading_time = request.form.get("reading_time", "7 min de lecture").strip()
    author = request.form.get("author", "Redaction VA").strip()
    country = request.form.get("country", "").strip() or None
    theme = request.form.get("theme", "").strip() or None
    format_label = request.form.get("format_label", "").strip() or "Brief strategique"
    strategic_question = request.form.get("strategic_question", "").strip() or title
    methodology = _editorial_methodology_from_form(request.form)
    key_points = _lines_from_form("key_points")
    implications = _lines_from_form("implications")
    limitations = request.form.get("limitations", "").strip() or None
    confidence_level = request.form.get("confidence_level", "").strip() or None
    edition_slug = request.form.get("edition_slug", "").strip() or None
    scheduled_at = request.form.get("scheduled_at", "").strip() or None
    sources_raw = request.form.get("sources", "").strip()
    sources = [line.strip() for line in sources_raw.splitlines() if line.strip()]
    tags = [item.strip() for item in request.form.get("tags", "").split(",") if item.strip()]

    if not all([rubrique, title, actor, agenda, evidence, contradiction, consequence, angle]) or not sources:
        flash("Filtre qualite incomplet: tous les champs sont obligatoires.")
        return redirect(url_for("main.admin"))

    excerpt = f"{angle} Acteur: {actor}. Consequence geopolitique: {consequence}"
    body = (
        "Pipeline editorial: Collecte -> Tri -> Verification -> Angle -> Redaction\n\n"
        "Filtre qualite (double verification requise avant publication)\n"
        f"- Qui parle ? (acteur): {actor}\n"
        f"- Quel interet ? (agenda): {agenda}\n"
        f"- Quelle preuve ? (document/donnee/citation): {evidence}\n"
        f"- Quelle contradiction ? (contre-source): {contradiction}\n"
        f"- Quelle consequence geopolitique ? {consequence}\n\n"
        f"Angle editorial propose:\n{angle}\n"
    )
    create_article(
        rubrique,
        title,
        excerpt,
        body,
        reading_time,
        author=author or "Redaction VA",
        scheduled_at=scheduled_at,
        sources=sources,
        country=country,
        theme=theme,
        format_label=format_label,
        strategic_question=strategic_question,
        methodology=methodology,
        key_points=key_points,
        implications=implications,
        limitations=limitations,
        confidence_level=confidence_level,
        edition_slug=edition_slug,
        tags=tags,
    )
    flash("Sujet verifie transforme en brouillon.")
    return redirect(url_for("main.admin"))


@bp.route("/admin/newsletter-subscribers.csv")
def export_subscribers_csv():
    if not _admin_allowed():
        return redirect(url_for("main.admin_login"))

    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(["email", "status", "consent", "consent_text", "form_version",
                     "source_page", "ip", "subscribed_at_utc", "confirmed_at_utc", "unsubscribed_at_utc"])
    for sub in list_subscribers():
        writer.writerow([
            sub.get("email", ""),
            sub.get("status", ""),
            "yes" if sub.get("consent") else "no",
            sub.get("consent_text", ""),
            sub.get("form_version", ""),
            sub.get("source_page", ""),
            sub.get("ip", ""),
            sub.get("subscribed_at_utc", ""),
            sub.get("confirmed_at_utc", "") or "",
            sub.get("unsubscribed_at_utc", "") or "",
        ])

    csv_data = output.getvalue()
    return Response(csv_data, mimetype="text/csv", headers={"Content-Disposition": "attachment; filename=newsletter-subscribers.csv"})


@bp.route("/admin/publish/<int:article_id>", methods=["POST"])
def publish_article(article_id: int):
    if not _admin_allowed():
        return redirect(url_for("main.admin_login"))
    article = next((r for r in list_articles() if r.get("id") == article_id), None)
    if not article or not article.get("sources"):
        flash("Publication bloquee: ajoutez les sources de l'article.")
        return redirect(url_for("main.admin"))
    set_published(article_id)
    return redirect(url_for("main.admin"))


@bp.route("/admin/feature/<int:article_id>", methods=["POST"])
def feature_article(article_id: int):
    if not _admin_allowed():
        return redirect(url_for("main.admin_login"))
    set_featured(article_id)
    return redirect(url_for("main.admin"))


@bp.route("/admin/schedule/<int:article_id>", methods=["POST"])
def schedule_article(article_id: int):
    if not _admin_allowed():
        return redirect(url_for("main.admin_login"))
    scheduled_at = request.form.get("scheduled_at", "").strip()
    if not scheduled_at:
        flash("Date de publication requise.")
        return redirect(url_for("main.admin"))
    set_scheduled(article_id, scheduled_at)
    flash("Article planifie.")
    return redirect(url_for("main.admin"))


@bp.route("/admin/preview/<slug>")
def admin_preview(slug: str):
    if not _admin_allowed():
        return redirect(url_for("main.admin_login"))
    article = get_any_article_by_slug(slug)
    if not article:
        abort(404)
    edition = get_edition_by_slug(article.get("edition_slug", "")) if article.get("edition_slug") else None
    return render_template("article_detail.html", article=article, edition=edition, meta_description=article.get("excerpt", "Preview article"))
