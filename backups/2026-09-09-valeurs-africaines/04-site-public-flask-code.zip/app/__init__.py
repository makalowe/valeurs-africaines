import os
import re
import secrets

from flask import Flask

from .data import init_store
from .taxonomy import taxonomy_context, slugify


def _configured_secret_key() -> str:
    configured = os.getenv("SECRET_KEY") or os.getenv("FLASK_SECRET_KEY") or ""
    weak_values = {"", "change-me", "change-me-with-a-secure-random-string", "va-dev-secret-change-me"}
    if configured.strip() in weak_values:
        return secrets.token_hex(32)
    return configured


_URL_PATTERN = re.compile(r"(https?://[^\s<>\"')]+)")


def linkify(value: str) -> str:
    """Rend les URLs d'un texte cliquables (liens externes, nouvel onglet)."""

    def _replace(match: re.Match[str]) -> str:
        url = match.group(1).rstrip(".,;:!?)]")
        return f'<a href="{url}" target="_blank" rel="noreferrer" class="source-link">{url}</a>'

    return _URL_PATTERN.sub(_replace, str(value))


def create_app() -> Flask:
    app = Flask(__name__)
    app.config["SECRET_KEY"] = _configured_secret_key()

    init_store()

    from .routes import bp as main_bp

    app.register_blueprint(main_bp)

    @app.context_processor
    def inject_taxonomy():
        return {"taxonomy": taxonomy_context(), "slugify": slugify}

    app.template_filter("linkify")(linkify)

    return app
