"""Stockage SQLite transactionnel, sans import Flask ni chargement de secrets.

Les objets éditoriaux gardent leurs champs JSON ; chaque élément est une ligne.
Cette première étape préserve les extensions de schéma sans perte de données.
"""
import json
import sqlite3
from contextlib import contextmanager
from contextvars import ContextVar
from pathlib import Path

_active = ContextVar("va_sqlite_transaction", default=None)
COLLECTIONS = ("articles", "subscribers", "editions")


def validate(payload):
    if not isinstance(payload, dict):
        raise ValueError("Le store doit être un objet")
    for key in COLLECTIONS:
        if key in payload and not isinstance(payload[key], list):
            raise ValueError("Collection invalide: " + key)
    if "articles" not in payload or "subscribers" not in payload:
        raise ValueError("Collections obligatoires absentes")
    ids = [a["id"] for a in payload["articles"]]
    if len(ids) != len(set(ids)):
        raise ValueError("Identifiants articles dupliqués")


class SQLiteStore:
    def __init__(self, path):
        self.path = Path(path).resolve()

    def connect(self):
        # mode=rw : une mauvaise configuration ne crée jamais une base vide.
        conn = sqlite3.connect(self.path.as_uri() + "?mode=rw", uri=True,
                               timeout=30, isolation_level=None)
        conn.execute("PRAGMA busy_timeout=30000")
        if conn.execute("PRAGMA user_version").fetchone()[0] != 1:
            conn.close()
            raise ValueError("Version SQLite VA inconnue")
        return conn

    @contextmanager
    def transaction(self):
        current = _active.get()
        if current is not None:
            if current[0] != self.path:
                raise RuntimeError("Transaction sur une autre base")
            yield
            return
        conn = self.connect()
        token = None
        try:
            conn.execute("BEGIN IMMEDIATE")
            token = _active.set((self.path, conn))
            yield
            conn.commit()
        except BaseException:
            conn.rollback()
            raise
        finally:
            if token is not None:
                _active.reset(token)
            conn.close()

    def load(self):
        current = _active.get()
        if current is not None:
            if current[0] != self.path:
                raise RuntimeError("Transaction sur une autre base")
            return self._read(current[1])
        conn = self.connect()
        try:
            conn.execute("BEGIN")
            return self._read(conn)
        finally:
            conn.rollback()
            conn.close()

    @staticmethod
    def _read(conn):
        payload = {key: json.loads(value) for key, value in
                   conn.execute("SELECT key,value FROM fields")}
        for key in COLLECTIONS:
            if key in payload:
                payload[key] = [json.loads(row[0]) for row in conn.execute(
                    "SELECT value FROM records WHERE collection=? ORDER BY position", (key,))]
        return payload

    def save(self, payload):
        current = _active.get()
        if current is None or current[0] != self.path:
            raise RuntimeError("Écriture SQLite hors transaction interdite")
        validate(payload)
        conn = current[1]
        conn.execute("DELETE FROM records")
        conn.execute("DELETE FROM fields")
        for key, value in payload.items():
            conn.execute("INSERT INTO fields VALUES (?,?)", (
                key, json.dumps([] if key in COLLECTIONS else value, ensure_ascii=False)))
            if key in COLLECTIONS:
                conn.executemany("INSERT INTO records VALUES (?,?,?)", (
                    (key, i, json.dumps(row, ensure_ascii=False)) for i, row in enumerate(value)))


def migrate(source, target):
    """Import explicite, sans écrasement ; source JSON laissée intacte."""
    source, target = Path(source), Path(target)
    payload = json.loads(source.read_text(encoding="utf-8"))
    validate(payload)
    # Réserver exclusivement le chemin ; ne jamais écraser une base existante.
    with target.open("xb"):
        pass
    target.chmod(0o600)
    try:
        with sqlite3.connect(target) as conn:
            conn.executescript("""
                CREATE TABLE fields(key TEXT PRIMARY KEY, value TEXT NOT NULL);
                CREATE TABLE records(collection TEXT NOT NULL, position INTEGER NOT NULL,
                    value TEXT NOT NULL, PRIMARY KEY(collection,position));
                PRAGMA user_version=1;
            """)
        store = SQLiteStore(target)
        with store.transaction():
            store.save(payload)
        if store.load() != payload:
            raise ValueError("Comparaison complète après import échouée")
        return {key: len(payload.get(key, [])) for key in COLLECTIONS}
    except BaseException:
        # Seul le fichier créé exclusivement par cet appel peut être supprimé.
        target.unlink(missing_ok=True)
        raise


def export_json(database, destination):
    payload = SQLiteStore(database).load()
    with Path(destination).open("x", encoding="utf-8") as f:
        json.dump(payload, f, ensure_ascii=False, indent=2)
    Path(destination).chmod(0o600)


def backup_database(database, destination):
    """Copie cohérente via l'API SQLite, même avec des écritures en cours."""
    destination = Path(destination)
    with destination.open("xb"):
        pass
    destination.chmod(0o600)
    source = SQLiteStore(database).connect()
    try:
        with sqlite3.connect(destination) as target:
            source.backup(target)
            if target.execute("PRAGMA integrity_check").fetchone()[0] != "ok":
                raise ValueError("Sauvegarde SQLite invalide")
    finally:
        source.close()
