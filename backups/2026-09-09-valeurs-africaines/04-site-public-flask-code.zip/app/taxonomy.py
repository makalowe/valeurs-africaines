import re
import unicodedata


def slugify(value: str) -> str:
    normalized = unicodedata.normalize("NFKD", value).encode("ascii", "ignore").decode("ascii")
    lowered = normalized.lower()
    return re.sub(r"[^a-z0-9]+", "-", lowered).strip("-") or "section"


DAILY_SUBRUBRIQUES = [
    {
        "name": "Actualité stratégique",
        "items": ["Événement majeur du jour", "Décision politique", "Diplomatie", "Relations internationales"],
    },
    {
        "name": "Économie, sécurité et diplomatie",
        "items": ["Économie", "Commerce", "Investissements", "Sécurité", "Défense", "Diplomatie"],
    },
    {
        "name": "Innovation, gouvernance, culture et médias",
        "items": ["Innovation", "Technologie", "Gouvernance", "Culture", "Médias", "Souveraineté narrative"],
    },
]

WEEKLY_FORMATS = [
    "Éditorial",
    "Research Brief",
    "Note Pays",
    "Infographie / Carte",
    "Signaux faibles",
]

RESEARCH_BRIEF_THEMES = [
    "Géopolitique & Diplomatie",
    "Économie & Développement",
    "Sécurité & Défense",
    "Technologie & Souveraineté numérique",
    "Gouvernance & Politiques publiques",
]

THEMATIC_RUBRIQUES = [
    {
        "name": "Géopolitique & Diplomatie",
        "themes": ["Union africaine", "CEDEAO", "SADC", "EAC", "BRICS", "ONU", "Chine", "États-Unis", "Europe", "Russie", "Turquie", "Inde", "Golfe"],
    },
    {
        "name": "Maghreb",
        "themes": ["Maroc", "Algérie", "Tunisie", "Libye", "Mauritanie", "Sahara occidental", "Méditerranée", "Lifestyle"],
    },
    {
        "name": "Économie & Développement",
        "themes": ["ZLECAf", "Commerce intra-africain", "Monnaies", "Dette", "Industrie", "Agriculture", "Mines", "Énergie", "Infrastructures"],
    },
    {
        "name": "Sécurité & Défense",
        "themes": ["Sahel", "Corne de l'Afrique", "Golfe de Guinée", "Terrorisme", "Piraterie", "Maintien de la paix", "Industries de défense"],
    },
    {
        "name": "Technologie & Souveraineté numérique",
        "themes": ["Intelligence artificielle", "Cybersécurité", "Satellites", "Télécommunications", "Centres de données", "Gouvernance numérique"],
    },
    {
        "name": "Gouvernance & Politiques publiques",
        "themes": ["Réformes administratives", "Fiscalité", "Éducation", "Santé", "Énergie", "Décentralisation"],
    },
    {
        "name": "Entrepreneuriat & Innovation",
        "themes": ["Start-up", "Fintech", "AgriTech", "HealthTech", "Économie créative", "Investissement"],
    },
    {
        "name": "Culture, Mémoire & Identité",
        "themes": ["Histoire africaine", "Langues africaines", "Patrimoine", "Littérature", "Cinéma", "Musique", "Pensée africaine"],
    },
    {
        "name": "Diaspora & Influence internationale",
        "themes": ["Talents africains", "Investissements de la diaspora", "Réseaux d'influence", "Coopération scientifique", "Diplomatie de la diaspora"],
    },
    {
        "name": "Médias & Souveraineté narrative",
        "themes": ["Désinformation", "Fact-checking", "Géopolitique des médias", "Réseaux sociaux", "Production des récits", "Influence informationnelle"],
    },
]

KNOWLEDGE_BASE = [
    "Fiches Pays",
    "Fiches Organisations",
    "Fiches Acteurs",
    "Chronologies",
    "Cartes stratégiques",
    "Bibliothèque documentaire",
]

SPECIAL_PRODUCTS = [
    "Dossiers stratégiques",
    "Rapports trimestriels",
    "Atlas stratégique africain",
    "Académie Valeurs Africaines",
    "Observatoire géopolitique africain",
]

MAIN_RUBRIQUES = [
    "Aujourd'hui en Afrique",
    "Édition hebdomadaire",
    *[item["name"] for item in THEMATIC_RUBRIQUES],
    *KNOWLEDGE_BASE,
    *SPECIAL_PRODUCTS,
]

FORMAT_LABELS = [
    "Article quotidien",
    "Éditorial",
    "Research Brief",
    "Note Pays",
    "Infographie / Carte",
    "Signaux faibles",
    "Analyse",
    "Brief stratégique",
    "Dossier stratégique",
    "Rapport trimestriel",
]

NAV_ITEMS = [
    {"label": "Aujourd'hui en Afrique", "endpoint": "main.archive_section", "slug": slugify("Aujourd'hui en Afrique")},
    {"label": "Édition hebdomadaire", "endpoint": "main.editions"},
    {"label": "Rubriques", "endpoint": "main.rubriques"},
    {"label": "Base de connaissances", "endpoint": "main.knowledge_base"},
    {"label": "Produits spéciaux", "endpoint": "main.special_products"},
    {"label": "Articles", "endpoint": "main.articles"},
]


def _section(name: str, level: int, kind: str, children: list | None = None, themes: list | None = None) -> dict:
    return {
        "name": name,
        "slug": slugify(name),
        "level": level,
        "kind": kind,
        "children": children or [],
        "themes": themes or [],
    }


def editorial_structure() -> list[dict]:
    return [
        _section("Aujourd'hui en Afrique", 1, "actualite quotidienne", children=DAILY_SUBRUBRIQUES),
        _section("Édition hebdomadaire", 2, "analyse hebdomadaire", children=[{"name": item, "items": RESEARCH_BRIEF_THEMES if item == "Research Brief" else []} for item in WEEKLY_FORMATS]),
        _section("Grandes rubriques thématiques", 3, "rubriques", children=THEMATIC_RUBRIQUES),
        _section("Base de connaissances", 4, "documentation", children=[{"name": item, "items": []} for item in KNOWLEDGE_BASE]),
        _section("Produits spéciaux", 5, "produits", children=[{"name": item, "items": []} for item in SPECIAL_PRODUCTS]),
    ]


def archive_sections() -> list[dict]:
    sections = [
        _section("Aujourd'hui en Afrique", 1, "actualite quotidienne", children=DAILY_SUBRUBRIQUES),
        _section("Édition hebdomadaire", 2, "analyse hebdomadaire", children=[{"name": item, "items": RESEARCH_BRIEF_THEMES if item == "Research Brief" else []} for item in WEEKLY_FORMATS]),
    ]
    sections += [_section(item["name"], 3, "rubrique thematique", themes=item["themes"]) for item in THEMATIC_RUBRIQUES]
    sections += [_section(item, 4, "base de connaissances") for item in KNOWLEDGE_BASE]
    sections += [_section(item, 5, "produit special") for item in SPECIAL_PRODUCTS]
    return sections


def section_by_slug(slug: str) -> dict | None:
    for section in archive_sections():
        if section["slug"] == slug:
            return section
    return None


def all_themes() -> list[str]:
    themes = []
    for group in DAILY_SUBRUBRIQUES:
        themes.extend(group["items"])
    themes.extend(RESEARCH_BRIEF_THEMES)
    for rubrique in THEMATIC_RUBRIQUES:
        themes.extend(rubrique["themes"])
    seen = set()
    ordered = []
    for theme in themes:
        if theme not in seen:
            ordered.append(theme)
            seen.add(theme)
    return ordered


def taxonomy_context() -> dict:
    return {
        "structure": editorial_structure(),
        "sections": archive_sections(),
        "main_rubriques": MAIN_RUBRIQUES,
        "themes": all_themes(),
        "formats": FORMAT_LABELS,
        "daily_subrubriques": DAILY_SUBRUBRIQUES,
        "weekly_formats": WEEKLY_FORMATS,
        "research_brief_themes": RESEARCH_BRIEF_THEMES,
        "nav_items": NAV_ITEMS,
    }
