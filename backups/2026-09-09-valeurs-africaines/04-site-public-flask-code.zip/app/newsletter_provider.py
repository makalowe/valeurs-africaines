# -*- coding: utf-8 -*-
import os
from typing import Tuple

import requests


BREVO_URL = "https://api.brevo.com/v3/contacts"
BREVO_SMTP_URL = "https://api.brevo.com/v3/smtp/email"
BREVO_SENDER_DEFAULT = "redaction@valeursafricaines.com"


def subscribe_email(email: str) -> Tuple[bool, str]:
    api_key = os.getenv("BREVO_API_KEY", "").strip()
    list_id = os.getenv("BREVO_LIST_ID", "").strip()

    if not api_key or not list_id:
        return False, "brevo_not_configured"

    headers = {
        "accept": "application/json",
        "api-key": api_key,
        "content-type": "application/json",
    }
    payload = {
        "email": email,
        "listIds": [int(list_id)],
        "updateEnabled": True,
    }

    resp = requests.post(BREVO_URL, headers=headers, json=payload, timeout=10)
    if resp.status_code in (200, 201, 204):
        return True, "ok"
    return False, f"brevo_error_{resp.status_code}"


def send_confirmation_email(email: str, confirm_url: str) -> Tuple[bool, str]:
    """Envoie l'email de confirmation (double opt-in) via Brevo.
    Retourne (ok, raison). Sans BREVO_API_KEY : confirmation_email_not_configured.
    L'inscription ne doit JAMAIS être bloquée par l'échec de cet envoi.
    """
    api_key = os.getenv("BREVO_API_KEY", "").strip()
    sender = os.getenv("BREVO_SENDER_EMAIL", "").strip() or BREVO_SENDER_DEFAULT
    if not api_key:
        return False, "confirmation_email_not_configured"

    headers = {
        "accept": "application/json",
        "api-key": api_key,
        "content-type": "application/json",
    }
    html = (
        "<p>Bonjour,</p>"
        "<p>Vous venez de vous inscrire a la newsletter hebdomadaire de "
        "<strong>Valeurs Africaines</strong>. Pour activer votre abonnement, "
        "confirmez votre adresse e-mail :</p>"
        f'<p style="text-align:center"><a href="{confirm_url}" '
        'style="background-color:#b08d3e;color:#ffffff;padding:12px 24px;'
        'text-decoration:none;border-radius:4px;display:inline-block">'
        "Confirmer mon inscription</a></p>"
        "<p>Si vous n'etes pas a l'origine de cette inscription, ignorez ce "
        "message : aucune newsletter ne vous sera envoyee.</p>"
        "<p>— Valeurs Africaines</p>"
    )
    payload = {
        "sender": {"name": "Valeurs Africaines", "email": sender},
        "to": [{"email": email}],
        "subject": "Confirmez votre inscription a la newsletter Valeurs Africaines",
        "htmlContent": html,
    }
    try:
        resp = requests.post(BREVO_SMTP_URL, headers=headers, json=payload, timeout=10)
    except requests.RequestException:
        return False, "confirmation_email_send_error"
    if resp.status_code in (200, 201, 202, 204):
        return True, "ok"
    return False, f"brevo_error_{resp.status_code}"
