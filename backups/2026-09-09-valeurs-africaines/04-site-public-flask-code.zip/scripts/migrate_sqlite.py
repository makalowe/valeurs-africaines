"""Outil local explicite ; ne charge ni Flask, ni .env, ni configuration privée."""
import argparse
import importlib.util
import json
from pathlib import Path

spec = importlib.util.spec_from_file_location(
    "va_sqlite", Path(__file__).resolve().parents[1] / "app/sqlite_store.py")
storage = importlib.util.module_from_spec(spec)
spec.loader.exec_module(storage)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("action", choices=["import", "export", "backup", "check"])
    parser.add_argument("source", type=Path)
    parser.add_argument("destination", nargs="?", type=Path)
    args = parser.parse_args()
    if args.action != "check" and args.destination is None:
        parser.error("destination obligatoire")
    if args.action == "import":
        counts = storage.migrate(args.source, args.destination)
    elif args.action == "export":
        storage.export_json(args.source, args.destination)
        counts = None
    elif args.action == "backup":
        storage.backup_database(args.source, args.destination)
        counts = None
    else:
        store = storage.SQLiteStore(args.source)
        conn = store.connect()
        try:
            if conn.execute("PRAGMA integrity_check").fetchone()[0] != "ok":
                raise ValueError("Intégrité SQLite invalide")
        finally:
            conn.close()
        payload = store.load()
        storage.validate(payload)
        counts = {key: len(payload.get(key, [])) for key in storage.COLLECTIONS}
    print(json.dumps({"result": "OK", "counts": counts}, ensure_ascii=False))


if __name__ == "__main__":
    main()
