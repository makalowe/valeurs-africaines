// Liste l'arborescence Google Drive VA (racine + sous-dossiers niveau 1)
const fs = require("fs");
const path = require("path");
const { google } = require("googleapis");

const envPath = path.join(process.cwd(), ".env.local");
function readEnv() {
  const vars = {};
  const raw = fs.readFileSync(envPath, "utf-8");
  for (const line of raw.split("\n")) {
    const match = line.match(/^([A-Z0-9_]+)=(.*)$/);
    if (!match) continue;
    let value = match[2].trim();
    if (value.startsWith('"') && value.endsWith('"')) value = value.slice(1, -1);
    vars[match[1]] = value;
  }
  return vars;
}

async function main() {
  const env = readEnv();
  const oauth = new google.auth.OAuth2({ clientId: env.GOOGLE_CLIENT_ID, clientSecret: env.GOOGLE_CLIENT_SECRET });
  oauth.setCredentials({ refresh_token: env.GOOGLE_REFRESH_TOKEN });
  const drive = google.drive({ version: "v3", auth: oauth });
  const rootId = env.GOOGLE_DRIVE_ROOT_FOLDER_ID;

  async function children(folderId) {
    const res = await drive.files.list({
      q: `'${folderId}' in parents and trashed=false`,
      fields: "files(id,name,mimeType)",
      pageSize: 200
    });
    return res.data.files ?? [];
  }

  const rootFiles = await children(rootId);
  console.log(`Racine "${rootId}" : ${rootFiles.length} élément(s)`);
  for (const file of rootFiles) {
    const kind = file.mimeType === "application/vnd.google-apps.folder" ? "[dossier]" : "[fichier]";
    console.log(`  ${kind} ${file.name}`);
    if (file.mimeType === "application/vnd.google-apps.folder") {
      const sub = await children(file.id);
      for (const item of sub) console.log(`      - ${item.name}`);
    }
  }
}
main().catch((error) => {
  console.error("Échec :", error.message);
  process.exit(1);
});
