import assert from "node:assert/strict";
import { readdirSync, readFileSync, statSync } from "node:fs";
import path from "node:path";

const root = process.cwd();
const sourceRoot = path.join(root, "src");
const forbidden = [
  /sk-[A-Za-z0-9_-]{20,}/,
  /GOOGLE_PRIVATE_KEY\s*=\s*["'][^-]/,
  /publication_automatique:\s*true/,
  /auto\s*publish/i
];

function walk(directory) {
  return readdirSync(directory).flatMap((entry) => {
    const fullPath = path.join(directory, entry);
    if (statSync(fullPath).isDirectory()) return walk(fullPath);
    return /\.(ts|tsx)$/.test(entry) ? [fullPath] : [];
  });
}

for (const file of walk(sourceRoot)) {
  const source = readFileSync(file, "utf8");
  for (const pattern of forbidden) {
    assert.equal(pattern.test(source), false, `Forbidden pattern ${pattern} found in ${path.relative(root, file)}`);
  }
}

console.log("Lint basic OK: no hardcoded API key pattern or automatic publication flag found.");
