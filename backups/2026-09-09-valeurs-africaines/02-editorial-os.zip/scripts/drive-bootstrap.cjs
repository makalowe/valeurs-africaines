// Bootstrap Google Drive : crée le dossier racine "Valeurs Africaines" (OAuth refresh token ou compte de service)
// et écrit GOOGLE_DRIVE_ROOT_FOLDER_ID dans .env.local. Usage : node scripts/drive-bootstrap.cjs
const fs = require("fs");
const path = require("path");
const { google } = require("googleapis");

const envPath = path.join(process.cwd(), ".env.local");

function readEnv() {
  const vars = {};
  const raw = fs.readFileSync(envPath, "utf-8");
  for (const line of raw.split("\n")) {
    const match = line.match(/^([A-Z0-9_]+)=(.*)$/);
    if (!match) continue;
    let value = match[2].trim();
    if (value.startsWith('"') && value.endsWith('"')) value = value.slice(1, -1);
    vars[match[1]] = value;
  }
  return vars;
}

async function buildAuth(env) {
  if (env.GOOGLE_CLIENT_ID && env.GOOGLE_CLIENT_SECRET && env.GOOGLE_REFRESH_TOKEN) {
    const oauth = new google.auth.OAuth2({ clientId: env.GOOGLE_CLIENT_ID, clientSecret: env.GOOGLE_CLIENT_SECRET });
    oauth.setCredentials({ refresh_token: env.GOOGLE_REFRESH_TOKEN });
    return oauth;
  }
  if (env.GOOGLE_SERVICE_ACCOUNT_EMAIL && env.GOOGLE_PRIVATE_KEY) {
    return new google.auth.JWT({
      email: env.GOOGLE_SERVICE_ACCOUNT_EMAIL,
      key: env.GOOGLE_PRIVATE_KEY.replace(/\\n/g, "\n"),
      scopes: ["https://www.googleapis.com/auth/drive"]
    });
  }
  throw new Error("Aucune authentification Google dans .env.local");
}

async function main() {
  const env = readEnv();
  const auth = await buildAuth(env);
  const drive = google.drive({ version: "v3", auth });

  // Dossier existant ?
  const existing = await drive.files.list({
    q: "name='Valeurs Africaines' and mimeType='application/vnd.google-apps.folder' and trashed=false",
    fields: "files(id,name)",
    spaces: "drive"
  });
  let folderId = existing.data.files?.[0]?.id ?? null;
  if (folderId) {
    console.log(`Dossier racine déjà présent : "Valeurs Africaines" (id=${folderId})`);
  } else {
    const response = await drive.files.create({
      requestBody: { name: "Valeurs Africaines", mimeType: "application/vnd.google-apps.folder" },
      fields: "id,name"
    });
    folderId = response.data.id;
    console.log(`Dossier créé : ${response.data.name} (id=${folderId})`);
  }

  const updated = fs.readFileSync(envPath, "utf-8").replace(/^GOOGLE_DRIVE_ROOT_FOLDER_ID=.*$/m, `GOOGLE_DRIVE_ROOT_FOLDER_ID=${folderId}`);
  fs.writeFileSync(envPath, updated, "utf-8");
  console.log("GOOGLE_DRIVE_ROOT_FOLDER_ID écrit dans .env.local");
}

main().catch((error) => {
  console.error("Échec du bootstrap Drive :", error.message);
  if (String(error.message).includes("Drive API")) {
    console.error("→ Vérifie que l'API Google Drive est activée sur le projet erika-492413.");
  }
  process.exit(1);
});
