const fs = require("fs");
const path = require("path");
const { google } = require("googleapis");

const envPath = path.join(process.cwd(), ".env.local");
const raw = fs.readFileSync(envPath, "utf-8");
function getVar(name) {
  const match = raw.match(new RegExp("^" + name + "=(.*)$", "m"));
  if (!match) return null;
  let value = match[1].trim();
  if (value.startsWith('"') && value.endsWith('"')) value = value.slice(1, -1);
  return value;
}

async function main() {
  const auth = new google.auth.JWT({
    email: getVar("GOOGLE_SERVICE_ACCOUNT_EMAIL"),
    key: (getVar("GOOGLE_PRIVATE_KEY") || "").replace(/\\n/g, "\n"),
    scopes: ["https://www.googleapis.com/auth/cloud-platform"]
  });
  const serviceUsage = google.serviceusage({ version: "v1", auth });
  try {
    const response = await serviceUsage.services.enable({ name: "projects/566985469173/services/drive.googleapis.com" });
    console.log("ACTIVÉ :", JSON.stringify(response.data).slice(0, 300));
  } catch (error) {
    console.log("ÉCHEC :", error.response ? `${error.response.status} ${error.response.data?.error?.message ?? ""}` : error.message);
  }
}
main();
