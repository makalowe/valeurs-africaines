// Consentement OAuth Google (voie B — sans clé de compte de service)
// 1) lit GOOGLE_CLIENT_ID/SECRET dans .env.local (ou credentials.json OAuth erika)
// 2) ouvre le navigateur pour l'autorisation eottsolutions (Drive + Sheets)
// 3) échange le code et écrit GOOGLE_REFRESH_TOKEN dans .env.local
// Usage : node scripts/oauth-consent.cjs
const fs = require("fs");
const path = require("path");
const http = require("http");
const { google } = require("googleapis");

const envPath = path.join(process.cwd(), ".env.local");
const CREDENTIALS_FALLBACK = path.join(process.cwd(), "..", "site-public-flask", "credentials.json");
const PORT = 8123;
const REDIRECT = `http://localhost:${PORT}/oauth2callback`;
const SCOPES = [
  "https://www.googleapis.com/auth/drive",
  "https://www.googleapis.com/auth/spreadsheets"
];

function readEnv(name) {
  const raw = fs.readFileSync(envPath, "utf-8");
  const match = raw.match(new RegExp("^" + name + "=(.*)$", "m"));
  return match ? match[1].trim().replace(/^"|"$/g, "") : null;
}

function writeEnv(name, value) {
  const raw = fs.readFileSync(envPath, "utf-8");
  const next = raw.match(new RegExp("^" + name + "=.*$", "m"))
    ? raw.replace(new RegExp("^" + name + "=.*$", "m"), `${name}=${value}`)
    : `${raw.replace(/\s*$/, "\n")}${name}=${value}\n`;
  fs.writeFileSync(envPath, next, "utf-8");
}

function loadClient() {
  let clientId = readEnv("GOOGLE_CLIENT_ID");
  let clientSecret = readEnv("GOOGLE_CLIENT_SECRET");
  if (!clientId && fs.existsSync(CREDENTIALS_FALLBACK)) {
    const installed = JSON.parse(fs.readFileSync(CREDENTIALS_FALLBACK, "utf-8")).installed;
    clientId = installed.client_id;
    clientSecret = installed.client_secret;
    writeEnv("GOOGLE_CLIENT_ID", clientId);
    writeEnv("GOOGLE_CLIENT_SECRET", clientSecret);
    console.log("Identifiants OAuth erika-492413 récupérés depuis credentials.json.");
  }
  if (!clientId || !clientSecret) throw new Error("GOOGLE_CLIENT_ID/SECRET introuvables.");
  return { clientId, clientSecret };
}

async function main() {
  const { clientId, clientSecret } = loadClient();
  const oauth = new google.auth.OAuth2({ clientId, clientSecret, redirectUri: REDIRECT });

  const url = oauth.generateAuthUrl({ access_type: "offline", prompt: "consent", scope: SCOPES });

  const server = http.createServer(async (req, res) => {
    const parsed = new URL(req.url, REDIRECT);
    if (parsed.pathname !== "/oauth2callback") {
      res.writeHead(404);
      res.end();
      return;
    }
    const code = parsed.searchParams.get("code");
    const error = parsed.searchParams.get("error");
    if (error || !code) {
      res.writeHead(400, { "Content-Type": "text/html; charset=utf-8" });
      res.end(`<h3>Autorisation refusée (${error ?? "code manquant"})</h3><p>Ferme cette page et réessaie.</p>`);
      server.close();
      process.exit(1);
      return;
    }
    try {
      const { tokens } = await oauth.getToken(code);
      if (!tokens.refresh_token) throw new Error("Aucun refresh_token reçu (autorisation déjà donnée ? supprime l'accès puis réessaie avec prompt=consent).");
      writeEnv("GOOGLE_REFRESH_TOKEN", tokens.refresh_token);
      res.writeHead(200, { "Content-Type": "text/html; charset=utf-8" });
      res.end("<h3>✅ Autorisation enregistrée — tu peux fermer cet onglet.</h3>");
      console.log("GOOGLE_REFRESH_TOKEN écrit dans .env.local");
      server.close();
      process.exit(0);
    } catch (err) {
      console.error("Échange du code échoué :", err.message);
      res.writeHead(500);
      res.end("Erreur.");
      server.close();
      process.exit(1);
    }
  });

  await new Promise((resolve) => server.listen(PORT, resolve));
  console.log("Serveur d'autorisation sur", REDIRECT);
  console.log("Ouverture du navigateur…");
  const open = require("child_process");
  if (process.platform === "win32") open.exec(`start "" "${url}"`);
  else if (process.platform === "darwin") open.exec(`open "${url}"`);
  else open.exec(`xdg-open "${url}"`);
}

main().catch((error) => {
  console.error("Échec :", error.message);
  process.exit(1);
});
