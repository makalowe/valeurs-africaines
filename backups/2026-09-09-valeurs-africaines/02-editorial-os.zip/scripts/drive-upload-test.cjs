// Test d'archivage réel : uploade un fichier markdown dans Drive (racine "Valeurs Africaines"/Articles)
// Usage : node scripts/drive-upload-test.cjs
const fs = require("fs");
const path = require("path");
const { google } = require("googleapis");

const envPath = path.join(process.cwd(), ".env.local");

function readEnv() {
  const vars = {};
  const raw = fs.readFileSync(envPath, "utf-8");
  for (const line of raw.split("\n")) {
    const match = line.match(/^([A-Z0-9_]+)=(.*)$/);
    if (!match) continue;
    let value = match[2].trim();
    if (value.startsWith('"') && value.endsWith('"')) value = value.slice(1, -1);
    vars[match[1]] = value;
  }
  return vars;
}

async function main() {
  const env = readEnv();
  if (!env.GOOGLE_CLIENT_ID || !env.GOOGLE_CLIENT_SECRET || !env.GOOGLE_REFRESH_TOKEN) {
    throw new Error("OAuth non configuré dans .env.local");
  }
  const oauth = new google.auth.OAuth2({ clientId: env.GOOGLE_CLIENT_ID, clientSecret: env.GOOGLE_CLIENT_SECRET });
  oauth.setCredentials({ refresh_token: env.GOOGLE_REFRESH_TOKEN });
  const drive = google.drive({ version: "v3", auth: oauth });

  const rootId = env.GOOGLE_DRIVE_ROOT_FOLDER_ID;
  if (!rootId) throw new Error("GOOGLE_DRIVE_ROOT_FOLDER_ID manquant");

  // 1. Dossier "Articles" sous la racine
  const list = await drive.files.list({
    q: `'${rootId}' in parents and name='Articles' and mimeType='application/vnd.google-apps.folder' and trashed=false`,
    fields: "files(id,name)"
  });
  let articlesId = list.data.files?.[0]?.id;
  if (!articlesId) {
    const created = await drive.files.create({
      requestBody: { name: "Articles", mimeType: "application/vnd.google-apps.folder", parents: [rootId] },
      fields: "id,name"
    });
    articlesId = created.data.id;
    console.log("Dossier 'Articles' créé.");
  }

  // 2. Upload du fichier de test
  const fileName = "TEST-archivage-2026-09-02.md";
  const content = `# TEST — archivage Valeurs Africaines\n\nVérification de l'archivage Google Drive (${new Date().toISOString()}).\n\n- Statut : opérationnel\n- Source : Editorial OS (OAuth eottsolutions)\n`;
  const uploaded = await drive.files.create({
    requestBody: { name: fileName, parents: [articlesId] },
    media: { mimeType: "text/markdown", body: content },
    fields: "id,name,webViewLink"
  });
  console.log(`Fichier archivé : ${uploaded.data.name}`);
  console.log(`ID : ${uploaded.data.id}`);
  console.log(`Lien : ${uploaded.data.webViewLink}`);
}

main().catch((error) => {
  console.error("Échec du test :", error.message);
  process.exit(1);
});
