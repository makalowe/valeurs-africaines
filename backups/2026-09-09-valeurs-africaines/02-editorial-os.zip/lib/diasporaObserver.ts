export * from "../src/lib/diasporaObserver";
