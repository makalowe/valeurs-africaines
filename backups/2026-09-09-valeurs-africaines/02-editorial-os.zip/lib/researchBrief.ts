export {
  africaImplications,
  buildExecutiveSummary,
  generateResearchBrief,
  identifyActors,
  monitoringPoints,
  riskAssessment,
  strategicAnalysis
} from "../src/lib/researchBrief";

export type { ResearchBrief, ResearchBriefInput } from "../src/lib/researchBrief";

