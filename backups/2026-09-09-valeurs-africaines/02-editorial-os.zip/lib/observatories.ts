export * from "../src/lib/observatories";
