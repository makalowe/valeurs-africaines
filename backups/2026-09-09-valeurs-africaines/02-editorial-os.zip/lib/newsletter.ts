export {
  buildEditorial,
  generateClosingNote,
  generateExecutiveInsights,
  generateNewsletter,
  summarizeArticles,
  summarizeBriefs,
  summarizeSignals
} from "../src/lib/newsletter";

export type { Newsletter, NewsletterInput } from "../src/lib/newsletter";

