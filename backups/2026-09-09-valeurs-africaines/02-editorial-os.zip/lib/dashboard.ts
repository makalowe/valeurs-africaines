export {
  getDashboardData,
  getDeadlines,
  getEditorialStats,
  getPriorityDistribution,
  getStatusDistribution
} from "../src/lib/dashboard";

export type {
  DashboardData,
  DeadlineStats,
  EditorialStats,
  PriorityDistribution,
  StatusDistribution
} from "../src/lib/dashboard";

