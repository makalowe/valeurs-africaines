export * from "../src/lib/sustainableEconomy";
