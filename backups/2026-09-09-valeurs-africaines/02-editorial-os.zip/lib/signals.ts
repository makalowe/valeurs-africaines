export {
  calculatePriority,
  classifySignal,
  collectSignals,
  generateWeakSignal
} from "../src/lib/signals";

export type {
  SignalImportance,
  SignalInput,
  WeakSignal
} from "../src/lib/signals";

