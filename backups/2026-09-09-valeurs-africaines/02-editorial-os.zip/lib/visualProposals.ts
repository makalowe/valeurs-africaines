export * from "../src/lib/visualProposals";
