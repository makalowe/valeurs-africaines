export {
  createKnowledgeRecord,
  getKnowledgeRecords
} from "../src/lib/knowledgeBase";

export type { KnowledgeRecord } from "../src/lib/knowledgeBase";
