export * from "../src/lib/africa2030";
