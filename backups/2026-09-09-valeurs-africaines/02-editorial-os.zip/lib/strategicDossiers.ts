export * from "../src/lib/strategicDossiers";
