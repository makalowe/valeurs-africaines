import assert from "node:assert/strict";
import { existsSync, readFileSync } from "node:fs";
import path from "node:path";
import test from "node:test";

const root = process.cwd();

function read(relativePath) {
  return readFileSync(path.join(root, relativePath), "utf8");
}

test("lecture planning: le module Google Sheets expose les fonctions attendues", () => {
  const source = read("src/lib/googleSheets.ts");
  assert.match(source, /export async function getPlanningRows/);
  assert.match(source, /export async function getPlanningRowById/);
  assert.match(source, /export async function updatePlanningStatus/);
});

test("génération brouillon: la route interne appelle la couche OpenAI serveur", () => {
  const source = read("src/app/api/generate-draft/route.ts");
  assert.match(source, /generateArticleDraft/);
  assert.match(source, /generateResearchBriefDraft/);
  assert.doesNotMatch(source, /NEXT_PUBLIC_OPENAI_API_KEY/);
});

test("validation humaine: la route impose une décision éditoriale", () => {
  const source = read("src/app/api/validate-content/route.ts");
  assert.match(source, /decision/);
  assert.match(source, /Validation humaine|Validé|approved/);
});

test("poste de pilotage quotidien: la publication locale exige 3 sujets retenus", () => {
  const page = read("src/app/comite-redaction/page.tsx");
  const route = read("src/app/api/publish/route.ts");
  const store = read("src/lib/siteStore.ts");
  assert.match(page, /retainedCount >= 3/);
  assert.match(page, /allSubjectsRetained: retainedCount >= 3/);
  assert.match(route, /hasThreeRetainedSubjects/);
  assert.match(route, /key\.startsWith\(`veille-\$\{date\}-`\)/);
  assert.match(store, /3 sujets retenus sont requis/);
  assert.match(store, /illustration validée ou décision « aucun visuel » requise/);
  assert.match(page, /visual\.decision === "validee" && visual\.file/);
  assert.match(store, /CLASSIFIED_ARTICLES_DIR/);
  assert.match(store, /findPublishableArticleFile/);
  assert.match(read("src/lib/editorialDashboardData.ts"), /readClassifiedArticleDrafts/);
});

test("archivage: l'archive alimente la base de connaissances et le Knowledge Hub", () => {
  const source = read("src/app/api/archive-content/route.ts");
  assert.match(source, /createKnowledgeRecord/);
  assert.match(source, /createKnowledgeEntry/);
  assert.match(source, /Content must be human validated/);
});

test("export Obsidian: le Knowledge Hub produit Markdown, YAML et liens internes", () => {
  const source = read("src/lib/knowledgeHub.ts");
  assert.match(source, /createKnowledgeEntry/);
  assert.match(source, /generateObsidianLinks/);
  assert.match(source, /---\\n/);
  assert.match(source, /titre:/);
  assert.match(source, /type:/);
  assert.match(source, /date:/);
  assert.match(source, /pays:/);
  assert.match(source, /region:/);
  assert.match(source, /observatoire:/);
  assert.match(source, /mots_cles:/);
  assert.match(source, /niveau_alerte:/);
  assert.match(source, /\[\[\$\{.*\}\]\]/);
});

test("knowledge hub: l'arborescence VAIS de reference existe", () => {
  const folders = [
    "knowledge-hub/conflits",
    "knowledge-hub/diaspora",
    "knowledge-hub/odd",
    "knowledge-hub/innovation",
    "knowledge-hub/chercheurs",
    "knowledge-hub/business",
    "knowledge-hub/ecologie",
    "knowledge-hub/souverainete-narrative",
    "knowledge-hub/pays",
    "knowledge-hub/organisations",
    "knowledge-hub/entreprises",
    "knowledge-hub/personnalites",
    "knowledge-hub/chronologies",
    "knowledge-hub/cartes",
    "knowledge-hub/visualisations",
    "knowledge-hub/research-briefs"
  ];

  for (const folder of folders) {
    assert.equal(existsSync(path.join(root, folder)), true, `${folder} should exist`);
  }
});

test("stabilisation v1: les pages principales existent", () => {
  const pages = [
    "src/app/afrique-2030/page.tsx",
    "src/app/conflits/page.tsx",
    "src/app/diaspora/page.tsx",
    "src/app/observatoires/page.tsx",
    "src/app/odd-agenda-2063/page.tsx",
    "src/app/radar/page.tsx",
    "src/app/atlas/page.tsx",
    "src/app/newsroom/page.tsx",
    "src/app/editorial-command-center/page.tsx",
    "src/app/dashboard/page.tsx",
    "src/app/planning/page.tsx",
    "src/app/generation/page.tsx",
    "src/app/validation/page.tsx",
    "src/app/veille/page.tsx",
    "src/app/special-rubriques/page.tsx",
    "src/app/business/page.tsx",
    "src/app/sustainable-economy/page.tsx",
    "src/app/portraits/page.tsx",
    "src/app/research-briefs/page.tsx",
    "src/app/think-tank/page.tsx",
    "src/app/newsletter/page.tsx",
    "src/app/visuals/page.tsx",
    "src/app/visual-selection/page.tsx",
    "src/app/knowledge/page.tsx",
    "src/app/search/page.tsx",
    "src/app/multicanal/page.tsx",
    "src/app/settings/page.tsx",
    "src/app/help/page.tsx"
  ];

  for (const page of pages) {
    assert.equal(existsSync(path.join(root, page)), true, `${page} should exist`);
  }
});

test("command center: le cockpit editorial et les dossiers strategiques existent", () => {
  const page = read("src/app/editorial-command-center/page.tsx");
  const dossiers = read("src/lib/strategicDossiers.ts");
  const metrics = read("src/lib/editorialMetrics.ts");

  assert.match(page, /Editorial Command Center/);
  assert.match(page, /Production éditoriale/);
  assert.match(page, /Couverture stratégique/);
  assert.match(page, /Carte Afrique/);
  assert.match(page, /Activité du Knowledge Hub/);
  assert.match(page, /Validation humaine/);
  assert.match(page, /Google Drive/);
  assert.match(dossiers, /Afrique & Souveraineté/);
  assert.match(dossiers, /Business & Industrie/);
  assert.match(dossiers, /Excellence Africaine/);
  assert.match(dossiers, /Écologie Durable/);
  assert.match(dossiers, /classifyCoverageStatus/);
  assert.match(metrics, /getPendingVisuals/);
  assert.match(metrics, /getEditorialAlerts/);
});

test("selection visuelle: trois propositions sont imposees avant validation finale", () => {
  const source = read("src/lib/visualProposals.ts");
  assert.match(source, /generatePhotoProposal/);
  assert.match(source, /generateIllustrationProposal/);
  assert.match(source, /generateChartOrDiagramProposal/);
  assert.match(source, /prompt_visuel/);
  assert.match(source, /date_selection/);
  assert.match(source, /Photo rights must be verified/);
  assert.match(source, /publication_automatique: false/);
});

test("rubriques speciales: les formats editoriaux differenciants sont disponibles", () => {
  const source = read("src/lib/specialRubriques.ts");
  assert.match(source, /elles-de-la-semaine/);
  assert.match(source, /entrepreneuriat-feminin/);
  assert.match(source, /souverainete-narrative/);
  assert.match(source, /publication_automatique: false/);
});

test("portraits: la rubrique savoirs africains encadre les profils sans invention", () => {
  const source = read("src/lib/portraits.ts");
  assert.match(source, /generateResearcherPortrait/);
  assert.match(source, /generateInnovatorPortrait/);
  assert.match(source, /generatePortraitVisualProposals/);
  assert.match(source, /Portrait de la semaine/);
  assert.match(source, /Option A - Portrait photographique professionnel/);
  assert.match(source, /Option B - Illustration éditoriale premium/);
  assert.match(source, /Option C - Infographie de carrière/);
  assert.match(source, /Ne mentionner aucun diplôme non sourcé|sans source vérifiée/);
  assert.match(source, /type: portrait/);
});

test("business: la rubrique entrepreneuriat analyse la creation de valeur sans publication automatique", () => {
  const source = read("src/lib/business.ts");
  assert.match(source, /Business Brief/);
  assert.match(source, /Comment créer davantage de richesse et de valeur en Afrique/);
  assert.match(source, /Ne pas inventer de chiffre d'affaires/);
  assert.match(source, /publication_automatique: false/);
});

test("ecologie durable: la rubrique distingue science, politiques publiques et opportunites", () => {
  const source = read("src/lib/sustainableEconomy.ts");
  assert.match(source, /Green Brief/);
  assert.match(source, /faits scientifiques/i);
  assert.match(source, /politiques publiques/i);
  assert.match(source, /impacts économiques/i);
  assert.match(source, /opportunités africaines/i);
  assert.match(source, /publication_automatique: false/);
});

test("afrique 2030: les ODD sont un fil rouge editorial sans remplacer l'analyse strategique", () => {
  const source = read("src/lib/africa2030.ts");
  const prompt = read("prompts/article-complet.md");
  assert.match(source, /Les engagements de développement sont-ils réellement appliqués/);
  assert.match(source, /impactsPositifs/);
  assert.match(source, /impactsNegatifs/);
  assert.match(source, /indicateursMesurables/);
  assert.match(source, /resultatsObservables/);
  assert.match(source, /Quel intérêt stratégique pour l'Afrique/);
  assert.match(source, /Quel impact sur la souveraineté/);
  assert.match(source, /Peut-on mesurer les résultats/);
  assert.match(source, /calculateImpactAfriqueScore/);
  assert.match(source, /Impact Afrique : XX \/ 50/);
  assert.match(source, /Éducation/);
  assert.match(source, /Gouvernance/);
  assert.match(source, /Climat/);
  assert.match(prompt, /Afrique 2030/);
  assert.match(prompt, /Impact Afrique : XX \/ 50/);
  assert.match(prompt, /Impact sur la souverainete/);
});

test("observatoire conflits: le module suit tensions, ODD et validation humaine", () => {
  const source = read("src/lib/conflictObserver.ts");
  assert.match(source, /getConflictZones/);
  assert.match(source, /classifyConflictLevel/);
  assert.match(source, /Effondrement critique/);
  assert.match(source, /donnée à vérifier/);
  assert.match(source, /ODD 16/);
  assert.match(source, /generateConflictVisualProposals/);
  assert.match(source, /Aucune publication automatique/);
});

test("centre observatoires: le hub regroupe les observatoires permanents", () => {
  const source = read("src/lib/observatories.ts");
  assert.match(source, /Observatoire des Conflits et de la Stabilité/);
  assert.match(source, /Observatoire de la Souveraineté africaine/);
  assert.match(source, /Observatoire Afrique–BRICS/);
  assert.match(source, /Observatoire ODD \/ Afrique 2030/);
  assert.match(source, /calculateObservatoryHealth/);
});

test("observatoire odd agenda 2063: les ODD et aspirations guident la couverture editoriale", async () => {
  const source = read("src/lib/sdgAgendaObserver.ts");
  const route = read("src/app/api/odd-agenda-2063/analyze/route.ts");
  const page = read("src/app/odd-agenda-2063/page.tsx");

  assert.match(source, /getAllSDGSheets/);
  assert.match(source, /getAgenda2063Aspirations/);
  assert.match(source, /analyzeArticleAgainstSDGAgenda/);
  assert.match(source, /ODD 14/);
  assert.match(source, /Aspiration 7/);
  assert.match(source, /publication_automatique: false/);
  assert.match(source, /validation_humaine_requise: true/);
  assert.match(route, /title or content is required/);
  assert.match(route, /validation_humaine_requise/);
  assert.match(page, /Observatoire ODD & Agenda 2063/);
  assert.match(page, /Carte Afrique/);
  assert.match(page, /Scores de couverture ODD/);
  assert.match(page, /Fil rouge éditorial/);
});

test("observatoire diaspora: le module suit le capital humain africain mondial sans invention", () => {
  const source = read("src/lib/diasporaObserver.ts");
  const route = read("src/app/api/diaspora/route.ts");
  const page = read("src/app/diaspora/page.tsx");

  assert.match(source, /getDiasporaProfiles/);
  assert.match(source, /classifyDiasporaProfile/);
  assert.match(source, /calculateDiasporaInfluenceScore/);
  assert.match(source, /detectDiasporaSignals/);
  assert.match(source, /generateDiasporaPortrait/);
  assert.match(source, /mapDiasporaNetworks/);
  assert.match(source, /identifyStrategicInstitutions/);
  assert.match(source, /generateDiasporaBrief/);
  assert.match(source, /exportDiasporaToKnowledgeHub/);
  assert.match(source, /Portrait photographique institutionnel/);
  assert.match(source, /Carte des flux diaspora Afrique/);
  assert.match(source, /Aucune publication automatique/);
  assert.match(route, /publication_automatique: false/);
  assert.match(page, /Observatoire de la Diaspora Africaine/);
  assert.match(page, /Cartographie mondiale de la diaspora/);
  assert.match(page, /Visuels obligatoires/);
});

test("boussole editoriale: le moteur score les sujets entrants selon la ligne VA", () => {
  const source = read("src/lib/editorialCompass.ts");
  assert.match(source, /interface EditorialScore/);
  assert.match(source, /evaluateAfricaImpact/);
  assert.match(source, /evaluateStrategicValue/);
  assert.match(source, /evaluateInnovationPotential/);
  assert.match(source, /evaluateConflictRisk/);
  assert.match(source, /evaluateBusinessImpact/);
  assert.match(source, /evaluateSDGImpact/);
  assert.match(source, /evaluateNarrativeInfluence/);
  assert.match(source, /Dossier stratégique/);
  assert.match(source, /Observatoire des conflits/);
  assert.match(source, /publication_automatique: false/);
});

test("radar afrique: le briefing quotidien classe les sujets strategiques", () => {
  const source = read("src/lib/radar.ts");
  assert.match(source, /scanSources/);
  assert.match(source, /classifyTopic/);
  assert.match(source, /detectWeakSignals/);
  assert.match(source, /detectStrategicAlerts/);
  assert.match(source, /generateMorningBrief/);
  assert.match(source, /top10Sujets/);
  assert.match(source, /publication_automatique: false/);
});

test("atlas afrique: les fiches pays restent extensibles et marquees a verifier", () => {
  const source = read("src/lib/atlas.ts");
  assert.match(source, /getCountryProfile/);
  assert.match(source, /compareCountries/);
  assert.match(source, /generateCountryBrief/);
  assert.match(source, /donnée à vérifier/);
  assert.match(source, /Agenda 2063/);
  assert.match(source, /Validation humaine obligatoire/);
});

test("strategic brief generator: le moteur central produit les formats VA", () => {
  const source = read("src/lib/brief-generator.ts");
  assert.match(source, /generateResearchBrief/);
  assert.match(source, /generateCountryNote/);
  assert.match(source, /generateStrategicDossier/);
  assert.match(source, /generateWeakSignalsReport/);
  assert.match(source, /generateConflictReport/);
  assert.match(source, /generateSDGProgressReport/);
  assert.match(source, /generateAgenda2063Report/);
  assert.match(source, /generateResearchPortrait/);
  assert.match(source, /generateBusinessAnalysis/);
  assert.match(source, /generateInnovationWatch/);
  assert.match(source, /Séparation faits \/ analyse/);
  assert.match(source, /citations_obligatoires/);
  assert.match(source, /publication_automatique: false/);
});

test("ai newsroom: le cockpit central expose production, alertes et validation", () => {
  const source = read("src/app/newsroom/page.tsx");
  assert.match(source, /Une Afrique en un coup d'œil/);
  assert.match(source, /File de publication/);
  assert.match(source, /Alertes prioritaires/);
  assert.match(source, /Carte d'Afrique interactive/);
  assert.match(source, /Centre de validation/);
  assert.match(source, /Aucune publication automatique/);
});

test("google drive archive: le Knowledge Hub peut archiver cote serveur sans exposer les cles", () => {
  const source = read("src/lib/googleDrive.ts");
  const route = read("src/app/api/drive/archive/route.ts");
  const env = read(".env.example");
  const docs = read("docs/google-drive-structure.md");
  assert.match(source, /ensureDriveFolderStructure/);
  assert.match(source, /Valeurs Africaines/);
  assert.match(source, /Observatoire Conflits/);
  assert.match(source, /Observatoire Diaspora/);
  assert.match(source, /Observatoire ODD/);
  assert.match(source, /Observatoire Innovation/);
  assert.match(source, /Observatoire Chercheurs/);
  assert.match(source, /Observatoire Business/);
  assert.match(source, /Observatoire Ecologie/);
  assert.match(source, /Observatoire Souveraineté Narrative/);
  assert.match(source, /Research Briefs/);
  assert.match(source, /Notes Pays/);
  assert.match(source, /Articles/);
  assert.match(source, /Cartes/);
  assert.match(source, /Infographies/);
  assert.match(source, /Données/);
  assert.match(source, /Archives/);
  assert.match(source, /uploadMarkdownToDrive/);
  assert.match(source, /archiveContentToDrive/);
  assert.match(source, /Drive archive requires human validation/);
  assert.match(source, /uniqueFileName/);
  assert.match(route, /validation_humaine/);
  assert.doesNotMatch(route, /NEXT_PUBLIC_GOOGLE/);
  assert.match(env, /GOOGLE_DRIVE_ROOT_FOLDER_ID/);
  assert.match(docs, /Drive\/Valeurs Africaines/);
});

test("vais: le prompt maitre encadre le systeme d'intelligence strategique", () => {
  const prompt = read("prompts/vais-master.md");
  const codexPrompt = read("prompts/codex-master-valeurs-africaines-v1.md");
  const docs = read("docs/vais.md");
  const schema = read("schemas/vais-frontmatter.schema.json");

  assert.match(prompt, /VALEURS AFRICAINES INTELLIGENCE SYSTEM/);
  assert.match(prompt, /Aucune donnée ne doit être inventée/);
  assert.match(prompt, /validation humaine/);
  assert.match(prompt, /Observatoire des Conflits Africains/);
  assert.match(prompt, /Observatoire de la Diaspora Africaine/);
  assert.match(prompt, /Observatoire du Développement Durable & ODD/);
  assert.match(prompt, /Observatoire de l'Innovation Africaine/);
  assert.match(prompt, /Observatoire des Chercheurs Africains/);
  assert.match(prompt, /Observatoire Business & Investissements/);
  assert.match(prompt, /Observatoire Écologie & Ressources/);
  assert.match(prompt, /Observatoire de la Souveraineté Narrative/);
  assert.match(prompt, /Research Brief/);
  assert.match(prompt, /Note Pays/);
  assert.match(prompt, /Signaux faibles/);
  assert.match(prompt, /Faits/);
  assert.match(prompt, /Analyse/);
  assert.match(prompt, /Hypothèses/);
  assert.match(prompt, /Scénarios/);
  assert.match(prompt, /Niveau 4 : critique/);
  assert.match(codexPrompt, /PROMPT CODEX MAITRE/);
  assert.match(codexPrompt, /Tu assistes la rédaction mais tu ne publies jamais directement/);
  assert.match(codexPrompt, /Plan stratégique UNICEF/);
  assert.match(codexPrompt, /Portrait d'excellence africaine/);
  assert.match(codexPrompt, /Choisissez le visuel 1, 2 ou 3/);
  assert.match(codexPrompt, /Workflow Obsidian/);
  assert.match(codexPrompt, /Workflow Google Drive/);
  assert.match(codexPrompt, /inventer des sources/);
  assert.match(docs, /prompts\/vais-master\.md/);
  assert.match(docs, /prompts\/codex-master-valeurs-africaines-v1\.md/);
  assert.match(docs, /titre:\ntype:\ndate:\npays:\nregion:\nobservatoire:\nmots_cles:\nacteurs:\nniveau_alerte:\nsources:/);
  assert.match(schema, /VAIS Knowledge Hub Frontmatter/);
});
