---
titre: "Template — Fiche de connaissance stratégique"
type: "reference"
date: "2026-06-13"
pays: []
region: "A verifier"
observatoire: "VAIS"
mots_cles: ["Knowledge Hub", "VAIS", "Obsidian", "RAG", "Knowledge Graph"]
acteurs: []
niveau_alerte: "A verifier"
sources: []
auteur: "Redaction Valeurs Africaines"
categorie: "Base de connaissances"
rubrique: "Knowledge Hub"
organisations: []
fiabilite: "A verifier"
validation_humaine: false
---

# Template — Fiche de connaissance stratégique

> Actif documentaire interne. Validation humaine requise avant integration definitive, publication ou reutilisation externe.

## 1. Fiche synthese

### Titre

Titre du contenu analyse.

### Type

Article / Research Brief / Note Pays / Signal Faible / Entretien / Dossier.

### Date

Date de creation ou de mise a jour.

### Resume executif

Resume en 5 a 10 lignes, sans fait invente.

## 2. Acteurs cles

| Acteur | Type | Role | Interets | Influence |
|---|---|---|---|---|
| Donnee a verifier | Etat / Organisation / Entreprise / Personnalite | A verifier | A verifier | Faible / Moyen / Eleve |

## 3. Thematiques associees

- Geopolitique
- Diplomatie
- Economie
- Energie
- Defense
- Technologie
- Gouvernance
- Medias
- Culture
- Souverainete numerique
- Souverainete narrative

## 4. Pays concernes

| Pays | Niveau d'implication |
|---|---|
| Donnee a verifier | Direct / Indirect |

## 5. Enjeux strategiques

### Enjeux economiques

Donnee a verifier.

### Enjeux geopolitiques

Donnee a verifier.

### Enjeux securitaires

Donnee a verifier.

### Enjeux technologiques

Donnee a verifier.

### Enjeux de gouvernance

Donnee a verifier.

### Enjeux narratifs

Donnee a verifier.

## 6. Faits cles

1. Donnee a verifier.
2. Donnee a verifier.
3. Donnee a verifier.
4. Donnee a verifier.
5. Donnee a verifier.

## 7. Chronologie

| Date | Evenement |
|---|---|
| Donnee a verifier | Donnee a verifier |

## 8. Consequences pour l'Afrique

### Court terme

Donnee a verifier.

### Moyen terme

Donnee a verifier.

### Long terme

Donnee a verifier.

## 9. Risques

| Risque | Probabilite | Impact |
|---|---|---|
| Donnee a verifier | Faible / Moyen / Eleve | Faible / Moyen / Eleve |

## 10. Opportunites

| Opportunite | Horizon |
|---|---|
| Donnee a verifier | Court / Moyen / Long terme |

## 11. Signaux a surveiller

- Signal a verifier.
- Signal a verifier.
- Signal a verifier.
- Signal a verifier.
- Signal a verifier.

## 12. Connexions avec la base

### Pays

- [[Pays]]

### Organisations

- [[Organisation]]

### Personnalites

- [[Nom]]

### Thematiques

- [[Theme]]

### Dossiers lies

- [[Titre]]

## 13. Mots-cles indexes

- Afrique
- Souverainete
- Diplomatie
- Economie
- Gouvernance

## 14. Metadonnees

| Champ | Valeur |
|---|---|
| Categorie | A verifier |
| Rubrique | A verifier |
| Region | A verifier |
| Niveau strategique | Faible / Moyen / Eleve |
| Sensibilite | Faible / Moyen / Eleve |
| Source principale | A verifier |
| Sources a verifier | A verifier |

## 15. Questions de recherche futures

1. Quels interets sont en jeu ?
2. Quels acteurs sont concernes ?
3. Quelles consequences pour l'Afrique ?
4. Quels effets de long terme sont plausibles ?
5. Quels indicateurs suivre ?
6. Quels acteurs emergent ?
7. Quels scenarios alternatifs sont possibles ?
8. Quelles sources independantes verifier ?

## Methode d'analyse

### Faits

Informations confirmees.

### Analyse

Interpretation argumentee.

### Hypotheses

Scenarios possibles.

### Incertitudes

Informations manquantes ou a verifier.
