---
title: "valeurs-africaines-editorial-os"
aliases: []
type: "concept"
status: "draft"
created: "2026-06-11"
updated: "2026-06-12"
source: ""
country: ""
region: ""
actors: []
themes: []
tags: ["#VAIS"]
confidence: "medium"
reviewed: false
---
# valeurs-africaines-editorial-os

Mini salle de rédaction IA pour **Valeurs Africaines**, magazine panafricain de géopolitique, stratégie, économie, gouvernance et souveraineté narrative.

Version cible : **1.0 utilisable en interne**.

## Fonctionnalités V1

- Dashboard éditorial exécutif.
- Planning connecté au Google Sheet éditorial.
- Génération de brouillons article / Research Brief.
- Validation humaine et archivage.
- Centre de veille stratégique.
- Agent Research Brief.
- Agent Newsletter.
- Cartographie & infographies.
- Knowledge Hub compatible Obsidian.
- Recherche documentaire RAG interne.
- Préparation multicanale LinkedIn, X, newsletter et Instagram.
- Pages Settings et Help.

## Règles non négociables

- Aucune publication automatique.
- Validation humaine obligatoire avant diffusion ou archivage.
- Aucune clé API en dur.
- Les clés restent dans `.env.local`.
- Les appels Google Sheets et OpenAI passent uniquement par les routes API serveur.
- Les sources doivent être conservées.
- Faits, analyses et hypothèses doivent être distingués.

## Installation

```bash
npm install
```

## Démarrage local

```bash
npm run dev
```

Application locale :

```text
http://localhost:3000
```

## Variables d'environnement

Créer un fichier `.env.local` à partir de `.env.example`.

```env
GOOGLE_SHEETS_ID=
GOOGLE_SERVICE_ACCOUNT_EMAIL=
GOOGLE_PRIVATE_KEY=
OPENAI_API_KEY=
OPENAI_MODEL=gpt-4.1-mini
```

Ne jamais committer `.env.local`.

## Workflow éditorial

```text
Planning
↓
Génération brouillon
↓
Recherche / vérification
↓
Validation humaine
↓
Archivage
↓
Knowledge Hub / RAG / multicanal
```

Le multicanal prépare uniquement des brouillons. La diffusion reste manuelle.

## Sécurité

- Les variables sensibles ne sont jamais exposées au frontend.
- La page Settings affiche seulement le statut configuré / non configuré.
- Les routes API valident les entrées.
- L'archivage et le multicanal refusent les contenus non validés humainement.
- Le RAG répond uniquement à partir du Knowledge Hub et cite les sources internes.

## Commandes

```bash
npm run dev
npm run build
npm run typecheck
npm run lint
npm test
```

## Tests de base

Les tests couvrent :

- lecture planning ;
- génération brouillon ;
- validation humaine ;
- archivage ;
- export Obsidian ;
- présence des pages principales V1.

## Limites connues

- Les brouillons générés doivent être relus et sourcés.
- Le RAG dépend du remplissage réel du `knowledge-hub/`.
- Les exports PDF côté navigateur utilisent l'impression HTML.
- La synchronisation Obsidian / GitHub reste une action explicite.
- Les connecteurs externes nécessitent des variables d'environnement valides.

## Documentation

- [Architecture](docs/architecture.md)
- [Workflow éditorial](docs/workflow-editorial.md)
- [Sécurité](docs/security.md)
- [Prompt rédacteur en chef](prompts/redacteur-en-chef.md)
- [Schéma planning](schemas/planning-row.schema.json)
