---
title: "Valeurs Africaines Intelligence System (VAIS)"
aliases: []
type: "concept"
status: "draft"
created: "2026-06-12"
updated: "2026-06-12"
source: ""
country: ""
region: ""
actors: []
themes: []
tags: ["#VAIS"]
confidence: "medium"
reviewed: false
---
# Valeurs Africaines Intelligence System (VAIS)

VAIS est le référentiel directeur du système d'intelligence stratégique de Valeurs Africaines.

Il coordonne les observatoires, la production éditoriale, les alertes, les formats de briefs et les règles méthodologiques du média.

## Rôle

VAIS agit comme un centre de veille stratégique permanent.

Il ne remplace pas la rédaction. Il structure la surveillance, l'analyse, l'archivage et la préparation des contenus.

## Observatoires couverts

- Observatoire des Conflits Africains
- Observatoire de la Diaspora Africaine
- Observatoire du Développement Durable & ODD
- Observatoire de l'Innovation Africaine
- Observatoire des Chercheurs Africains
- Observatoire Business & Investissements
- Observatoire Écologie & Ressources
- Observatoire de la Souveraineté Narrative

## Garde-fous

- Aucune donnée inventée.
- Aucune publication automatique.
- Validation humaine obligatoire.
- Sources à vérifier explicitement listées.
- Séparation stricte entre faits, analyses, hypothèses et scénarios.

## Usage dans l'application

Le prompt maître est stocké dans :

`prompts/vais-master.md`

Le prompt Codex maître orienté exécution projet est stocké dans :

`prompts/codex-master-valeurs-africaines-v1.md`

Il sert de base aux futurs agents d'analyse, à la génération de briefs, aux observatoires, au Radar Afrique et au Knowledge Hub.

## Question centrale

Chaque analyse doit répondre :

> Quels intérêts sont en jeu, quels acteurs sont concernés, quelles conséquences cela produit-il pour l'Afrique et comment ces évolutions s'inscrivent-elles dans le temps ?

## Formats structurants

- 3 articles quotidiens
- Research Brief
- Note Pays
- Signaux faibles
- Alertes stratégiques
- Fiches Knowledge Hub

## Frontmatter Knowledge Hub

Chaque fiche VAIS doit commencer par le frontmatter minimal suivant :

```yaml
---
titre:
type:
date:
pays:
region:
observatoire:
mots_cles:
acteurs:
niveau_alerte:
sources:
---
```

Le schéma de référence est stocké dans :

`schemas/vais-frontmatter.schema.json`

## Niveaux d'alerte

- Niveau 1 : faible
- Niveau 2 : moyen
- Niveau 3 : élevé
- Niveau 4 : critique

Déclencheurs principaux : conflit, coup d'État, crise sanitaire, catastrophe climatique, risque économique, rupture diplomatique, campagne de désinformation.
