---
title: "Architecture"
aliases: []
type: "concept"
status: "draft"
created: "2026-06-11"
updated: "2026-06-12"
source: ""
country: ""
region: ""
actors: []
themes: []
tags: ["#VAIS"]
confidence: "medium"
reviewed: false
---
# Architecture

## Vue d'ensemble

`valeurs-africaines-editorial-os` est l'outil interne de pilotage editorial de Valeurs Africaines.

L'application doit organiser le travail de redaction autour d'un planning actif, d'un assistant GPT, d'une validation humaine obligatoire et d'une base de connaissances durable.

## Composants cibles

```text
Utilisateur redaction
  |
  v
Application web Next.js
  |
  |-- Frontend React
  |     - dashboard
  |     - planning editorial
  |     - espace brouillons
  |     - validation humaine
  |     - base de connaissances
  |
  |-- Backend/API Next.js
        - lecture Google Sheet
        - orchestration GPT
        - gestion statuts
        - logs actions sensibles
        - export / archivage
```

## Modules

### 1. Mini-application web Next.js

Role :

- afficher le planning editorial ;
- filtrer les contenus ;
- ouvrir une fiche editoriale ;
- afficher les brouillons ;
- gerer les statuts ;
- preparer l'archivage.

Le frontend ne doit jamais recevoir de cle API.

### 2. Google Sheet editorial

Role cible :

- tableau actif de la redaction ;
- source de verite operationnelle du planning ;
- lignes identifiees par un ID editorial ;
- colonnes normalisees selon `schemas/planning-row.schema.json`.

La connexion n'est pas codee dans cette phase.

### 3. GPT "Redacteur en chef IA"

Role cible :

- generer un brouillon a partir d'une ligne editorialisee ;
- proposer une structure ;
- signaler les sources a verifier ;
- produire des formats reseaux sociaux ;
- ne jamais publier.

L'appel GPT doit etre effectue cote backend uniquement.

### 4. Couche API securisee

Role cible :

- exposer des routes internes ;
- lire le Google Sheet ;
- appeler le GPT ;
- appliquer les controles de statut ;
- journaliser les actions sensibles ;
- empecher toute publication automatique.

Exemples de futures routes :

```text
GET  /api/planning
GET  /api/planning/:id
POST /api/drafts
POST /api/validation/request
POST /api/archive
```

### 5. Validation humaine

Role :

- relire les brouillons ;
- verifier les faits ;
- verifier les sources ;
- approuver ou demander correction ;
- bloquer toute publication automatique.

### 6. Base de connaissances editoriale

Role :

- conserver les contenus valides ;
- alimenter fiches pays, fiches organisations, fiches acteurs ;
- alimenter chronologies, cartes strategiques et bibliotheque documentaire ;
- servir de memoire editoriale.

## Separation frontend/backend

Frontend :

- affichage ;
- filtres ;
- selection d'une ligne ;
- visualisation des brouillons ;
- actions utilisateur.

Backend :

- secrets ;
- API externes ;
- logique de validation ;
- logs sensibles ;
- orchestration GPT ;
- lecture Google Sheets.

## Donnees principales

Une ligne planning represente :

- ID editorial ;
- date ;
- rythme ;
- format ;
- titre ;
- angle ;
- rubrique ;
- pays / zone ;
- responsable ;
- statut ;
- sources ;
- formats sociaux ;
- cible base de connaissances.

## Statuts normalises

```text
idea -> drafting -> review -> validation -> approved -> archived
```

Regle :

`approved` ne signifie pas "publie". Cela signifie seulement "valide editorialement".

## Principes d'evolutivite

- Ajouter une integration dans `src/server` ou `src/lib/server` plus tard.
- Garder les schemas dans `schemas/`.
- Garder les prompts dans `prompts/`.
- Garder la logique editoriale dans des types et services separes.
- Eviter de coupler l'interface a Google Sheets directement.

