---
title: "Workflow editorial"
aliases: []
type: "concept"
status: "draft"
created: "2026-06-11"
updated: "2026-06-12"
source: ""
country: ""
region: ""
actors: []
themes: []
tags: ["#VAIS"]
confidence: "medium"
reviewed: false
---
# Workflow editorial

## Formule editoriale

Valeurs Africaines publie trois articles quotidiens et une edition strategique hebdomadaire structuree.

## Regle fondamentale

Aucune publication automatique.

Tout contenu doit passer par :

1. preparation ;
2. generation ou redaction ;
3. verification ;
4. validation humaine ;
5. archivage ;
6. publication manuelle eventuelle.

## Production quotidienne

Chaque jour, le planning doit prevoir trois articles.

### Article 1 - Actualite strategique

Contenu :

- evenement majeur du jour ;
- faits ;
- acteurs ;
- consequences pour l'Afrique.

### Article 2 - Economie, securite ou diplomatie

Contenu :

- decryptage ;
- interets en jeu ;
- rapport de force ;
- perspectives.

### Article 3 - Innovation, gouvernance, culture ou medias

Contenu :

- tendance emergente ;
- enjeu strategique ;
- impact potentiel.

## Edition hebdomadaire

Chaque semaine :

- 1 edito de la semaine ;
- 3 a 5 Research Briefs ;
- 1 Note pays ;
- 1 infographie ou carte ;
- 1 rubrique Signaux faibles ;
- 1 newsletter hebdomadaire.

## Flux operationnel cible

### 0. Veille strategique

Les signaux faibles alimentent les futurs sujets editoriaux.

Flux editorial cible :

```text
Veille -> Recherche -> Rédaction -> Validation -> Archivage
```

Flux Research Brief :

```text
Sujet -> Recherche -> Brief généré -> Validation humaine -> Archivage
```

Flux Newsletter :

```text
Articles + Research Briefs + Signaux faibles -> Newsletter générée -> Validation humaine -> Publication manuelle
```

Flux Cartographie & Infographies :

```text
Contenu -> Analyse structure -> Proposition visuels -> Validation humaine -> Archivage
```

Flux Selection visuelle avant validation finale :

```text
Article genere -> Relecture -> Propositions visuelles -> Choix humain du visuel -> Validation humaine -> Archivage -> Publication manuelle eventuelle
```

Regles :

- ne jamais publier sans choix visuel ou decision explicite `aucun visuel` ;
- ne jamais utiliser une photo sans verification des droits ;
- documenter le type de visuel, les droits verifies et la validation visuelle humaine ;
- les graphiques doivent reposer uniquement sur des donnees et sources verifiees.

Flux Knowledge Hub Obsidian :

```text
Article -> Validation humaine -> Knowledge Entry -> GitHub Commit -> Obsidian Sync
```

Le systeme cree des fiches Markdown natives avec metadonnees YAML, liens internes Obsidian et backlinks proposes. Le commit GitHub et la synchronisation Obsidian restent des actions explicites, jamais automatiques.

Flux RAG editorial :

```text
Question utilisateur -> Recherche semantique -> Top resultats -> Contexte injecte -> GPT -> Reponse citee
```

Le moteur RAG consulte uniquement le `knowledge-hub/`. Toute reponse editoriale doit citer les sources internes recuperees et signaler les informations absentes ou insuffisamment verifiees.

### 1. Creation de la ligne dans Google Sheet

La redaction cree une ligne avec :

- ID editorial ;
- format ;
- sujet ;
- angle ;
- rubrique ;
- responsable ;
- statut initial.

Statut recommande : `idea` ou `drafting`.

### 2. Lecture dans l'application

L'application Next.js recupere les lignes via la couche API securisee.

Le frontend affiche :

- le planning ;
- les statuts ;
- les priorites ;
- les filtres par format, rubrique, pays et statut.

### 3. Generation du brouillon

Depuis une ligne, l'utilisateur peut demander un brouillon.

Le backend :

- recupere la ligne ;
- construit le prompt ;
- appelle le GPT "Redacteur en chef IA" ;
- stocke ou retourne le brouillon ;
- marque l'action dans les logs.

Le GPT doit toujours signaler les sources a verifier.

### 4. Verification editoriale

La redaction verifie :

- faits ;
- dates ;
- chiffres ;
- citations ;
- sources ;
- distinction faits / analyses / hypotheses ;
- ton editorial.

Statut : `review`.

### 5. Validation humaine

Un humain autorise ou refuse le contenu.

L'interface doit afficher systematiquement :

```text
Article prêt.

Souhaitez-vous le valider ?

OUI / NON
```

Si la reponse est OUI, l'interface rappelle :

```text
Validation humaine requise avant publication finale.
```

Avant cette validation finale, le redacteur doit avoir traite la selection visuelle :

- `visuel_propose` : oui/non ;
- `visuel_choisi` : identifiant de proposition ou `aucun-visuel` ;
- `type_visuel` : photo, illustration, diagramme ou aucun ;
- `prompt_visuel` : prompt ou description du visuel retenu ;
- `date_selection` : date ISO de selection ;
- `droits_visuels_verifies` : obligatoire pour toute photo ;
- `validation_visuelle_humaine` : oui/non.

Statuts possibles :

- `validation` : en attente de validation ;
- `approved` : valide ;
- `drafting` : retour correction.

Important :

`approved` ne declenche aucune publication automatique.

### 6. Archivage

Un contenu valide peut alimenter :

- fiche pays ;
- fiche organisation ;
- fiche acteur ;
- chronologie ;
- carte strategique ;
- bibliotheque documentaire ;
- dossier strategique ;
- observatoire geopolitique.

Statut : `archived`.

## Statuts editoriaux normalises

| Statut | Sens | Action possible |
|---|---|---|
| `idea` | Idee creee | completer l'angle |
| `watch` | Veille | transformer un signal en sujet |
| `drafting` | A rediger | rediger ou generer un brouillon |
| `review` | A verifier | verifier faits et sources |
| `validation` | A valider | decision humaine |
| `approved` | Valide editorialement | archiver ou publier manuellement |
| `archived` | Archive dans la base | reutiliser comme connaissance |

## Logs requis

Les actions suivantes doivent etre journalisees dans une phase future :

- generation GPT ;
- changement de statut ;
- demande de validation ;
- validation ;
- archivage ;
- export ;
- tentative de publication.
