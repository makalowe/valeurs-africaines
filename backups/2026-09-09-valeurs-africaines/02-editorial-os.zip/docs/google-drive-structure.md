---
title: "Structure Google Drive — Valeurs Africaines"
aliases: []
type: "concept"
status: "draft"
created: "2026-06-12"
updated: "2026-06-12"
source: ""
country: ""
region: ""
actors: []
themes: []
tags: ["#VAIS"]
confidence: "medium"
reviewed: false
---
# Structure Google Drive — Valeurs Africaines

Le dossier racine Drive attendu est :

`Drive/Valeurs Africaines`

Arborescence cible :

```text
Drive/
└── Valeurs Africaines
    ├── Observatoire Conflits
    ├── Observatoire Diaspora
    ├── Observatoire ODD
    ├── Observatoire Innovation
    ├── Observatoire Chercheurs
    ├── Observatoire Business
    ├── Observatoire Ecologie
    ├── Observatoire Souveraineté Narrative
    ├── Research Briefs
    ├── Notes Pays
    ├── Articles
    ├── Cartes
    ├── Infographies
    ├── Données
    └── Archives
```

## Règles d'archivage

- Articles : `Valeurs Africaines/Articles/YYYY/MM`
- Research Briefs : `Valeurs Africaines/Research Briefs/YYYY/MM`
- Notes Pays : `Valeurs Africaines/Notes Pays/Pays`
- Observatoires : dossier observatoire correspondant, puis `YYYY/MM`
- Portraits et chercheurs : `Valeurs Africaines/Observatoire Chercheurs/YYYY`
- Business : `Valeurs Africaines/Observatoire Business/YYYY/MM`
- Ecologie : `Valeurs Africaines/Observatoire Ecologie/YYYY/MM`
- Visuels : `Valeurs Africaines/Infographies/YYYY/MM`
- Sources : `Valeurs Africaines/Données/Sources à vérifier`

## Sécurité

L'archivage Drive est uniquement serveur. Les clés Google ne sont jamais exposées côté client.

Toute archive exige une validation humaine préalable.
