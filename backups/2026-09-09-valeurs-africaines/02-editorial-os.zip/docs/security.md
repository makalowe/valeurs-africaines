---
title: "Securite"
aliases: []
type: "concept"
status: "draft"
created: "2026-06-11"
updated: "2026-06-12"
source: ""
country: ""
region: ""
actors: []
themes: []
tags: ["#VAIS"]
confidence: "medium"
reviewed: false
---
# Securite

## Objectif

Definir les regles de securite pour l'application redactionnelle IA de Valeurs Africaines.

## Principes non negociables

- Aucune cle API en clair.
- Variables d'environnement uniquement.
- Aucun secret cote frontend.
- Aucune publication automatique.
- Validation humaine obligatoire.
- Logs des actions sensibles.
- Separation frontend/backend.

## Gestion des secrets

Les secrets doivent etre stockes dans :

```text
.env.local
```

Ils ne doivent jamais etre commites.

Exemples de secrets futurs :

```env
GOOGLE_SHEETS_CLIENT_EMAIL=
GOOGLE_SHEETS_PRIVATE_KEY=
OPENAI_API_KEY=
```

Regles :

- ne jamais exposer ces variables avec le prefixe `NEXT_PUBLIC_` ;
- ne jamais les passer au navigateur ;
- ne jamais les afficher dans les logs ;
- ne jamais les copier dans README, tickets, captures d'ecran ou prompts.

## Separation frontend/backend

Frontend autorise :

- afficher les contenus ;
- filtrer le planning ;
- selectionner une ligne ;
- demander une generation ;
- demander une validation.

Frontend interdit :

- appeler OpenAI directement ;
- appeler Google Sheets directement ;
- contenir des cles ;
- publier automatiquement.

Backend autorise :

- lire les variables d'environnement ;
- appeler Google Sheets ;
- appeler OpenAI ;
- verifier les droits ;
- journaliser les actions ;
- appliquer les transitions de statuts.

## Publication

La publication automatique est interdite.

Le systeme peut preparer :

- brouillon ;
- export ;
- archive ;
- checklist de publication.

Il ne doit pas :

- publier sur un site ;
- envoyer une newsletter ;
- poster sur reseaux sociaux ;
- modifier un CMS public ;
- changer des permissions publiques.

## Validation humaine

Avant toute publication manuelle :

- verification des faits ;
- verification des sources ;
- verification des citations ;
- validation du ton ;
- validation du responsable editorial.

## Logs des actions sensibles

Actions a journaliser :

- connexion utilisateur ;
- lecture planning ;
- generation GPT ;
- changement de statut ;
- demande de validation ;
- approbation ;
- rejet ;
- archivage ;
- export ;
- tentative de publication.

Un log doit contenir :

- date ;
- utilisateur ;
- action ;
- ID editorial ;
- ancien statut ;
- nouveau statut ;
- resultat ;
- message d'erreur si applicable.

Un log ne doit jamais contenir :

- cle API ;
- token ;
- secret ;
- contenu prive non necessaire ;
- donnees personnelles sensibles non utiles.

## Statuts editoriaux securises

Transitions recommandees :

```text
idea -> drafting
drafting -> review
review -> validation
validation -> approved
approved -> archived
```

Transitions a bloquer :

```text
idea -> approved
drafting -> approved
review -> archived
validation -> archived
```

## Erreurs et garde-fous

En cas d'erreur API :

- afficher un message sobre ;
- ne pas exposer le detail du secret ;
- journaliser cote serveur ;
- conserver le contenu en brouillon.

En cas de doute sur une source :

- bloquer la validation ;
- marquer le contenu `review` ;
- ajouter une note "source a verifier".

