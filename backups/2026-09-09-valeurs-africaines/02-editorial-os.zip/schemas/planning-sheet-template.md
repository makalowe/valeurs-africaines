# Modèle de la feuille Google Sheets « Planning » (Valeurs Africaines)

À créer dans le spreadsheet référencé par `GOOGLE_SHEETS_ID`, avec un onglet nommé **exactement** `Planning` (l'application lit la plage `Planning!A2:Q`).

## Ligne d'en-tête (A1:Q1) — copier telle quelle

| A | B | C | D | E | F | G | H | I | J | K | L | M | N | O | P | Q |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| id | date | sujet | rubrique | format | angle_strategique | statut | priorite | echeance | validation_humaine | visuel_propose | visuel_choisi | type_visuel | prompt_visuel | date_selection | droits_visuels_verifies | validation_visuelle_humaine |

Colonnes A→Q = 17 colonnes. Les données commencent **ligne 2** (la ligne 1 est ignorée).

## Exemple de ligne (ligne 2)

| id | date | sujet | rubrique | format | angle_strategique | statut | priorite | echeance | validation_humaine | K…Q |
|---|---|---|---|---|---|---|---|---|---|---|
| VA-001 | 2026-09-03 | Sujet de test | Aujourd'hui en Afrique | article | Angle stratégique à préciser | Brouillon | Haute | 2026-09-03 | non | (laisser vide) |

## Valeurs attendues par l'application

- **statut (G)** : libres (ex. `Brouillon`, `Recherche`, `Rédaction`, `Validation humaine`, `Prêt à publier`, `Publié`, `Archive`) — la page Planning propose « Recherche », « Rédaction », « Validation humaine ».
- **validation_humaine (J)** : `oui` / `non`.
- **id (A)** : identifiant unique éditorial (ex. `VA-001`). La page Planning recherche par cet ID.
- **K→Q (métadonnées visuelles)** : `visuel_propose`, `visuel_choisi`, `type_visuel`, `prompt_visuel`, `date_selection`, `droits_visuels_verifies`, `validation_visuelle_humaine` — mises à jour par l'application quand la feuille est connectée.

## Comment créer la feuille

1. Ouvrir le spreadsheet `GOOGLE_SHEETS_ID` (compte autorisé OAuth).
2. `+` (nouvel onglet) → renommer **`Planning`**.
3. Coller la ligne d'en-tête en A1 (ou importer le CSV `planning-sheet-template.csv` fourni).
4. Ajouter les lignes de contenu à partir de la ligne 2.
5. Recharger `/planning` — le mode Sheets remplace automatiquement le repli local (détecté à la prochaine fenêtre de 10 min).

## Repli local (tant que la feuille n'existe pas)

Sans la feuille, l'OS bascule automatiquement sur le **planning local** : les lignes sont construites depuis les **vrais brouillons** du dossier `02-EDITION-HEBDOMADAIRE/Brouillons/` (id = nom du fichier, statut dérivé Brouillon / Prêt à publier / Publié) et les mises à jour sont persistées dans `valeurs-africaines-editorial-os/data/planning-local-state.json`. Aucune donnée n'est perdue quand la feuille sera créée (mais l'état local n'est pas réimporté automatiquement dans Sheets).
