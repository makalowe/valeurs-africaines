---
title: "Audit editorial pre-lancement"
aliases: []
type: "concept"
status: "draft"
created: "2026-06-11"
updated: "2026-06-12"
source: ""
country: ""
region: ""
actors: []
themes: []
tags: ["#VAIS"]
confidence: "medium"
reviewed: false
---
# Audit editorial pre-lancement

Projet : valeurs-africaines-editorial-os  
Date : 2026-06-11  
Classification : P0 critique, P1 important, P2 amelioration

## Synthese

Le workflow editorial respecte le principe central de Valeurs Africaines : produire des brouillons, analyses, briefs, newsletters, visuels et declinaisons multicanales sans publication automatique.

Validation humaine obligatoire avant mise en production.

## Points conformes

- Validation humaine presente dans le workflow.
- Archivage refuse si le contenu n'est pas valide humainement.
- Module multicanal refuse les contenus non valides.
- Les contenus generes sont qualifies comme brouillons.
- Les sources sont conservees dans Knowledge Hub, RAG, newsletter et multicanal.
- Les prompts et sorties demandent la distinction faits / analyses / hypotheses.
- Research Briefs structurés selon le format Valeurs Africaines.
- Newsletter structurée avec édito, faits stratégiques, rubriques et signaux faibles.
- Visuals génère des représentations sans publication automatique.
- Knowledge Hub produit des fiches Markdown Obsidian avec YAML et liens internes.

## Controle publication automatique

Statut : conforme.

Aucune route ne declenche de publication externe. Les modules produisent des brouillons, exports ou entrees internes. Le lint basique verifie l'absence du flag `publication_automatique: true`.

## Risques editoriaux

### P1 - Sources encore parfois declaratives

Plusieurs modules conservent un champ source, mais ne verifient pas automatiquement la qualite, la date ou l'autorite des sources.

Recommandation : ajouter un scoring des sources en V2.1.

### P1 - Notes pays pas encore specialisees en agent dedie complet

La structure Note pays existe dans le workflow, mais la generation dediee reste moins avancee que Research Brief, Newsletter ou Multicanal.

Recommandation : creer un agent Note pays avec schema fixe : politique, economie, geopolitique, vulnerabilites, opportunites, perspectives 3-5 ans.

### P1 - Distinction faits / analyses / hypotheses a renforcer en validation

La distinction est presente dans les prompts et brouillons, mais il manque une checklist forcee cote interface de validation.

Recommandation : ajouter une grille de validation editoriale obligatoire.

### P2 - Charte editoriale pas encore integree dans toutes les interfaces

Les regles sont presentes dans la documentation et Help, mais pas toujours visibles au moment de generer.

Recommandation : ajouter des rappels contextuels courts dans les modules Generation, Research Briefs et Multicanal.

### P2 - Historique editorial limite

Plusieurs pages disposent d'historiques locaux ou mockes, mais pas encore d'historique persistant complet.

Recommandation : ajouter un journal editorial persistant des actions.

## Recommandations prioritaires

| Priorite | Action |
|---|---|
| P1 | Ajouter scoring et verification des sources. |
| P1 | Creer un agent Note pays complet. |
| P1 | Ajouter checklist de validation humaine obligatoire. |
| P2 | Integrer la charte editoriale dans les formulaires critiques. |
| P2 | Creer un historique editorial persistant. |

## Conclusion editoriale

Statut : conforme pour une V1 interne.  
Condition : aucune diffusion sans relecture, verification des sources et validation humaine formelle.
