---
title: "Roadmap V2"
aliases: []
type: "concept"
status: "draft"
created: "2026-06-11"
updated: "2026-06-12"
source: ""
country: ""
region: ""
actors: []
themes: []
tags: ["#VAIS"]
confidence: "medium"
reviewed: false
---
# Roadmap V2

Projet : valeurs-africaines-editorial-os  
Date : 2026-06-11  
Classification : P0 critique, P1 important, P2 amelioration

## Vision V2

Faire evoluer la V1 en veritable systeme de memoire strategique, veille geopolitique et production editoriale assistee, tout en conservant les principes :

- aucune publication automatique ;
- validation humaine obligatoire ;
- sources citees et scorees ;
- distinction faits / analyses / hypotheses.

## V2.1 - Enrichissement RAG et scoring des sources

Objectif : renforcer la qualite documentaire avant generation.

Livrables :

- scoring des sources : autorite, fraicheur, fiabilite, proximite du sujet ;
- citations internes obligatoires dans chaque generation ;
- detection des informations non sourcées ;
- recherche hybride amelioree avec chunks Markdown ;
- index incremental du Knowledge Hub.

Priorite : P1

## V2.2 - Cartographie geopolitique interactive

Objectif : transformer les contenus en cartes analytiques interactives.

Livrables :

- carte Afrique interactive ;
- couches pays, organisations, corridors, conflits, flux commerciaux ;
- filtres par periode, acteur, theme et niveau de risque ;
- export image et PDF ;
- integration Knowledge Hub.

Priorite : P1

## V2.3 - Agent Veille strategique

Objectif : automatiser la detection de signaux faibles sans publication automatique.

Livrables :

- ingestion de sources de veille configurees ;
- classification geopolitique, economique, securitaire, technologique ;
- score de confiance ;
- horizon temporel ;
- proposition de sujets pour le planning ;
- validation humaine avant transformation en article.

Priorite : P1

## V2.4 - Assistant Research Brief

Objectif : professionnaliser la production des briefs.

Livrables :

- assistant guide par etapes : sujet, contexte, acteurs, these, antithese, synthese ;
- verification RAG avant generation ;
- grille faits / analyses / hypotheses ;
- sources a verifier ;
- export Markdown, HTML, Obsidian ;
- passage en validation humaine.

Priorite : P1

## V2.5 - Knowledge Graph africain

Objectif : relier pays, acteurs, organisations, entreprises, themes, evenements et sources.

Livrables :

- modele de graphe : noeuds et relations ;
- relations : influence, alliance, concurrence, dependance, financement, appartenance ;
- visualisation reseau ;
- backlinks Obsidian enrichis ;
- API de recherche graphe ;
- integration RAG.

Priorite : P2

## Fondations transversales V2

### Authentification et roles

Priorite : P0 avant exposition publique.

Roles proposes :

- administrateur ;
- redacteur en chef ;
- redacteur ;
- analyste ;
- lecteur interne.

### Journal d'audit

Priorite : P1.

Tracer :

- generation ;
- validation ;
- correction ;
- archivage ;
- export ;
- changement de statut.

### Tests et qualite

Priorite : P1.

Ajouter :

- tests API avec mocks ;
- tests Playwright responsive ;
- tests RAG ;
- tests de non-publication automatique ;
- tests de validation humaine obligatoire.

## Sequence recommandee

1. P0 : authentification si deploiement hors poste local.
2. P1 : scoring des sources et RAG enrichi.
3. P1 : audit log persistant.
4. P1 : assistant Research Brief avance.
5. P1 : agent Veille strategique.
6. P2 : cartographie interactive avancee.
7. P2 : Knowledge Graph africain.

## Critere de passage V2

La V2 ne doit etre activee que si :

- la V1 est validee humainement ;
- les acces sont controles ;
- les sources sont scorees ;
- les logs sensibles sont persistants ;
- aucune fonctionnalite ne publie automatiquement.
