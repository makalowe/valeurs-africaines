---
title: "Audit technique pre-lancement"
aliases: []
type: "concept"
status: "draft"
created: "2026-06-11"
updated: "2026-06-12"
source: ""
country: ""
region: ""
actors: []
themes: []
tags: ["#VAIS"]
confidence: "medium"
reviewed: false
---
# Audit technique pre-lancement

Projet : valeurs-africaines-editorial-os  
Date : 2026-06-11  
Classification : P0 critique, P1 important, P2 amelioration

## Synthese

La plateforme est techniquement exploitable pour une V1 interne. Les pages principales existent, le build Next.js passe, TypeScript strict passe, les tests de base passent et la navigation globale est en place.

Validation avant production : obligatoire.

## Controles executes

| Controle | Resultat |
|---|---|
| `npm test` | Conforme |
| `npm run lint` | Conforme |
| `npm run build` | Conforme |
| `npm run typecheck` | Conforme |
| `npm ls --depth=0` | Conforme |
| `npm audit --audit-level=moderate` | 2 vulnerabilites moderees transitives |

## Points conformes

- Build Next.js sans erreur.
- TypeScript strict valide via `tsc --noEmit`.
- Lint de securite basique valide.
- Routes API presentes pour planning, generation, validation, archivage, dashboard, RAG, Knowledge Hub, visuals, newsletter et multicanal.
- Gestion d'erreurs presente dans les routes critiques avec codes 400, 404, 409 et 500 selon les cas.
- Navigation principale globale disponible dans `AppShell`.
- Structure modulaire claire : `src/app`, `src/lib`, `src/components`, `knowledge-hub`, `docs`, `prompts`, `schemas`, `tests`.
- Dashboard dispose de donnees mockees si les sources reelles sont absentes.
- L'interface est globalement responsive avec grilles Tailwind et breakpoints.

## Risques

### P1 - Vulnerabilite PostCSS transitive via Next.js

`npm audit` signale une vulnerabilite moderee liee a PostCSS dans la dependance transitive de Next.js. La correction proposee par npm passe par `npm audit fix --force`, qui installerait une version de Next potentiellement cassante.

Recommandation : surveiller une mise a jour stable de Next.js corrigeant la dependance sans downgrade/breaking change.

### P1 - Tests encore principalement structurels

Les tests actuels verifient l'existence des routes, fonctions et garde-fous, mais pas encore les comportements complets avec mocks de Google Sheets/OpenAI.

Recommandation : ajouter des tests unitaires avec mocks serveur pour chaque route API.

### P1 - Dashboard lourd

La route `/dashboard` embarque Recharts et affiche un First Load JS autour de 220 kB.

Recommandation : conserver pour V1 interne, mais envisager du lazy loading des graphiques en V2.

### P2 - Responsive non verifie par test visuel automatique

Le code utilise des classes responsive, mais il n'existe pas encore de test Playwright mobile/tablette.

Recommandation : ajouter une suite visuelle minimale sur 390px, 768px et desktop.

### P2 - Gestion des donnees live dependante des credentials

Les appels Google Sheets echouent si `.env.local` ou les permissions du service account ne sont pas configurees.

Recommandation : ajouter une page de diagnostic serveur plus detaillee en V2, sans exposer les secrets.

## Recommandations prioritaires

| Priorite | Action |
|---|---|
| P1 | Ajouter mocks et tests API comportementaux. |
| P1 | Suivre la correction de la vulnerabilite PostCSS/Next. |
| P1 | Verifier les credentials Google Sheets dans l'environnement cible. |
| P2 | Ajouter tests visuels responsive. |
| P2 | Optimiser le bundle dashboard par lazy loading. |

## Conclusion technique

Statut : pret pour usage interne controle.  
Condition : validation humaine avant mise en production et configuration explicite des secrets en environnement cible.
