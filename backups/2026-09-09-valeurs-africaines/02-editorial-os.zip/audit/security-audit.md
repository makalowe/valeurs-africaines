---
title: "Audit securite pre-lancement"
aliases: []
type: "concept"
status: "draft"
created: "2026-06-11"
updated: "2026-06-12"
source: ""
country: ""
region: ""
actors: []
themes: []
tags: ["#VAIS"]
confidence: "medium"
reviewed: false
---
# Audit securite pre-lancement

Projet : valeurs-africaines-editorial-os  
Date : 2026-06-11  
Classification : P0 critique, P1 important, P2 amelioration

## Synthese

La base V1 respecte les contraintes principales : pas de cle en dur detectee, variables d'environnement utilisees, appels sensibles cote serveur, aucune publication automatique.

Validation humaine obligatoire avant mise en production.

## Controles executes

- Recherche de patterns de secrets : aucun secret reel detecte.
- `npm run lint` : conforme.
- `npm audit --audit-level=moderate` : 2 vulnerabilites moderees transitives liees a PostCSS/Next.
- Verification routes API : les operations sensibles passent par le backend.

## Points conformes

- `OPENAI_API_KEY`, `GOOGLE_PRIVATE_KEY`, `GOOGLE_SERVICE_ACCOUNT_EMAIL` et `GOOGLE_SHEETS_ID` sont lus via `process.env`.
- Aucune cle API reelle n'est presente dans le code source.
- La page Settings n'affiche que configure / non configure, pas les valeurs.
- Les appels Google Sheets et OpenAI ne sont pas faits depuis le frontend.
- Archivage protege par validation humaine.
- Multicanal protege par validation humaine.
- Les routes API gerent les payloads invalides.
- Les exports restent locaux et manuels.

## Risques

### P1 - Absence d'authentification applicative

La V1 ne protege pas encore les pages ni les routes API par session utilisateur, role ou authentification.

Impact : en environnement expose, toute personne ayant acces a l'application pourrait utiliser les routes internes.

Recommandation : ajouter auth obligatoire avant tout deploiement public ou partage reseau.

### P1 - Permissions Google Sheets a limiter

Le service account utilise le scope `https://www.googleapis.com/auth/spreadsheets`, necessaire pour lire/ecrire. Il faut limiter le partage au seul spreadsheet editorial.

Recommandation : verifier que le service account n'a acces qu'au document cible.

### P1 - Logs serveur a encadrer

Les logs sont explicites, mais il faut eviter tout contenu source sensible dans les logs futurs.

Recommandation : standardiser des logs d'action sans texte editorial complet ni secrets.

### P1 - Vulnerabilite PostCSS transitive

`npm audit` signale une vulnerabilite moderee. La correction forcee peut introduire un changement cassant.

Recommandation : surveiller la mise a jour Next.js et appliquer une correction non cassante des que disponible.

### P2 - Pas de rate limiting

Les routes de generation pourraient etre abusees si l'application est exposee.

Recommandation : ajouter rate limiting et quotas par utilisateur.

### P2 - Pas de journal d'audit persistant

Les validations, archivages et generations sont logges en console mais pas encore dans une table d'audit.

Recommandation : creer un audit log persistant.

## Controles critiques

| Controle | Statut |
|---|---|
| Aucune cle en dur | Conforme |
| Variables d'environnement | Conforme |
| Publication automatique interdite | Conforme |
| Validation humaine obligatoire | Conforme pour archivage et multicanal |
| Authentification | A ajouter avant exposition |
| Audit logs persistants | A ajouter |

## Recommandations prioritaires

| Priorite | Action |
|---|---|
| P0 | Ne pas exposer l'application publiquement sans authentification. |
| P1 | Restreindre les permissions Google Sheets. |
| P1 | Ajouter audit log persistant. |
| P1 | Surveiller/mettre a jour Next.js pour la vulnerabilite PostCSS. |
| P2 | Ajouter rate limiting. |

## Conclusion securite

Statut : acceptable pour usage local/interne controle.  
Blocage production publique : authentification et controle d'acces obligatoires.
