export type EditorialStatus =
  | "idea"
  | "drafting"
  | "review"
  | "validation"
  | "approved"
  | "archived";

export type EditorialFormat =
  | "article"
  | "editorial"
  | "research_brief"
  | "country_note"
  | "map_infographic"
  | "weak_signals"
  | "newsletter";

export type EditorialItem = {
  id: string;
  date: string;
  rhythm: "daily" | "weekly";
  format: EditorialFormat;
  title: string;
  angle: string;
  category: string;
  countryOrRegion: string;
  owner: string;
  status: EditorialStatus;
  sources: string;
  socialFormats: string[];
  knowledgeBaseTarget: string;
};

export type Draft = {
  editorialId: string;
  title: string;
  body: string;
  sourcesToVerify: string[];
  generatedAt: string;
  status: "draft" | "human_review_required" | "approved";
};

