"use client";

import { Bar, BarChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import type { CountryCoverage } from "@/lib/dashboard";

type AfricaCoverageProps = {
  data: CountryCoverage[];
};

export function AfricaCoverage({ data }: AfricaCoverageProps) {
  if (data.length === 0) {
    return <EmptyState text="Aucune couverture pays détectée dans les sources." />;
  }

  return (
    <div className="grid grid-cols-[minmax(0,1.1fr)_minmax(280px,0.9fr)] gap-4 max-lg:grid-cols-1">
      <ResponsiveContainer width="100%" height={320}>
        <BarChart data={data}>
          <CartesianGrid stroke="#262626" vertical={false} />
          <XAxis dataKey="pays" stroke="#a3a3a3" fontSize={12} />
          <YAxis stroke="#a3a3a3" fontSize={12} allowDecimals={false} />
          <Tooltip contentStyle={{ background: "#111", border: "1px solid #2d2d2d", color: "#f5f5f5" }} />
          <Bar dataKey="frequence" fill="#d5b56e" radius={[6, 6, 0, 0]} />
        </BarChart>
      </ResponsiveContainer>

      <div className="space-y-3">
        {data.map((item) => (
          <div key={item.pays} className="rounded-md border border-line bg-black/20 p-3">
            <div className="flex items-center justify-between gap-3">
              <span className="font-semibold text-neutral-100">{item.pays}</span>
              <span className={coverageClass(item.niveau)}>{item.niveau}</span>
            </div>
            <div className="mt-2 h-2 overflow-hidden rounded bg-[#242424]">
              <div className="h-full bg-gold" style={{ width: `${Math.min(item.frequence * 16, 100)}%` }} />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function coverageClass(level: CountryCoverage["niveau"]) {
  if (level === "fort") return "rounded bg-green-500/10 px-2 py-1 text-xs font-bold text-green-100";
  if (level === "moyen") return "rounded bg-gold/10 px-2 py-1 text-xs font-bold text-gold";
  return "rounded bg-neutral-500/10 px-2 py-1 text-xs font-bold text-neutral-300";
}

function EmptyState({ text }: { text: string }) {
  return (
    <div className="grid min-h-[220px] place-items-center rounded-md border border-line bg-black/20 p-4 text-center text-sm text-neutral-500">
      {text}
    </div>
  );
}
