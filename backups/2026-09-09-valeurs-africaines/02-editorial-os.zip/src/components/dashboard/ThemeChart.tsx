"use client";

import { Cell, Pie, PieChart, ResponsiveContainer, Tooltip } from "recharts";
import type { TopicDistribution } from "@/lib/dashboard";

const chartColors = ["#d5b56e", "#7c9f86", "#9b8a6a", "#c66f5a", "#6d8ea0", "#b7b7b7"];

type ThemeChartProps = {
  data: TopicDistribution[];
};

export function ThemeChart({ data }: ThemeChartProps) {
  if (data.length === 0) {
    return <EmptyChart text="Aucune thématique détectée." />;
  }

  return (
    <ResponsiveContainer width="100%" height={320}>
      <PieChart>
        <Pie data={data} dataKey="total" nameKey="theme" innerRadius={65} outerRadius={115} paddingAngle={3}>
          {data.map((item, index) => <Cell key={item.theme} fill={chartColors[index % chartColors.length]} />)}
        </Pie>
        <Tooltip contentStyle={{ background: "#111", border: "1px solid #2d2d2d", color: "#f5f5f5" }} />
      </PieChart>
    </ResponsiveContainer>
  );
}

function EmptyChart({ text }: { text: string }) {
  return (
    <div className="grid min-h-[220px] place-items-center rounded-md border border-line bg-black/20 p-4 text-center text-sm text-neutral-500">
      {text}
    </div>
  );
}
