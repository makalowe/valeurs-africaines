import type { StrategicDossierCoverage } from "@/lib/strategicDossiers";

type StrategicDossiersProps = {
  dossiers: StrategicDossierCoverage[];
  compact?: boolean;
};

const statusClass: Record<StrategicDossierCoverage["status"], string> = {
  "sous-couvert": "border-red-400/40 bg-red-400/10 text-red-100",
  "à renforcer": "border-orange-400/40 bg-orange-400/10 text-orange-100",
  correct: "border-green-400/40 bg-green-400/10 text-green-100",
  "bien couvert": "border-gold/40 bg-gold/10 text-gold-soft"
};

export function StrategicDossiers({ dossiers, compact = false }: StrategicDossiersProps) {
  return (
    <section className="rounded-lg border border-line bg-panel">
      <div className="border-b border-line bg-[#171717] px-4 py-3">
        <h2 className="text-sm font-semibold uppercase tracking-[0.18em] text-gold">Dossiers stratégiques</h2>
        <p className="mt-1 text-sm text-neutral-400">Couverture éditoriale des grands axes permanents.</p>
      </div>
      <div className={`grid gap-3 p-4 ${compact ? "grid-cols-1" : "grid-cols-2 max-lg:grid-cols-1"}`}>
        {dossiers.map((dossier) => (
          <article key={dossier.name} className="rounded-md border border-line bg-black/20 p-4">
            <div className="flex items-start justify-between gap-3">
              <div>
                <h3 className="font-semibold text-gold-soft">{dossier.name}</h3>
                <p className="mt-1 text-xs text-neutral-500">{dossier.contentCount} contenus liés · évolution {formatEvolution(dossier.evolution)}</p>
              </div>
              <span className={`shrink-0 rounded-full border px-2.5 py-1 text-xs font-semibold ${statusClass[dossier.status]}`}>
                {dossier.status}
              </span>
            </div>
            <div className="mt-4 flex items-center gap-3">
              <div className="h-2 flex-1 rounded-full bg-neutral-800">
                <div className="h-full rounded-full bg-gold" style={{ width: `${dossier.coverage}%` }} />
              </div>
              <span className="w-12 text-right text-sm font-bold text-gold-soft">{dossier.coverage} %</span>
            </div>
          </article>
        ))}
      </div>
    </section>
  );
}

function formatEvolution(value: number): string {
  if (value > 0) return `+${value} %`;
  return `${value} %`;
}
