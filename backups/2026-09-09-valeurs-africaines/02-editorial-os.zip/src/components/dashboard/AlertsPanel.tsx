import type { DashboardAlert } from "@/lib/dashboard";

type AlertsPanelProps = {
  alerts: DashboardAlert[];
};

export function AlertsPanel({ alerts }: AlertsPanelProps) {
  if (alerts.length === 0) {
    return <EmptyState text="Aucune alerte critique détectée." />;
  }

  return (
    <div className="space-y-3">
      {alerts.map((alert) => (
        <div key={`${alert.type}-${alert.titre}`} className={`rounded-md border p-3 ${alertClass(alert.niveau)}`}>
          <div className="font-semibold">{alert.titre}</div>
          <div className="mt-1 text-sm opacity-90">{alert.detail}</div>
        </div>
      ))}
    </div>
  );
}

function alertClass(level: DashboardAlert["niveau"]) {
  if (level === "haut") return "border-red-400/40 bg-red-400/10 text-red-100";
  if (level === "moyen") return "border-gold/40 bg-gold/10 text-gold-soft";
  return "border-line bg-black/20 text-neutral-300";
}

function EmptyState({ text }: { text: string }) {
  return (
    <div className="grid min-h-[180px] place-items-center rounded-md border border-line bg-black/20 p-4 text-center text-sm text-neutral-500">
      {text}
    </div>
  );
}
