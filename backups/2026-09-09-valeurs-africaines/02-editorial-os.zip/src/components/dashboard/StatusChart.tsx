"use client";

import { Bar, BarChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import type { StatusDistribution } from "@/lib/dashboard";

type StatusChartProps = {
  data: StatusDistribution;
};

export function StatusChart({ data }: StatusChartProps) {
  const rows = [
    { status: "Idées", total: data.idees },
    { status: "Recherche", total: data.recherche },
    { status: "Rédaction", total: data.redactionIA },
    { status: "Validation", total: data.validation },
    { status: "Prêt", total: data.pret },
    { status: "Archivé", total: data.archive }
  ];

  if (rows.every((row) => row.total === 0)) {
    return <EmptyChart text="Aucune donnée de workflow disponible." />;
  }

  return (
    <ResponsiveContainer width="100%" height={300}>
      <BarChart data={rows}>
        <CartesianGrid stroke="#262626" vertical={false} />
        <XAxis dataKey="status" stroke="#a3a3a3" fontSize={12} />
        <YAxis stroke="#a3a3a3" fontSize={12} allowDecimals={false} />
        <Tooltip contentStyle={{ background: "#111", border: "1px solid #2d2d2d", color: "#f5f5f5" }} />
        <Bar dataKey="total" fill="#d5b56e" radius={[6, 6, 0, 0]} />
      </BarChart>
    </ResponsiveContainer>
  );
}

function EmptyChart({ text }: { text: string }) {
  return (
    <div className="grid min-h-[220px] place-items-center rounded-md border border-line bg-black/20 p-4 text-center text-sm text-neutral-500">
      {text}
    </div>
  );
}
