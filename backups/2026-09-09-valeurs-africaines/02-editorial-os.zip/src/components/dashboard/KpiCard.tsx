type KpiCardProps = {
  label: string;
  value: number | string;
  hint?: string;
  loading?: boolean;
};

export function KpiCard({ label, value, hint, loading = false }: KpiCardProps) {
  return (
    <div className="rounded-lg border border-line bg-panel p-4">
      <div className="text-3xl font-bold text-gold-soft">{loading ? "..." : value}</div>
      <div className="mt-1 text-sm text-neutral-400">{label}</div>
      {hint ? <div className="mt-2 text-xs text-neutral-500">{hint}</div> : null}
    </div>
  );
}
