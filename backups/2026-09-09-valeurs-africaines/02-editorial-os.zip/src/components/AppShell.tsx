"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { ClipboardList, Newspaper } from "lucide-react";
import type { LucideIcon } from "lucide-react";

type NavItem = {
  label: string;
  href: string;
  icon: LucideIcon;
};

// Interface unique : le poste de pilotage. Les autres routes restent accessibles
// par URL directe mais ne figurent plus dans la navigation.
const navItems: NavItem[] = [{ label: "Poste de pilotage", href: "/comite-redaction", icon: ClipboardList }];

export function AppShell({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();

  // Pages publiques (magazine) : rendu plein écran sans chrome de la console.
  if (pathname.startsWith("/magazine")) {
    return <div className="min-h-screen bg-white text-neutral-900">{children}</div>;
  }

  return (
    <div className="min-h-screen bg-ink text-neutral-100">
      <header className="sticky top-0 z-40 border-b border-line bg-[#0b0b0b]/95 backdrop-blur">
        <div className="mx-auto flex max-w-[1680px] items-center justify-between gap-4 px-5 py-3">
          <Link href="/" className="flex items-center gap-3">
            <div className="grid h-9 w-9 place-items-center rounded-md border border-gold/50 bg-gold/10">
              <Newspaper size={18} className="text-gold" />
            </div>
            <div>
              <div className="font-serif text-lg font-bold uppercase tracking-wide text-gold-soft">Valeurs Africaines</div>
              <div className="text-[11px] uppercase tracking-[0.22em] text-neutral-500">Editorial OS v1.0</div>
            </div>
          </Link>
          <div className="hidden rounded-md border border-red-400/30 bg-red-400/10 px-3 py-2 text-xs font-semibold text-red-100 md:block">
            Validation humaine obligatoire · aucune publication automatique
          </div>
        </div>
        <nav className="border-t border-line">
          <div className="mx-auto flex max-w-[1680px] gap-1 overflow-x-auto px-5 py-2">
            {navItems.map(({ label, href, icon: Icon }) => {
              const active = pathname === href || (href !== "/" && pathname.startsWith(`${href}/`));
              return (
                <Link
                  key={href}
                  href={href}
                  className={`flex shrink-0 items-center gap-2 rounded-md px-3 py-2 text-sm font-semibold transition ${
                    active ? "bg-gold/15 text-gold-soft" : "text-neutral-400 hover:bg-gold/10 hover:text-gold-soft"
                  }`}
                >
                  <Icon size={16} />
                  {label}
                </Link>
              );
            })}
          </div>
        </nav>
      </header>
      {children}
    </div>
  );
}
