import type { EditorialStatus } from "@/types/editorial";
import { statusLabel } from "@/lib/status";

const classes: Record<EditorialStatus, string> = {
  idea: "border-neutral-600 bg-neutral-900 text-neutral-300",
  drafting: "border-gold/40 bg-gold/10 text-gold-soft",
  review: "border-blue-400/40 bg-blue-400/10 text-blue-200",
  validation: "border-red-400/40 bg-red-400/10 text-red-200",
  approved: "border-green-400/40 bg-green-400/10 text-green-200",
  archived: "border-neutral-500/40 bg-neutral-700/30 text-neutral-300"
};

export function StatusBadge({ status }: { status: EditorialStatus }) {
  return (
    <span className={`inline-flex rounded-full border px-2.5 py-1 text-xs font-semibold ${classes[status]}`}>
      {statusLabel[status]}
    </span>
  );
}

