"use client";

import type { EditorialItem } from "@/types/editorial";
import { formatLabel } from "@/lib/status";
import { StatusBadge } from "@/components/StatusBadge";
import { formatDisplayDate } from "@/lib/dateDisplay";

type Props = {
  items: EditorialItem[];
  selectedId?: string;
  onSelect: (item: EditorialItem) => void;
};

export function EditorialTable({ items, selectedId, onSelect }: Props) {
  return (
    <div className="overflow-hidden rounded-lg border border-line bg-panel">
      <div className="border-b border-line bg-[#171717] px-4 py-3">
        <h2 className="text-lg font-semibold text-gold-soft">Planning editorial</h2>
        <p className="text-sm text-neutral-400">Cliquez sur une ligne pour generer ou valider un brouillon.</p>
      </div>
      <div className="overflow-x-auto">
        <table className="min-w-[1120px] w-full border-collapse text-left text-sm">
          <thead className="bg-[#12100b] text-xs uppercase tracking-wide text-gold">
            <tr>
              <th className="px-4 py-3">ID</th>
              <th className="px-4 py-3">Date</th>
              <th className="px-4 py-3">Rythme</th>
              <th className="px-4 py-3">Format</th>
              <th className="px-4 py-3">Sujet</th>
              <th className="px-4 py-3">Rubrique</th>
              <th className="px-4 py-3">Pays / zone</th>
              <th className="px-4 py-3">Statut</th>
              <th className="px-4 py-3">Archivage</th>
            </tr>
          </thead>
          <tbody>
            {items.map((item) => (
              <tr
                key={item.id}
                onClick={() => onSelect(item)}
                className={`cursor-pointer border-t border-line transition hover:bg-white/5 ${
                  selectedId === item.id ? "bg-gold/10" : ""
                }`}
              >
                <td className="px-4 py-3 font-semibold text-gold-soft">{item.id}</td>
                <td className="px-4 py-3 text-neutral-300">{formatDisplayDate(item.date)}</td>
                <td className="px-4 py-3 text-neutral-300">{item.rhythm === "daily" ? "Quotidien" : "Hebdomadaire"}</td>
                <td className="px-4 py-3 text-neutral-300">{formatLabel[item.format]}</td>
                <td className="px-4 py-3">
                  <div className="font-semibold text-neutral-100">{item.title}</div>
                  <div className="mt-1 max-w-xs text-xs text-neutral-400">{item.angle}</div>
                </td>
                <td className="px-4 py-3 text-neutral-300">{item.category}</td>
                <td className="px-4 py-3 text-neutral-300">{item.countryOrRegion}</td>
                <td className="px-4 py-3"><StatusBadge status={item.status} /></td>
                <td className="px-4 py-3 text-neutral-300">{item.knowledgeBaseTarget}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
