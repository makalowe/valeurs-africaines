"use client";

import { FileText, ShieldCheck, Sparkles } from "lucide-react";
import type { Draft, EditorialItem } from "@/types/editorial";
import { formatLabel } from "@/lib/status";

type Props = {
  selected?: EditorialItem;
  draft?: Draft;
  onGenerate: () => void;
};

export function DraftPanel({ selected, draft, onGenerate }: Props) {
  return (
    <aside className="rounded-lg border border-line bg-panel">
      <div className="border-b border-line bg-[#171717] px-4 py-3">
        <h2 className="text-lg font-semibold text-gold-soft">Generation & validation</h2>
        <p className="text-sm text-neutral-400">Aucune publication automatique. Validation humaine obligatoire.</p>
      </div>

      <div className="space-y-4 p-4">
        {selected ? (
          <div className="rounded-md border border-line bg-black/30 p-4">
            <div className="text-xs uppercase tracking-wide text-gold">Selection</div>
            <h3 className="mt-2 font-semibold text-neutral-100">{selected.title}</h3>
            <p className="mt-1 text-sm text-neutral-400">{formatLabel[selected.format]} · {selected.category}</p>
            <button
              type="button"
              onClick={onGenerate}
              className="mt-4 inline-flex w-full items-center justify-center gap-2 rounded-md bg-gold px-4 py-2.5 text-sm font-bold text-black"
            >
              <Sparkles size={16} />
              Preparer un brouillon test
            </button>
          </div>
        ) : (
          <div className="rounded-md border border-line bg-black/30 p-4 text-sm text-neutral-400">
            Selectionnez une ligne du planning pour lancer un brouillon.
          </div>
        )}

        <div className="rounded-md border border-line bg-black/30 p-4">
          <div className="mb-3 flex items-center gap-2 text-gold-soft">
            <FileText size={17} />
            <h3 className="font-semibold">Brouillon</h3>
          </div>
          {draft ? (
            <pre className="max-h-[520px] whitespace-pre-wrap rounded-md bg-[#080808] p-4 text-sm leading-6 text-neutral-200">
              {draft.body}
            </pre>
          ) : (
            <p className="text-sm text-neutral-400">Le brouillon de demonstration apparaitra ici. Les connexions IA seront ajoutees plus tard.</p>
          )}
        </div>

        <div className="rounded-md border border-green-500/30 bg-green-500/10 p-4">
          <div className="mb-2 flex items-center gap-2 text-green-200">
            <ShieldCheck size={17} />
            <h3 className="font-semibold">Validation humaine</h3>
          </div>
          <p className="text-sm text-green-100/80">
            Les boutons de publication ne sont pas inclus en V1. Un contenu approuve peut seulement etre marque pour archivage ou export.
          </p>
        </div>
      </div>
    </aside>
  );
}
