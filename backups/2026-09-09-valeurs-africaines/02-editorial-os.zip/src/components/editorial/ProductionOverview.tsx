import type { ProductionMetric } from "@/lib/editorialMetrics";

export function ProductionOverview({ title, metrics }: { title: string; metrics: ProductionMetric[] }) {
  return (
    <section className="rounded-lg border border-line bg-panel">
      <div className="border-b border-line bg-[#171717] px-4 py-3">
        <h2 className="text-sm font-semibold uppercase tracking-[0.18em] text-gold">{title}</h2>
      </div>
      <div className="grid gap-3 p-4 sm:grid-cols-2 xl:grid-cols-3">
        {metrics.map((metric) => {
          const progress = metric.target > 0 ? Math.min(100, Math.round((metric.current / metric.target) * 100)) : 0;
          return (
            <article key={metric.label} className="rounded-md border border-line bg-black/20 p-4">
              <div className="flex items-center justify-between gap-3">
                <h3 className="text-sm font-semibold text-neutral-200">{metric.label}</h3>
                <span className="text-sm font-bold text-gold-soft">{metric.current} / {metric.target}</span>
              </div>
              <div className="mt-3 h-2 rounded-full bg-neutral-800">
                <div className="h-full rounded-full bg-gold" style={{ width: `${progress}%` }} />
              </div>
            </article>
          );
        })}
      </div>
    </section>
  );
}
