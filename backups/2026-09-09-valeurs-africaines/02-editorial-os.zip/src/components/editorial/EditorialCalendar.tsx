import type { CalendarItem } from "@/lib/editorialMetrics";
import { formatDisplayDate } from "@/lib/dateDisplay";

export function EditorialCalendar({ items }: { items: CalendarItem[] }) {
  return (
    <section className="rounded-lg border border-line bg-panel">
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-line bg-[#171717] px-4 py-3">
        <div>
          <h2 className="text-sm font-semibold uppercase tracking-[0.18em] text-gold">Calendrier éditorial</h2>
          <p className="mt-1 text-sm text-neutral-400">Vue Jour · Semaine · Mois</p>
        </div>
        <div className="flex rounded-md border border-line text-xs font-semibold">
          {["Jour", "Semaine", "Mois"].map((label) => (
            <button key={label} className="border-r border-line px-3 py-2 last:border-r-0 hover:bg-gold/10">{label}</button>
          ))}
        </div>
      </div>
      <div className="grid gap-3 p-4 md:grid-cols-2 xl:grid-cols-4">
        {items.map((item) => (
          <article key={`${item.date}-${item.title}`} className="rounded-md border border-line bg-black/20 p-4">
            <p className="text-xs font-semibold uppercase tracking-wide text-gold">{formatDisplayDate(item.date)}</p>
            <h3 className="mt-2 font-semibold text-gold-soft">{item.title}</h3>
            <p className="mt-2 text-sm text-neutral-400">{item.type}</p>
            <p className="mt-3 rounded-full border border-line px-2.5 py-1 text-xs font-semibold text-neutral-300">{item.status}</p>
          </article>
        ))}
      </div>
    </section>
  );
}
