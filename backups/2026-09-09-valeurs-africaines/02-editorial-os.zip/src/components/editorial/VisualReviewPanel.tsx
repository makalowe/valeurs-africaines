import type { PendingVisual } from "@/lib/editorialMetrics";

const statusClass: Record<PendingVisual["proposals"][number]["status"], string> = {
  "En attente": "border-orange-400/40 bg-orange-400/10 text-orange-100",
  Sélectionné: "border-green-400/40 bg-green-400/10 text-green-100",
  Rejeté: "border-neutral-600 bg-neutral-800 text-neutral-300"
};

export function VisualReviewPanel({ items }: { items: PendingVisual[] }) {
  return (
    <section className="rounded-lg border border-line bg-panel">
      <div className="border-b border-line bg-[#171717] px-4 py-3">
        <h2 className="text-sm font-semibold uppercase tracking-[0.18em] text-gold">Visuels en attente</h2>
        <p className="mt-1 text-sm text-neutral-400">Chaque article doit recevoir trois propositions avant validation finale.</p>
      </div>
      <div className="grid gap-4 p-4 xl:grid-cols-2">
        {items.map((item) => (
          <article key={item.editorialId} className="rounded-md border border-line bg-black/20 p-4">
            <p className="text-xs uppercase tracking-wide text-neutral-500">Article</p>
            <h3 className="mt-1 font-semibold text-gold-soft">{item.articleTitle}</h3>
            <div className="mt-4 grid gap-3">
              {item.proposals.map((proposal) => (
                <div key={proposal.id} className="grid grid-cols-[1fr_auto] gap-3 rounded-md border border-line bg-[#101010] p-3">
                  <div>
                    <p className="text-xs font-semibold text-gold">Proposition {proposal.id} · {proposal.type}</p>
                    <p className="mt-1 text-sm text-neutral-200">{proposal.title}</p>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className={`rounded-full border px-2.5 py-1 text-xs font-semibold ${statusClass[proposal.status]}`}>{proposal.status}</span>
                    <button className="rounded-md border border-line px-3 py-1.5 text-xs font-semibold hover:border-gold">Sélectionner</button>
                  </div>
                </div>
              ))}
            </div>
          </article>
        ))}
      </div>
    </section>
  );
}
