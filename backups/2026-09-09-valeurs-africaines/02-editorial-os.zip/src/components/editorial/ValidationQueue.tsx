import type { ValidationItem } from "@/lib/editorialMetrics";
import { formatDisplayDate } from "@/lib/dateDisplay";

export function ValidationQueue({ items }: { items: ValidationItem[] }) {
  return (
    <section className="rounded-lg border border-line bg-panel">
      <div className="border-b border-line bg-[#171717] px-4 py-3">
        <h2 className="text-sm font-semibold uppercase tracking-[0.18em] text-gold">Contenus à valider</h2>
      </div>
      <div className="overflow-x-auto">
        <table className="w-full min-w-[760px] text-left text-sm">
          <thead className="text-xs uppercase tracking-wide text-neutral-500">
            <tr>
              <th className="px-4 py-3">Titre</th>
              <th className="px-4 py-3">Auteur</th>
              <th className="px-4 py-3">Date</th>
              <th className="px-4 py-3">Statut</th>
              <th className="px-4 py-3">Actions</th>
            </tr>
          </thead>
          <tbody>
            {items.map((item) => (
              <tr key={item.id} className="border-t border-line">
                <td className="px-4 py-3 font-semibold text-gold-soft">{item.title}</td>
                <td className="px-4 py-3 text-neutral-300">{item.author}</td>
                <td className="px-4 py-3 text-neutral-400">{formatDisplayDate(item.date)}</td>
                <td className="px-4 py-3 text-neutral-300">{item.status}</td>
                <td className="px-4 py-3">
                  <div className="flex gap-2">
                    <button className="rounded-md border border-line px-3 py-1.5 text-xs font-semibold hover:border-gold">Ouvrir</button>
                    <button className="rounded-md border border-green-500/40 bg-green-500/10 px-3 py-1.5 text-xs font-semibold text-green-100">Valider</button>
                    <button className="rounded-md border border-orange-400/40 bg-orange-400/10 px-3 py-1.5 text-xs font-semibold text-orange-100">Retour corrections</button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </section>
  );
}
