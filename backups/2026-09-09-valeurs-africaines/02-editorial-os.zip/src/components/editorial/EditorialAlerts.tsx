import type { EditorialAlert } from "@/lib/editorialMetrics";

const labels: Record<EditorialAlert["level"], string> = {
  critique: "critique",
  attention: "attention",
  normal: "normal"
};

const className: Record<EditorialAlert["level"], string> = {
  critique: "border-red-400/40 bg-red-400/10 text-red-100",
  attention: "border-orange-400/40 bg-orange-400/10 text-orange-100",
  normal: "border-green-400/40 bg-green-400/10 text-green-100"
};

export function EditorialAlerts({ alerts }: { alerts: EditorialAlert[] }) {
  return (
    <section className="rounded-lg border border-line bg-panel">
      <div className="border-b border-line bg-[#171717] px-4 py-3">
        <h2 className="text-sm font-semibold uppercase tracking-[0.18em] text-gold">Alertes rédaction</h2>
      </div>
      <div className="grid gap-3 p-4">
        {alerts.map((alert) => (
          <article key={`${alert.level}-${alert.title}`} className={`rounded-md border p-4 ${className[alert.level]}`}>
            <div className="text-xs font-bold uppercase tracking-wide">{labels[alert.level]}</div>
            <h3 className="mt-1 font-semibold">{alert.title}</h3>
            <p className="mt-1 text-sm opacity-90">{alert.detail}</p>
          </article>
        ))}
      </div>
    </section>
  );
}
