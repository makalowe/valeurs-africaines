"use client";

import { FormEvent, useEffect, useState } from "react";
import type { PlanningRow } from "@/lib/googleSheets";
import type { DraftResult } from "@/lib/openai";

type GenerateDraftResponse = {
  row?: PlanningRow;
  result?: DraftResult;
  error?: string;
};

export default function GenerationPage() {
  const [editorialId, setEditorialId] = useState("VA-001");
  const [draft, setDraft] = useState("");
  const [row, setRow] = useState<PlanningRow | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [copyLabel, setCopyLabel] = useState("Copier");
  const [rows, setRows] = useState<PlanningRow[]>([]);
  const [source, setSource] = useState<"sheets" | "local" | null>(null);

  useEffect(() => {
    let cancelled = false;
    void fetch("/api/planning", { cache: "no-store" })
      .then(async (response) => {
        const payload = (await response.json()) as { rows?: PlanningRow[]; source?: "sheets" | "local" };
        if (!cancelled && Array.isArray(payload.rows)) {
          setRows(payload.rows);
          setSource(payload.source ?? null);
        }
      })
      .catch(() => undefined);
    return () => {
      cancelled = true;
    };
  }, []);

  async function generateDraft(event?: FormEvent<HTMLFormElement>, forcedId?: string) {
    event?.preventDefault();
    const id = (forcedId ?? editorialId).trim();

    if (!id) {
      setError("Saisis un ID editorial.");
      return;
    }

    setIsLoading(true);
    setError(null);
    setDraft("");
    setRow(null);

    try {
      const response = await fetch("/api/generate-draft", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({ editorialId: id })
      });

      const payload = (await response.json()) as GenerateDraftResponse;

      if (!response.ok) {
        setError(payload.error ?? "Erreur pendant la generation du brouillon.");
        return;
      }

      setRow(payload.row ?? null);
      setDraft(payload.result?.draft ?? "");
    } catch {
      setError("Impossible de contacter l'API interne.");
    } finally {
      setIsLoading(false);
    }
  }

  async function copyDraft() {
    if (!draft) return;
    await navigator.clipboard.writeText(draft);
    setCopyLabel("Copie");
    window.setTimeout(() => setCopyLabel("Copier"), 1600);
  }

  function selectPlanningRow(id: string) {
    setEditorialId(id);
    void generateDraft(undefined, id);
  }

  return (
    <main className="min-h-screen bg-ink px-5 py-8 text-neutral-100">
      <section className="mx-auto max-w-6xl space-y-6">
        <header className="border-b border-line pb-5">
          <p className="text-xs font-semibold uppercase tracking-[0.24em] text-gold">Valeurs Africaines Editorial OS</p>
          <h1 className="mt-3 text-3xl font-semibold text-gold-soft">Generation de brouillons</h1>
          <p className="mt-2 max-w-3xl text-sm leading-6 text-neutral-400">
            Genere un brouillon editorial a partir d'une ligne du planning. Aucun contenu n'est publie, envoye ou archive automatiquement.
          </p>
        </header>

        {source === "local" ? (
          <div className="rounded-lg border border-gold/30 bg-gold/5 p-4 text-sm text-neutral-200">
            <p className="font-semibold text-gold-soft">Mode planning local (feuille « Planning » absente)</p>
            <p className="mt-1 leading-5 text-neutral-400">
              Les lignes sont vos <span className="font-semibold text-neutral-200">brouillons réels</span> — choisis-en une pour générer un premier jet IA à partir de son sujet.
            </p>
          </div>
        ) : null}

        <form onSubmit={generateDraft} className="rounded-lg border border-line bg-panel p-4">
          {rows.length > 0 ? (
            <div>
              <label htmlFor="planningRowSelect" className="block text-sm font-semibold text-gold">
                Ligne du planning ({rows.length} disponible{rows.length > 1 ? "s" : ""})
              </label>
              <select
                id="planningRowSelect"
                onChange={(event) => {
                  if (event.target.value) selectPlanningRow(event.target.value);
                }}
                className="mt-2 min-h-11 w-full rounded-md border border-line bg-black px-3 text-neutral-100 outline-none focus:border-gold"
              >
                <option value="">— Choisir une ligne —</option>
                {rows.map((row) => (
                  <option key={row.id} value={row.id}>
                    {row.id} · {row.sujet.slice(0, 60)} · {row.statut}
                  </option>
                ))}
              </select>
            </div>
          ) : null}
          <label htmlFor="editorialId" className="mt-4 block text-sm font-semibold text-gold">
            ID editorial
          </label>
          <div className="mt-3 flex gap-3 max-sm:grid">
            <input
              id="editorialId"
              value={editorialId}
              onChange={(event) => setEditorialId(event.target.value)}
              placeholder={source === "local" ? "nom-du-brouillon.md sans extension" : "VA-001"}
              className="min-h-11 flex-1 rounded-md border border-line bg-black px-3 text-neutral-100 outline-none focus:border-gold"
            />
            <button
              type="submit"
              disabled={isLoading}
              className="rounded-md bg-gold px-5 py-2.5 font-bold text-black disabled:opacity-50"
            >
              {isLoading ? "Generation..." : "Generer brouillon"}
            </button>
          </div>
        </form>

        {error ? (
          <div className="rounded-lg border border-red-400/40 bg-red-400/10 p-4 text-sm text-red-100">
            {error}
          </div>
        ) : null}

        <section className="grid grid-cols-[330px_minmax(0,1fr)] gap-5 max-lg:grid-cols-1">
          <aside className="rounded-lg border border-line bg-panel p-4">
            <h2 className="font-semibold text-gold-soft">Ligne planning</h2>
            {row ? (
              <dl className="mt-4 space-y-3 text-sm">
                <Info label="Sujet" value={row.sujet} />
                <Info label="Rubrique" value={row.rubrique} />
                <Info label="Format" value={row.format} />
                <Info label="Priorite" value={row.priorite} />
                <Info label="Statut" value={row.statut} />
              </dl>
            ) : (
              <p className="mt-4 text-sm leading-6 text-neutral-400">Aucune ligne chargee.</p>
            )}
            <div className="mt-5 rounded-md border border-red-400/30 bg-red-400/10 p-3 text-xs leading-5 text-red-100">
              Brouillon uniquement. Validation humaine obligatoire avant toute publication.
            </div>
          </aside>

          <article className="rounded-lg border border-line bg-panel">
            <div className="flex items-center justify-between gap-3 border-b border-line bg-[#171717] px-4 py-3">
              <div>
                <h2 className="font-semibold text-gold-soft">Brouillon genere</h2>
                <p className="text-sm text-neutral-400">Zone scrollable. Aucun envoi externe n'est effectue.</p>
              </div>
              <button
                type="button"
                onClick={copyDraft}
                disabled={!draft}
                className="rounded-md border border-line px-4 py-2 text-sm font-semibold text-neutral-100 hover:border-gold disabled:cursor-not-allowed disabled:opacity-50"
              >
                {copyLabel}
              </button>
            </div>
            <pre className="max-h-[660px] min-h-[430px] overflow-auto whitespace-pre-wrap p-5 text-sm leading-6 text-neutral-200">
              {draft || "Le brouillon apparaitra ici apres generation."}
            </pre>
          </article>
        </section>
      </section>
    </main>
  );
}

function Info({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <dt className="text-xs uppercase tracking-wide text-gold">{label}</dt>
      <dd className="mt-1 text-neutral-200">{value || "-"}</dd>
    </div>
  );
}

