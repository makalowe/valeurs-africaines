"use client";

import { useEffect, useMemo, useState } from "react";
import { AfricaCoverage } from "@/components/dashboard/AfricaCoverage";
import { AlertsPanel } from "@/components/dashboard/AlertsPanel";
import { KpiCard } from "@/components/dashboard/KpiCard";
import { StatusChart } from "@/components/dashboard/StatusChart";
import { ThemeChart } from "@/components/dashboard/ThemeChart";
import type { DashboardData } from "@/lib/dashboard";

type DashboardResponse = {
  data?: DashboardData;
  source?: "live" | "mock";
  error?: string;
};

const emptyData: DashboardData = {
  stats: { total: 0, generated: 0, validation: 0, archives: 0, en_retard: 0, haute_priorite: 0 },
  statusDistribution: { idees: 0, recherche: 0, redactionIA: 0, validation: 0, pret: 0, archive: 0 },
  priorityDistribution: { haute: 0, moyenne: 0, faible: 0 },
  deadlines: { en_retard: 0, aujourd_hui: 0, cette_semaine: 0 },
  overview: { contenusPublies: 0, contenusEnAttente: 0, contenusEnValidation: 0, contenusProgrammes: 0 },
  kpis: { articlesSemaine: 0, articlesMois: 0, articlesAnnee: 0 },
  countryCoverage: [],
  topicDistribution: [],
  alerts: [],
  weakSignals: [],
  isMock: false
};

export default function DashboardPage() {
  const [data, setData] = useState<DashboardData>(emptyData);
  const [source, setSource] = useState<"live" | "mock">("live");
  const [error, setError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    async function loadDashboard() {
      try {
        const response = await fetch("/api/dashboard");
        const payload = (await response.json()) as DashboardResponse;

        if (!response.ok) {
          setError(payload.error ?? "Impossible de charger le dashboard.");
          setData(payload.data ?? emptyData);
          return;
        }

        setData(payload.data ?? emptyData);
        setSource(payload.source ?? "live");
      } catch {
        setError("Impossible de contacter l'API interne.");
      } finally {
        setIsLoading(false);
      }
    }

    void loadDashboard();
  }, []);

  const [conflictData, setConflictData] = useState<{ zones: Array<{ zone: string; evolution?: string; niveau?: string }> } | null>(null);
  const [diasporaData, setDiasporaData] = useState<{ profiles: Array<{ nom: string; pays_origine?: string; domaine?: string }> } | null>(null);

  useEffect(() => {
    let cancelled = false;
    void fetch("/api/conflits", { cache: "no-store" })
      .then(async (response) => {
        if (response.ok && !cancelled) setConflictData((await response.json()) as typeof conflictData);
      })
      .catch(() => undefined);
    void fetch("/api/diaspora", { cache: "no-store" })
      .then(async (response) => {
        if (response.ok && !cancelled) setDiasporaData((await response.json()) as typeof diasporaData);
      })
      .catch(() => undefined);
    return () => {
      cancelled = true;
    };
  }, []);

  const overviewCards = useMemo(
    () => [
      { label: "Contenus publiés", value: data.overview.contenusPublies },
      { label: "En attente", value: data.overview.contenusEnAttente },
      { label: "En validation", value: data.overview.contenusEnValidation },
      { label: "Programmés", value: data.overview.contenusProgrammes }
    ],
    [data.overview]
  );

  const kpiCards = useMemo(
    () => [
      { label: "Articles semaine", value: data.kpis.articlesSemaine },
      { label: "Articles mois", value: data.kpis.articlesMois },
      { label: "Articles année", value: data.kpis.articlesAnnee }
    ],
    [data.kpis]
  );

  // Rubriques spéciales : compteurs réels là où une source de module existe
  // (conflits, diaspora), sinon « Donnée à vérifier » — aucune valeur inventée.
  const conflictCards = conflictData
    ? [
        { label: "Zones suivies", value: conflictData.zones.length },
        { label: "Zones en dégradation", value: conflictData.zones.filter((zone) => zone.evolution === "dégradation").length },
        { label: "Zones en amélioration", value: conflictData.zones.filter((zone) => zone.evolution === "amélioration").length },
        { label: "Tension élevée", value: conflictData.zones.filter((zone) => (zone.niveau ?? "").toLowerCase().includes("élevé")).length },
        { label: "Médiations en cours", value: null },
        { label: "Alertes rouges", value: null }
      ]
    : null;

  const diasporaCards = diasporaData
    ? [
        { label: "Profils suivis", value: diasporaData.profiles.length },
        { label: "Pays d'origine représentés", value: new Set(diasporaData.profiles.map((profile) => profile.pays_origine).filter(Boolean)).size },
        { label: "Domaines couverts", value: new Set(diasporaData.profiles.map((profile) => profile.domaine).filter(Boolean)).size },
        { label: "Profils à documenter", value: diasporaData.profiles.length }
      ]
    : null;

  const moduleSections: Array<{
    title: string;
    subtitle: string;
    cards: Array<{ label: string; value: number | null }> | null;
    note: string;
  }> = [
    {
      title: "Portraits d'excellence",
      subtitle: "Chercheurs, innovateurs, femmes scientifiques et diasporas académiques.",
      cards: null,
      note: "Donnée à vérifier — rubrique alimentée via sa page de génération ; aucun compteur persistant."
    },
    {
      title: "BUSINESS",
      subtitle: "Entreprises, entrepreneurs, investisseurs, marchés et modèles économiques.",
      cards: null,
      note: "Donnée à vérifier — rubrique alimentée via sa page de génération ; aucun compteur persistant."
    },
    {
      title: "Écologie & Économie durable",
      subtitle: "Développement, souveraineté, opportunités économiques et durabilité.",
      cards: null,
      note: "Donnée à vérifier — rubrique alimentée via sa page de génération ; aucun compteur persistant."
    },
    {
      title: "Afrique 2030",
      subtitle: "Fil rouge ODD : engagements, mise en œuvre et résultats mesurables.",
      cards: null,
      note: "Donnée à vérifier — rubrique alimentée via sa page de génération ; aucun compteur persistant."
    },
    {
      title: "Observatoire des conflits",
      subtitle: "Zones suivies, dégradations et tensions (module Conflits).",
      cards: conflictCards,
      note: "Module Conflits en chargement ou indisponible — « Donnée à vérifier »."
    },
    {
      title: "Observatoire diaspora",
      subtitle: "Profils du module Diaspora (exemples à documenter).",
      cards: diasporaCards,
      note: "Module Diaspora en chargement ou indisponible — « Donnée à vérifier »."
    }
  ];

  return (
    <main className="min-h-screen bg-ink px-5 py-8 text-neutral-100">
      <section className="mx-auto max-w-7xl space-y-6">
        <header className="flex items-start justify-between gap-5 border-b border-line pb-5 max-lg:grid">
          <div>
            <p className="text-xs font-semibold uppercase tracking-[0.24em] text-gold">Valeurs Africaines Editorial OS</p>
            <h1 className="mt-3 text-3xl font-semibold text-gold-soft">Dashboard éditorial</h1>
            <p className="mt-2 max-w-3xl text-sm leading-6 text-neutral-400">
              Pilotage exécutif de la production éditoriale, de la couverture africaine, des thématiques, des alertes et des signaux faibles.
            </p>
          </div>
          <div className="rounded-lg border border-red-400/30 bg-red-400/10 px-4 py-3 text-sm text-red-100">
            Validation humaine obligatoire · aucune publication automatique
          </div>
        </header>

        {error ? <ErrorState message={error} /> : null}
        {source === "mock" ? <MockNotice /> : null}

        <section>
          <SectionTitle title="Vue générale" subtitle={isLoading ? "Chargement des sources..." : "Planning éditorial, Knowledge Hub et archives internes."} />
          <div className="grid grid-cols-4 gap-3 max-lg:grid-cols-2 max-sm:grid-cols-1">
            {overviewCards.map((card) => <KpiCard key={card.label} label={card.label} value={card.value} loading={isLoading} />)}
          </div>
        </section>

        <section>
          <SectionTitle title="KPI" subtitle="Production éditoriale par période." />
          <div className="grid grid-cols-3 gap-3 max-md:grid-cols-1">
            {kpiCards.map((card) => <KpiCard key={card.label} label={card.label} value={card.value} loading={isLoading} />)}
          </div>
        </section>

        {moduleSections.map((section) => (
          <section key={section.title}>
            <SectionTitle title={section.title} subtitle={section.subtitle} />
            {section.cards && section.cards.length > 0 ? (
              <div className="grid grid-cols-3 gap-3 max-md:grid-cols-1">
                {section.cards.map((card) => (
                  <article key={card.label} className="rounded-md border border-line bg-black/20 p-4">
                    <div className="text-2xl font-bold text-gold-soft">{card.value ?? "—"}</div>
                    <div className="mt-1 text-sm text-neutral-400">{card.label}</div>
                  </article>
                ))}
              </div>
            ) : (
              <div className="rounded-md border border-dashed border-line bg-black/10 p-4 text-sm leading-5 text-neutral-500">{section.note}</div>
            )}
          </section>
        ))}

        <section className="grid grid-cols-[minmax(0,0.95fr)_minmax(0,1.05fr)] gap-5 max-xl:grid-cols-1">
          <Panel title="Workflow éditorial" subtitle="Répartition par statut normalisé.">
            <StatusChart data={data.statusDistribution} />
          </Panel>
          <Panel title="Cartographie Afrique" subtitle="Pays couverts, fréquence et niveau de couverture.">
            <AfricaCoverage data={data.countryCoverage} />
          </Panel>
        </section>

        <section className="grid grid-cols-[minmax(0,0.9fr)_minmax(0,1.1fr)] gap-5 max-xl:grid-cols-1">
          <Panel title="Thématiques" subtitle="Répartition des sujets par thème ou catégorie.">
            <ThemeChart data={data.topicDistribution} />
          </Panel>
          <Panel title="Répartition des sujets" subtitle="Lecture éditoriale des thèmes dominants.">
            <TopicList data={data.topicDistribution} />
          </Panel>
        </section>

        <section className="grid grid-cols-[minmax(0,0.95fr)_minmax(0,1.05fr)] gap-5 max-xl:grid-cols-1">
          <Panel title="Alertes" subtitle="Retards, validations manquantes et événements prioritaires.">
            <AlertsPanel alerts={data.alerts} />
          </Panel>
          <Panel title="Signaux faibles" subtitle="Derniers signaux détectés par la veille stratégique.">
            <WeakSignals data={data.weakSignals} />
          </Panel>
        </section>
      </section>
    </main>
  );
}

function SectionTitle({ title, subtitle }: { title: string; subtitle: string }) {
  return (
    <div className="mb-3">
      <h2 className="text-lg font-semibold text-gold-soft">{title}</h2>
      <p className="mt-1 text-sm text-neutral-400">{subtitle}</p>
    </div>
  );
}

function Panel({ title, subtitle, children }: { title: string; subtitle: string; children: React.ReactNode }) {
  return (
    <article className="rounded-lg border border-line bg-panel">
      <div className="border-b border-line bg-[#171717] px-4 py-3">
        <h2 className="font-semibold text-gold-soft">{title}</h2>
        <p className="text-sm text-neutral-400">{subtitle}</p>
      </div>
      <div className="p-4">{children}</div>
    </article>
  );
}

function TopicList({ data }: { data: DashboardData["topicDistribution"] }) {
  if (data.length === 0) return <EmptyState text="Ajoute des fiches validées pour alimenter les thématiques." />;

  return (
    <div className="space-y-2">
      {data.map((item) => (
        <div key={item.theme} className="flex items-center justify-between rounded-md border border-line bg-black/20 px-3 py-2 text-sm">
          <span className="text-neutral-200">{item.theme}</span>
          <span className="font-bold text-gold-soft">{item.total}</span>
        </div>
      ))}
    </div>
  );
}

function WeakSignals({ data }: { data: DashboardData["weakSignals"] }) {
  if (data.length === 0) return <EmptyState text="Aucun signal faible disponible." />;

  return (
    <div className="space-y-3">
      {data.map((signal) => (
        <div key={signal.signal} className="rounded-md border border-line bg-black/20 p-3">
          <div className="flex items-start justify-between gap-3">
            <div>
              <div className="font-semibold text-neutral-100">{signal.signal}</div>
              <div className="mt-1 text-sm text-neutral-400">{signal.region} · {signal.acteurs}</div>
            </div>
            <span className="rounded bg-gold/10 px-2 py-1 text-xs font-bold text-gold">{signal.priorite}</span>
          </div>
          <div className="mt-2 text-xs text-neutral-500">{signal.source} · {signal.horizon} · confiance {signal.scoreConfiance}/100</div>
        </div>
      ))}
    </div>
  );
}

function MockNotice() {
  return (
    <div className="rounded-lg border border-gold/40 bg-gold/10 p-4 text-sm text-gold-soft">
      Données de démonstration affichées : les sources réelles ne sont pas encore disponibles ou sont vides.
    </div>
  );
}

function ErrorState({ message }: { message: string }) {
  return (
    <div className="rounded-lg border border-red-400/40 bg-red-400/10 p-4 text-sm text-red-100">
      {message}
    </div>
  );
}

function EmptyState({ text }: { text: string }) {
  return (
    <div className="grid min-h-[180px] place-items-center rounded-md border border-line bg-black/20 p-4 text-center text-sm text-neutral-500">
      {text}
    </div>
  );
}
