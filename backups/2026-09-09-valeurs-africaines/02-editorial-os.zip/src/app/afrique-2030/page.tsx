import { generateWeeklyAfrica2030Report, getAfrica2030CoverageMetrics, getAfrica2030StrategicQuestions } from "@/lib/africa2030";

const indicators = [
  "ODD concernés",
  "Impacts positifs",
  "Impacts négatifs",
  "Indicateurs mesurables",
  "Résultats observables"
];

export default function Afrique2030Page() {
  const report = generateWeeklyAfrica2030Report();
  const questions = getAfrica2030StrategicQuestions();
  const coverage = getAfrica2030CoverageMetrics();

  return (
    <main className="min-h-screen bg-ink px-5 py-8 text-neutral-100">
      <section className="mx-auto max-w-7xl space-y-6">
        <header className="border-b border-line pb-5">
          <p className="text-xs font-semibold uppercase tracking-[0.24em] text-gold">Fil rouge éditorial</p>
          <h1 className="mt-3 text-3xl font-semibold text-gold-soft">Afrique 2030 – État d'avancement</h1>
          <p className="mt-2 max-w-3xl text-sm leading-6 text-neutral-400">
            Utiliser les Objectifs de Développement Durable comme grille de lecture transversale, sans remplacer l'analyse géopolitique, économique, stratégique et souveraine.
          </p>
        </header>

        <section className="rounded-lg border border-line bg-panel p-5">
          <h2 className="font-semibold text-gold-soft">Question centrale</h2>
          <p className="mt-2 text-lg leading-7 text-neutral-200">
            Les engagements de développement sont-ils réellement appliqués en Afrique et produisent-ils des résultats mesurables ?
          </p>
        </section>

        <section className="rounded-lg border border-gold/40 bg-gold/10 p-5">
          <h2 className="text-sm font-semibold uppercase tracking-[0.2em] text-gold">Score transversal</h2>
          <p className="mt-2 text-3xl font-bold text-gold-soft">Impact Afrique : XX / 50</p>
          <p className="mt-2 text-sm text-neutral-300">À calculer pour chaque publication à partir de l'intérêt stratégique, la souveraineté, l'économie, l'impact humain, les ODD et la mesurabilité.</p>
        </section>

        <section className="rounded-lg border border-line bg-panel p-5">
          <h2 className="font-semibold text-gold-soft">Grille d'analyse obligatoire</h2>
          <ol className="mt-3 grid gap-2 text-sm text-neutral-300 md:grid-cols-2">
            {questions.map((question) => (
              <li key={question} className="rounded-md border border-line bg-black/20 p-3">{question}</li>
            ))}
          </ol>
        </section>

        <section className="grid grid-cols-5 gap-3 max-xl:grid-cols-3 max-md:grid-cols-1">
          {indicators.map((indicator) => (
            <article key={indicator} className="rounded-lg border border-line bg-panel p-4">
              <h2 className="text-sm font-semibold text-gold-soft">{indicator}</h2>
              <p className="mt-2 text-xs leading-5 text-neutral-400">À documenter pour chaque publication.</p>
            </article>
          ))}
        </section>

        <section className="rounded-lg border border-line bg-panel">
          <div className="border-b border-line bg-[#171717] px-4 py-3">
            <h2 className="font-semibold text-gold-soft">Afrique 2030</h2>
            <p className="text-sm text-neutral-400">Couverture éditoriale par axe prioritaire.</p>
          </div>
          <div className="grid gap-3 p-4 md:grid-cols-2">
            {coverage.map((item) => (
              <article key={item.axis} className="rounded-md border border-line bg-black/20 p-4">
                <div className="flex items-center justify-between gap-3">
                  <h3 className="font-semibold text-gold-soft">{item.axis}</h3>
                  <span className="text-sm font-bold text-gold">{item.coverage} %</span>
                </div>
                <div className="mt-3 h-2 rounded-full bg-neutral-800">
                  <div className="h-full rounded-full bg-gold" style={{ width: `${item.coverage}%` }} />
                </div>
                <p className="mt-2 text-xs text-neutral-500">{item.relatedODD.join(" · ")}</p>
              </article>
            ))}
          </div>
        </section>

        <article className="rounded-lg border border-line bg-panel">
          <div className="border-b border-line bg-[#171717] px-4 py-3">
            <h2 className="font-semibold text-gold-soft">Rubrique hebdomadaire</h2>
            <p className="text-sm text-neutral-400">Brouillon structurel de suivi ODD pour l'édition stratégique hebdomadaire.</p>
          </div>
          <pre className="min-h-[520px] overflow-auto whitespace-pre-wrap p-5 text-sm leading-6 text-neutral-200">{report}</pre>
        </article>
      </section>
    </main>
  );
}
