import {
  auditLog,
  contentTypes,
  editorialRoles,
  editorialStatuses,
  factCheckingChecklist,
  workflowTransitions
} from "@/lib/publicationWorkflow";
import type { ReactNode } from "react";

export default function PublicationWorkflowPage() {
  return (
    <main className="min-h-screen bg-ink px-5 py-8 text-neutral-100">
      <section className="mx-auto max-w-7xl space-y-6">
        <header className="border-b border-line pb-5">
          <p className="text-xs font-semibold uppercase tracking-[0.24em] text-gold">Publication</p>
          <h1 className="mt-3 text-3xl font-semibold text-gold-soft">Workflow éditorial</h1>
          <p className="mt-2 max-w-4xl text-sm leading-6 text-neutral-400">
            Système central de validation et publication. Aucun contenu ne peut être publié sans validation humaine explicite.
          </p>
        </header>

        <section className="grid gap-4 lg:grid-cols-4">
          <Kpi title="Statuts" value={String(editorialStatuses.length)} />
          <Kpi title="Types" value={String(contentTypes.length)} />
          <Kpi title="Rôles" value={String(editorialRoles.length)} />
          <Kpi title="Audit log" value={String(auditLog.length)} />
        </section>

        <section className="rounded-lg border border-line bg-panel p-5">
          <p className="text-xs font-semibold uppercase tracking-[0.22em] text-gold">États éditoriaux</p>
          <div className="mt-5 grid gap-3 md:grid-cols-4">
            {editorialStatuses.map((status, index) => (
              <article key={status} className="rounded-md border border-line bg-black/20 p-4">
                <p className="text-xs text-neutral-500">Étape {index + 1}</p>
                <h2 className="mt-1 font-semibold text-gold-soft">{status}</h2>
                <p className="mt-2 text-sm text-neutral-400">Transitions : {workflowTransitions[status].join(", ") || "Aucune"}</p>
              </article>
            ))}
          </div>
        </section>

        <section className="grid gap-6 xl:grid-cols-2">
          <Panel title="Validation factuelle">
            <div className="space-y-2">
              {factCheckingChecklist.map((item) => (
                <label key={item.label} className="flex items-center gap-3 rounded-md border border-line bg-black/20 px-3 py-2 text-sm">
                  <input type="checkbox" checked={item.checked} readOnly className="accent-gold" />
                  {item.label}
                </label>
              ))}
            </div>
            <p className="mt-4 text-sm text-red-100">Publication impossible tant que toutes les cases ne sont pas cochées.</p>
          </Panel>

          <Panel title="Validation direction">
            <dl className="grid gap-3 text-sm">
              {["Titre", "Résumé", "Auteur", "Date", "Sources utilisées", "Risques identifiés"].map((field) => (
                <div key={field} className="rounded-md border border-line bg-black/20 p-3">
                  <dt className="text-xs uppercase tracking-wide text-neutral-500">{field}</dt>
                  <dd className="mt-1 text-neutral-300">Donnée à charger depuis le contenu sélectionné</dd>
                </div>
              ))}
            </dl>
            <textarea disabled placeholder="Commentaire obligatoire" className="mt-4 min-h-24 w-full rounded-md border border-line bg-black/25 px-3 py-2 text-sm text-neutral-500" />
            <div className="mt-3 flex flex-wrap gap-2">
              {["Valider", "Retour correction", "Refuser"].map((action) => <button key={action} className="rounded-md border border-gold/40 bg-gold/10 px-3 py-2 text-sm font-semibold text-gold-soft">{action}</button>)}
            </div>
          </Panel>
        </section>

        <section className="grid gap-6 xl:grid-cols-3">
          <Panel title="Publication">
            <p className="text-sm text-neutral-300">Options : publier immédiatement ou programmer publication.</p>
            <div className="mt-4 grid gap-3">
              <input disabled type="date" className="rounded-md border border-line bg-black/25 px-3 py-2 text-sm" />
              <input disabled type="time" className="rounded-md border border-line bg-black/25 px-3 py-2 text-sm" />
              <input disabled value="Europe/Brussels" readOnly className="rounded-md border border-line bg-black/25 px-3 py-2 text-sm text-neutral-500" />
            </div>
          </Panel>
          <Panel title="Archivage">
            <div className="flex flex-wrap gap-2">
              {["Archiver", "Restaurer", "Dupliquer"].map((action) => <button key={action} className="rounded-md border border-line bg-black/20 px-3 py-2 text-sm text-neutral-300">{action}</button>)}
            </div>
            <p className="mt-4 text-sm text-neutral-400">Historique complet conservé. Suppression interdite.</p>
          </Panel>
          <Panel title="Permissions">
            <ul className="list-inside list-disc space-y-1 text-sm text-neutral-300">
              {editorialRoles.map((role) => <li key={role}>{role}</li>)}
            </ul>
          </Panel>
        </section>

        <Panel title="Alertes & notifications">
          <div className="grid gap-3 md:grid-cols-5">
            {["Contenu à vérifier", "Validation requise", "Publication programmée", "Publication effectuée", "Contenu refusé"].map((notification) => (
              <div key={notification} className="rounded-md border border-line bg-black/20 p-3 text-sm text-neutral-300">
                {notification}
              </div>
            ))}
          </div>
        </Panel>

        <Panel title="Audit Log">
          <div className="overflow-x-auto">
            <table className="w-full min-w-[760px] text-sm">
              <thead className="text-left text-xs uppercase tracking-[0.16em] text-neutral-500">
                <tr><th className="py-2">Utilisateur</th><th>Quand</th><th>Contenu</th><th>Action</th><th>Ancienne valeur</th><th>Nouvelle valeur</th></tr>
              </thead>
              <tbody>
                <tr><td colSpan={6} className="py-5 text-neutral-400">Aucune action enregistrée. Le journal est prêt pour traçabilité complète.</td></tr>
              </tbody>
            </table>
          </div>
        </Panel>
      </section>
    </main>
  );
}

function Kpi({ title, value }: { title: string; value: string }) {
  return <article className="rounded-lg border border-gold/20 bg-panel p-5"><p className="text-xs font-semibold uppercase tracking-[0.18em] text-gold">{title}</p><p className="mt-2 text-2xl font-semibold text-gold-soft">{value}</p></article>;
}

function Panel({ title, children }: { title: string; children: ReactNode }) {
  return <section className="rounded-lg border border-line bg-panel p-5"><p className="text-xs font-semibold uppercase tracking-[0.22em] text-gold">{title}</p><div className="mt-4">{children}</div></section>;
}
