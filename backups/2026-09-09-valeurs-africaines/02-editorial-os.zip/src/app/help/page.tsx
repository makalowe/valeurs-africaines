export default function HelpPage() {
  return (
    <main className="min-h-screen bg-ink px-5 py-8 text-neutral-100">
      <section className="mx-auto max-w-6xl space-y-6">
        <header className="border-b border-line pb-5">
          <p className="text-xs font-semibold uppercase tracking-[0.24em] text-gold">Aide</p>
          <h1 className="mt-3 text-3xl font-semibold text-gold-soft">Mode d'emploi Valeurs Africaines Editorial OS</h1>
          <p className="mt-2 max-w-3xl text-sm leading-6 text-neutral-400">
            Guide rapide pour utiliser la mini salle de rédaction IA en version 1.0.
          </p>
        </header>

        <section className="grid grid-cols-2 gap-5 max-lg:grid-cols-1">
          <Panel title="Workflow éditorial">
            <ol className="space-y-2 text-sm leading-6 text-neutral-300">
              <li>1. Créer ou charger une ligne dans le planning éditorial.</li>
              <li>2. Générer un brouillon ou un Research Brief.</li>
              <li>3. Vérifier les faits, sources, dates et hypothèses.</li>
              <li>4. Valider humainement le contenu.</li>
              <li>5. Archiver dans le Knowledge Hub.</li>
              <li>6. Préparer les déclinaisons visuelles, newsletter ou multicanales.</li>
            </ol>
          </Panel>

          <Panel title="Commandes utiles">
            <pre className="whitespace-pre-wrap rounded-md border border-line bg-black/30 p-4 text-sm leading-6 text-neutral-200">{`npm install
npm run dev
npm run build
npm run typecheck
npm run lint
npm test`}</pre>
          </Panel>
        </section>

        <section className="grid grid-cols-2 gap-5 max-lg:grid-cols-1">
          <Panel title="Règles éthiques">
            <ul className="space-y-2 text-sm leading-6 text-neutral-300">
              <li>- Ne jamais publier automatiquement.</li>
              <li>- Ne jamais présenter une hypothèse comme un fait.</li>
              <li>- Citer et conserver les sources internes.</li>
              <li>- Signaler les informations non vérifiées.</li>
              <li>- Respecter la souveraineté narrative sans propagande ni désinformation.</li>
            </ul>
          </Panel>

          <Panel title="Repères par module">
            <ul className="space-y-2 text-sm leading-6 text-neutral-300">
              <li>- Dashboard : pilotage exécutif.</li>
              <li>- Planning : lecture et statut des lignes éditoriales.</li>
              <li>- Génération : brouillons IA.</li>
              <li>- Validation : décision humaine et archivage.</li>
              <li>- Search / RAG : mémoire stratégique interne.</li>
              <li>- Multicanal : déclinaisons avant diffusion.</li>
            </ul>
          </Panel>
        </section>
      </section>
    </main>
  );
}

function Panel({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <article className="rounded-lg border border-line bg-panel p-4">
      <h2 className="mb-4 font-semibold text-gold-soft">{title}</h2>
      {children}
    </article>
  );
}
