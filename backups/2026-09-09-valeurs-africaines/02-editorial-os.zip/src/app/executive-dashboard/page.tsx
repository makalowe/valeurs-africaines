"use client";

import { Printer, RefreshCw } from "lucide-react";
import type { ReactNode } from "react";
import { useState } from "react";
import { buildPilotageAlerts, usePilotageData, type DayArticleClient } from "@/lib/usePilotageData";
import { formatDisplayDate, formatDisplayDateTime } from "@/lib/dateDisplay";

export default function ExecutiveDashboardPage() {
  const [theme, setTheme] = useState<"dark" | "light">("dark");
  const { loading, error, dashboard, store, day, refresh } = usePilotageData();
  const watchSubjects = dashboard?.watch.subjects ?? [];
  const reviewDate = dashboard?.review?.date ?? dashboard?.watch.date ?? "";
  const reviewDateLabel = formatDisplayDate(reviewDate);
  const decisions = dashboard?.workflow.decisions ?? {};
  const retainedCount = watchSubjects.length > 0
    ? Object.entries(decisions).filter(([key, value]) => key.startsWith(`veille-${dashboard?.watch.date}-`) && value === "Retenir").length
    : 0;
  const alerts = buildPilotageAlerts(dashboard, day, retainedCount);
  const publishedToday = store?.publishedToday ?? 0;
  const dayPublished = (day ?? []).filter((article) => article.publishedId !== null).length;
  const dayReadyUnpublished = (day ?? []).filter((article) => article.publishedId === null && article.ready).length;
  const humanChecks = dashboard?.workflow.humanValidation ?? {};
  const humanChecksDone = Object.values(humanChecks).filter(Boolean).length;
  const humanChecksTotal = Object.keys(humanChecks).length;

  // Pays couverts par la veille du jour (agrégation réelle).
  const countryCounts = new Map<string, number>();
  for (const subject of watchSubjects) {
    for (const country of subject.countries) countryCounts.set(country, (countryCounts.get(country) ?? 0) + 1);
  }
  const countries = [...countryCounts.entries()].sort((a, b) => b[1] - a[1]).map(([country, count]) => `${country} (${count})`);

  const rubricCounts = new Map<string, number>();
  for (const subject of watchSubjects) rubricCounts.set(subject.rubric, (rubricCounts.get(subject.rubric) ?? 0) + 1);
  const rubriques = [...rubricCounts.entries()].sort((a, b) => b[1] - a[1]).map(([rubric, count]) => `${rubric} (${count})`);

  const topSubjects = [...watchSubjects]
    .sort((a, b) => b.relevance.score - a.relevance.score)
    .slice(0, 5)
    .map((subject) => subject.title);

  const chainValues = [watchSubjects.length, retainedCount, dashboard?.draftsForToday.length ?? 0, publishedToday];
  const chainLabels = ["Sujets veille", "Retenus", "Brouillons du jour", "Publiés aujourd'hui"];
  const chainMax = Math.max(1, ...chainValues);

  const summaryParagraphs = [
    dashboard && dashboard.review?.present
      ? `Revue « Aujourd'hui en Afrique » du ${formatDisplayDate(dashboard.review.date)} : ${dashboard.review.subjectCount} sujet(s) détecté(s), ${retainedCount} retenu(s), ${dashboard.draftsForToday.length} brouillon(s) produit(s).`
      : "Aucune revue quotidienne détectée pour le moment (lancer la veille puis générer la revue depuis le poste de pilotage).",
    store
      ? `Site local : ${store.published} article(s) publié(s) au total (${store.publishedToday} aujourd'hui), ${store.total} entrée(s) dans le store.`
      : "Store du site local : non lisible.",
    `Workflow courant : ${dashboard?.workflow.workflow ?? "inconnu"} — prochaine action : ${dashboard?.nextAction.daily ?? "à définir"}. Validation humaine : ${humanChecksTotal > 0 ? `${humanChecksDone}/${humanChecksTotal} critère(s) coché(s)` : "aucun critère enregistré"}.`
  ];

  return (
    <main className={`min-h-screen px-5 py-8 ${theme === "dark" ? "bg-ink text-neutral-100" : "bg-neutral-100 text-neutral-950"}`}>
      <section className="mx-auto max-w-7xl space-y-6">
        <header className="flex items-start justify-between gap-5 border-b border-line pb-5 max-lg:grid">
          <div>
            <p className="text-xs font-semibold uppercase tracking-[0.24em] text-gold">Direction</p>
            <h1 className="mt-3 text-3xl font-semibold text-gold-soft">Tableau de Bord Stratégique</h1>
            <p className="mt-2 max-w-4xl text-sm leading-6 text-neutral-400">
              Vue direction branchée sur les données réelles (veille, brouillons, publications locales).
              {reviewDate ? ` Journée de référence : ${reviewDateLabel}.` : ""}
            </p>
          </div>
          <div className="flex flex-wrap gap-2">
            <button onClick={() => setTheme(theme === "dark" ? "light" : "dark")} className="rounded-md border border-gold/40 bg-gold/10 px-3 py-2 text-sm font-semibold text-gold-soft">
              Mode {theme === "dark" ? "clair" : "sombre"}
            </button>
            <Action icon={<RefreshCw size={15} />} label="Actualiser" onClick={refresh} />
            <Action icon={<Printer size={15} />} label="Imprimer" onClick={() => window.print()} />
          </div>
        </header>

        {error && (
          <div className="rounded-md border border-red-400/30 bg-red-400/10 p-3 text-sm text-red-100">
            Données indisponibles : {error}
          </div>
        )}
        {loading && <p className="text-sm text-neutral-500">Chargement des données réelles…</p>}

        <Block title="Bloc 1 — Activité éditoriale">
          <div className="grid gap-4 md:grid-cols-6">
            <Kpi title="Articles publiés (total)" value={store?.published ?? 0} />
            <Kpi title="Publiés aujourd'hui" value={publishedToday} />
            <Kpi title="Brouillons (tous)" value={dashboard?.drafts.length ?? 0} />
            <Kpi title="Brouillons du jour" value={dashboard?.draftsForToday.length ?? 0} />
            <Kpi title="Sujets de veille" value={watchSubjects.length} />
            <Kpi title="Sujets retenus" value={retainedCount} />
          </div>
          <div className="mt-5">
            <MiniChart title="Chaîne du jour (veille → retenus → brouillons → publiés)" values={chainValues} max={chainMax} labels={chainLabels} />
          </div>
        </Block>

        <Block title="Bloc 2 — Brouillons du jour (fichiers réels)">
          {dashboard && dashboard.draftsForToday.length > 0 ? (
            <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-3">
              {dashboard.draftsForToday.map((draft) => (
                <article key={draft.filename} className="rounded-md border border-line bg-black/20 p-4">
                  <h2 className="break-all text-sm font-semibold text-gold-soft">{draft.filename}</h2>
                  <p className="mt-2 text-xs text-neutral-500">
                    {draft.sizeBytes} o · modifié {formatDisplayDateTime(draft.modifiedAt)}
                  </p>
                </article>
              ))}
            </div>
          ) : (
            <p className="text-sm text-neutral-500">Aucun brouillon pour la journée de référence — « Donnée à vérifier ».</p>
          )}
        </Block>

        <Block title="Bloc 3 — Pays couverts aujourd'hui (veille réelle)">
          {countries.length > 0 ? (
            <div className="flex flex-wrap gap-2">
              {countries.map((country) => (
                <span key={country} className="rounded-md border border-emerald-400/30 bg-emerald-400/5 px-3 py-1.5 text-xs font-semibold text-emerald-100">
                  {country}
                </span>
              ))}
            </div>
          ) : (
            <p className="text-sm text-neutral-500">Aucun pays détecté dans la veille du jour.</p>
          )}
        </Block>

        <Block title="Bloc 4 — Indicateurs du jour">
          <div className="grid gap-4 lg:grid-cols-4">
            <Indicator title="Pays de la veille" items={countries} />
            <Indicator title="Rubriques des sujets" items={rubriques} />
            <Indicator title="Top sujets (score VA)" items={topSubjects} />
            <Indicator title="Publication du jour" items={dayPublished > 0 ? [`${dayPublished} publié(s) · ${dayReadyUnpublished} prêt(s) non publié(s)`] : []} />
          </div>
        </Block>

        <Block title="Bloc 5 — Alertes (réelles)">
          <div className="space-y-2">
            {alerts.map((alert) => (
              <p key={alert} className={`rounded-md border px-3 py-2 text-sm ${alert.startsWith("Aucune alerte") ? "border-emerald-400/30 bg-emerald-400/5 text-emerald-100" : "border-amber-400/30 bg-amber-400/5 text-amber-100"}`}>
                {alert}
              </p>
            ))}
          </div>
        </Block>

        <Block title="Bloc 6 — Synthèse Exécutive">
          <div className="space-y-3 text-sm leading-6 text-neutral-300">
            {summaryParagraphs.map((paragraph) => (
              <p key={paragraph}>{paragraph}</p>
            ))}
          </div>
        </Block>

        <section className="grid gap-4 lg:grid-cols-3">
          <Block title="Workflow">
            <p className="text-sm font-semibold text-gold-soft">{dashboard?.workflow.workflow ?? "—"}</p>
            <p className="mt-1 text-xs text-neutral-500">Mis à jour : {formatDisplayDateTime(dashboard?.workflow.updatedAt) || "jamais"}</p>
            <p className="mt-2 text-sm leading-5 text-neutral-300">{dashboard?.nextAction.daily ?? "—"}</p>
          </Block>
          <Block title="Validation en attente">
            <p className="text-sm text-neutral-300">
              {dayReadyUnpublished > 0 ? `${dayReadyUnpublished} article(s) prêt(s) à valider/publier sur le site local.` : "Aucun article prêt en attente."}
            </p>
            <p className="mt-2 text-xs text-neutral-500">
              Checklist humaine : {humanChecksTotal > 0 ? `${humanChecksDone}/${humanChecksTotal} coché(s)` : "aucun critère enregistré"}
            </p>
          </Block>
          <Block title="Derniers ajouts publiés">
            {store && store.latest.length > 0 ? (
              <ul className="space-y-1.5">
                {store.latest.map((article) => (
                  <li key={article.id} className="text-xs leading-5 text-neutral-300">
                    <a className="text-gold-soft underline decoration-gold/40 underline-offset-2" href={`http://127.0.0.1:5000/articles/${encodeURIComponent(article.slug)}`} target="_blank" rel="noreferrer">
                      #{article.id} · {article.title.slice(0, 60)}
                    </a>
                  </li>
                ))}
              </ul>
            ) : (
              <p className="text-sm text-neutral-500">Aucun article publié détecté.</p>
            )}
          </Block>
        </section>
      </section>
    </main>
  );
}

function Kpi({ title, value }: { title: string; value: number }) {
  return (
    <article className="rounded-md border border-line bg-black/20 p-4">
      <p className="text-xs uppercase tracking-[0.16em] text-gold">{title}</p>
      <p className="mt-2 text-2xl font-semibold text-gold-soft">{value}</p>
    </article>
  );
}

function Block({ title, children }: { title: string; children: ReactNode }) {
  return (
    <section className="rounded-lg border border-line bg-panel p-5">
      <p className="text-xs font-semibold uppercase tracking-[0.22em] text-gold">{title}</p>
      <div className="mt-4">{children}</div>
    </section>
  );
}

function Action({ icon, label, onClick }: { icon: ReactNode; label: string; onClick: () => void }) {
  return (
    <button onClick={onClick} className="inline-flex items-center gap-2 rounded-md border border-gold/40 bg-gold/10 px-3 py-2 text-sm font-semibold text-gold-soft">
      {icon}
      {label}
    </button>
  );
}

function MiniChart({ title, values, max, labels }: { title: string; values: number[]; max: number; labels: string[] }) {
  return (
    <div className="rounded-md border border-line bg-black/20 p-4">
      <p className="text-sm font-semibold text-gold-soft">{title}</p>
      <div className="mt-3 flex h-28 items-end gap-3">
        {values.map((value, index) => (
          <div key={`${title}-${index}`} className="flex h-full flex-1 flex-col justify-end gap-1">
            <div className="rounded-t bg-gold/50" style={{ height: `${Math.max(4, (value / max) * 100)}%` }} />
            <p className="text-center text-[10px] text-neutral-400">{value}</p>
          </div>
        ))}
      </div>
      <p className="mt-2 flex justify-between gap-2 text-[10px] text-neutral-500">
        {labels.map((label) => (
          <span key={label} className="flex-1 text-center">{label}</span>
        ))}
      </p>
    </div>
  );
}

function Indicator({ title, items }: { title: string; items: string[] }) {
  return (
    <div className="rounded-md border border-line bg-black/20 p-4">
      <p className="font-semibold text-gold-soft">{title}</p>
      {items.length > 0 ? (
        <ul className="mt-3 space-y-1.5">
          {items.slice(0, 6).map((item) => (
            <li key={item} className="break-words text-xs leading-5 text-neutral-300">{item}</li>
          ))}
        </ul>
      ) : (
        <p className="mt-3 text-sm text-neutral-500">Donnée à vérifier</p>
      )}
    </div>
  );
}
