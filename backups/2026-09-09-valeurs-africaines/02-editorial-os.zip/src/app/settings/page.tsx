const requiredGoogleVars = ["GOOGLE_SHEETS_ID", "GOOGLE_SERVICE_ACCOUNT_EMAIL", "GOOGLE_PRIVATE_KEY"];
const requiredAiVars = ["OPENAI_API_KEY"];

export default function SettingsPage() {
  const googleStatus = requiredGoogleVars.map((name) => ({
    name,
    configured: Boolean(process.env[name])
  }));
  const aiStatus = requiredAiVars.map((name) => ({
    name,
    configured: Boolean(process.env[name])
  }));
  const model = process.env.OPENAI_MODEL || "gpt-4.1-mini";

  return (
    <main className="min-h-screen bg-ink px-5 py-8 text-neutral-100">
      <section className="mx-auto max-w-6xl space-y-6">
        <header className="border-b border-line pb-5">
          <p className="text-xs font-semibold uppercase tracking-[0.24em] text-gold">Configuration</p>
          <h1 className="mt-3 text-3xl font-semibold text-gold-soft">Settings</h1>
          <p className="mt-2 max-w-3xl text-sm leading-6 text-neutral-400">
            Statut de configuration serveur. Les valeurs sensibles ne sont jamais affichées côté client.
          </p>
        </header>

        <section className="grid grid-cols-2 gap-5 max-lg:grid-cols-1">
          <Panel title="Google Sheet éditorial">
            <ConfigList items={googleStatus} />
            <Info label="Usage" value="Lecture planning, statuts, validation humaine et archivage." />
          </Panel>

          <Panel title="Modèle IA">
            <Info label="Modèle configuré" value={model} />
            <ConfigList items={aiStatus} />
            <Info label="Règle" value="L'API OpenAI est appelée uniquement côté serveur." />
          </Panel>
        </section>

        <section className="grid grid-cols-2 gap-5 max-lg:grid-cols-1">
          <Panel title="Statut des connexions">
            <StatusLine label="Google Sheets" active={googleStatus.every((item) => item.configured)} />
            <StatusLine label="OpenAI" active={aiStatus.every((item) => item.configured)} />
            <StatusLine label="Knowledge Hub local" active />
            <StatusLine label="Publication automatique" active={false} inverted />
          </Panel>

          <Panel title="Règles de validation humaine">
            <ul className="space-y-3 text-sm leading-6 text-neutral-300">
              <li>- Aucun contenu n'est publié automatiquement.</li>
              <li>- Toute génération reste un brouillon jusqu'à validation humaine.</li>
              <li>- L'archivage documentaire intervient après validation.</li>
              <li>- Les sources doivent être conservées et vérifiées.</li>
              <li>- Faits, analyses et hypothèses doivent rester distingués.</li>
            </ul>
          </Panel>
        </section>
      </section>
    </main>
  );
}

function Panel({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <article className="rounded-lg border border-line bg-panel p-4">
      <h2 className="mb-4 font-semibold text-gold-soft">{title}</h2>
      <div className="space-y-4">{children}</div>
    </article>
  );
}

function ConfigList({ items }: { items: Array<{ name: string; configured: boolean }> }) {
  return (
    <div className="space-y-2">
      {items.map((item) => <StatusLine key={item.name} label={item.name} active={item.configured} />)}
    </div>
  );
}

function StatusLine({ label, active, inverted = false }: { label: string; active: boolean; inverted?: boolean }) {
  const good = inverted ? !active : active;
  return (
    <div className="flex items-center justify-between rounded-md border border-line bg-black/20 px-3 py-2 text-sm">
      <span className="font-semibold text-neutral-200">{label}</span>
      <span className={good ? "text-green-100" : "text-red-100"}>{good ? "OK" : "À configurer"}</span>
    </div>
  );
}

function Info({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-md border border-line bg-black/20 p-3">
      <div className="text-xs uppercase tracking-wide text-gold">{label}</div>
      <div className="mt-1 text-sm text-neutral-300">{value}</div>
    </div>
  );
}
