"use client";

import { FormEvent, useMemo, useState } from "react";
import type { Newsletter } from "@/lib/newsletter";
import { formatDisplayDate } from "@/lib/dateDisplay";

type NewsletterHistoryItem = {
  id: string;
  periode: string;
  statut: "Brouillon" | "Validée";
  date: string;
};

type ApiResponse = {
  newsletter?: Newsletter;
  error?: string;
};

const initialHistory: NewsletterHistoryItem[] = [
  { id: "NL-001", periode: "S24-2026", statut: "Brouillon", date: "2026-06-11" }
];

export default function NewsletterPage() {
  const [history, setHistory] = useState<NewsletterHistoryItem[]>(initialHistory);
  const [periode, setPeriode] = useState("S24-2026");
  const [articles, setArticles] = useState("Article 1 : croissance africaine sous contrainte\nArticle 2 : dette et gouvernance des donnees\nArticle 3 : innovation et souverainete narrative");
  const [briefs, setBriefs] = useState("Research Brief : Sahel 2030\nResearch Brief : ZLECAf et couts de transaction");
  const [signaux, setSignaux] = useState("Signal faible : corridors strategiques\nSignal faible : IA et langues africaines");
  const [newsletter, setNewsletter] = useState<Newsletter | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [isValidated, setIsValidated] = useState(false);

  const preview = useMemo(() => newsletter?.markdown ?? "La newsletter apparaitra ici apres generation.", [newsletter]);

  async function generate(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setIsLoading(true);
    setError(null);
    setNewsletter(null);
    setIsValidated(false);

    try {
      const response = await fetch("/api/newsletter/generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          periode,
          articles: splitLines(articles),
          briefs: splitLines(briefs),
          signaux: splitLines(signaux)
        })
      });
      const payload = (await response.json()) as ApiResponse;

      if (!response.ok) {
        setError(payload.error ?? "Erreur pendant la generation de la newsletter.");
        return;
      }

      if (payload.newsletter) {
        setNewsletter(payload.newsletter);
        setHistory((current) => [
          {
            id: `NL-${String(current.length + 1).padStart(3, "0")}`,
            periode: payload.newsletter?.periode ?? periode,
            statut: "Brouillon",
            date: new Date().toISOString().slice(0, 10)
          },
          ...current
        ]);
      }
    } catch {
      setError("Impossible de contacter l'API interne.");
    } finally {
      setIsLoading(false);
    }
  }

  async function copyExport(kind: "markdown" | "html") {
    if (!newsletter) return;
    await navigator.clipboard.writeText(kind === "markdown" ? newsletter.markdown : newsletter.html);
  }

  function validateNewsletter() {
    if (!newsletter) return;
    setIsValidated(true);
    setHistory((current) =>
      current.map((item, index) => (index === 0 ? { ...item, statut: "Validée" } : item))
    );
  }

  return (
    <main className="min-h-screen bg-ink px-5 py-8 text-neutral-100">
      <section className="mx-auto max-w-7xl space-y-6">
        <header className="border-b border-line pb-5">
          <p className="text-xs font-semibold uppercase tracking-[0.24em] text-gold">Valeurs Africaines Editorial OS</p>
          <h1 className="mt-3 text-3xl font-semibold text-gold-soft">Agent Newsletter IA</h1>
          <p className="mt-2 max-w-3xl text-sm leading-6 text-neutral-400">
            Generer une newsletter strategique hebdomadaire a partir des articles, Research Briefs et signaux faibles. Aucune publication automatique.
          </p>
        </header>

        <section className="grid grid-cols-[360px_minmax(0,1fr)] gap-5 max-xl:grid-cols-1">
          <aside className="space-y-5">
            <div className="rounded-lg border border-line bg-panel p-4">
              <h2 className="font-semibold text-gold-soft">Historique</h2>
              <div className="mt-4 space-y-2">
                {history.map((item) => (
                  <div key={item.id} className="rounded-md border border-line bg-black/20 px-3 py-2 text-sm">
                    <div className="font-semibold text-neutral-100">{item.periode}</div>
                    <div className="mt-1 flex justify-between text-xs text-neutral-400">
                      <span>{formatDisplayDate(item.date)}</span>
                      <span>{item.statut}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <form onSubmit={generate} className="rounded-lg border border-line bg-panel p-4">
              <h2 className="font-semibold text-gold-soft">Générer une newsletter</h2>
              <div className="mt-4 space-y-3">
                <Field label="Période">
                  <input value={periode} onChange={(event) => setPeriode(event.target.value)} className="w-full rounded-md border border-line bg-black px-3 py-2 text-sm text-neutral-100 outline-none focus:border-gold" />
                </Field>
                <Field label="Articles">
                  <textarea value={articles} onChange={(event) => setArticles(event.target.value)} className="min-h-24 w-full rounded-md border border-line bg-black px-3 py-2 text-sm text-neutral-100 outline-none focus:border-gold" />
                </Field>
                <Field label="Research Briefs">
                  <textarea value={briefs} onChange={(event) => setBriefs(event.target.value)} className="min-h-24 w-full rounded-md border border-line bg-black px-3 py-2 text-sm text-neutral-100 outline-none focus:border-gold" />
                </Field>
                <Field label="Signaux faibles">
                  <textarea value={signaux} onChange={(event) => setSignaux(event.target.value)} className="min-h-24 w-full rounded-md border border-line bg-black px-3 py-2 text-sm text-neutral-100 outline-none focus:border-gold" />
                </Field>
                <button type="submit" disabled={isLoading} className="w-full rounded-md bg-gold px-4 py-2.5 font-bold text-black disabled:opacity-50">
                  {isLoading ? "Generation..." : "Générer newsletter"}
                </button>
              </div>
            </form>
          </aside>

          <section className="rounded-lg border border-line bg-panel">
            <div className="flex items-center justify-between gap-3 border-b border-line bg-[#171717] px-4 py-3 max-lg:grid">
              <div>
                <h2 className="font-semibold text-gold-soft">Prévisualisation</h2>
                <p className="text-sm text-neutral-400">Brouillon uniquement. Validation humaine obligatoire avant diffusion.</p>
              </div>
              <div className="flex flex-wrap gap-2">
                <button onClick={() => copyExport("markdown")} disabled={!newsletter} className="rounded-md border border-line px-3 py-2 text-sm font-semibold text-neutral-100 hover:border-gold disabled:opacity-50">Export Markdown</button>
                <button onClick={() => copyExport("html")} disabled={!newsletter} className="rounded-md border border-line px-3 py-2 text-sm font-semibold text-neutral-100 hover:border-gold disabled:opacity-50">Export HTML</button>
                <button onClick={validateNewsletter} disabled={!newsletter} className="rounded-md bg-gold px-3 py-2 text-sm font-bold text-black disabled:opacity-50">Validation</button>
              </div>
            </div>

            {error ? <div className="m-4 rounded-md border border-red-400/40 bg-red-400/10 p-3 text-sm text-red-100">{error}</div> : null}
            {isValidated ? <div className="m-4 rounded-md border border-green-400/40 bg-green-400/10 p-3 text-sm text-green-100">Newsletter validée humainement. Aucune publication automatique n'a été effectuée.</div> : null}

            {newsletter ? (
              <div className="grid grid-cols-4 gap-3 border-b border-line p-4 max-lg:grid-cols-2 max-sm:grid-cols-1">
                <Metric label="Temps de lecture" value={`${newsletter.temps_lecture_minutes} min`} />
                <Metric label="Confiance" value={`${newsletter.score_confiance}/100`} />
                <Metric label="Priorité" value={newsletter.priorite_sujets} />
                <Metric label="Sources conservées" value={String(newsletter.sources_conservees.length)} />
              </div>
            ) : null}

            <pre className="max-h-[760px] min-h-[560px] overflow-auto whitespace-pre-wrap p-5 text-sm leading-6 text-neutral-200">
              {preview}
            </pre>
          </section>
        </section>
      </section>
    </main>
  );
}

function splitLines(value: string): string[] {
  return value.split("\n").map((line) => line.trim()).filter(Boolean);
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="block text-sm">
      <span className="mb-1 block font-semibold text-gold">{label}</span>
      {children}
    </label>
  );
}

function Metric({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-md border border-line bg-black/20 p-3">
      <div className="text-lg font-bold text-gold-soft">{value}</div>
      <div className="text-xs text-neutral-400">{label}</div>
    </div>
  );
}
