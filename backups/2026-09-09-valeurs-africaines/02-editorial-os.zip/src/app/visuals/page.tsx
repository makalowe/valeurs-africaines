"use client";

import { FormEvent, useEffect, useMemo, useState } from "react";
import type { Visual, VisualType } from "@/lib/visualGenerator";
import { formatDisplayDate } from "@/lib/dateDisplay";

type ApiResponse = {
  visual?: Visual;
  error?: string;
};

type VisualHistoryItem = {
  id: string;
  titre: string;
  type: VisualType;
  date: string;
};

const VISUAL_TYPE_OPTIONS: Array<{ value: VisualType; label: string }> = [
  { value: "chronologie", label: "Chronologie" },
  { value: "carte_acteurs", label: "Carte d'acteurs" },
  { value: "carte_influence", label: "Carte d'influence" },
  { value: "carte_pays", label: "Carte pays" },
  { value: "diagramme_strategique", label: "Diagramme strategique" },
  { value: "flux", label: "Flux" },
  { value: "infographie_donnees", label: "Infographie donnees" }
];

const initialHistory: VisualHistoryItem[] = [
  {
    id: "VIS-DEMO-001",
    titre: "Routes strategiques et dependances regionales",
    type: "carte_influence",
    date: "2026-06-11"
  }
];

export default function VisualsPage() {
  const [history, setHistory] = useState<VisualHistoryItem[]>(initialHistory);
  const [search, setSearch] = useState("");
  const [filterType, setFilterType] = useState<"all" | VisualType>("all");
  const [type, setType] = useState<VisualType>("diagramme_strategique");
  const [titre, setTitre] = useState("Sahel 2030 : causes, acteurs et consequences");
  const [contenu, setContenu] = useState("La recomposition securitaire au Sahel implique les Etats, les organisations regionales, les partenaires internationaux et les nouveaux acteurs economiques. Les causes principales concernent la gouvernance, les flux transfrontaliers et la competition d'influence. Les consequences touchent la securite, les infrastructures, les alliances et la souverainete regionale.");
  const [donnees, setDonnees] = useState("{\n  \"Etats\": \"Mali, Niger, Burkina Faso\",\n  \"Organisations\": \"UA, CEDEAO\",\n  \"Risques\": \"Fragmentation regionale\",\n  \"Opportunites\": \"Cooperation securitaire africaine\"\n}");
  const [visual, setVisual] = useState<Visual | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [isValidated, setIsValidated] = useState(false);

  useEffect(() => {
    const rawPrefill = window.localStorage.getItem("va-visual-prefill");
    if (!rawPrefill) return;

    try {
      const prefill = JSON.parse(rawPrefill) as Partial<{
        titre: string;
        contenu: string;
        type: VisualType;
      }>;
      if (prefill.titre) setTitre(prefill.titre);
      if (prefill.contenu) setContenu(prefill.contenu);
      if (prefill.type) setType(prefill.type);
    } catch {
      setError("Prefill visuel ignore : donnees locales invalides.");
    } finally {
      window.localStorage.removeItem("va-visual-prefill");
    }
  }, []);

  const filteredHistory = useMemo(() => {
    const query = search.trim().toLowerCase();
    return history.filter((item) => {
      const matchesSearch = !query || item.titre.toLowerCase().includes(query) || item.id.toLowerCase().includes(query);
      const matchesType = filterType === "all" || item.type === filterType;
      return matchesSearch && matchesType;
    });
  }, [filterType, history, search]);

  async function generate(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setIsLoading(true);
    setError(null);
    setVisual(null);
    setIsValidated(false);

    let parsedData: Record<string, unknown> = {};
    try {
      parsedData = donnees.trim() ? (JSON.parse(donnees) as Record<string, unknown>) : {};
    } catch {
      setError("Le champ donnees doit etre un JSON valide.");
      setIsLoading(false);
      return;
    }

    try {
      const response = await fetch("/api/visuals/generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          type,
          titre,
          contenu,
          donnees: parsedData
        })
      });
      const payload = (await response.json()) as ApiResponse;

      if (!response.ok) {
        setError(payload.error ?? "Erreur pendant la generation du visuel.");
        return;
      }

      if (payload.visual) {
        const generatedVisual = payload.visual;
        setVisual(generatedVisual);
        setHistory((current) => [
          {
            id: generatedVisual.id,
            titre: generatedVisual.titre,
            type: generatedVisual.type,
            date: new Date().toISOString().slice(0, 10)
          },
          ...current
        ]);
      }
    } catch {
      setError("Impossible de contacter l'API interne.");
    } finally {
      setIsLoading(false);
    }
  }

  function validateVisual() {
    if (!visual) return;
    setIsValidated(true);
  }

  function exportSvg() {
    if (!visual) return;
    downloadBlob(`${slugify(visual.titre)}.svg`, visual.svg, "image/svg+xml;charset=utf-8");
  }

  async function exportPng() {
    if (!visual) return;

    const image = new Image();
    const svgBlob = new Blob([visual.svg], { type: "image/svg+xml;charset=utf-8" });
    const url = URL.createObjectURL(svgBlob);

    await new Promise<void>((resolve, reject) => {
      image.onload = () => resolve();
      image.onerror = () => reject(new Error("Image load failed"));
      image.src = url;
    });

    const canvas = document.createElement("canvas");
    canvas.width = visual.resolution.width;
    canvas.height = visual.resolution.height;
    const context = canvas.getContext("2d");
    if (!context) {
      URL.revokeObjectURL(url);
      setError("Export PNG indisponible dans ce navigateur.");
      return;
    }

    context.drawImage(image, 0, 0);
    URL.revokeObjectURL(url);

    canvas.toBlob((blob) => {
      if (!blob) {
        setError("Impossible de produire le PNG.");
        return;
      }
      downloadBlob(`${slugify(visual.titre)}.png`, blob, "image/png");
    }, "image/png");
  }

  function exportPdf() {
    if (!visual) return;
    const html = `<!doctype html><html><head><meta charset="utf-8"><title>${escapeHtml(visual.titre)}</title><style>body{margin:0;background:#0b0b0b;display:grid;place-items:center;min-height:100vh}@media print{body{background:#fff}}</style></head><body>${visual.svg}<script>window.onload=()=>window.print()</script></body></html>`;
    const blob = new Blob([html], { type: "text/html;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    window.open(url, "_blank", "noopener,noreferrer");
  }

  return (
    <main className="min-h-screen bg-ink px-5 py-8 text-neutral-100">
      <section className="mx-auto max-w-7xl space-y-6">
        <header className="border-b border-line pb-5">
          <p className="text-xs font-semibold uppercase tracking-[0.24em] text-gold">Valeurs Africaines Editorial OS</p>
          <h1 className="mt-3 text-3xl font-semibold text-gold-soft">Cartographie & Infographies IA</h1>
          <p className="mt-2 max-w-3xl text-sm leading-6 text-neutral-400">
            Transformer articles, Research Briefs et Notes pays en visuels strategiques exploitables pour le site, LinkedIn, newsletter et rapports PDF.
          </p>
        </header>

        <section className="grid grid-cols-[380px_minmax(0,1fr)] gap-5 max-xl:grid-cols-1">
          <aside className="space-y-5">
            <div className="rounded-lg border border-line bg-panel p-4">
              <h2 className="font-semibold text-gold-soft">Liste des visuels</h2>
              <div className="mt-4 grid gap-3">
                <input
                  value={search}
                  onChange={(event) => setSearch(event.target.value)}
                  placeholder="Rechercher"
                  className="w-full rounded-md border border-line bg-black px-3 py-2 text-sm text-neutral-100 outline-none focus:border-gold"
                />
                <select
                  value={filterType}
                  onChange={(event) => setFilterType(event.target.value as "all" | VisualType)}
                  className="w-full rounded-md border border-line bg-black px-3 py-2 text-sm text-neutral-100 outline-none focus:border-gold"
                >
                  <option value="all">Tous les types</option>
                  {VISUAL_TYPE_OPTIONS.map((option) => (
                    <option key={option.value} value={option.value}>{option.label}</option>
                  ))}
                </select>
              </div>
              <div className="mt-4 space-y-2">
                {filteredHistory.map((item) => (
                  <div key={item.id} className="rounded-md border border-line bg-black/20 px-3 py-2 text-sm">
                    <div className="font-semibold text-neutral-100">{item.titre}</div>
                    <div className="mt-1 flex justify-between gap-3 text-xs text-neutral-400">
                      <span>{labelForType(item.type)}</span>
                      <span>{formatDisplayDate(item.date)}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <form onSubmit={generate} className="rounded-lg border border-line bg-panel p-4">
              <h2 className="font-semibold text-gold-soft">Créer un visuel</h2>
              <div className="mt-4 space-y-3">
                <Field label="Type">
                  <select value={type} onChange={(event) => setType(event.target.value as VisualType)} className="w-full rounded-md border border-line bg-black px-3 py-2 text-sm text-neutral-100 outline-none focus:border-gold">
                    {VISUAL_TYPE_OPTIONS.map((option) => (
                      <option key={option.value} value={option.value}>{option.label}</option>
                    ))}
                  </select>
                </Field>
                <Field label="Titre">
                  <input value={titre} onChange={(event) => setTitre(event.target.value)} className="w-full rounded-md border border-line bg-black px-3 py-2 text-sm text-neutral-100 outline-none focus:border-gold" />
                </Field>
                <Field label="Contenu editorial">
                  <textarea value={contenu} onChange={(event) => setContenu(event.target.value)} className="min-h-40 w-full rounded-md border border-line bg-black px-3 py-2 text-sm text-neutral-100 outline-none focus:border-gold" />
                </Field>
                <Field label="Donnees JSON">
                  <textarea value={donnees} onChange={(event) => setDonnees(event.target.value)} className="min-h-32 w-full rounded-md border border-line bg-black px-3 py-2 font-mono text-xs text-neutral-100 outline-none focus:border-gold" />
                </Field>
                <button type="submit" disabled={isLoading} className="w-full rounded-md bg-gold px-4 py-2.5 font-bold text-black disabled:opacity-50">
                  {isLoading ? "Analyse..." : "Créer un visuel"}
                </button>
              </div>
            </form>
          </aside>

          <section className="rounded-lg border border-line bg-panel">
            <div className="flex items-center justify-between gap-3 border-b border-line bg-[#171717] px-4 py-3 max-lg:grid">
              <div>
                <h2 className="font-semibold text-gold-soft">Prévisualisation</h2>
                <p className="text-sm text-neutral-400">Brouillon visuel uniquement. Validation humaine obligatoire avant diffusion.</p>
              </div>
              <div className="flex flex-wrap gap-2">
                <button onClick={exportPng} disabled={!visual} className="rounded-md border border-line px-3 py-2 text-sm font-semibold text-neutral-100 hover:border-gold disabled:opacity-50">Export PNG</button>
                <button onClick={exportSvg} disabled={!visual} className="rounded-md border border-line px-3 py-2 text-sm font-semibold text-neutral-100 hover:border-gold disabled:opacity-50">Export SVG</button>
                <button onClick={exportPdf} disabled={!visual} className="rounded-md border border-line px-3 py-2 text-sm font-semibold text-neutral-100 hover:border-gold disabled:opacity-50">Export PDF</button>
                <button onClick={validateVisual} disabled={!visual} className="rounded-md bg-gold px-3 py-2 text-sm font-bold text-black disabled:opacity-50">Validation</button>
              </div>
            </div>

            {error ? <div className="m-4 rounded-md border border-red-400/40 bg-red-400/10 p-3 text-sm text-red-100">{error}</div> : null}
            {isValidated ? <div className="m-4 rounded-md border border-green-400/40 bg-green-400/10 p-3 text-sm text-green-100">Visuel valide humainement. Aucune publication automatique n'a ete effectuee.</div> : null}

            {visual ? (
              <div className="grid grid-cols-4 gap-3 border-b border-line p-4 max-lg:grid-cols-2 max-sm:grid-cols-1">
                <Metric label="Type" value={labelForType(visual.type)} />
                <Metric label="Confiance" value={`${visual.confidence_score}/100`} />
                <Metric label="Resolution" value={`${visual.resolution.width}x${visual.resolution.height}`} />
                <Metric label="Formats" value={visual.export_formats.join(" · ")} />
              </div>
            ) : null}

            <div className="grid grid-cols-[minmax(0,1fr)_320px] gap-4 p-4 max-lg:grid-cols-1">
              <div className="min-h-[560px] overflow-auto rounded-md border border-line bg-black/30 p-4">
                {visual ? (
                  <div className="mx-auto max-w-full" dangerouslySetInnerHTML={{ __html: visual.svg }} />
                ) : (
                  <div className="grid min-h-[520px] place-items-center text-center text-sm text-neutral-500">
                    Le visuel apparaitra ici apres analyse du contenu.
                  </div>
                )}
              </div>

              <aside className="space-y-4">
                <div className="rounded-md border border-line bg-black/20 p-4">
                  <h3 className="font-semibold text-gold-soft">Structure detectee</h3>
                  <div className="mt-3 space-y-2">
                    {visual ? visual.structure.map((item) => (
                      <div key={`${item.label}-${item.value}`} className="rounded border border-line p-2 text-sm">
                        <div className="font-semibold text-gold">{item.label}</div>
                        <div className="mt-1 text-neutral-300">{item.value}</div>
                      </div>
                    )) : <p className="text-sm text-neutral-500">Aucune structure chargee.</p>}
                  </div>
                </div>

                <div className="rounded-md border border-line bg-black/20 p-4">
                  <h3 className="font-semibold text-gold-soft">Propositions visuelles</h3>
                  <div className="mt-3 space-y-2">
                    {visual ? visual.suggestions.map((suggestion) => (
                      <div key={suggestion.type} className="rounded border border-line p-2 text-sm">
                        <div className="font-semibold text-neutral-100">{suggestion.label}</div>
                        <div className="mt-1 text-neutral-400">{suggestion.reason}</div>
                      </div>
                    )) : <p className="text-sm text-neutral-500">Les propositions seront generees avec le visuel.</p>}
                  </div>
                </div>
              </aside>
            </div>
          </section>
        </section>
      </section>
    </main>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="block text-sm">
      <span className="mb-1 block font-semibold text-gold">{label}</span>
      {children}
    </label>
  );
}

function Metric({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-md border border-line bg-black/20 p-3">
      <div className="text-lg font-bold text-gold-soft">{value}</div>
      <div className="text-xs text-neutral-400">{label}</div>
    </div>
  );
}

function downloadBlob(fileName: string, content: BlobPart | Blob, type: string) {
  const blob = content instanceof Blob ? content : new Blob([content], { type });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = fileName;
  document.body.appendChild(link);
  link.click();
  link.remove();
  URL.revokeObjectURL(url);
}

function slugify(value: string): string {
  return value
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-|-$/g, "")
    .slice(0, 80) || "visuel-valeurs-africaines";
}

function labelForType(type: VisualType): string {
  const labels: Record<VisualType, string> = {
    chronologie: "Chronologie",
    carte_acteurs: "Carte d'acteurs",
    carte_influence: "Carte d'influence",
    carte_pays: "Carte pays",
    diagramme_strategique: "Diagramme strategique",
    flux: "Flux",
    infographie_donnees: "Infographie donnees"
  };
  return labels[type];
}

function escapeHtml(value: string): string {
  return value
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}
