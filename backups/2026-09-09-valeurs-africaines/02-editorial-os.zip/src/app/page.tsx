import { redirect } from "next/navigation";

/** Interface unique : tout mène au poste de pilotage. */
export default function HomePage() {
  redirect("/comite-redaction");
}
