import type { ReactNode } from "react";
import { AlertTriangle, Bot, CalendarDays, CheckCircle2, ClipboardList, LockKeyhole, ShieldCheck, Sparkles } from "lucide-react";
import { getChiefEditorialState, getChiefStatusJsonExample, runChiefBriefCommand, runChiefWeeklyCommand, type ChiefScores } from "@/lib/chiefEditorialOfficer";
import { WorkflowBridge } from "@/lib/editorialWorkflowState";

export default async function ChiefEditorPage() {
  const state = await getChiefEditorialState();
  const chiefBrief = await runChiefBriefCommand();
  const chiefWeekly = await runChiefWeeklyCommand();
  const chiefStatus = await getChiefStatusJsonExample();

  return (
    <main className="min-h-screen bg-ink px-5 py-8 text-neutral-100">
      <section className="mx-auto max-w-7xl space-y-6">
        <header className="flex items-start justify-between gap-5 border-b border-line pb-5 max-lg:grid">
          <div>
            <p className="text-xs font-semibold uppercase tracking-[0.24em] text-gold">Direction</p>
            <h1 className="mt-3 text-3xl font-semibold text-gold-soft">Directeur de Rédaction IA</h1>
            <p className="mt-2 max-w-4xl text-sm leading-6 text-neutral-400">
              Chief Editorial Officer IA pour prioriser, scorer, coordonner les agents et préparer les décisions éditoriales. Aucune publication automatique.
            </p>
            {state.snapshot.mockData && (
              <p className="mt-2 text-xs text-neutral-500">Données locales de démonstration (mock) — aucune source externe appelée.</p>
            )}
          </div>
          <div className="rounded-md border border-red-400/30 bg-red-400/10 px-3 py-2 text-sm font-semibold text-red-100">
            Validation humaine obligatoire
          </div>
        </header>

        {state.publicationBlocked && (
          <div className="flex items-center gap-3 rounded-md border border-red-400/40 bg-red-400/10 px-4 py-3 text-sm font-semibold text-red-100">
            <LockKeyhole size={18} className="shrink-0" />
            <span>Publication bloquée — {state.publicationBlocked.reason}</span>
          </div>
        )}

        <section className="grid gap-4 md:grid-cols-4">
          <Kpi icon={<Sparkles size={18} />} title="Priorités du jour" value={`${state.dailyPriorities.length}/3`} />
          <Kpi icon={<ClipboardList size={18} />} title="Planning recommandé" value={String(state.planning.length)} />
          <Kpi icon={<AlertTriangle size={18} />} title="Alertes éditoriales" value={String(state.alerts.length)} />
          <Kpi icon={<CheckCircle2 size={18} />} title="En validation" value={String(state.pendingValidation)} />
        </section>

        <section className="grid gap-4 xl:grid-cols-5">
          <MetricCard title="Sources connectées" value={String(state.snapshot.connectedSources.length)} items={state.snapshot.connectedSources} empty="Source non connectée" />
          <MetricCard title="Sources manquantes" value={String(state.snapshot.missingSources.length)} items={state.snapshot.missingSources} empty="Aucune source manquante" tone="warning" />
          <MetricCard title="Couverture éditoriale" value={`${state.snapshot.coverageReport.coveredCountries.length} pays`} items={state.snapshot.coverageReport.coveredCountries.slice(0, 6)} empty="Source non connectée" />
          <MetricCard title="Alertes stratégiques" value={String(state.snapshot.strategicAlerts.length)} items={state.snapshot.strategicAlerts.map((alert) => alert.label)} empty="Aucune alerte" tone="warning" />
          <MetricCard title="Contenus prioritaires" value={String(state.dailyPriorities.length)} items={state.dailyPriorities.map((subject) => subject.title)} empty="Source non connectée" />
        </section>

        <section className="grid gap-6 xl:grid-cols-[minmax(0,1fr)_360px]">
          <Panel title="Sujet prioritaire & décision">
            {state.leadingSubject ? (
              <article className="rounded-md border border-gold/30 bg-gold/5 p-5">
                <div className="flex items-start justify-between gap-4">
                  <div>
                    <h2 className="text-lg font-semibold text-gold-soft">{state.leadingSubject.title}</h2>
                    <p className="mt-2 text-sm leading-6 text-neutral-400">{state.leadingSubject.summary}</p>
                  </div>
                  <Score value={state.leadingSubject.score} />
                </div>
                <div className="mt-4 grid gap-3 md:grid-cols-2">
                  <DecisionBlock label="Décision recommandée" value={state.leadingSubject.decision} />
                  <DecisionBlock label="Agent responsable" value={state.leadingSubject.responsibleAgent} />
                  <DecisionBlock label="Prochaine action" value={state.leadingSubject.nextAction} wide />
                  <DecisionBlock
                    label="Publication"
                    value={state.leadingSubject.publicationBlocked ? `Bloquée — ${state.leadingSubject.publicationBlocked.reason}` : "Autorisée (validation humaine enregistrée)"}
                    wide
                    tone={state.leadingSubject.publicationBlocked ? "danger" : "ok"}
                  />
                </div>
                <ScoresBreakdown scores={state.leadingSubject.scores} />
              </article>
            ) : (
              <Empty text="Aucun sujet prioritaire identifiable. Connecter veille stratégique, signaux faibles, planning éditorial et Knowledge Hub avant recommandation nominative." />
            )}
          </Panel>

          <Panel title="Recommandation forte">
            <p className="text-sm leading-6 text-neutral-300">{state.strongRecommendation}</p>
            <div className="mt-5 space-y-2">
              {state.sourcesMissing.map((source) => (
                <div key={source} className="rounded-md border border-red-400/20 bg-red-400/10 px-3 py-2 text-sm text-red-100">
                  {source}
                </div>
              ))}
            </div>
          </Panel>
        </section>

        <section className="grid gap-6 xl:grid-cols-[minmax(0,1fr)_360px]">
          <Panel title="Priorités du jour">
            <div className="space-y-3">
              {state.dailyPriorities.length > 0 ? state.dailyPriorities.map((subject) => (
                <article key={subject.id} className="rounded-md border border-line bg-black/20 p-4">
                  <div className="flex items-start justify-between gap-4">
                    <div>
                      <h2 className="font-semibold text-gold-soft">{subject.title}</h2>
                      <p className="mt-2 text-sm leading-6 text-neutral-400">{subject.summary}</p>
                    </div>
                    <Score value={subject.score} />
                  </div>
                  <div className="mt-3 flex flex-wrap gap-2 text-xs">
                    <Badge>{subject.priority}</Badge>
                    <Badge>{subject.source}</Badge>
                    <Badge>{subject.rubric}</Badge>
                    <Badge>{subject.responsibleAgent}</Badge>
                    <Badge>{subject.decision}</Badge>
                    {subject.publicationBlocked && <Badge danger>Publication bloquée</Badge>}
                    {subject.formats.map((format) => <Badge key={format}>{format}</Badge>)}
                  </div>
                  <p className="mt-3 text-xs text-neutral-500">Prochaine action : {subject.nextAction}</p>
                  <p className="mt-1 text-xs text-neutral-500">Doublons : {subject.duplicateRisk}</p>
                  <ScoresBreakdown scores={subject.scores} compact />
                </article>
              )) : (
                <Empty text="Aucune priorité sourcée disponible. Connecter veille stratégique, signaux faibles, planning éditorial et Knowledge Hub avant recommandation nominative." />
              )}
            </div>
          </Panel>

          <Panel title="Verrou publication">
            {state.publicationBlocked ? (
              <div className="space-y-3">
                <div className="flex items-start gap-3 rounded-md border border-red-400/30 bg-red-400/10 p-3 text-sm text-red-100">
                  <LockKeyhole size={16} className="mt-0.5 shrink-0" />
                  <span>{state.publicationBlocked.reason}</span>
                </div>
                <p className="text-xs leading-5 text-neutral-500">
                  Déverrouillage : validation humaine enregistrée sur chaque sujet prioritaire (statut « en validation » puis « validé ») avant toute
                  publication ou archivage.
                </p>
              </div>
            ) : (
              <div className="flex items-start gap-3 rounded-md border border-emerald-400/30 bg-emerald-400/10 p-3 text-sm text-emerald-100">
                <ShieldCheck size={16} className="mt-0.5 shrink-0" />
                <span>Validation humaine enregistrée : la publication est autorisée sur les sujets validés.</span>
              </div>
            )}
          </Panel>
        </section>

        <Panel title="État comité de rédaction (temps réel)">
          <WorkflowBridge
            subjects={[...state.dailyPriorities, ...state.secondarySubjects].map((subject) => ({ id: subject.id, title: subject.title }))}
          />
        </Panel>

        <section className="grid gap-6 xl:grid-cols-2">
          <Panel title="Coordination des agents">
            <div className="grid gap-3">
              {state.agents.map((agent) => (
                <article key={agent.agent} className="rounded-md border border-line bg-black/20 p-4">
                  <div className="flex items-center justify-between gap-3">
                    <div className="flex items-center gap-3">
                      <Bot size={18} className="text-gold" />
                      <div>
                        <h2 className="font-semibold text-gold-soft">{agent.agent}</h2>
                        <p className="text-xs text-neutral-500">{agent.role}</p>
                      </div>
                    </div>
                    <Badge>{agent.status}</Badge>
                  </div>
                  <p className="mt-3 text-sm text-neutral-400">{agent.currentTask}</p>
                </article>
              ))}
            </div>
          </Panel>

          <Panel title="Workflow orchestré">
            <div className="grid gap-2 text-sm text-neutral-300">
              {["veille", "vérification", "scoring", "analyse", "rédaction", "proposition visuelle", "validation humaine", "archivage"].map((step, index) => (
                <div key={step} className="flex items-center gap-3 rounded-md border border-line bg-black/20 px-3 py-2">
                  <span className="grid h-7 w-7 place-items-center rounded-md border border-gold/40 text-xs text-gold-soft">{index + 1}</span>
                  <span>{step}</span>
                </div>
              ))}
            </div>
          </Panel>
        </section>

        <section className="grid gap-6 xl:grid-cols-2">
          <Panel title="Couverture éditoriale">
            <div className="grid gap-4 md:grid-cols-2">
              <CoverageList title="Pays couverts" items={state.snapshot.coverageReport.coveredCountries} />
              <CoverageList title="Pays absents" items={state.snapshot.coverageReport.absentCountries} />
              <CoverageList title="Thèmes couverts" items={state.snapshot.coverageReport.coveredThemes.slice(0, 12)} />
              <CoverageList title="Thèmes absents" items={state.snapshot.coverageReport.absentThemes} />
            </div>
          </Panel>
          <Panel title="/chief-status">
            <pre className="max-h-[420px] overflow-auto whitespace-pre-wrap rounded-md border border-line bg-black/25 p-4 text-sm leading-6 text-neutral-300">{chiefStatus}</pre>
          </Panel>
        </section>

        <Panel title="Planning recommandé">
          <div className="overflow-x-auto">
            <table className="w-full min-w-[980px] text-sm">
              <thead className="text-left text-xs uppercase tracking-[0.16em] text-neutral-500">
                <tr>
                  <th className="py-2">Période</th>
                  <th>Sujet</th>
                  <th>Format</th>
                  <th>Priorité</th>
                  <th>Rubrique</th>
                  <th>Pays</th>
                  <th>Statut</th>
                  <th>Agent</th>
                  <th>Validation</th>
                </tr>
              </thead>
              <tbody>
                {state.planning.map((row) => (
                  <tr key={`${row.period}-${row.subject}`} className="border-t border-line text-neutral-300">
                    <td className="py-3">{row.period}</td>
                    <td>{row.subject}</td>
                    <td>{row.format}</td>
                    <td>{row.priority}</td>
                    <td>{row.rubric}</td>
                    <td>{row.countries.length ? row.countries.join(", ") : "A vérifier"}</td>
                    <td>{row.status}</td>
                    <td>{row.responsibleAgent}</td>
                    <td>requise</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Panel>

        <section className="grid gap-6 xl:grid-cols-2">
          <Panel title="/chief-brief">
            <pre className="max-h-[520px] overflow-auto whitespace-pre-wrap rounded-md border border-line bg-black/25 p-4 text-sm leading-6 text-neutral-300">{chiefBrief}</pre>
          </Panel>
          <Panel title="/chief-weekly">
            <pre className="max-h-[520px] overflow-auto whitespace-pre-wrap rounded-md border border-line bg-black/25 p-4 text-sm leading-6 text-neutral-300">{chiefWeekly}</pre>
          </Panel>
        </section>

        <Panel title="Alertes éditoriales">
          <div className="grid gap-3 md:grid-cols-2">
            {state.alerts.map((alert) => (
              <div key={alert} className="flex items-start gap-3 rounded-md border border-line bg-black/20 p-3 text-sm text-neutral-300">
                <ShieldCheck size={16} className="mt-0.5 shrink-0 text-gold" />
                <span>{alert}</span>
              </div>
            ))}
          </div>
        </Panel>
      </section>
    </main>
  );
}

function Kpi({ icon, title, value }: { icon: ReactNode; title: string; value: string }) {
  return (
    <article className="rounded-lg border border-gold/20 bg-panel p-5">
      <div className="flex items-center gap-2 text-gold">{icon}<p className="text-xs font-semibold uppercase tracking-[0.16em]">{title}</p></div>
      <p className="mt-3 text-3xl font-semibold text-gold-soft">{value}</p>
    </article>
  );
}

function Panel({ title, children }: { title: string; children: ReactNode }) {
  return (
    <section className="rounded-lg border border-line bg-panel p-5">
      <div className="flex items-center gap-2">
        <CalendarDays size={16} className="text-gold" />
        <p className="text-xs font-semibold uppercase tracking-[0.22em] text-gold">{title}</p>
      </div>
      <div className="mt-4">{children}</div>
    </section>
  );
}

function Badge({ children, danger = false }: { children: ReactNode; danger?: boolean }) {
  return danger
    ? <span className="rounded-md border border-red-400/40 bg-red-400/10 px-2 py-1 text-red-100">{children}</span>
    : <span className="rounded-md border border-gold/25 bg-gold/10 px-2 py-1 text-gold-soft">{children}</span>;
}

function DecisionBlock({ label, value, wide = false, tone = "default" }: { label: string; value: string; wide?: boolean; tone?: "default" | "danger" | "ok" }) {
  const color = tone === "danger" ? "border-red-400/30 bg-red-400/10 text-red-100" : tone === "ok" ? "border-emerald-400/30 bg-emerald-400/10 text-emerald-100" : "border-line bg-black/20 text-neutral-300";
  return (
    <div className={`rounded-md border px-3 py-2 ${color} ${wide ? "md:col-span-2" : ""}`}>
      <p className="text-[11px] font-semibold uppercase tracking-[0.16em] text-gold">{label}</p>
      <p className="mt-1 text-sm">{value}</p>
    </div>
  );
}

function ScoresBreakdown({ scores, compact = false }: { scores: ChiefScores; compact?: boolean }) {
  const entries: Array<[string, number]> = [
    ["Urgence", scores.urgence],
    ["Impact africain", scores.impactAfricain],
    ["Qualité sources", scores.qualiteSources],
    ["Risque éditorial", scores.risqueEditorial],
    ["Adéquation ligne VA", scores.adequationLigneVA]
  ];
  return (
    <div className={`mt-4 space-y-2 ${compact ? "" : "rounded-md border border-line bg-black/20 p-4"}`}>
      {entries.map(([label, value]) => (
        <div key={label} className="flex items-center gap-3 text-xs">
          <span className="w-32 shrink-0 text-neutral-500">{label}</span>
          <div className="h-1.5 flex-1 overflow-hidden rounded-full bg-black/40">
            <div className="h-full rounded-full bg-gold" style={{ width: `${Math.min(100, (value / 20) * 100)}%` }} />
          </div>
          <span className="w-10 shrink-0 text-right font-semibold text-gold-soft">{value}/20</span>
        </div>
      ))}
    </div>
  );
}

function MetricCard({ title, value, items, empty, tone = "default" }: { title: string; value: string; items: string[]; empty: string; tone?: "default" | "warning" }) {
  const color = tone === "warning" ? "border-red-400/30 bg-red-400/10 text-red-100" : "border-line bg-panel text-neutral-300";
  return (
    <article className={`rounded-lg border p-4 ${color}`}>
      <p className="text-xs font-semibold uppercase tracking-[0.16em] text-gold">{title}</p>
      <p className="mt-2 text-2xl font-semibold text-gold-soft">{value}</p>
      <div className="mt-3 space-y-1 text-xs">
        {items.length > 0 ? items.slice(0, 6).map((item) => <p key={item}>{item}</p>) : <p>{empty}</p>}
      </div>
    </article>
  );
}

function CoverageList({ title, items }: { title: string; items: string[] }) {
  return (
    <div className="rounded-md border border-line bg-black/20 p-4">
      <p className="font-semibold text-gold-soft">{title}</p>
      <div className="mt-3 space-y-1 text-sm text-neutral-400">
        {items.length > 0 ? items.map((item) => <p key={item}>{item}</p>) : <p>Source non connectée</p>}
      </div>
    </div>
  );
}

function Score({ value }: { value: number }) {
  return <div className="grid h-16 w-16 place-items-center rounded-full border border-gold/40 bg-gold/10 text-lg font-bold text-gold-soft">{value}</div>;
}

function Empty({ text }: { text: string }) {
  return <div className="rounded-md border border-line bg-black/20 p-4 text-sm leading-6 text-neutral-400">{text}</div>;
}
