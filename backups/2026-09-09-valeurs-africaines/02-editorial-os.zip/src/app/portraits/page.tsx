"use client";

import { FormEvent, useState } from "react";
import type { PortraitVisualProposal } from "@/lib/portraits";

type PortraitResponse = {
  portrait?: string;
  sources_a_verifier?: string[];
  niveau_confiance?: string;
  validation_humaine_requise?: boolean;
  visual_proposals?: PortraitVisualProposal[];
  error?: string;
};

const sections = [
  "Portrait de la semaine",
  "Chercheurs africains",
  "Innovateurs",
  "Femmes scientifiques",
  "Diaspora académique",
  "Jeunes talents",
  "Grandes universités",
  "Prix, distinctions et publications"
];

export default function PortraitsPage() {
  const [nom, setNom] = useState("");
  const [pays, setPays] = useState("");
  const [domaine, setDomaine] = useState("");
  const [institution, setInstitution] = useState("");
  const [fonction, setFonction] = useState("");
  const [sources, setSources] = useState("");
  const [result, setResult] = useState<PortraitResponse | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  async function generate(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setIsLoading(true);
    setError(null);
    setResult(null);

    try {
      const response = await fetch("/api/portraits/generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ nom, pays, domaine, institution, fonction, sources: splitList(sources) })
      });
      const payload = (await response.json()) as PortraitResponse;

      if (!response.ok) {
        setError(payload.error ?? "Erreur pendant la génération du portrait.");
        return;
      }

      setResult(payload);
    } catch {
      setError("Impossible de contacter l'API interne.");
    } finally {
      setIsLoading(false);
    }
  }

  return (
    <main className="min-h-screen bg-ink px-5 py-8 text-neutral-100">
      <section className="mx-auto max-w-7xl space-y-6">
        <header className="border-b border-line pb-5">
          <p className="text-xs font-semibold uppercase tracking-[0.24em] text-gold">Portraits d'excellence</p>
          <h1 className="mt-3 text-3xl font-semibold text-gold-soft">Portrait de la semaine — Savoirs africains</h1>
          <p className="mt-2 max-w-3xl text-sm leading-6 text-neutral-400">
            Chaque semaine, mettre en lumière une personnalité africaine ou afro-descendante contribuant à la recherche, l'innovation, l'enseignement supérieur, la technologie, la médecine, l'économie, les sciences humaines ou la gouvernance.
          </p>
        </header>

        <section className="grid grid-cols-4 gap-3 max-lg:grid-cols-2 max-sm:grid-cols-1">
          {sections.map((section) => (
            <div key={section} className="rounded-lg border border-line bg-panel p-4">
              <h2 className="text-sm font-semibold text-gold-soft">{section}</h2>
            </div>
          ))}
        </section>

        {error ? <div className="rounded-lg border border-red-400/40 bg-red-400/10 p-4 text-sm text-red-100">{error}</div> : null}

        <section className="grid grid-cols-[360px_minmax(0,1fr)] gap-5 max-lg:grid-cols-1">
          <form onSubmit={generate} className="rounded-lg border border-line bg-panel p-4">
              <h2 className="font-semibold text-gold-soft">Créer un portrait</h2>
            <Field label="Nom"><input value={nom} onChange={(event) => setNom(event.target.value)} className={fieldClass} placeholder="Nom complet" /></Field>
            <Field label="Pays"><input value={pays} onChange={(event) => setPays(event.target.value)} className={fieldClass} placeholder="Pays" /></Field>
            <Field label="Domaine"><input value={domaine} onChange={(event) => setDomaine(event.target.value)} className={fieldClass} placeholder="IA, médecine, économie..." /></Field>
            <Field label="Institution"><input value={institution} onChange={(event) => setInstitution(event.target.value)} className={fieldClass} placeholder="Université, laboratoire, institution" /></Field>
            <Field label="Fonction"><input value={fonction} onChange={(event) => setFonction(event.target.value)} className={fieldClass} placeholder="Professeur, chercheuse, ingénieur, médecin..." /></Field>
            <Field label="Sources"><textarea value={sources} onChange={(event) => setSources(event.target.value)} className={`${fieldClass} min-h-24`} placeholder="CV, page institutionnelle, publication, interview..." /></Field>
            <button type="submit" disabled={isLoading} className="mt-4 w-full rounded-md bg-gold px-4 py-2.5 font-bold text-black disabled:opacity-50">
              {isLoading ? "Génération..." : "Générer portrait"}
            </button>
            <div className="mt-4 rounded-md border border-red-400/30 bg-red-400/10 p-3 text-xs leading-5 text-red-100">
              1 portrait par semaine. Aucune publication automatique. L'utilisateur choisit A, B ou C avant intégration du visuel. Validation humaine obligatoire.
            </div>
          </form>

          <section className="space-y-5">
            <article className="rounded-lg border border-line bg-panel">
              <div className="flex items-center justify-between gap-3 border-b border-line bg-[#171717] px-4 py-3">
                <div>
                  <h2 className="font-semibold text-gold-soft">Portrait de la semaine</h2>
                  <p className="text-sm text-neutral-400">Intégré à l'édition stratégique hebdomadaire et archivé dans le Knowledge Hub après validation.</p>
                </div>
                <div className="text-right text-xs text-neutral-400">
                  <div>Confiance : {result?.niveau_confiance ?? "-"}</div>
                  <div>Validation : {result?.validation_humaine_requise ? "requise" : "-"}</div>
                </div>
              </div>
              <pre className="max-h-[680px] min-h-[420px] overflow-auto whitespace-pre-wrap p-5 text-sm leading-6 text-neutral-200">
                {result?.portrait ?? "Le portrait apparaîtra ici."}
              </pre>
            </article>

            {result?.visual_proposals ? (
              <section className="grid grid-cols-3 gap-3 max-xl:grid-cols-1">
                {result.visual_proposals.map((visual) => (
                  <article key={visual.id} className="rounded-lg border border-line bg-panel p-4">
                    <p className="text-xs font-semibold uppercase tracking-[0.18em] text-gold">{visual.type}</p>
                    <h3 className="mt-2 font-semibold text-gold-soft">{visual.title}</h3>
                    <p className="mt-2 text-sm leading-6 text-neutral-300">{visual.description}</p>
                    <p className="mt-3 rounded-md border border-line bg-black/20 p-3 text-xs leading-5 text-neutral-300">{visual.prompt}</p>
                    <p className="mt-3 text-xs text-red-100">{visual.rightsNote}</p>
                  </article>
                ))}
              </section>
            ) : null}
          </section>
        </section>
      </section>
    </main>
  );
}

const fieldClass = "w-full rounded-md border border-line bg-black px-3 py-2 text-sm text-neutral-100 outline-none focus:border-gold";

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="mt-3 block text-sm">
      <span className="mb-1 block font-semibold text-gold">{label}</span>
      {children}
    </label>
  );
}

function splitList(value: string): string[] {
  return value.split(/[,;\n]/).map((item) => item.trim()).filter(Boolean);
}
