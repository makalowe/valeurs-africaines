"use client";

import { buildPilotageAlerts, usePilotageData } from "@/lib/usePilotageData";
import { formatDisplayDate } from "@/lib/dateDisplay";

const alertClass: Record<string, string> = {
  Critique: "border-red-400/40 bg-red-400/10 text-red-100",
  Élevé: "border-orange-400/40 bg-orange-400/10 text-orange-100",
  Moyen: "border-gold/40 bg-gold/10 text-gold-soft",
  Faible: "border-green-400/40 bg-green-400/10 text-green-100"
};

export default function NewsroomPage() {
  const { loading, error, dashboard, store, day, refresh } = usePilotageData();
  const watchSubjects = dashboard?.watch.subjects ?? [];
  const reviewDate = dashboard?.review?.date ?? dashboard?.watch.date ?? "";
  const reviewDateLabel = formatDisplayDate(reviewDate);
  const decisions = dashboard?.workflow.decisions ?? {};
  const retainedCount = watchSubjects.length > 0
    ? Object.entries(decisions).filter(([key, value]) => key.startsWith(`veille-${dashboard?.watch.date}-`) && value === "Retenir").length
    : 0;
  const alerts = buildPilotageAlerts(dashboard, day, retainedCount);
  const publishedToday = store?.publishedToday ?? 0;
  const readyUnpublished = (day ?? []).filter((article) => article.publishedId === null && article.ready);

  // Répartition réelle par rubrique (sujets de la veille du jour).
  const rubricCounts = new Map<string, number>();
  for (const subject of watchSubjects) rubricCounts.set(subject.rubric, (rubricCounts.get(subject.rubric) ?? 0) + 1);
  const overview = [...rubricCounts.entries()]
    .map(([label, count]) => ({ label, value: watchSubjects.length > 0 ? Math.round((count / watchSubjects.length) * 100) : 0 }))
    .sort((a, b) => b.value - a.value);

  const countryCounts = new Map<string, number>();
  for (const subject of watchSubjects) {
    for (const country of subject.countries) countryCounts.set(country, (countryCounts.get(country) ?? 0) + 1);
  }
  const countries = [...countryCounts.entries()].sort((a, b) => b[1] - a[1]).map(([country]) => country);

  const domainCounts = new Map<string, number>();
  for (const subject of watchSubjects) {
    for (const url of subject.sourceUrls) {
      const domain = (() => {
        try {
          return new URL(url).hostname.replace(/^www\./, "");
        } catch {
          return "";
        }
      })();
      if (domain) domainCounts.set(domain, (domainCounts.get(domain) ?? 0) + 1);
    }
  }
  const domains = [...domainCounts.entries()].sort((a, b) => b[1] - a[1]).slice(0, 8).map(([domain]) => domain);

  const humanChecks = dashboard?.workflow.humanValidation ?? {};
  const humanChecksDone = Object.values(humanChecks).filter(Boolean).length;
  const humanChecksTotal = Object.keys(humanChecks).length;

  const publicationQueue = [
    { status: "Brouillons du jour", items: (dashboard?.draftsForToday ?? []).slice(0, 6).map((draft) => draft.filename) },
    { status: "Prêts non publiés", items: readyUnpublished.slice(0, 6).map((article) => article.slug) },
    { status: "Validation humaine", items: humanChecksTotal > 0 ? [`${humanChecksDone}/${humanChecksTotal} critère(s) coché(s)`] : ["Aucun critère enregistré"] },
    { status: "Publiés aujourd'hui", items: (store?.latest ?? []).slice(0, 6).map((article) => `#${article.id} · ${article.title.slice(0, 50)}`) }
  ];

  const alertsRows = alerts.map((alert) => ({
    level: alert.startsWith("Aucune alerte") ? "Faible" : "Élevé",
    title: alert.startsWith("Aucune alerte") ? "OK" : "À traiter",
    detail: alert
  }));

  const calendar = [
    { period: "Jour", items: [`${publishedToday} publication(s) locale(s)`, `${dashboard?.draftsForToday.length ?? 0} brouillon(s)`, `${watchSubjects.length} sujet(s) de veille`, `${retainedCount} retenu(s)`] },
    { period: "Semaine", items: dashboard ? [`Édition hebdomadaire : ${dashboard.progress.weekly}%`, dashboard.nextAction.weekly] : ["Donnée à vérifier"] },
    { period: "Mois", items: ["Rapport mensuel : à compiler depuis les archives", "Donnée à vérifier"] }
  ];

  return (
    <main className="min-h-screen bg-ink px-5 py-8 text-neutral-100">
      <section className="mx-auto max-w-[1680px] space-y-6">
        <header className="border-b border-line pb-5">
          <p className="text-xs font-semibold uppercase tracking-[0.24em] text-gold">Valeurs Africaines</p>
          <h1 className="mt-3 text-3xl font-semibold text-gold-soft">AI Newsroom</h1>
          <p className="mt-2 max-w-3xl text-sm leading-6 text-neutral-400">
            Cockpit central branché sur les données réelles (veille, brouillons, publications locales). Aucune publication automatique.
            {reviewDate ? ` Journée de référence : ${reviewDateLabel}.` : ""}
          </p>
          <div className="mt-3 flex flex-wrap items-center gap-2">
            <button onClick={refresh} className="rounded-md border border-gold/40 bg-gold/10 px-3 py-2 text-sm font-semibold text-gold-soft transition hover:bg-gold/20">
              Actualiser
            </button>
            {loading && <span className="text-sm text-neutral-500">Chargement…</span>}
            {error && <span className="rounded-md border border-red-400/30 bg-red-400/10 px-3 py-2 text-sm text-red-100">{error}</span>}
          </div>
        </header>

        <section className="rounded-lg border border-line bg-panel">
          <div className="border-b border-line bg-[#171717] px-4 py-3">
            <h2 className="font-semibold text-gold-soft">Une Afrique en un coup d'œil</h2>
            <p className="text-sm text-neutral-400">Répartition réelle des sujets de la veille du jour par rubrique.</p>
          </div>
          {overview.length > 0 ? (
            <div className="grid gap-3 p-4 md:grid-cols-2 xl:grid-cols-4">
              {overview.map((item) => <ProgressCard key={item.label} label={item.label} value={item.value} />)}
            </div>
          ) : (
            <p className="p-4 text-sm text-neutral-500">Aucune veille détectée — « Donnée à vérifier ».</p>
          )}
        </section>

        <section className="grid grid-cols-[1.1fr_0.9fr] gap-5 max-xl:grid-cols-1">
          <Panel title="File de production (réelle)">
            <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-4">
              {publicationQueue.map((entry) => (
                <article key={entry.status} className="rounded-md border border-line bg-black/20 p-3">
                  <h3 className="font-semibold text-gold-soft">{entry.status}</h3>
                  <div className="mt-3 space-y-2">
                    {entry.items.length > 0 ? (
                      entry.items.map((item) => <p key={item} className="break-all rounded border border-line bg-[#101010] p-2 text-xs leading-4 text-neutral-300">{item}</p>)
                    ) : (
                      <p className="rounded border border-line bg-[#101010] p-2 text-xs text-neutral-500">Aucun élément</p>
                    )}
                  </div>
                </article>
              ))}
            </div>
          </Panel>

          <Panel title="Alertes prioritaires (réelles)">
            <div className="grid gap-3">
              {alertsRows.map((alert) => (
                <article key={alert.detail} className={`rounded-md border p-3 ${alertClass[alert.level]}`}>
                  <p className="text-xs font-bold uppercase tracking-wide">{alert.level}</p>
                  <h3 className="mt-1 font-semibold">{alert.title}</h3>
                  <p className="mt-1 text-sm opacity-90">{alert.detail}</p>
                </article>
              ))}
            </div>
          </Panel>
        </section>

        <section className="grid grid-cols-[0.9fr_1.1fr] gap-5 max-xl:grid-cols-1">
          <Panel title="Pays couverts aujourd'hui (veille réelle)">
            {countries.length > 0 ? (
              <div className="grid min-h-[180px] content-start gap-2 rounded-md border border-line bg-black/30 p-4">
                {countries.map((country) => (
                  <span key={country} className="rounded-full border border-emerald-400/30 bg-emerald-400/5 px-3 py-1 text-xs font-semibold text-emerald-100">
                    {country}
                  </span>
                ))}
              </div>
            ) : (
              <p className="rounded-md border border-line bg-black/30 p-4 text-sm text-neutral-500">Aucun pays détecté — « Donnée à vérifier ».</p>
            )}
          </Panel>

          <Panel title="Sujets de la veille du jour">
            {watchSubjects.length > 0 ? (
              <div className="grid gap-2">
                {watchSubjects.map((subject) => (
                  <p key={`${subject.index}-${subject.title}`} className="rounded-md border border-line bg-black/20 p-3 text-sm text-neutral-300">
                    <span className="mr-2 rounded bg-gold/15 px-1.5 py-0.5 text-[10px] font-bold uppercase tracking-wide text-gold-soft">{subject.rubric.split(",")[0]}</span>
                    {subject.title}
                  </p>
                ))}
              </div>
            ) : (
              <p className="rounded-md border border-line bg-black/20 p-3 text-sm text-neutral-500">Aucune veille détectée.</p>
            )}
          </Panel>
        </section>

        <section className="grid grid-cols-2 gap-5 max-xl:grid-cols-1">
          <Panel title="Agenda éditorial">
            <div className="grid gap-3 md:grid-cols-3">
              {calendar.map((entry) => (
                <article key={entry.period} className="rounded-md border border-line bg-black/20 p-4">
                  <h3 className="font-semibold text-gold-soft">{entry.period}</h3>
                  <ul className="mt-3 space-y-2 text-sm text-neutral-300">
                    {entry.items.map((item) => <li key={item}>{item}</li>)}
                  </ul>
                </article>
              ))}
            </div>
          </Panel>

          <Panel title="Centre de validation">
            <div className="grid gap-3">
              <div className="rounded-md border border-gold/40 bg-gold/10 p-3 text-sm text-gold-soft">
                Workflow : {dashboard?.workflow.workflow ?? "—"} · {dashboard?.nextAction.daily ?? "—"}
              </div>
              <div className="rounded-md border border-red-400/30 bg-red-400/10 p-3 text-sm font-semibold text-red-100">
                Aucun contenu ne peut être publié automatiquement — validation humaine obligatoire.
              </div>
              <div className="rounded-md border border-line bg-black/20 p-3 text-sm text-neutral-300">
                Publication locale uniquement (localhost:5000) — jamais site distant, réseaux, newsletter, Git ou Obsidian sans demande explicite.
              </div>
            </div>
          </Panel>
        </section>

        <section className="grid grid-cols-3 gap-5 max-xl:grid-cols-1">
          <Panel title="Pays de la veille">
            <div className="space-y-2">
              {countries.length > 0 ? countries.slice(0, 10).map((country) => (
                <p key={country} className="rounded-md border border-line bg-black/20 p-3 text-sm text-neutral-300">{country}</p>
              )) : <p className="rounded-md border border-line bg-black/20 p-3 text-sm text-neutral-500">Donnée à vérifier</p>}
            </div>
          </Panel>
          <Panel title="Sources de la veille (domaines)">
            <div className="space-y-2">
              {domains.length > 0 ? domains.map((domain) => (
                <p key={domain} className="break-all rounded-md border border-line bg-black/20 p-3 text-sm text-neutral-300">{domain}</p>
              )) : <p className="rounded-md border border-line bg-black/20 p-3 text-sm text-neutral-500">Donnée à vérifier</p>}
            </div>
          </Panel>
          <Panel title="Derniers articles publiés">
            <div className="space-y-2">
              {store && store.latest.length > 0 ? store.latest.map((article) => (
                <p key={article.id} className="rounded-md border border-line bg-black/20 p-3 text-sm text-neutral-300">
                  <a className="break-all text-gold-soft underline decoration-gold/40 underline-offset-2" href={`http://127.0.0.1:5000/articles/${encodeURIComponent(article.slug)}`} target="_blank" rel="noreferrer">
                    #{article.id} · {article.title}
                  </a>
                </p>
              )) : <p className="rounded-md border border-line bg-black/20 p-3 text-sm text-neutral-500">Aucun article publié détecté.</p>}
            </div>
          </Panel>
        </section>
      </section>
    </main>
  );
}

function ProgressCard({ label, value }: { label: string; value: number }) {
  return (
    <article className="rounded-md border border-line bg-black/20 p-4">
      <div className="flex items-center justify-between gap-3">
        <h3 className="text-sm font-semibold text-gold-soft">{label}</h3>
        <span className="text-sm font-bold text-gold">{value}%</span>
      </div>
      <div className="mt-3 h-2 rounded-full bg-neutral-800">
        <div className="h-full rounded-full bg-gold" style={{ width: `${Math.min(100, Math.max(0, value))}%` }} />
      </div>
    </article>
  );
}

function Panel({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <section className="rounded-lg border border-line bg-panel">
      <div className="border-b border-line bg-[#171717] px-4 py-3">
        <h2 className="font-semibold text-gold-soft">{title}</h2>
      </div>
      <div className="p-4">{children}</div>
    </section>
  );
}
