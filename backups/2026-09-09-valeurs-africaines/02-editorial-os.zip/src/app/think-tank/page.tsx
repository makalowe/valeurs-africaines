"use client";

import { FormEvent, useState } from "react";
import type { ThinkTankType } from "@/lib/thinkTank";

type ThinkTankResponse = {
  draft?: string;
  sources_a_verifier?: string[];
  niveau_confiance?: string;
  validation_humaine_requise?: boolean;
  error?: string;
};

const useCases: Array<{ type: ThinkTankType; title: string; description: string }> = [
  { type: "note-strategique-pays", title: "Notes stratégiques pays", description: "Situation politique, économique, géopolitique et prospective." },
  { type: "barometre-influences", title: "Baromètre des influences étrangères", description: "Puissances extérieures, alliances, dépendances et instruments d'influence." },
  { type: "observatoire-souverainete", title: "Observatoire de la souveraineté africaine", description: "Capacité de décision, autonomie stratégique et dépendances critiques." },
  { type: "indice-souverainete-narrative", title: "Indice de souveraineté narrative", description: "Production des récits, médias, langues et influence informationnelle." },
  { type: "cartographie-elites", title: "Cartographie des élites émergentes", description: "Acteurs, réseaux, trajectoires et nouveaux lieux d'influence." },
  { type: "veille-minerais-critiques", title: "Veille minerais critiques", description: "Chaînes de valeur, compétition industrielle et souveraineté extractive." },
  { type: "observatoire-afrique-brics", title: "Observatoire Afrique-BRICS", description: "Coopérations Sud-Sud, financements, diplomatie économique." },
  { type: "scenario", title: "Scénarios 2030 / 2050", description: "Hypothèses prospectives, variables critiques et trajectoires africaines." }
];

export default function ThinkTankPage() {
  const [type, setType] = useState<ThinkTankType>("note-strategique-pays");
  const [sujet, setSujet] = useState("Sahel 2030 : souveraineté, alliances et recompositions régionales");
  const [pays, setPays] = useState("Mali, Niger, Burkina Faso");
  const [acteurs, setActeurs] = useState("CEDEAO, Union africaine, Russie, BRICS");
  const [themes, setThemes] = useState("Souveraineté, sécurité, influence, ressources");
  const [horizon, setHorizon] = useState("2030");
  const [result, setResult] = useState<ThinkTankResponse | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  async function generate(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setIsLoading(true);
    setError(null);
    setResult(null);

    try {
      const response = await fetch("/api/think-tank/generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          type,
          sujet,
          pays: splitList(pays),
          acteurs: splitList(acteurs),
          themes: splitList(themes),
          horizon
        })
      });
      const payload = (await response.json()) as ThinkTankResponse;

      if (!response.ok) {
        setError(payload.error ?? "Erreur pendant la génération think tank.");
        return;
      }

      setResult(payload);
    } catch {
      setError("Impossible de contacter l'API interne.");
    } finally {
      setIsLoading(false);
    }
  }

  async function copyDraft() {
    if (!result?.draft) return;
    await navigator.clipboard.writeText(result.draft);
  }

  return (
    <main className="min-h-screen bg-ink px-5 py-8 text-neutral-100">
      <section className="mx-auto max-w-7xl space-y-6">
        <header className="border-b border-line pb-5">
          <p className="text-xs font-semibold uppercase tracking-[0.24em] text-gold">Think Tank & Prospective</p>
          <h1 className="mt-3 text-3xl font-semibold text-gold-soft">Production stratégique avancée</h1>
          <p className="mt-2 max-w-3xl text-sm leading-6 text-neutral-400">
            Générer des brouillons analytiques de niveau think tank, à relire, sourcer, valider humainement puis archiver dans le Knowledge Hub.
          </p>
        </header>

        {error ? <div className="rounded-lg border border-red-400/40 bg-red-400/10 p-4 text-sm text-red-100">{error}</div> : null}

        <section className="grid grid-cols-4 gap-3 max-xl:grid-cols-2 max-sm:grid-cols-1">
          {useCases.map((item) => (
            <button
              key={item.type}
              type="button"
              onClick={() => setType(item.type)}
              className={`rounded-lg border p-4 text-left transition ${type === item.type ? "border-gold bg-gold/10" : "border-line bg-panel hover:border-gold/60"}`}
            >
              <h2 className="font-semibold text-gold-soft">{item.title}</h2>
              <p className="mt-2 text-sm leading-6 text-neutral-400">{item.description}</p>
            </button>
          ))}
        </section>

        <section className="grid grid-cols-[380px_minmax(0,1fr)] gap-5 max-xl:grid-cols-1">
          <form onSubmit={generate} className="rounded-lg border border-line bg-panel p-4">
            <h2 className="font-semibold text-gold-soft">Paramètres de génération</h2>
            <div className="mt-4 space-y-3">
              <Field label="Type">
                <select value={type} onChange={(event) => setType(event.target.value as ThinkTankType)} className="w-full rounded-md border border-line bg-black px-3 py-2 text-sm text-neutral-100 outline-none focus:border-gold">
                  {useCases.map((item) => <option key={item.type} value={item.type}>{item.title}</option>)}
                </select>
              </Field>
              <Field label="Sujet">
                <textarea value={sujet} onChange={(event) => setSujet(event.target.value)} className="min-h-20 w-full rounded-md border border-line bg-black px-3 py-2 text-sm text-neutral-100 outline-none focus:border-gold" />
              </Field>
              <Field label="Pays">
                <input value={pays} onChange={(event) => setPays(event.target.value)} className="w-full rounded-md border border-line bg-black px-3 py-2 text-sm text-neutral-100 outline-none focus:border-gold" />
              </Field>
              <Field label="Acteurs">
                <input value={acteurs} onChange={(event) => setActeurs(event.target.value)} className="w-full rounded-md border border-line bg-black px-3 py-2 text-sm text-neutral-100 outline-none focus:border-gold" />
              </Field>
              <Field label="Thèmes">
                <input value={themes} onChange={(event) => setThemes(event.target.value)} className="w-full rounded-md border border-line bg-black px-3 py-2 text-sm text-neutral-100 outline-none focus:border-gold" />
              </Field>
              <Field label="Horizon">
                <input value={horizon} onChange={(event) => setHorizon(event.target.value)} className="w-full rounded-md border border-line bg-black px-3 py-2 text-sm text-neutral-100 outline-none focus:border-gold" />
              </Field>
              <button type="submit" disabled={isLoading} className="w-full rounded-md bg-gold px-4 py-2.5 font-bold text-black disabled:opacity-50">
                {isLoading ? "Génération..." : "Générer le brouillon"}
              </button>
            </div>
            <div className="mt-5 rounded-md border border-red-400/30 bg-red-400/10 p-3 text-xs leading-5 text-red-100">
              Aucune publication automatique. Ne jamais inventer de sources. Validation humaine obligatoire.
            </div>
          </form>

          <section className="rounded-lg border border-line bg-panel">
            <div className="flex items-center justify-between gap-3 border-b border-line bg-[#171717] px-4 py-3 max-sm:grid">
              <div>
                <h2 className="font-semibold text-gold-soft">Brouillon think tank</h2>
                <p className="text-sm text-neutral-400">Compatible Obsidian après validation et archivage Knowledge Hub.</p>
              </div>
              <button onClick={copyDraft} disabled={!result?.draft} className="rounded-md border border-line px-3 py-2 text-sm font-semibold hover:border-gold disabled:opacity-50">Copier</button>
            </div>
            {result ? (
              <div className="grid grid-cols-3 gap-3 border-b border-line p-4 max-md:grid-cols-1">
                <Metric label="Confiance" value={result.niveau_confiance ?? "-"} />
                <Metric label="Sources à vérifier" value={String(result.sources_a_verifier?.length ?? 0)} />
                <Metric label="Validation humaine" value={result.validation_humaine_requise ? "requise" : "-"} />
              </div>
            ) : null}
            <pre className="max-h-[760px] min-h-[540px] overflow-auto whitespace-pre-wrap p-5 text-sm leading-6 text-neutral-200">
              {result?.draft ?? "Le brouillon apparaîtra ici après génération."}
            </pre>
          </section>
        </section>
      </section>
    </main>
  );
}

function splitList(value: string): string[] {
  return value.split(/[,;\n]/).map((item) => item.trim()).filter(Boolean);
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="block text-sm">
      <span className="mb-1 block font-semibold text-gold">{label}</span>
      {children}
    </label>
  );
}

function Metric({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-md border border-line bg-black/20 p-3">
      <div className="text-lg font-bold text-gold-soft">{value}</div>
      <div className="text-xs text-neutral-400">{label}</div>
    </div>
  );
}
