"use client";

import { FormEvent, useEffect, useMemo, useState } from "react";
import type { KnowledgeEntry, KnowledgeEntryType } from "@/lib/knowledgeHub";
import { formatDisplayDate } from "@/lib/dateDisplay";

type ApiListResponse = {
  entries?: KnowledgeEntry[];
  error?: string;
};

type ApiCreateResponse = {
  entry?: KnowledgeEntry;
  error?: string;
};

type DriveArchiveResponse = {
  success?: boolean;
  driveFileUrl?: string;
  driveFolderPath?: string;
  obsidianPath?: string;
  knowledgeHubUpdated?: boolean;
  error?: string;
};

type DriveArchiveStatus = {
  archived: boolean;
  driveFileUrl: string;
  driveFolderPath: string;
  archivedAt: string;
};

const TYPES: Array<{ value: KnowledgeEntryType; label: string }> = [
  { value: "article", label: "Article" },
  { value: "research-brief", label: "Research Brief" },
  { value: "note-pays", label: "Note pays" },
  { value: "signal-faible", label: "Signal faible" },
  { value: "infographie", label: "Infographie" },
  { value: "fiche-pays", label: "Fiche pays" },
  { value: "fiche-acteur", label: "Fiche acteur" },
  { value: "fiche-entreprise", label: "Fiche entreprise" },
  { value: "fiche-organisation", label: "Fiche organisation" },
  { value: "fiche-theme", label: "Fiche theme" },
  { value: "think-tank", label: "Think Tank" },
  { value: "observatoire", label: "Observatoire" },
  { value: "scenario", label: "Scénario" },
  { value: "portrait", label: "Portrait" },
  { value: "chercheur", label: "Chercheur" },
  { value: "innovateur", label: "Innovateur" },
  { value: "conflict-observer", label: "Observatoire conflit" },
  { value: "country-profile", label: "Fiche pays Atlas" }
];

export default function KnowledgePage() {
  const [entries, setEntries] = useState<KnowledgeEntry[]>([]);
  const [selected, setSelected] = useState<KnowledgeEntry | null>(null);
  const [search, setSearch] = useState("");
  const [filterType, setFilterType] = useState<"all" | KnowledgeEntryType>("all");
  const [message, setMessage] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [driveArchives, setDriveArchives] = useState<Record<string, DriveArchiveStatus>>({});

  const [type, setType] = useState<KnowledgeEntryType>("article");
  const [titre, setTitre] = useState("Sahel 2030 : recomposition strategique");
  const [categorie, setCategorie] = useState("Sécurité & Défense");
  const [rubrique, setRubrique] = useState("Édition hebdomadaire");
  const [pays, setPays] = useState("Mali, Niger, Burkina Faso");
  const [acteurs, setActeurs] = useState("Russie, CEDEAO");
  const [organisations, setOrganisations] = useState("Union africaine, CEDEAO");
  const [themes, setThemes] = useState("Sahel, Souveraineté, Sécurité");
  const [sources, setSources] = useState("Sources à vérifier");
  const [contenu, setContenu] = useState("Synthese documentaire interne sur les dynamiques securitaires, les recompositions diplomatiques et les consequences strategiques pour l'Afrique de l'Ouest.");

  useEffect(() => {
    void loadEntries();
  }, []);

  const filteredEntries = useMemo(() => {
    const query = search.trim().toLowerCase();
    return entries.filter((entry) => {
      const haystack = [
        entry.titre,
        entry.categorie,
        entry.rubrique,
        ...entry.pays,
        ...entry.acteurs,
        ...entry.organisations,
        ...entry.themes
      ].join(" ").toLowerCase();
      const matchesSearch = !query || haystack.includes(query);
      const matchesType = filterType === "all" || entry.type === filterType;
      return matchesSearch && matchesType;
    });
  }, [entries, filterType, search]);

  async function loadEntries() {
    setIsLoading(true);
    setError(null);

    try {
      const response = await fetch("/api/knowledge");
      const payload = (await response.json()) as ApiListResponse;

      if (!response.ok) {
        setError(payload.error ?? "Impossible de charger le Knowledge Hub.");
        return;
      }

      const loadedEntries = payload.entries ?? [];
      setEntries(loadedEntries);
      setSelected((current) => current ?? loadedEntries[0] ?? null);
    } catch {
      setError("Impossible de contacter l'API interne.");
    } finally {
      setIsLoading(false);
    }
  }

  async function createEntry(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setIsLoading(true);
    setError(null);
    setMessage(null);

    try {
      const response = await fetch("/api/knowledge/create", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          type,
          titre,
          categorie,
          rubrique,
          pays: splitList(pays),
          acteurs: splitList(acteurs),
          organisations: splitList(organisations),
          themes: splitList(themes),
          sources: splitList(sources),
          fiabilite: "A verifier",
          contenu,
          validation_humaine: true
        })
      });
      const payload = (await response.json()) as ApiCreateResponse;

      if (!response.ok) {
        setError(payload.error ?? "Erreur pendant la creation de la fiche.");
        return;
      }

      if (payload.entry) {
        setEntries((current) => [payload.entry as KnowledgeEntry, ...current.filter((entry) => entry.filePath !== payload.entry?.filePath)]);
        setSelected(payload.entry);
        setMessage("Fiche Markdown Obsidian creee dans knowledge-hub.");
      }
    } catch {
      setError("Impossible de contacter l'API interne.");
    } finally {
      setIsLoading(false);
    }
  }

  function exportMarkdown() {
    if (!selected) return;
    downloadBlob(`${selected.slug}.md`, selected.markdown, "text/markdown;charset=utf-8");
  }

  function exportPdf() {
    if (!selected) return;
    const html = `<!doctype html><html><head><meta charset="utf-8"><title>${escapeHtml(selected.titre)}</title><style>body{font-family:Arial,sans-serif;line-height:1.55;margin:48px;max-width:860px}pre{white-space:pre-wrap;border:1px solid #ddd;padding:16px}</style></head><body><pre>${escapeHtml(selected.markdown)}</pre><script>window.onload=()=>window.print()</script></body></html>`;
    const blob = new Blob([html], { type: "text/html;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    window.open(url, "_blank", "noopener,noreferrer");
  }

  async function exportToDrive() {
    if (!selected) return;
    setIsLoading(true);
    setError(null);
    setMessage(null);

    try {
      const response = await fetch("/api/drive/archive", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          contentId: selected.slug,
          type: mapKnowledgeTypeToDriveType(selected.type),
          title: selected.titre,
          markdown: selected.markdown,
          metadata: {
            rubrique: selected.rubrique,
            categorie: selected.categorie,
            pays: selected.pays,
            acteurs: selected.acteurs,
            themes: selected.themes,
            odd: selected.themes.filter((theme) => theme.startsWith("ODD")),
            agenda2063: selected.themes.filter((theme) => theme.includes("Agenda 2063")),
            sources: selected.sources,
            validation_humaine: selected.validation_humaine,
            visuel_choisi: "",
            obsidianPath: selected.obsidianPath
          }
        })
      });
      const payload = (await response.json()) as DriveArchiveResponse;

      if (!response.ok || !payload.success) {
        setError(payload.error ?? "Erreur pendant l'archivage Google Drive.");
        return;
      }

      setDriveArchives((current) => ({
        ...current,
        [selected.filePath]: {
          archived: true,
          driveFileUrl: payload.driveFileUrl ?? "",
          driveFolderPath: payload.driveFolderPath ?? "",
          archivedAt: new Date().toISOString()
        }
      }));
      setMessage("Fiche archivée dans Google Drive.");
    } catch {
      setError("Impossible de contacter l'API Drive interne.");
    } finally {
      setIsLoading(false);
    }
  }

  return (
    <main className="min-h-screen bg-ink px-5 py-8 text-neutral-100">
      <section className="mx-auto max-w-7xl space-y-6">
        <header className="border-b border-line pb-5">
          <p className="text-xs font-semibold uppercase tracking-[0.24em] text-gold">Valeurs Africaines Editorial OS</p>
          <h1 className="mt-3 text-3xl font-semibold text-gold-soft">Knowledge Hub Obsidian</h1>
          <p className="mt-2 max-w-3xl text-sm leading-6 text-neutral-400">
            Base documentaire Markdown avec YAML, liens internes Obsidian et backlinks. Aucune publication automatique.
          </p>
        </header>

        {error ? <Alert tone="error" text={error} /> : null}
        {message ? <Alert tone="success" text={message} /> : null}

        <section className="grid grid-cols-[390px_minmax(0,1fr)] gap-5 max-xl:grid-cols-1">
          <aside className="space-y-5">
            <div className="rounded-lg border border-line bg-panel p-4">
              <div className="flex items-center justify-between gap-3">
                <h2 className="font-semibold text-gold-soft">Fiches</h2>
                <button onClick={loadEntries} disabled={isLoading} className="rounded-md border border-line px-3 py-1.5 text-xs font-semibold hover:border-gold disabled:opacity-50">
                  Actualiser
                </button>
              </div>
              <div className="mt-4 grid gap-3">
                <input value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Recherche" className="w-full rounded-md border border-line bg-black px-3 py-2 text-sm text-neutral-100 outline-none focus:border-gold" />
                <select value={filterType} onChange={(event) => setFilterType(event.target.value as "all" | KnowledgeEntryType)} className="w-full rounded-md border border-line bg-black px-3 py-2 text-sm text-neutral-100 outline-none focus:border-gold">
                  <option value="all">Tous les types</option>
                  {TYPES.map((option) => <option key={option.value} value={option.value}>{option.label}</option>)}
                </select>
              </div>
              <div className="mt-4 max-h-[360px] space-y-2 overflow-auto pr-1">
                {filteredEntries.map((entry) => (
                  <button key={entry.filePath} onClick={() => setSelected(entry)} className="w-full rounded-md border border-line bg-black/20 px-3 py-2 text-left text-sm hover:border-gold">
                    <div className="font-semibold text-neutral-100">{entry.titre}</div>
                    <div className="mt-1 flex justify-between gap-3 text-xs text-neutral-400">
                      <span>{labelForType(entry.type)}</span>
                      <span>{formatDisplayDate(entry.date)}</span>
                    </div>
                  </button>
                ))}
                {filteredEntries.length === 0 ? <p className="text-sm text-neutral-500">Aucune fiche trouvee.</p> : null}
              </div>
            </div>

            <form onSubmit={createEntry} className="rounded-lg border border-line bg-panel p-4">
              <h2 className="font-semibold text-gold-soft">Créer une fiche</h2>
              <div className="mt-4 space-y-3">
                <Field label="Type">
                  <select value={type} onChange={(event) => setType(event.target.value as KnowledgeEntryType)} className="w-full rounded-md border border-line bg-black px-3 py-2 text-sm text-neutral-100 outline-none focus:border-gold">
                    {TYPES.map((option) => <option key={option.value} value={option.value}>{option.label}</option>)}
                  </select>
                </Field>
                <Field label="Titre"><input value={titre} onChange={(event) => setTitre(event.target.value)} className="w-full rounded-md border border-line bg-black px-3 py-2 text-sm text-neutral-100 outline-none focus:border-gold" /></Field>
                <Field label="Categorie"><input value={categorie} onChange={(event) => setCategorie(event.target.value)} className="w-full rounded-md border border-line bg-black px-3 py-2 text-sm text-neutral-100 outline-none focus:border-gold" /></Field>
                <Field label="Rubrique"><input value={rubrique} onChange={(event) => setRubrique(event.target.value)} className="w-full rounded-md border border-line bg-black px-3 py-2 text-sm text-neutral-100 outline-none focus:border-gold" /></Field>
                <Field label="Pays"><input value={pays} onChange={(event) => setPays(event.target.value)} className="w-full rounded-md border border-line bg-black px-3 py-2 text-sm text-neutral-100 outline-none focus:border-gold" /></Field>
                <Field label="Acteurs"><input value={acteurs} onChange={(event) => setActeurs(event.target.value)} className="w-full rounded-md border border-line bg-black px-3 py-2 text-sm text-neutral-100 outline-none focus:border-gold" /></Field>
                <Field label="Organisations"><input value={organisations} onChange={(event) => setOrganisations(event.target.value)} className="w-full rounded-md border border-line bg-black px-3 py-2 text-sm text-neutral-100 outline-none focus:border-gold" /></Field>
                <Field label="Themes"><input value={themes} onChange={(event) => setThemes(event.target.value)} className="w-full rounded-md border border-line bg-black px-3 py-2 text-sm text-neutral-100 outline-none focus:border-gold" /></Field>
                <Field label="Sources"><input value={sources} onChange={(event) => setSources(event.target.value)} className="w-full rounded-md border border-line bg-black px-3 py-2 text-sm text-neutral-100 outline-none focus:border-gold" /></Field>
                <Field label="Contenu"><textarea value={contenu} onChange={(event) => setContenu(event.target.value)} className="min-h-32 w-full rounded-md border border-line bg-black px-3 py-2 text-sm text-neutral-100 outline-none focus:border-gold" /></Field>
                <button type="submit" disabled={isLoading} className="w-full rounded-md bg-gold px-4 py-2.5 font-bold text-black disabled:opacity-50">
                  Créer Knowledge Entry
                </button>
              </div>
            </form>
          </aside>

          <section className="rounded-lg border border-line bg-panel">
            <div className="flex items-center justify-between gap-3 border-b border-line bg-[#171717] px-4 py-3 max-lg:grid">
              <div>
                <h2 className="font-semibold text-gold-soft">Aperçu fiche</h2>
                <p className="text-sm text-neutral-400">Markdown natif compatible Obsidian avec YAML frontmatter et liens internes.</p>
              </div>
              <div className="flex flex-wrap gap-2">
                <button onClick={exportMarkdown} disabled={!selected} className="rounded-md border border-line px-3 py-2 text-sm font-semibold hover:border-gold disabled:opacity-50">Export Markdown</button>
                <button onClick={exportPdf} disabled={!selected} className="rounded-md border border-line px-3 py-2 text-sm font-semibold hover:border-gold disabled:opacity-50">Export PDF</button>
                <button onClick={exportToDrive} disabled={!selected || isLoading} className="rounded-md border border-gold/50 bg-gold/10 px-3 py-2 text-sm font-semibold text-gold-soft hover:border-gold disabled:opacity-50">Exporter vers Google Drive</button>
              </div>
            </div>
            {selected ? (
              <>
                <div className="grid grid-cols-4 gap-3 border-b border-line p-4 max-lg:grid-cols-2 max-sm:grid-cols-1">
                  <Metric label="Type" value={labelForType(selected.type)} />
                  <Metric label="Fiabilite" value={selected.fiabilite} />
                  <Metric label="Liens pays" value={String(selected.pays.length)} />
                  <Metric label="Backlinks" value={String(selected.backlinks.length)} />
                </div>
                <DriveStatusPanel status={driveArchives[selected.filePath]} />
                <pre className="max-h-[760px] min-h-[560px] overflow-auto whitespace-pre-wrap p-5 text-sm leading-6 text-neutral-200">
                  {selected.markdown}
                </pre>
              </>
            ) : (
              <div className="grid min-h-[560px] place-items-center p-5 text-sm text-neutral-500">
                Selectionne ou cree une fiche.
              </div>
            )}
          </section>
        </section>
      </section>
    </main>
  );
}

function mapKnowledgeTypeToDriveType(type: KnowledgeEntryType): string {
  if (type === "research-brief") return "research-brief";
  if (type === "note-pays" || type === "country-profile" || type === "fiche-pays") return "note-pays";
  if (type === "observatoire" || type === "think-tank" || type === "scenario" || type === "conflict-observer") return "observatoire";
  if (type === "portrait" || type === "chercheur" || type === "innovateur") return "portrait";
  if (type === "fiche-entreprise") return "business";
  if (type === "infographie") return "visuel";
  return "article";
}

function DriveStatusPanel({ status }: { status?: DriveArchiveStatus }) {
  return (
    <div className="grid grid-cols-4 gap-3 border-b border-line p-4 max-lg:grid-cols-2 max-sm:grid-cols-1">
      <Metric label="Statut Drive" value={status?.archived ? "Archivé Drive" : "Non archivé"} />
      <Metric label="Dossier Drive" value={status?.driveFolderPath || "-"} />
      <Metric label="Date archivage" value={status?.archivedAt ? status.archivedAt.slice(0, 10) : "-"} />
      <div className="rounded-md border border-line bg-black/20 p-3">
        <div className="text-sm font-bold text-gold-soft">
          {status?.driveFileUrl ? <a href={status.driveFileUrl} target="_blank" rel="noreferrer" className="underline">Ouvrir Drive</a> : "-"}
        </div>
        <div className="text-xs text-neutral-400">Lien Drive</div>
      </div>
    </div>
  );
}

function splitList(value: string): string[] {
  return value.split(/[,;\n]/).map((item) => item.trim()).filter(Boolean);
}

function labelForType(type: KnowledgeEntryType): string {
  return TYPES.find((item) => item.value === type)?.label ?? type;
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="block text-sm">
      <span className="mb-1 block font-semibold text-gold">{label}</span>
      {children}
    </label>
  );
}

function Metric({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-md border border-line bg-black/20 p-3">
      <div className="text-lg font-bold text-gold-soft">{value}</div>
      <div className="text-xs text-neutral-400">{label}</div>
    </div>
  );
}

function Alert({ tone, text }: { tone: "error" | "success"; text: string }) {
  const className =
    tone === "error"
      ? "border-red-400/40 bg-red-400/10 text-red-100"
      : "border-green-400/40 bg-green-400/10 text-green-100";
  return <div className={`rounded-lg border p-4 text-sm ${className}`}>{text}</div>;
}

function downloadBlob(fileName: string, content: string, type: string) {
  const blob = new Blob([content], { type });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = fileName;
  document.body.appendChild(link);
  link.click();
  link.remove();
  URL.revokeObjectURL(url);
}

function escapeHtml(value: string): string {
  return value
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}
