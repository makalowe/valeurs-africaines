"use client";

import Link from "next/link";
import type { ReactNode } from "react";
import { useMemo, useState } from "react";
import {
  continentalCountries,
  continentalIndicators,
  continentalRegions,
  continentalSections,
  getAlertInterpretation,
  type ContinentalDashboardSection,
  type ContinentalIndicator,
  type StrategicAlertLevel
} from "@/lib/continentalDashboard";
import { formatDisplayDate } from "@/lib/dateDisplay";

const timelinePlaceholder = [
  { period: "T-3", value: 0 },
  { period: "T-2", value: 0 },
  { period: "T-1", value: 0 },
  { period: "T", value: 0 }
];

export default function ContinentalDashboardPage() {
  const [section, setSection] = useState<ContinentalDashboardSection | "Toutes les sections">("Toutes les sections");
  const [region, setRegion] = useState("Toutes les régions");
  const [country, setCountry] = useState("Tous les pays");
  const [selectedId, setSelectedId] = useState(continentalIndicators[0]?.id ?? "");

  const filteredIndicators = useMemo(() => {
    return continentalIndicators.filter((indicator) => {
      const sectionMatch = section === "Toutes les sections" || indicator.section === section;
      const regionMatch = region === "Toutes les régions" || indicator.region === region;
      const countryMatch = country === "Tous les pays" || indicator.country === country;
      return sectionMatch && regionMatch && countryMatch;
    });
  }, [country, region, section]);

  const selectedIndicator = filteredIndicators.find((indicator) => indicator.id === selectedId) ?? filteredIndicators[0] ?? null;
  const sectionCounts = continentalSections.map((item) => ({
    section: item,
    indicateurs: continentalIndicators.filter((indicator) => indicator.section === item).length
  }));

  return (
    <main className="min-h-screen bg-ink px-5 py-8 text-neutral-100">
      <section className="mx-auto max-w-7xl space-y-6">
        <header className="flex items-start justify-between gap-5 border-b border-line pb-5 max-lg:grid">
          <div>
            <p className="text-xs font-semibold uppercase tracking-[0.24em] text-gold">Atlas Afrique</p>
            <h1 className="mt-3 text-3xl font-semibold text-gold-soft">Dashboard Continental</h1>
            <p className="mt-2 max-w-3xl text-sm leading-6 text-neutral-400">
              Tableau de bord stratégique pour suivre l'évolution du continent. Les valeurs restent non calculées tant que les sources ne sont pas validées.
            </p>
          </div>
          <Link href="/atlas" className="rounded-md border border-gold/40 bg-gold/10 px-4 py-2 text-sm font-semibold text-gold-soft transition hover:bg-gold/20">
            Retour Atlas
          </Link>
        </header>

        <section className="grid gap-4 md:grid-cols-4">
          <Kpi title="Sections" value={String(continentalSections.length)} />
          <Kpi title="Indicateurs" value={String(continentalIndicators.length)} />
          <Kpi title="Alertes rouges" value="0" />
          <Kpi title="Statut" value="À vérifier" />
        </section>

        <section className="grid gap-3 rounded-lg border border-line bg-panel p-4 lg:grid-cols-3">
          <Select label="Filtrer par section" value={section} values={["Toutes les sections", ...continentalSections]} onChange={(value) => setSection(value as ContinentalDashboardSection | "Toutes les sections")} />
          <Select label="Filtrer par région" value={region} values={continentalRegions} onChange={setRegion} />
          <Select label="Filtrer par pays" value={country} values={continentalCountries} onChange={setCountry} />
        </section>

        <section className="grid gap-6 xl:grid-cols-[minmax(0,1fr)_380px]">
          <div className="space-y-6">
            <section className="rounded-lg border border-gold/20 bg-panel p-5">
              <p className="text-xs font-semibold uppercase tracking-[0.22em] text-gold">Cartes interactives</p>
              <h2 className="mt-2 text-xl font-semibold text-gold-soft">Vue continentale des indicateurs</h2>
              <div className="relative mt-5 h-[430px] overflow-hidden rounded-lg border border-line bg-[radial-gradient(circle_at_50%_45%,rgba(214,170,77,0.16),transparent_32%),linear-gradient(135deg,#080808,#141414)] max-md:h-[340px]">
                <AfricaSilhouette />
                <div className="absolute inset-x-5 bottom-5 rounded-lg border border-gold/20 bg-black/70 p-4 text-sm text-neutral-300">
                  Les marqueurs cartographiques seront activés après validation des données par pays et par indicateur.
                </div>
              </div>
            </section>

            <section className="grid gap-6 xl:grid-cols-2">
              <ChartPanel title="Répartition des indicateurs">
                <BarSummaryChart data={sectionCounts} />
              </ChartPanel>
              <ChartPanel title="Courbe temporelle">
                <TimelineChart data={timelinePlaceholder} />
                <p className="mt-3 text-sm text-neutral-500">Série temporelle en attente de données vérifiées.</p>
              </ChartPanel>
            </section>

            <section className="grid gap-4 lg:grid-cols-2">
              {continentalSections.map((item) => (
                <Widget key={item} title={item} indicators={filteredIndicators.filter((indicator) => indicator.section === item)} onSelect={setSelectedId} />
              ))}
            </section>
          </div>

          <aside className="space-y-6">
            <section className="rounded-lg border border-gold/30 bg-gold/10 p-5">
              <p className="text-xs font-semibold uppercase tracking-[0.22em] text-gold">Alertes stratégiques</p>
              <h2 className="mt-2 text-xl font-semibold text-gold-soft">Système d'alerte</h2>
              <div className="mt-4 grid gap-3">
                {(["Vert", "Jaune", "Orange", "Rouge", "À vérifier"] as StrategicAlertLevel[]).map((level) => (
                  <div key={level} className="rounded-md border border-line bg-black/20 p-3">
                    <p className="font-semibold text-neutral-100">{level}</p>
                    <p className="mt-1 text-sm text-neutral-400">{getAlertInterpretation(level)}</p>
                  </div>
                ))}
              </div>
            </section>

            <IndicatorDetail indicator={selectedIndicator} />
          </aside>
        </section>
      </section>
    </main>
  );
}

function Widget({ title, indicators, onSelect }: { title: string; indicators: ContinentalIndicator[]; onSelect: (id: string) => void }) {
  const visibleIndicators = indicators.length ? indicators : continentalIndicators.filter((indicator) => indicator.section === title);
  return (
    <section className="rounded-lg border border-line bg-panel p-5">
      <p className="text-xs font-semibold uppercase tracking-[0.2em] text-gold">{title}</p>
      <div className="mt-4 space-y-2">
        {visibleIndicators.map((indicator) => (
          <button key={indicator.id} type="button" onClick={() => onSelect(indicator.id)} className="w-full rounded-md border border-line bg-black/20 p-3 text-left text-sm transition hover:border-gold/50">
            <span className="block font-semibold text-neutral-100">{indicator.name}</span>
            <span className="mt-1 block text-xs text-neutral-500">Valeur : {indicator.currentValue} · Risque : {indicator.riskLevel}</span>
          </button>
        ))}
      </div>
    </section>
  );
}

function IndicatorDetail({ indicator }: { indicator: ContinentalIndicator | null }) {
  if (!indicator) return null;
  return (
    <section className="rounded-lg border border-line bg-panel p-5">
      <p className="text-xs font-semibold uppercase tracking-[0.22em] text-gold">Indicateur sélectionné</p>
      <h2 className="mt-2 text-xl font-semibold text-gold-soft">{indicator.name}</h2>
      <dl className="mt-4 grid gap-3 text-sm">
        <Meta label="Valeur actuelle" value={indicator.currentValue} />
        <Meta label="Évolution" value={indicator.evolution} />
        <Meta label="Tendance" value={indicator.trend} />
        <Meta label="Niveau de risque" value={indicator.riskLevel} />
        <Meta label="Niveau d'opportunité" value={indicator.opportunityLevel} />
        <Meta label="Source" value={indicator.source} />
        <Meta label="Date de mise à jour" value={formatDisplayDate(indicator.updatedAt)} />
      </dl>
    </section>
  );
}

function Kpi({ title, value }: { title: string; value: string }) {
  return (
    <article className="rounded-lg border border-gold/20 bg-panel p-5">
      <p className="text-xs font-semibold uppercase tracking-[0.18em] text-gold">{title}</p>
      <p className="mt-2 text-2xl font-semibold text-gold-soft">{value}</p>
      <p className="mt-1 text-sm text-neutral-400">Validation humaine obligatoire</p>
    </article>
  );
}

function Select({ label, value, values, onChange }: { label: string; value: string; values: string[]; onChange: (value: string) => void }) {
  return (
    <select
      value={value}
      onChange={(event) => onChange(event.target.value)}
      aria-label={label}
      className="rounded-lg border border-line bg-black/25 px-3 py-3 text-sm text-neutral-100 outline-none focus:border-gold"
    >
      {values.map((item) => <option key={item}>{item}</option>)}
    </select>
  );
}

function ChartPanel({ title, children }: { title: string; children: ReactNode }) {
  return (
    <section className="rounded-lg border border-line bg-panel p-5">
      <p className="text-xs font-semibold uppercase tracking-[0.22em] text-gold">{title}</p>
      <div className="mt-4 min-h-[320px] min-w-0">{children}</div>
    </section>
  );
}

function BarSummaryChart({ data }: { data: Array<{ section: string; indicateurs: number }> }) {
  const max = Math.max(...data.map((item) => item.indicateurs), 1);
  return (
    <div className="space-y-3" aria-label="Graphique de répartition des indicateurs">
      {data.map((item) => {
        const width = Math.max(8, (item.indicateurs / max) * 100);
        return (
          <div key={item.section} className="grid gap-2">
            <div className="flex items-center justify-between gap-3 text-xs">
              <span className="text-neutral-300">{item.section}</span>
              <span className="font-semibold text-gold-soft">{item.indicateurs}</span>
            </div>
            <div className="h-2 rounded-full bg-black/40">
              <div className="h-2 rounded-full bg-gold" style={{ width: `${width}%` }} />
            </div>
          </div>
        );
      })}
    </div>
  );
}

function TimelineChart({ data }: { data: Array<{ period: string; value: number }> }) {
  const points = data.map((item, index) => {
    const x = 20 + index * 80;
    const y = 160 - item.value;
    return { ...item, x, y };
  });
  const line = points.map((point) => `${point.x},${point.y}`).join(" ");

  return (
    <svg viewBox="0 0 280 190" className="h-[320px] w-full rounded-lg border border-line bg-black/20" role="img" aria-label="Courbe temporelle des indicateurs">
      <path d="M20 160H260M20 40V160" stroke="rgba(255,255,255,0.16)" strokeWidth="1" />
      <polyline points={line} fill="none" stroke="#d6aa4d" strokeWidth="3" />
      {points.map((point) => (
        <g key={point.period}>
          <circle cx={point.x} cy={point.y} r="4" fill="#d6aa4d" />
          <text x={point.x} y="178" textAnchor="middle" fill="#a3a3a3" fontSize="10">
            {point.period}
          </text>
        </g>
      ))}
      <text x="140" y="28" textAnchor="middle" fill="#737373" fontSize="11">
        Données à vérifier
      </text>
    </svg>
  );
}

function Meta({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-md border border-line bg-black/20 p-3">
      <dt className="text-xs uppercase tracking-wide text-neutral-500">{label}</dt>
      <dd className="mt-1 font-medium text-neutral-200">{value}</dd>
    </div>
  );
}

function AfricaSilhouette() {
  return (
    <svg viewBox="0 0 720 720" className="absolute inset-0 h-full w-full" aria-hidden="true">
      <path
        d="M302 58 246 86l-34 56-58 50-12 80 50 58 16 88 58 50 34 72 62 76 82-32 36-82 72-22 22-76 62-56-18-68 34-78-50-50-28-78-84-26-50-56-78 10Z"
        fill="rgba(214,170,77,0.12)"
        stroke="rgba(214,170,77,0.55)"
        strokeWidth="3"
      />
    </svg>
  );
}
