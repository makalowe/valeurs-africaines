"use client";

import Link from "next/link";
import { Search } from "lucide-react";
import type { ReactNode } from "react";
import { useMemo, useState } from "react";
import {
  strategicActorCategories,
  strategicActorRelations,
  strategicActors,
  strategicActorSectors,
  strategicActorZones,
  type StrategicActor
} from "@/lib/strategicActors";

export default function StrategicActorsPage() {
  const [query, setQuery] = useState("");
  const [category, setCategory] = useState("Toutes les catégories");
  const [zone, setZone] = useState("Toutes les zones");
  const [sector, setSector] = useState("Tous les secteurs");
  const [selectedId, setSelectedId] = useState(strategicActors[0]?.id ?? "");

  const filteredActors = useMemo(() => {
    const normalizedQuery = normalize(query);
    return strategicActors.filter((actor) => {
      const categoryMatch = category === "Toutes les catégories" || actor.category === category;
      const zoneMatch = zone === "Toutes les zones" || actor.influenceZones.some((item) => normalize(item).includes(normalize(zone)));
      const sectorMatch = sector === "Tous les secteurs" || actor.sector === sector;
      const queryMatch = !normalizedQuery || normalize([
        actor.name,
        actor.type,
        actor.category,
        actor.originCountry,
        actor.sector,
        actor.description,
        actor.influenceZones.join(" "),
        actor.strategicInterests.join(" "),
        actor.africaImpact
      ].join(" ")).includes(normalizedQuery);
      return categoryMatch && zoneMatch && sectorMatch && queryMatch;
    });
  }, [category, query, sector, zone]);

  const selectedActor = filteredActors.find((actor) => actor.id === selectedId) ?? filteredActors[0] ?? null;

  return (
    <main className="min-h-screen bg-ink px-5 py-8 text-neutral-100">
      <section className="mx-auto max-w-7xl space-y-6">
        <header className="flex items-start justify-between gap-5 border-b border-line pb-5 max-lg:grid">
          <div>
            <p className="text-xs font-semibold uppercase tracking-[0.24em] text-gold">Atlas Afrique</p>
            <h1 className="mt-3 text-3xl font-semibold text-gold-soft">Acteurs Stratégiques</h1>
            <p className="mt-2 max-w-3xl text-sm leading-6 text-neutral-400">
              Cartographie des acteurs influençant les dynamiques africaines. Les relations, niveaux d'influence et risques exigent des sources avant validation.
            </p>
          </div>
          <Link href="/atlas" className="rounded-md border border-gold/40 bg-gold/10 px-4 py-2 text-sm font-semibold text-gold-soft transition hover:bg-gold/20">
            Retour Atlas
          </Link>
        </header>

        <section className="grid gap-3 rounded-lg border border-line bg-panel p-4 xl:grid-cols-[minmax(0,1fr)_240px_220px_240px]">
          <label className="group flex items-center gap-3 rounded-lg border border-gold/20 bg-black/25 px-4 py-3 transition focus-within:border-gold focus-within:shadow-[0_0_0_3px_rgba(214,170,77,0.12)]">
            <Search size={18} className="text-gold" aria-hidden="true" />
            <span className="sr-only">Rechercher un acteur stratégique</span>
            <input
              type="search"
              value={query}
              onChange={(event) => setQuery(event.target.value)}
              aria-label="Rechercher un acteur stratégique"
              placeholder="Rechercher acteur, zone, secteur, intérêt..."
              className="h-9 w-full bg-transparent text-sm text-neutral-100 outline-none placeholder:text-neutral-500"
            />
          </label>
          <Select label="Filtrer par catégorie d'acteur" value={category} values={["Toutes les catégories", ...strategicActorCategories]} onChange={setCategory} />
          <Select label="Filtrer par zone géographique" value={zone} values={["Toutes les zones", ...strategicActorZones]} onChange={setZone} />
          <Select label="Filtrer par secteur" value={sector} values={strategicActorSectors} onChange={setSector} />
        </section>

        <section className="grid gap-6 xl:grid-cols-[minmax(0,1fr)_390px]">
          <div className="space-y-6">
            <NetworkMap actors={filteredActors} selectedId={selectedActor?.id ?? ""} onSelect={setSelectedId} />

            <section className="grid gap-5 xl:grid-cols-2">
              {filteredActors.map((actor) => (
                <ActorCard key={actor.id} actor={actor} onSelect={() => setSelectedId(actor.id)} />
              ))}
            </section>

            {filteredActors.length === 0 ? (
              <section className="rounded-lg border border-line bg-panel p-5 text-sm text-neutral-400">
                Aucun acteur stratégique ne correspond aux filtres sélectionnés.
              </section>
            ) : null}
          </div>

          <aside className="space-y-6">
            <ActorDetail actor={selectedActor} />
            <InfluenceEcosystem />
          </aside>
        </section>
      </section>
    </main>
  );
}

function NetworkMap({ actors, selectedId, onSelect }: { actors: StrategicActor[]; selectedId: string; onSelect: (id: string) => void }) {
  return (
    <section className="rounded-lg border border-gold/20 bg-panel p-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <p className="text-xs font-semibold uppercase tracking-[0.22em] text-gold">Visualisation réseau</p>
          <h2 className="mt-2 text-xl font-semibold text-gold-soft">Nœuds et connexions vérifiées</h2>
        </div>
        <p className="text-sm text-neutral-400">{actors.length} nœud{actors.length > 1 ? "s" : ""} · {strategicActorRelations.length} connexion sourcée</p>
      </div>

      <div className="relative mt-5 h-[480px] overflow-hidden rounded-lg border border-line bg-[radial-gradient(circle_at_50%_45%,rgba(214,170,77,0.16),transparent_32%),linear-gradient(135deg,#080808,#141414)] max-md:h-[360px]">
        <svg viewBox="0 0 100 100" className="absolute inset-0 h-full w-full" aria-hidden="true">
          {strategicActorRelations.map((relation) => {
            const source = actors.find((actor) => actor.id === relation.sourceId);
            const target = actors.find((actor) => actor.id === relation.targetId);
            if (!source || !target) return null;
            return (
              <line
                key={relation.id}
                x1={source.networkPosition.x}
                y1={source.networkPosition.y}
                x2={target.networkPosition.x}
                y2={target.networkPosition.y}
                stroke="rgba(214,170,77,0.55)"
                strokeWidth="0.4"
              />
            );
          })}
        </svg>
        {actors.map((actor) => (
          <button
            key={actor.id}
            type="button"
            onClick={() => onSelect(actor.id)}
            className={`absolute -translate-x-1/2 -translate-y-1/2 rounded-full border-2 bg-black/90 px-3 py-2 text-xs font-semibold transition hover:scale-105 ${
              selectedId === actor.id ? "border-gold text-gold-soft shadow-[0_0_0_6px_rgba(214,170,77,0.18)]" : "border-line text-neutral-200"
            }`}
            style={{ left: `${actor.networkPosition.x}%`, top: `${actor.networkPosition.y}%` }}
          >
            {actor.name}
          </button>
        ))}
        {strategicActorRelations.length === 0 ? (
          <div className="absolute inset-x-5 bottom-5 rounded-lg border border-gold/20 bg-black/70 p-4 text-sm text-neutral-300">
            Aucune connexion affichée : les alliances, rivalités et dépendances doivent être sourcées avant visualisation.
          </div>
        ) : null}
      </div>
    </section>
  );
}

function ActorCard({ actor, onSelect }: { actor: StrategicActor; onSelect: () => void }) {
  return (
    <article className="rounded-lg border border-gold/20 bg-panel p-5 shadow-[0_18px_45px_rgba(0,0,0,0.22)]">
      <div className="flex items-start justify-between gap-4 border-b border-line pb-4">
        <div>
          <p className="text-xs font-semibold uppercase tracking-[0.22em] text-gold">{actor.category}</p>
          <h2 className="mt-2 text-2xl font-semibold text-gold-soft">{actor.name}</h2>
          <p className="mt-1 text-sm text-neutral-400">{actor.type} · {actor.sector}</p>
        </div>
        <span className="rounded-md border border-yellow-500/30 bg-yellow-500/10 px-2 py-1 text-xs font-semibold uppercase text-yellow-100">
          À vérifier
        </span>
      </div>

      <section className="mt-4 grid gap-4 text-sm text-neutral-300">
        <Block title="Identité">
          <dl className="grid gap-2 sm:grid-cols-2">
            <Meta label="Pays d'origine" value={actor.originCountry} />
            <Meta label="Zone d'influence" value={actor.influenceZones.join(", ")} />
            <Meta label="Influence" value={actor.influenceLevel} />
            <Meta label="Risque" value={actor.riskLevel} />
          </dl>
        </Block>
        <Block title="Description">{actor.description}</Block>
        <Block title="Intérêts stratégiques"><List values={actor.strategicInterests} /></Block>
        <Block title="Sources"><List values={actor.sources} /></Block>
        <button type="button" onClick={onSelect} className="rounded-md border border-gold/40 bg-gold/10 px-3 py-2 text-sm font-semibold text-gold-soft transition hover:bg-gold/20">
          Ouvrir la fiche détaillée
        </button>
      </section>
    </article>
  );
}

function ActorDetail({ actor }: { actor: StrategicActor | null }) {
  if (!actor) {
    return (
      <section className="rounded-lg border border-line bg-panel p-5 text-sm text-neutral-400">
        Sélectionnez un acteur pour afficher sa fiche détaillée.
      </section>
    );
  }

  return (
    <section className="rounded-lg border border-gold/30 bg-gold/10 p-5">
      <p className="text-xs font-semibold uppercase tracking-[0.22em] text-gold">Fiche détaillée</p>
      <h2 className="mt-2 text-2xl font-semibold text-gold-soft">{actor.name}</h2>
      <div className="mt-4 space-y-4 text-sm text-neutral-300">
        <Block title="Résumé exécutif">{actor.detailedProfile.executiveSummary}</Block>
        <Block title="Objectifs"><List values={actor.detailedProfile.objectives} /></Block>
        <Block title="Capacités"><List values={actor.detailedProfile.capabilities} /></Block>
        <Block title="Réseaux d'influence"><List values={actor.detailedProfile.influenceNetworks} /></Block>
        <Block title="Présence en Afrique">{actor.detailedProfile.presenceInAfrica}</Block>
        <Block title="Évolution récente">{actor.detailedProfile.recentEvolution}</Block>
        <Block title="Implications pour l'Afrique">{actor.detailedProfile.africaImplications}</Block>
      </div>
    </section>
  );
}

function InfluenceEcosystem() {
  return (
    <section className="rounded-lg border border-line bg-panel p-5">
      <p className="text-xs font-semibold uppercase tracking-[0.22em] text-gold">Écosystème d'influence</p>
      <div className="mt-4 space-y-4 text-sm text-neutral-300">
        <Block title="Alliances">À documenter uniquement avec sources vérifiées.</Block>
        <Block title="Rivalités">Aucune rivalité affichée sans source traçable.</Block>
        <Block title="Dépendances">À qualifier par secteur, pays et source.</Block>
        <Block title="Opportunités de coopération">À produire après analyse éditoriale validée.</Block>
      </div>
    </section>
  );
}

function Select({ label, value, values, onChange }: { label: string; value: string; values: string[]; onChange: (value: string) => void }) {
  return (
    <select
      value={value}
      onChange={(event) => onChange(event.target.value)}
      aria-label={label}
      className="rounded-lg border border-line bg-black/25 px-3 py-3 text-sm text-neutral-100 outline-none focus:border-gold"
    >
      {values.map((item) => <option key={item}>{item}</option>)}
    </select>
  );
}

function Block({ title, children }: { title: string; children: ReactNode }) {
  return (
    <section>
      <h3 className="text-xs font-semibold uppercase tracking-[0.18em] text-gold">{title}</h3>
      <div className="mt-2 leading-6">{children}</div>
    </section>
  );
}

function Meta({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-md border border-line bg-black/20 p-3">
      <dt className="text-xs uppercase tracking-wide text-neutral-500">{label}</dt>
      <dd className="mt-1 font-medium text-neutral-200">{value}</dd>
    </div>
  );
}

function List({ values }: { values: string[] }) {
  return (
    <ul className="list-inside list-disc space-y-1">
      {values.map((value) => <li key={value}>{value}</li>)}
    </ul>
  );
}

function normalize(value: string) {
  return value
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[’']/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}
