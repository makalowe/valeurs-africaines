"use client";

import Link from "next/link";
import { useSearchParams } from "next/navigation";
import { Search, SlidersHorizontal, X } from "lucide-react";
import { Suspense, useEffect, useMemo, useState } from "react";
import { getAllCountryProfilesSync } from "@/lib/atlas";
import { formatDisplayDate } from "@/lib/dateDisplay";

const regions = [
  "Toutes les régions",
  "Afrique du Nord",
  "Afrique de l'Ouest",
  "Afrique Centrale",
  "Afrique de l'Est",
  "Afrique Australe"
];

const strategicRegions = regions.filter((region) => region !== "Toutes les régions");
const subRegions = ["Sahel", "Golfe de Guinée", "Corne de l'Afrique", "Bassin du Congo", "Océan Indien"];
const categories = ["Géopolitique", "Économie", "Sécurité", "Défense", "Énergie", "Technologie", "Gouvernance", "Culture"];

const countryFilterMetadata: Record<string, { subRegions: string[]; categories: string[] }> = {
  maroc: { subRegions: [], categories: ["Géopolitique", "Économie", "Énergie", "Technologie", "Gouvernance", "Culture"] },
  algerie: { subRegions: ["Sahel"], categories: ["Géopolitique", "Économie", "Sécurité", "Défense", "Énergie", "Gouvernance"] },
  egypte: { subRegions: [], categories: ["Géopolitique", "Économie", "Sécurité", "Défense", "Énergie", "Culture"] },
  nigeria: { subRegions: ["Golfe de Guinée", "Sahel"], categories: ["Géopolitique", "Économie", "Sécurité", "Énergie", "Technologie", "Culture"] },
  "afrique-du-sud": { subRegions: [], categories: ["Géopolitique", "Économie", "Défense", "Énergie", "Technologie", "Gouvernance", "Culture"] },
  kenya: { subRegions: ["Corne de l'Afrique", "Océan Indien"], categories: ["Géopolitique", "Économie", "Sécurité", "Technologie", "Gouvernance", "Culture"] },
  ethiopie: { subRegions: ["Corne de l'Afrique"], categories: ["Géopolitique", "Économie", "Sécurité", "Défense", "Énergie", "Gouvernance"] },
  rdc: { subRegions: ["Bassin du Congo"], categories: ["Géopolitique", "Économie", "Sécurité", "Énergie", "Gouvernance", "Culture"] },
  senegal: { subRegions: ["Sahel"], categories: ["Géopolitique", "Économie", "Sécurité", "Énergie", "Gouvernance", "Culture"] },
  "cote-d-ivoire": { subRegions: ["Golfe de Guinée"], categories: ["Géopolitique", "Économie", "Sécurité", "Énergie", "Gouvernance", "Culture"] }
};

export default function AtlasPage() {
  return (
    <Suspense fallback={<AtlasFallback />}>
      <AtlasContent />
    </Suspense>
  );
}

function AtlasContent() {
  const searchParams = useSearchParams();
  const countries = getAllCountryProfilesSync();
  const [selectedRegion, setSelectedRegion] = useState("Toutes les régions");
  const [query, setQuery] = useState("");
  const [debouncedQuery, setDebouncedQuery] = useState("");
  const [isSearching, setIsSearching] = useState(false);
  const [filtersOpen, setFiltersOpen] = useState(false);
  const [selectedRegions, setSelectedRegions] = useState<string[]>([]);
  const [selectedSubRegions, setSelectedSubRegions] = useState<string[]>([]);
  const [selectedCategories, setSelectedCategories] = useState<string[]>([]);
  const [comparisonSlugs, setComparisonSlugs] = useState<string[]>([]);

  useEffect(() => {
    const requestedSlugs = searchParams
      .get("compare")
      ?.split(",")
      .map((slug) => slug.trim())
      .filter(Boolean)
      .slice(0, 4);
    if (!requestedSlugs?.length) return;

    const validSlugs = requestedSlugs.filter((slug) => countries.some((country) => country.slug === slug));
    if (validSlugs.length) setComparisonSlugs(validSlugs);
  }, [countries, searchParams]);

  useEffect(() => {
    setIsSearching(query.trim().length > 0);
    const timer = window.setTimeout(() => {
      setDebouncedQuery(query.trim());
      setIsSearching(false);
    }, 180);

    return () => window.clearTimeout(timer);
  }, [query]);

  const filteredCountries = useMemo(() => {
    const normalizedQuery = normalize(debouncedQuery);

    return countries.filter((country) => {
      const metadata = countryFilterMetadata[country.slug] ?? { subRegions: [], categories: [] };
      const activeRegions = selectedRegions.length ? selectedRegions : selectedRegion === "Toutes les régions" ? [] : [selectedRegion];
      const regionMatch = activeRegions.length === 0 || activeRegions.includes(country.region);
      const subRegionMatch = selectedSubRegions.length === 0 || selectedSubRegions.some((subRegion) => metadata.subRegions.includes(subRegion));
      const categoryMatch = selectedCategories.length === 0 || selectedCategories.some((category) => metadata.categories.includes(category));
      if (!regionMatch) return false;
      if (!subRegionMatch) return false;
      if (!categoryMatch) return false;
      if (!normalizedQuery) return true;
      return buildSearchText(country).includes(normalizedQuery);
    });
  }, [countries, debouncedQuery, selectedCategories, selectedRegion, selectedRegions, selectedSubRegions]);

  const activeFilters = useMemo(() => {
    return [...selectedRegions, ...selectedSubRegions, ...selectedCategories];
  }, [selectedCategories, selectedRegions, selectedSubRegions]);

  const comparedCountries = useMemo(() => {
    return comparisonSlugs
      .map((slug) => countries.find((country) => country.slug === slug))
      .filter((country): country is AtlasCountry => Boolean(country));
  }, [comparisonSlugs, countries]);

  const resultLabel = useMemo(() => {
    if (isSearching) return "Recherche en cours";
    if (debouncedQuery && filteredCountries.length === 0) return "Aucun résultat trouvé";
    if (debouncedQuery) return `${filteredCountries.length} résultat${filteredCountries.length > 1 ? "s" : ""} trouvé${filteredCountries.length > 1 ? "s" : ""}`;
    return `${filteredCountries.length} Note${filteredCountries.length > 1 ? "s" : ""} Pays disponible${filteredCountries.length > 1 ? "s" : ""}`;
  }, [debouncedQuery, filteredCountries.length, isSearching]);

  return (
    <main className="min-h-screen bg-ink px-5 py-8 text-neutral-100">
      <section className="mx-auto max-w-7xl space-y-6">
        <header className="flex items-start justify-between gap-5 border-b border-line pb-5 max-lg:grid">
          <div>
            <p className="text-xs font-semibold uppercase tracking-[0.24em] text-gold">Atlas Afrique</p>
            <h1 className="mt-3 text-3xl font-semibold text-gold-soft">Notes Pays prioritaires</h1>
            <p className="mt-2 max-w-3xl text-sm leading-6 text-neutral-400">
              Vue opérationnelle des 10 premières Notes Pays. Données à vérifier, statut brouillon et validation humaine obligatoire avant publication.
            </p>
          </div>
          <div className="rounded-lg border border-gold/40 bg-gold/10 px-5 py-4 text-right max-lg:text-left">
            <p className="text-sm uppercase tracking-[0.2em] text-gold">Atlas Afrique</p>
            <p className="mt-2 text-2xl font-semibold text-gold-soft">{countries.length} Notes Pays disponibles</p>
            <p className="mt-1 text-xs text-neutral-400">Architecture extensible jusqu&apos;à 54 pays</p>
            <div className="mt-4 flex flex-wrap justify-end gap-2 max-lg:justify-start">
              <Link
                href="/atlas/acteurs"
                className="inline-flex rounded-md border border-gold/40 bg-black/20 px-3 py-2 text-sm font-semibold text-gold-soft transition hover:border-gold hover:bg-gold/15"
              >
                Acteurs Stratégiques
              </Link>
              <Link
                href="/atlas/cartographie"
                className="inline-flex rounded-md border border-gold/40 bg-black/20 px-3 py-2 text-sm font-semibold text-gold-soft transition hover:border-gold hover:bg-gold/15"
              >
                Cartographie
              </Link>
              <Link
                href="/atlas/indice-puissance"
                className="inline-flex rounded-md border border-gold/40 bg-black/20 px-3 py-2 text-sm font-semibold text-gold-soft transition hover:border-gold hover:bg-gold/15"
              >
                Indice de Puissance
              </Link>
              <Link
                href="/atlas/veille-geopolitique"
                className="inline-flex rounded-md border border-gold/40 bg-black/20 px-3 py-2 text-sm font-semibold text-gold-soft transition hover:border-gold hover:bg-gold/15"
              >
                Veille Géopolitique
              </Link>
              <Link
                href="/atlas/dashboard-continental"
                className="inline-flex rounded-md border border-gold/40 bg-black/20 px-3 py-2 text-sm font-semibold text-gold-soft transition hover:border-gold hover:bg-gold/15"
              >
                Dashboard Continental
              </Link>
              <Link
                href="/atlas/africa-geopolitical-map"
                className="inline-flex rounded-md border border-gold/40 bg-black/20 px-3 py-2 text-sm font-semibold text-gold-soft transition hover:border-gold hover:bg-gold/15"
              >
                Africa Geopolitical Map
              </Link>
            </div>
          </div>
        </header>

        <section className="rounded-lg border border-line bg-panel p-4">
          <div className="grid gap-4">
            <label
              htmlFor="atlas-search"
              className="group flex items-center gap-3 rounded-lg border border-gold/20 bg-black/25 px-4 py-3 transition duration-200 focus-within:border-gold focus-within:bg-black/40 focus-within:shadow-[0_0_0_3px_rgba(214,170,77,0.12)]"
            >
              <Search size={18} className="shrink-0 text-gold transition group-focus-within:scale-110" aria-hidden="true" />
              <span className="sr-only">Rechercher dans Atlas Afrique</span>
              <input
                id="atlas-search"
                type="search"
                value={query}
                onChange={(event) => setQuery(event.target.value)}
                aria-label="Rechercher un pays, une région ou un sujet stratégique"
                placeholder="Rechercher un pays, une région, un sujet stratégique..."
                className="h-9 w-full bg-transparent text-sm font-medium text-neutral-100 outline-none placeholder:text-neutral-500 focus-visible:ring-0"
              />
              <span className="hidden rounded-md border border-line px-2 py-1 text-xs text-neutral-500 sm:inline">Atlas</span>
            </label>

            <div className="flex flex-wrap items-center gap-2">
            {regions.map((region) => {
              const active = selectedRegion === region && selectedRegions.length === 0;
              return (
                <button
                  key={region}
                  type="button"
                  onClick={() => {
                    setSelectedRegion(region);
                    setSelectedRegions([]);
                  }}
                  className={`rounded-md border px-3 py-2 text-sm font-semibold transition ${
                    active
                      ? "border-gold bg-gold/15 text-gold-soft"
                      : "border-line bg-black/20 text-neutral-300 hover:border-gold/60 hover:text-gold-soft"
                  }`}
                >
                  {region}
                </button>
              );
            })}
              <button
                type="button"
                onClick={() => setFiltersOpen(true)}
                aria-expanded={filtersOpen}
                aria-controls="atlas-strategic-filters"
                className="ml-auto inline-flex items-center gap-2 rounded-md border border-gold/40 bg-gold/10 px-3 py-2 text-sm font-semibold text-gold-soft transition hover:border-gold hover:bg-gold/20 max-md:ml-0"
              >
                <SlidersHorizontal size={16} aria-hidden="true" />
                Filtres stratégiques
              </button>
            </div>

            <div
              aria-live="polite"
              className={`rounded-md border px-3 py-2 text-sm transition ${
                debouncedQuery && filteredCountries.length === 0
                  ? "border-red-400/30 bg-red-400/10 text-red-100"
                  : "border-gold/20 bg-gold/10 text-gold-soft"
              }`}
            >
              {resultLabel}
            </div>

            <div className="flex flex-wrap items-center gap-2 text-sm">
              <span className="text-neutral-500">Filtres actifs :</span>
              {activeFilters.length ? (
                activeFilters.map((filter) => (
                  <span key={filter} className="rounded-md border border-gold/20 bg-gold/10 px-2 py-1 text-xs font-semibold text-gold-soft">
                    {filter}
                  </span>
                ))
              ) : (
                <span className="text-neutral-400">Aucun filtre stratégique avancé</span>
              )}
              {activeFilters.length ? (
                <button
                  type="button"
                  onClick={() => {
                    setSelectedRegions([]);
                    setSelectedSubRegions([]);
                    setSelectedCategories([]);
                    setSelectedRegion("Toutes les régions");
                  }}
                  className="rounded-md border border-line px-2 py-1 text-xs font-semibold text-neutral-300 transition hover:border-gold/50 hover:text-gold-soft"
                >
                  Réinitialiser
                </button>
              ) : null}
            </div>
          </div>
        </section>

        {filtersOpen ? (
          <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm" role="dialog" aria-modal="true" aria-label="Filtres stratégiques Atlas Afrique">
            <button type="button" className="absolute inset-0 cursor-default" aria-label="Fermer les filtres stratégiques" onClick={() => setFiltersOpen(false)} />
            <aside
              id="atlas-strategic-filters"
              className="absolute right-0 top-0 flex h-full w-full max-w-md flex-col border-l border-gold/20 bg-[#101010] shadow-[0_30px_90px_rgba(0,0,0,0.45)]"
            >
              <div className="flex items-start justify-between gap-4 border-b border-line p-5">
                <div>
                  <p className="text-xs font-semibold uppercase tracking-[0.22em] text-gold">Atlas Afrique</p>
                  <h2 className="mt-2 text-xl font-semibold text-gold-soft">Filtres stratégiques</h2>
                  <p className="mt-1 text-sm text-neutral-400">{filteredCountries.length} pays trouvé{filteredCountries.length > 1 ? "s" : ""}</p>
                </div>
                <button
                  type="button"
                  onClick={() => setFiltersOpen(false)}
                  aria-label="Fermer le panneau de filtres"
                  className="rounded-md border border-line p-2 text-neutral-300 transition hover:border-gold/50 hover:text-gold-soft"
                >
                  <X size={18} aria-hidden="true" />
                </button>
              </div>

              <div className="flex-1 space-y-6 overflow-y-auto p-5">
                <FilterGroup title="Région" options={strategicRegions} selected={selectedRegions} onToggle={(value) => toggleFilter(value, selectedRegions, setSelectedRegions)} />
                <FilterGroup title="Sous-région" options={subRegions} selected={selectedSubRegions} onToggle={(value) => toggleFilter(value, selectedSubRegions, setSelectedSubRegions)} />
                <FilterGroup title="Catégories" options={categories} selected={selectedCategories} onToggle={(value) => toggleFilter(value, selectedCategories, setSelectedCategories)} />
              </div>

              <div className="grid grid-cols-2 gap-3 border-t border-line p-5">
                <button
                  type="button"
                  onClick={() => {
                    setSelectedRegions([]);
                    setSelectedSubRegions([]);
                    setSelectedCategories([]);
                    setSelectedRegion("Toutes les régions");
                  }}
                  className="h-11 rounded-md border border-line text-sm font-semibold text-neutral-200 transition hover:border-gold/50 hover:text-gold-soft"
                >
                  Réinitialiser
                </button>
                <button
                  type="button"
                  onClick={() => setFiltersOpen(false)}
                  className="h-11 rounded-md border border-gold/50 bg-gold/10 text-sm font-semibold text-gold-soft transition hover:border-gold hover:bg-gold/20"
                >
                  Appliquer
                </button>
              </div>
            </aside>
          </div>
        ) : null}

        <section className="grid items-stretch gap-4 md:grid-cols-2 xl:grid-cols-3">
          {filteredCountries.map((country) => (
            <article
              key={country.slug}
              className="flex min-h-[300px] flex-col rounded-lg border border-gold/20 bg-panel p-5 shadow-[0_18px_45px_rgba(0,0,0,0.22)] transition duration-200 hover:-translate-y-0.5 hover:border-gold/45 hover:shadow-[0_22px_55px_rgba(0,0,0,0.32)]"
            >
              <div className="flex min-h-[78px] items-start justify-between gap-4">
                <div className="min-w-0">
                  <h2 className="inline-flex max-w-full items-center gap-2 rounded-md border border-gold/30 bg-black/25 px-3 py-2 text-lg font-semibold text-gold-soft shadow-sm shadow-black/20">
                  <span className="text-2xl leading-none" aria-hidden="true">{country.flag}</span>
                  <span className="truncate">{country.country}</span>
                  </h2>
                  <p className="mt-3 text-xs font-semibold uppercase tracking-[0.22em] text-neutral-500">Note stratégique</p>
                </div>
                <span className="rounded-md border border-yellow-500/30 bg-yellow-500/10 px-2 py-1 text-xs font-semibold uppercase tracking-wide text-yellow-100">
                  Draft
                </span>
              </div>

              <dl className="mt-6 flex-1 space-y-3 text-sm">
                <div className="flex justify-between gap-4 border-t border-line pt-3">
                  <dt className="text-neutral-500">Score global</dt>
                  <dd className="text-right font-semibold text-gold-soft">À vérifier</dd>
                </div>
                <div className="flex justify-between gap-4 border-t border-line pt-3">
                  <dt className="text-neutral-500">Région</dt>
                  <dd className="text-right font-medium text-neutral-200">{country.region}</dd>
                </div>
                <div className="flex justify-between gap-4 border-t border-line pt-3">
                  <dt className="text-neutral-500">Date de mise à jour</dt>
                  <dd className="text-right font-medium text-neutral-200">{formatDisplayDate(country.lastUpdate)}</dd>
                </div>
              </dl>

              <Link
                href={`/atlas/${country.slug}`}
                className="mt-6 inline-flex h-11 w-full items-center justify-center rounded-md border border-gold/50 bg-gold/10 px-4 text-sm font-semibold text-gold-soft transition duration-200 hover:border-gold hover:bg-gold/20"
              >
                Consulter
              </Link>
              <button
                type="button"
                onClick={() => toggleComparison(country.slug, comparisonSlugs, setComparisonSlugs)}
                disabled={!comparisonSlugs.includes(country.slug) && comparisonSlugs.length >= 4}
                className={`mt-3 inline-flex h-10 w-full items-center justify-center rounded-md border px-4 text-sm font-semibold transition duration-200 ${
                  comparisonSlugs.includes(country.slug)
                    ? "border-gold bg-gold/20 text-gold-soft"
                    : "border-line bg-black/20 text-neutral-200 hover:border-gold/50 hover:text-gold-soft disabled:cursor-not-allowed disabled:opacity-40"
                }`}
              >
                {comparisonSlugs.includes(country.slug) ? "Retirer" : "Comparer"}
              </button>
            </article>
          ))}
        </section>

        {filteredCountries.length === 0 ? (
          <section className="rounded-lg border border-line bg-panel p-5 text-sm text-neutral-400">
            Aucun résultat trouvé. Essayez un pays, une région ou un sujet stratégique plus large.
          </section>
        ) : null}

        <ComparisonPanel countries={comparedCountries} onClear={() => setComparisonSlugs([])} />
      </section>
    </main>
  );
}

function AtlasFallback() {
  return (
    <main className="min-h-screen bg-ink px-5 py-8 text-neutral-100">
      <section className="mx-auto max-w-7xl rounded-lg border border-line bg-panel p-5 text-sm text-neutral-400">
        Chargement de l'Atlas Afrique...
      </section>
    </main>
  );
}

type AtlasCountry = ReturnType<typeof getAllCountryProfilesSync>[number];

function normalize(value: string) {
  return value
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[’']/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

function buildSearchText(country: AtlasCountry) {
  const metadata = countryFilterMetadata[country.slug] ?? { subRegions: [], categories: [] };
  const strategicCategories = [
    "note strategique",
    "geopolitique",
    "economie",
    "souverainete",
    "developpement",
    "securite",
    "innovation",
    "business",
    "odd",
    "agenda 2063",
    "atlas afrique"
  ];

  const searchable = [
    country.country,
    country.slug,
    country.region,
    ...country.regionalOrganizations,
    ...country.strategicPartners,
    ...country.risks,
    ...country.opportunities,
    ...country.odd,
    ...country.agenda2063,
    ...country.sourcesToVerify,
    ...metadata.subRegions,
    ...metadata.categories,
    ...strategicCategories
  ];

  return normalize(searchable.join(" "));
}

function toggleFilter(value: string, selected: string[], setSelected: (next: string[]) => void) {
  setSelected(selected.includes(value) ? selected.filter((item) => item !== value) : [...selected, value]);
}

function toggleComparison(slug: string, selected: string[], setSelected: (next: string[]) => void) {
  if (selected.includes(slug)) {
    setSelected(selected.filter((item) => item !== slug));
    return;
  }

  if (selected.length < 4) {
    setSelected([...selected, slug]);
  }
}

function ComparisonPanel({ countries, onClear }: { countries: AtlasCountry[]; onClear: () => void }) {
  const shareUrl = typeof window === "undefined"
    ? ""
    : `${window.location.origin}/atlas?compare=${countries.map((country) => country.slug).join(",")}`;

  if (countries.length === 0) {
    return (
      <section className="rounded-lg border border-line bg-panel p-5 text-sm text-neutral-400">
        Sélectionnez 2 à 4 pays avec le bouton Comparer pour activer la comparaison stratégique.
      </section>
    );
  }

  return (
    <section className="rounded-lg border border-gold/20 bg-panel shadow-[0_18px_45px_rgba(0,0,0,0.22)]">
      <div className="flex items-start justify-between gap-4 border-b border-line p-5 max-lg:grid">
        <div>
          <p className="text-xs font-semibold uppercase tracking-[0.22em] text-gold">Comparaison stratégique</p>
          <h2 className="mt-2 text-2xl font-semibold text-gold-soft">{countries.length} pays sélectionné{countries.length > 1 ? "s" : ""}</h2>
          <p className="mt-1 text-sm text-neutral-400">Minimum 2 pays, maximum 4. Les champs non sourcés restent indiqués comme non disponibles.</p>
        </div>
        <div className="flex flex-wrap gap-2">
          <button type="button" onClick={() => window.print()} className="rounded-md border border-gold/40 bg-gold/10 px-3 py-2 text-sm font-semibold text-gold-soft hover:bg-gold/20">
            Export PDF
          </button>
          <button type="button" onClick={() => window.print()} className="rounded-md border border-line px-3 py-2 text-sm font-semibold text-neutral-200 hover:border-gold/50 hover:text-gold-soft">
            Imprimer
          </button>
          <button
            type="button"
            onClick={() => void navigator.clipboard?.writeText(shareUrl)}
            className="rounded-md border border-line px-3 py-2 text-sm font-semibold text-neutral-200 hover:border-gold/50 hover:text-gold-soft"
          >
            Partager un lien
          </button>
          <button type="button" onClick={onClear} className="rounded-md border border-line px-3 py-2 text-sm font-semibold text-neutral-200 hover:border-gold/50 hover:text-gold-soft">
            Réinitialiser
          </button>
        </div>
      </div>

      {countries.length < 2 ? (
        <div className="p-5 text-sm text-yellow-100">Ajoutez au moins un deuxième pays pour afficher le tableau comparatif.</div>
      ) : (
        <div className="space-y-6 p-5">
          <ComparisonRadar countries={countries} />
          <div className="overflow-x-auto">
            <table className="w-full min-w-[920px] border-separate border-spacing-0 text-left text-sm">
              <thead>
                <tr>
                  <th className="sticky left-0 z-10 border-b border-line bg-panel px-3 py-3 text-xs uppercase tracking-wide text-neutral-500">Critère</th>
                  {countries.map((country) => (
                    <th key={country.slug} className="border-b border-line px-3 py-3 text-gold-soft">{country.flag} {country.country}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                <ComparisonSection title="Informations générales" rows={[
                  ["Capitale", (country) => country.capital],
                  ["Population", (country) => country.population],
                  ["Superficie", () => unavailable()],
                  ["Monnaie", (country) => country.currency]
                ]} countries={countries} />
                <ComparisonSection title="Économie" rows={[
                  ["PIB", (country) => country.gdp],
                  ["Croissance", () => unavailable()],
                  ["Inflation", () => unavailable()],
                  ["Secteurs stratégiques", (country) => country.opportunities.join(", ")]
                ]} countries={countries} />
                <ComparisonSection title="Géopolitique" rows={[
                  ["Organisations régionales", (country) => country.regionalOrganizations.join(", ")],
                  ["Partenaires majeurs", (country) => country.strategicPartners.join(", ")],
                  ["Position diplomatique", () => unavailable()]
                ]} countries={countries} />
                <ComparisonSection title="Sécurité" rows={[
                  ["Principaux risques", (country) => country.risks.join(", ")],
                  ["Menaces transfrontalières", () => unavailable()],
                  ["Situation sécuritaire", () => unavailable()]
                ]} countries={countries} />
                <ComparisonSection title="Énergie" rows={[
                  ["Ressources stratégiques", () => unavailable()],
                  ["Production énergétique", () => unavailable()]
                ]} countries={countries} />
                <ComparisonSection title="Technologie" rows={[
                  ["Niveau de numérisation", () => unavailable()],
                  ["Infrastructures numériques", () => unavailable()]
                ]} countries={countries} />
              </tbody>
            </table>
          </div>
        </div>
      )}
    </section>
  );
}

function ComparisonSection({
  title,
  rows,
  countries
}: {
  title: string;
  rows: Array<[string, (country: AtlasCountry) => string]>;
  countries: AtlasCountry[];
}) {
  return (
    <>
      <tr>
        <td colSpan={countries.length + 1} className="border-b border-line bg-black/30 px-3 py-3 text-xs font-semibold uppercase tracking-[0.2em] text-gold">
          {title}
        </td>
      </tr>
      {rows.map(([label, getValue]) => (
        <tr key={`${title}-${label}`}>
          <td className="sticky left-0 z-10 border-b border-line bg-panel px-3 py-3 font-semibold text-neutral-300">{label}</td>
          {countries.map((country) => (
            <td key={`${country.slug}-${label}`} className="border-b border-line px-3 py-3 text-neutral-300">
              {displayValue(getValue(country))}
            </td>
          ))}
        </tr>
      ))}
    </>
  );
}

function ComparisonRadar({ countries }: { countries: AtlasCountry[] }) {
  const axes = ["Économie", "Géopolitique", "Sécurité", "Énergie", "Technologie"];
  return (
    <div className="grid gap-3 lg:grid-cols-5">
      {axes.map((axis) => (
        <div key={axis} className="rounded-md border border-line bg-black/20 p-3">
          <p className="text-xs font-semibold uppercase tracking-wide text-gold">{axis}</p>
          <div className="mt-3 space-y-2">
            {countries.map((country) => {
              const score = availabilityScore(country, axis);
              return (
                <div key={`${country.slug}-${axis}`}>
                  <div className="flex justify-between gap-2 text-xs text-neutral-400">
                    <span>{country.country}</span>
                    <span>{score}%</span>
                  </div>
                  <div className="mt-1 h-1.5 rounded-full bg-neutral-800">
                    <div className="h-1.5 rounded-full bg-gold" style={{ width: `${score}%` }} />
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      ))}
    </div>
  );
}

function availabilityScore(country: AtlasCountry, axis: string) {
  const values: Record<string, string[]> = {
    "Économie": [country.gdp, country.currency, country.opportunities.join(" ")],
    "Géopolitique": [country.regionalOrganizations.join(" "), country.strategicPartners.join(" ")],
    "Sécurité": [country.risks.join(" ")],
    "Énergie": [country.opportunities.join(" ")],
    "Technologie": [country.opportunities.join(" ")]
  };
  const axisValues = values[axis] ?? [];
  if (!axisValues.length) return 0;
  const available = axisValues.filter((value) => !isUnavailable(value)).length;
  return Math.round((available / axisValues.length) * 100);
}

function displayValue(value: string) {
  return isUnavailable(value) ? unavailable() : value;
}

function isUnavailable(value: string) {
  const normalized = normalize(value);
  return !normalized || normalized.includes("donnee a verifier") || normalized.includes("a verifier");
}

function unavailable() {
  return "Donnée non disponible";
}

function FilterGroup({
  title,
  options,
  selected,
  onToggle
}: {
  title: string;
  options: string[];
  selected: string[];
  onToggle: (value: string) => void;
}) {
  return (
    <fieldset>
      <legend className="text-sm font-semibold uppercase tracking-[0.18em] text-gold">{title}</legend>
      <div className="mt-3 grid gap-2">
        {options.map((option) => {
          const active = selected.includes(option);
          return (
            <label
              key={option}
              className={`flex cursor-pointer items-center justify-between gap-3 rounded-md border px-3 py-2 text-sm transition ${
                active ? "border-gold bg-gold/15 text-gold-soft" : "border-line bg-black/20 text-neutral-300 hover:border-gold/50"
              }`}
            >
              <span>{option}</span>
              <input
                type="checkbox"
                checked={active}
                onChange={() => onToggle(option)}
                className="h-4 w-4 accent-[#d6aa4d]"
              />
            </label>
          );
        })}
      </div>
    </fieldset>
  );
}
