"use client";

import Link from "next/link";
import { Search } from "lucide-react";
import { useMemo, useState } from "react";
import {
  getGeopoliticalWatchEvents,
  watchCategories,
  watchLevels,
  watchRegions,
  type GeopoliticalWatchEvent,
  type WatchCategory,
  type WatchLevel
} from "@/lib/geopoliticalWatch";
import { formatDisplayDate } from "@/lib/dateDisplay";

const events = getGeopoliticalWatchEvents();

export default function GeopoliticalWatchPage() {
  const [query, setQuery] = useState("");
  const [category, setCategory] = useState<WatchCategory | "Toutes les catégories">("Toutes les catégories");
  const [level, setLevel] = useState<WatchLevel | "Tous les niveaux">("Tous les niveaux");
  const [region, setRegion] = useState("Toutes les régions");
  const [selectedId, setSelectedId] = useState<string | null>(events[0]?.id ?? null);

  const filteredEvents = useMemo(() => {
    const normalizedQuery = normalize(query);
    return events.filter((event) => {
      const categoryMatch = category === "Toutes les catégories" || event.category === category;
      const levelMatch = level === "Tous les niveaux" || event.importanceLevel === level;
      const regionMatch = region === "Toutes les régions" || event.region === region || event.country === region;
      const queryMatch = !normalizedQuery || normalize([
        event.title,
        event.country,
        event.region,
        event.actors.join(" "),
        event.summary,
        event.sources.join(" ")
      ].join(" ")).includes(normalizedQuery);
      return categoryMatch && levelMatch && regionMatch && queryMatch;
    });
  }, [category, level, query, region]);

  const selectedEvent = filteredEvents.find((event) => event.id === selectedId) ?? filteredEvents[0] ?? null;

  return (
    <main className="min-h-screen bg-ink px-5 py-8 text-neutral-100">
      <section className="mx-auto max-w-7xl space-y-6">
        <header className="flex items-start justify-between gap-5 border-b border-line pb-5 max-lg:grid">
          <div>
            <p className="text-xs font-semibold uppercase tracking-[0.24em] text-gold">Atlas Afrique</p>
            <h1 className="mt-3 text-3xl font-semibold text-gold-soft">Veille Géopolitique</h1>
            <p className="mt-2 max-w-3xl text-sm leading-6 text-neutral-400">
              Centre de veille intégré pour centraliser les événements stratégiques affectant l'Afrique. Aucun événement n'est affiché sans source traçable.
            </p>
          </div>
          <Link href="/atlas" className="rounded-md border border-gold/40 bg-gold/10 px-4 py-2 text-sm font-semibold text-gold-soft transition hover:bg-gold/20">
            Retour Atlas
          </Link>
        </header>

        <section className="grid gap-4 md:grid-cols-3">
          <Kpi title="Événements vérifiés" value={String(events.filter((event) => event.verificationStatus === "vérifié").length)} />
          <Kpi title="À vérifier" value={String(events.filter((event) => event.verificationStatus !== "vérifié").length)} />
          <Kpi title="Catégories suivies" value={String(watchCategories.length)} />
        </section>

        <section className="grid gap-3 rounded-lg border border-line bg-panel p-4 xl:grid-cols-[minmax(0,1fr)_220px_220px_220px]">
          <label className="group flex items-center gap-3 rounded-lg border border-gold/20 bg-black/25 px-4 py-3 transition focus-within:border-gold focus-within:shadow-[0_0_0_3px_rgba(214,170,77,0.12)]">
            <Search size={18} className="text-gold" aria-hidden="true" />
            <span className="sr-only">Rechercher dans la veille géopolitique</span>
            <input
              type="search"
              value={query}
              onChange={(event) => setQuery(event.target.value)}
              aria-label="Rechercher un événement, pays, acteur ou source"
              placeholder="Rechercher un événement, pays, acteur, source..."
              className="h-9 w-full bg-transparent text-sm text-neutral-100 outline-none placeholder:text-neutral-500"
            />
          </label>
          <Select label="Filtrer par catégorie" value={category} onChange={(value) => setCategory(value as WatchCategory | "Toutes les catégories")} values={["Toutes les catégories", ...watchCategories]} />
          <Select label="Filtrer par niveau" value={level} onChange={(value) => setLevel(value as WatchLevel | "Tous les niveaux")} values={["Tous les niveaux", ...watchLevels]} />
          <Select label="Filtrer par région" value={region} onChange={setRegion} values={watchRegions} />
        </section>

        <section className="grid gap-6 xl:grid-cols-[minmax(0,1fr)_380px]">
          <div className="space-y-6">
            <section className="rounded-lg border border-gold/20 bg-panel p-5">
              <div className="flex items-center justify-between gap-3">
                <div>
                  <p className="text-xs font-semibold uppercase tracking-[0.22em] text-gold">Carte interactive</p>
                  <h2 className="mt-2 text-xl font-semibold text-gold-soft">Événements stratégiques localisés</h2>
                </div>
                <p className="text-sm text-neutral-400">{filteredEvents.length} événement{filteredEvents.length > 1 ? "s" : ""}</p>
              </div>
              <div className="relative mt-5 h-[460px] overflow-hidden rounded-lg border border-line bg-[radial-gradient(circle_at_50%_45%,rgba(214,170,77,0.16),transparent_32%),linear-gradient(135deg,#080808,#141414)] max-md:h-[360px]">
                <AfricaSilhouette />
                {filteredEvents.map((event) => (
                  event.mapPosition ? (
                    <button
                      key={event.id}
                      type="button"
                      onClick={() => setSelectedId(event.id)}
                      className="absolute h-4 w-4 -translate-x-1/2 -translate-y-1/2 rounded-full border-2 border-gold bg-black shadow-[0_0_0_6px_rgba(214,170,77,0.12)]"
                      style={{ left: `${event.mapPosition.x}%`, top: `${event.mapPosition.y}%` }}
                      aria-label={`Afficher ${event.title}`}
                    />
                  ) : null
                ))}
                {filteredEvents.length === 0 ? <EmptyState title="Aucun événement cartographié" text="Ajoutez uniquement des événements sourcés et validés pour alimenter la carte." /> : null}
              </div>
            </section>

            <section className="rounded-lg border border-line bg-panel p-5">
              <p className="text-xs font-semibold uppercase tracking-[0.22em] text-gold">Chronologie</p>
              <h2 className="mt-2 text-xl font-semibold text-gold-soft">Évolution des événements</h2>
              <div className="mt-5 space-y-3">
                {filteredEvents.map((event) => <TimelineItem key={event.id} event={event} onSelect={() => setSelectedId(event.id)} />)}
                {filteredEvents.length === 0 ? (
                  <div className="rounded-md border border-line bg-black/20 p-4 text-sm text-neutral-400">
                    Aucun événement vérifié dans la chronologie. Les entrées doivent contenir date, source et statut de vérification.
                  </div>
                ) : null}
              </div>
            </section>
          </div>

          <aside className="space-y-6">
            <section className="rounded-lg border border-gold/30 bg-gold/10 p-5">
              <p className="text-xs font-semibold uppercase tracking-[0.22em] text-gold">Impact pour l'Afrique</p>
              <h2 className="mt-2 text-xl font-semibold text-gold-soft">{selectedEvent?.title ?? "Aucun événement sélectionné"}</h2>
              {selectedEvent ? (
                <div className="mt-4 space-y-4 text-sm text-neutral-300">
                  <ImpactBlock title="Conséquences économiques" value={selectedEvent.impact.economic} />
                  <ImpactBlock title="Conséquences géopolitiques" value={selectedEvent.impact.geopolitical} />
                  <ImpactBlock title="Conséquences sécuritaires" value={selectedEvent.impact.security} />
                  <ImpactBlock title="Opportunités" value={selectedEvent.impact.opportunities} />
                  <ImpactBlock title="Risques" value={selectedEvent.impact.risks} />
                </div>
              ) : (
                <p className="mt-4 text-sm leading-6 text-neutral-300">
                  La vue impact sera alimentée lorsqu'un événement sourcé sera ajouté et vérifié.
                </p>
              )}
            </section>

            <section className="rounded-lg border border-line bg-panel p-5">
              <p className="text-xs font-semibold uppercase tracking-[0.22em] text-gold">Événements filtrés</p>
              <div className="mt-4 max-h-[480px] space-y-3 overflow-auto pr-1">
                {filteredEvents.map((event) => (
                  <EventCard key={event.id} event={event} onSelect={() => setSelectedId(event.id)} />
                ))}
                {filteredEvents.length === 0 ? (
                  <div className="rounded-md border border-line bg-black/20 p-4 text-sm leading-6 text-neutral-400">
                    Aucun événement disponible. La contrainte éditoriale interdit d'afficher des faits non sourcés.
                  </div>
                ) : null}
              </div>
            </section>
          </aside>
        </section>
      </section>
    </main>
  );
}

function Kpi({ title, value }: { title: string; value: string }) {
  return (
    <article className="rounded-lg border border-gold/20 bg-panel p-5">
      <p className="text-xs font-semibold uppercase tracking-[0.18em] text-gold">{title}</p>
      <p className="mt-2 text-2xl font-semibold text-gold-soft">{value}</p>
      <p className="mt-1 text-sm text-neutral-400">Validation humaine obligatoire</p>
    </article>
  );
}

function Select({ label, value, values, onChange }: { label: string; value: string; values: string[]; onChange: (value: string) => void }) {
  return (
    <select
      value={value}
      onChange={(event) => onChange(event.target.value)}
      aria-label={label}
      className="rounded-lg border border-line bg-black/25 px-3 py-3 text-sm text-neutral-100 outline-none focus:border-gold"
    >
      {values.map((item) => <option key={item}>{item}</option>)}
    </select>
  );
}

function EventCard({ event, onSelect }: { event: GeopoliticalWatchEvent; onSelect: () => void }) {
  return (
    <button type="button" onClick={onSelect} className="w-full rounded-md border border-line bg-black/20 p-4 text-left text-sm transition hover:border-gold/50 hover:bg-gold/10">
      <span className="block font-semibold text-neutral-100">{event.title}</span>
      <span className="mt-1 block text-xs text-neutral-500">{formatDisplayDate(event.date)} · {event.country} · {event.importanceLevel}</span>
      <span className="mt-2 block text-neutral-300">{event.summary}</span>
      <span className="mt-2 block text-xs text-gold-soft">Sources : {event.sources.join(", ")}</span>
    </button>
  );
}

function TimelineItem({ event, onSelect }: { event: GeopoliticalWatchEvent; onSelect: () => void }) {
  return (
    <button type="button" onClick={onSelect} className="grid w-full grid-cols-[120px_1fr] gap-4 rounded-md border border-line bg-black/20 p-4 text-left text-sm transition hover:border-gold/50">
      <span className="font-semibold text-gold-soft">{formatDisplayDate(event.date)}</span>
      <span>
        <span className="block font-semibold text-neutral-100">{event.title}</span>
        <span className="mt-1 block text-neutral-400">{event.region} · {event.category}</span>
      </span>
    </button>
  );
}

function ImpactBlock({ title, value }: { title: string; value: string }) {
  return (
    <section>
      <h3 className="text-xs font-semibold uppercase tracking-[0.16em] text-gold">{title}</h3>
      <p className="mt-1 leading-6">{value}</p>
    </section>
  );
}

function EmptyState({ title, text }: { title: string; text: string }) {
  return (
    <div className="absolute inset-x-5 top-1/2 -translate-y-1/2 rounded-lg border border-gold/20 bg-black/60 p-5 text-center">
      <p className="font-semibold text-gold-soft">{title}</p>
      <p className="mt-2 text-sm text-neutral-400">{text}</p>
    </div>
  );
}

function AfricaSilhouette() {
  return (
    <svg viewBox="0 0 720 720" className="absolute inset-0 h-full w-full" aria-hidden="true">
      <path
        d="M302 58 246 86l-34 56-58 50-12 80 50 58 16 88 58 50 34 72 62 76 82-32 36-82 72-22 22-76 62-56-18-68 34-78-50-50-28-78-84-26-50-56-78 10Z"
        fill="rgba(214,170,77,0.12)"
        stroke="rgba(214,170,77,0.55)"
        strokeWidth="3"
      />
    </svg>
  );
}

function normalize(value: string) {
  return value
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[’']/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}
