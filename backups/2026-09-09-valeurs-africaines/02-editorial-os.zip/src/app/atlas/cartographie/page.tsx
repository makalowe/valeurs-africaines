"use client";

import Link from "next/link";
import { Expand, Minus, Plus, RotateCcw, Search } from "lucide-react";
import type { PointerEvent, ReactNode } from "react";
import { useMemo, useRef, useState } from "react";
import {
  geopoliticalCountries,
  geopoliticalLayers,
  geopoliticalThemes,
  getGeopoliticalMapItems,
  type GeopoliticalLayerId,
  type GeopoliticalMapItem
} from "@/lib/geopoliticalMap";
import { formatDisplayDate } from "@/lib/dateDisplay";

const allItems = getGeopoliticalMapItems();
const allLayerIds = geopoliticalLayers.map((layer) => layer.id);

export default function GeopoliticalMapPage() {
  const [query, setQuery] = useState("");
  const [theme, setTheme] = useState("Tous les thèmes");
  const [country, setCountry] = useState("Tous les pays");
  const [activeLayers, setActiveLayers] = useState<GeopoliticalLayerId[]>(allLayerIds);
  const [selectedItem, setSelectedItem] = useState<GeopoliticalMapItem | null>(allItems[0] ?? null);
  const [scale, setScale] = useState(1);
  const [offset, setOffset] = useState({ x: 0, y: 0 });
  const [dragStart, setDragStart] = useState<{ pointerId: number; x: number; y: number; originX: number; originY: number } | null>(null);
  const mapRef = useRef<HTMLDivElement | null>(null);

  const filteredItems = useMemo(() => {
    const normalizedQuery = normalize(query);
    return allItems.filter((item) => {
      const layer = geopoliticalLayers.find((candidate) => candidate.id === item.layerId);
      const layerMatch = activeLayers.includes(item.layerId);
      const themeMatch = theme === "Tous les thèmes" || layer?.name === theme || item.theme === theme;
      const countryMatch = country === "Tous les pays" || normalize(item.country).includes(normalize(country)) || normalize(country).includes(normalize(item.country));
      const queryMatch = !normalizedQuery || normalize([
        item.name,
        item.country,
        item.theme,
        item.description,
        item.strategicImportance,
        item.source,
        layer?.name ?? ""
      ].join(" ")).includes(normalizedQuery);
      return layerMatch && themeMatch && countryMatch && queryMatch;
    });
  }, [activeLayers, country, query, theme]);

  const activeLayerDetails = geopoliticalLayers.filter((layer) => activeLayers.includes(layer.id));

  function toggleLayer(layerId: GeopoliticalLayerId) {
    setActiveLayers((current) => {
      if (current.includes(layerId)) {
        return current.filter((item) => item !== layerId);
      }
      return [...current, layerId];
    });
  }

  function zoom(delta: number) {
    setScale((current) => Math.min(2.25, Math.max(0.75, Number((current + delta).toFixed(2)))));
  }

  function resetView() {
    setScale(1);
    setOffset({ x: 0, y: 0 });
  }

  async function openFullscreen() {
    if (!mapRef.current || !document.fullscreenEnabled) return;
    if (document.fullscreenElement) {
      await document.exitFullscreen();
      return;
    }
    await mapRef.current.requestFullscreen();
  }

  function onPointerDown(event: PointerEvent<HTMLDivElement>) {
    event.currentTarget.setPointerCapture(event.pointerId);
    setDragStart({
      pointerId: event.pointerId,
      x: event.clientX,
      y: event.clientY,
      originX: offset.x,
      originY: offset.y
    });
  }

  function onPointerMove(event: PointerEvent<HTMLDivElement>) {
    if (!dragStart || dragStart.pointerId !== event.pointerId) return;
    setOffset({
      x: dragStart.originX + event.clientX - dragStart.x,
      y: dragStart.originY + event.clientY - dragStart.y
    });
  }

  function onPointerUp(event: PointerEvent<HTMLDivElement>) {
    if (dragStart?.pointerId === event.pointerId) {
      setDragStart(null);
    }
  }

  return (
    <main className="min-h-screen bg-ink px-5 py-8 text-neutral-100">
      <section className="mx-auto max-w-7xl space-y-6">
        <header className="flex items-start justify-between gap-5 border-b border-line pb-5 max-lg:grid">
          <div>
            <p className="text-xs font-semibold uppercase tracking-[0.24em] text-gold">Atlas Afrique</p>
            <h1 className="mt-3 text-3xl font-semibold text-gold-soft">Cartographie Géopolitique</h1>
            <p className="mt-2 max-w-3xl text-sm leading-6 text-neutral-400">
              Carte stratégique exploratoire pour visualiser les couches d'influence, de conflit, d'infrastructures et de ressources. Les données restent à vérifier avant publication.
            </p>
          </div>
          <Link href="/atlas" className="rounded-md border border-gold/40 bg-gold/10 px-4 py-2 text-sm font-semibold text-gold-soft transition hover:bg-gold/20">
            Retour Atlas
          </Link>
        </header>

        <section className="grid gap-4 rounded-lg border border-line bg-panel p-4 xl:grid-cols-[minmax(0,1fr)_220px_220px]">
          <label className="group flex items-center gap-3 rounded-lg border border-gold/20 bg-black/25 px-4 py-3 transition focus-within:border-gold focus-within:shadow-[0_0_0_3px_rgba(214,170,77,0.12)]">
            <Search size={18} className="text-gold" aria-hidden="true" />
            <span className="sr-only">Rechercher sur la carte géopolitique</span>
            <input
              type="search"
              value={query}
              onChange={(event) => setQuery(event.target.value)}
              aria-label="Rechercher un acteur, un pays, une couche ou un enjeu stratégique"
              placeholder="Rechercher une zone, un acteur, une ressource..."
              className="h-9 w-full bg-transparent text-sm text-neutral-100 outline-none placeholder:text-neutral-500"
            />
          </label>
          <select
            value={theme}
            onChange={(event) => setTheme(event.target.value)}
            aria-label="Filtrer par thème"
            className="rounded-lg border border-line bg-black/25 px-3 py-3 text-sm text-neutral-100 outline-none focus:border-gold"
          >
            {geopoliticalThemes.map((item) => <option key={item}>{item}</option>)}
          </select>
          <select
            value={country}
            onChange={(event) => setCountry(event.target.value)}
            aria-label="Filtrer par pays ou région"
            className="rounded-lg border border-line bg-black/25 px-3 py-3 text-sm text-neutral-100 outline-none focus:border-gold"
          >
            {geopoliticalCountries.map((item) => <option key={item}>{item}</option>)}
          </select>
        </section>

        <section className="grid gap-6 xl:grid-cols-[minmax(0,1fr)_360px]">
          <div className="space-y-4">
            <section className="rounded-lg border border-line bg-panel p-4">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div>
                  <p className="text-xs font-semibold uppercase tracking-[0.2em] text-gold">Couches activables</p>
                  <p className="mt-1 text-sm text-neutral-400">{filteredItems.length} élément{filteredItems.length > 1 ? "s" : ""} affiché{filteredItems.length > 1 ? "s" : ""}</p>
                </div>
                <div className="flex flex-wrap gap-2">
                  {geopoliticalLayers.map((layer) => (
                    <button
                      key={layer.id}
                      type="button"
                      onClick={() => toggleLayer(layer.id)}
                      className={`rounded-md border px-3 py-2 text-xs font-semibold transition ${
                        activeLayers.includes(layer.id)
                          ? "border-gold bg-gold/15 text-gold-soft"
                          : "border-line bg-black/20 text-neutral-400 hover:border-gold/50 hover:text-gold-soft"
                      }`}
                    >
                      {layer.name}
                    </button>
                  ))}
                </div>
              </div>
            </section>

            <section ref={mapRef} className="overflow-hidden rounded-lg border border-gold/20 bg-[#070707] shadow-[0_18px_45px_rgba(0,0,0,0.28)]">
              <div className="flex flex-wrap items-center justify-between gap-3 border-b border-line bg-black/30 px-4 py-3">
                <div>
                  <p className="text-sm font-semibold text-gold-soft">Carte interactive de l'Afrique</p>
                  <p className="text-xs text-neutral-500">Zoom, déplacement, plein écran. Positionnement schématique à valider.</p>
                </div>
                <div className="flex items-center gap-2">
                  <IconButton label="Zoom avant" onClick={() => zoom(0.15)} icon={<Plus size={16} />} />
                  <IconButton label="Zoom arrière" onClick={() => zoom(-0.15)} icon={<Minus size={16} />} />
                  <IconButton label="Réinitialiser la vue" onClick={resetView} icon={<RotateCcw size={16} />} />
                  <IconButton label="Plein écran" onClick={openFullscreen} icon={<Expand size={16} />} />
                </div>
              </div>

              <div
                role="application"
                aria-label="Carte géopolitique interactive de l'Afrique"
                className="relative h-[560px] touch-none overflow-hidden bg-[radial-gradient(circle_at_50%_45%,rgba(214,170,77,0.16),transparent_32%),linear-gradient(135deg,#080808,#141414)] max-md:h-[440px]"
                onPointerDown={onPointerDown}
                onPointerMove={onPointerMove}
                onPointerUp={onPointerUp}
                onPointerCancel={onPointerUp}
              >
                <div
                  className="absolute left-1/2 top-1/2 h-[720px] w-[720px] max-w-none origin-center -translate-x-1/2 -translate-y-1/2 transition-transform duration-100"
                  style={{ transform: `translate(calc(-50% + ${offset.x}px), calc(-50% + ${offset.y}px)) scale(${scale})` }}
                >
                  <AfricaSilhouette />
                  {filteredItems.map((item) => {
                    const layer = geopoliticalLayers.find((candidate) => candidate.id === item.layerId);
                    const selected = selectedItem?.id === item.id;
                    return (
                      <button
                        key={item.id}
                        type="button"
                        onClick={(event) => {
                          event.stopPropagation();
                          setSelectedItem(item);
                        }}
                        className={`absolute -translate-x-1/2 -translate-y-1/2 rounded-full border-2 bg-black/80 transition hover:scale-125 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-gold ${
                          selected ? "h-5 w-5 shadow-[0_0_0_6px_rgba(214,170,77,0.18)]" : "h-4 w-4"
                        }`}
                        style={{ left: `${item.position.x}%`, top: `${item.position.y}%`, borderColor: layer?.color ?? "#d6aa4d" }}
                        aria-label={`Afficher ${item.name}`}
                        title={item.name}
                      />
                    );
                  })}
                </div>
              </div>

              <div className="grid gap-2 border-t border-line bg-black/20 px-4 py-3 text-xs text-neutral-400 sm:grid-cols-2 lg:grid-cols-3">
                {activeLayerDetails.map((layer) => (
                  <div key={layer.id} className="flex items-center gap-2">
                    <span className="h-2.5 w-2.5 rounded-full" style={{ backgroundColor: layer.color }} />
                    <span>{layer.name}</span>
                  </div>
                ))}
              </div>
            </section>
          </div>

          <aside className="space-y-4">
            <section className="rounded-lg border border-gold/30 bg-gold/10 p-5">
              <p className="text-xs font-semibold uppercase tracking-[0.22em] text-gold">Lecture stratégique</p>
              <h2 className="mt-2 text-xl font-semibold text-gold-soft">Synthèse cartographique</h2>
              <div className="mt-4 space-y-4 text-sm leading-6 text-neutral-300">
                <PanelBlock title="Résumé analytique">
                  Cette carte sert de grille de lecture éditoriale. Les couches indiquent les domaines à documenter avant analyse publiée.
                </PanelBlock>
                <PanelBlock title="Implications régionales">
                  Les implications régionales doivent être établies à partir des Notes Pays, observatoires et sources vérifiées.
                </PanelBlock>
                <PanelBlock title="Implications pour l'Afrique">
                  L'impact continental doit être évalué selon l'intérêt stratégique, la souveraineté, l'économie, l'ODD concerné et le niveau de risque.
                </PanelBlock>
              </div>
            </section>

            {selectedItem ? (
              <section className="rounded-lg border border-line bg-panel p-5">
                <p className="text-xs font-semibold uppercase tracking-[0.2em] text-gold">
                  {geopoliticalLayers.find((layer) => layer.id === selectedItem.layerId)?.name}
                </p>
                <h2 className="mt-2 text-2xl font-semibold text-gold-soft">{selectedItem.name}</h2>
                <dl className="mt-4 grid gap-3 text-sm">
                  <Meta label="Pays / zone" value={selectedItem.country} />
                  <Meta label="Description" value={selectedItem.description} />
                  <Meta label="Importance stratégique" value={selectedItem.strategicImportance} />
                  <Meta label="Source" value={selectedItem.source} />
                  <Meta label="Date de mise à jour" value={formatDisplayDate(selectedItem.updatedAt)} />
                </dl>
              </section>
            ) : null}

            <section className="rounded-lg border border-line bg-panel p-5">
              <p className="text-xs font-semibold uppercase tracking-[0.2em] text-gold">Éléments filtrés</p>
              <div className="mt-3 max-h-[360px] space-y-2 overflow-auto pr-1">
                {filteredItems.map((item) => (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => setSelectedItem(item)}
                    className="w-full rounded-md border border-line bg-black/20 p-3 text-left text-sm transition hover:border-gold/50 hover:bg-gold/10"
                  >
                    <span className="font-semibold text-neutral-100">{item.name}</span>
                    <span className="mt-1 block text-xs text-neutral-500">{item.country}</span>
                  </button>
                ))}
                {filteredItems.length === 0 ? <p className="text-sm text-neutral-400">Aucun élément ne correspond aux filtres.</p> : null}
              </div>
            </section>
          </aside>
        </section>
      </section>
    </main>
  );
}

function AfricaSilhouette() {
  return (
    <svg viewBox="0 0 720 720" className="absolute inset-0 h-full w-full" aria-hidden="true">
      <path
        d="M302 58 246 86l-34 56-58 50-12 80 50 58 16 88 58 50 34 72 62 76 82-32 36-82 72-22 22-76 62-56-18-68 34-78-50-50-28-78-84-26-50-56-78 10Z"
        fill="rgba(214,170,77,0.12)"
        stroke="rgba(214,170,77,0.55)"
        strokeWidth="3"
      />
      <path
        d="M202 310c96 18 194 10 300-26M248 464c82-34 176-38 288-18M382 98c-18 150-6 312 48 488"
        fill="none"
        stroke="rgba(255,255,255,0.08)"
        strokeWidth="2"
      />
    </svg>
  );
}

function IconButton({ label, icon, onClick }: { label: string; icon: ReactNode; onClick: () => void }) {
  return (
    <button
      type="button"
      onClick={onClick}
      aria-label={label}
      title={label}
      className="inline-flex h-9 w-9 items-center justify-center rounded-md border border-line bg-black/25 text-gold-soft transition hover:border-gold hover:bg-gold/10"
    >
      {icon}
    </button>
  );
}

function PanelBlock({ title, children }: { title: string; children: ReactNode }) {
  return (
    <section>
      <h3 className="text-xs font-semibold uppercase tracking-[0.16em] text-gold">{title}</h3>
      <p className="mt-1">{children}</p>
    </section>
  );
}

function Meta({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-md border border-line bg-black/20 p-3">
      <dt className="text-xs uppercase tracking-wide text-neutral-500">{label}</dt>
      <dd className="mt-1 text-neutral-200">{value}</dd>
    </div>
  );
}

function normalize(value: string) {
  return value
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[’']/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}
