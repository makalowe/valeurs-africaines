"use client";

import Link from "next/link";
import { Minus, Plus, RotateCcw, Search } from "lucide-react";
import type { ReactNode } from "react";
import { useMemo, useState } from "react";
import {
  geopoliticalMapLayers,
  getAfricaGeopoliticalMapProfiles,
  getRiskColorClass,
  type GeopoliticalCountryMapProfile
} from "@/lib/africaGeopoliticalMap";

const countries = getAfricaGeopoliticalMapProfiles();
const regions = ["Toutes les régions", ...Array.from(new Set(countries.map((country) => country.region)))];

export default function AfricaGeopoliticalMapPage() {
  const [query, setQuery] = useState("");
  const [region, setRegion] = useState("Toutes les régions");
  const [activeLayers, setActiveLayers] = useState<string[]>(geopoliticalMapLayers);
  const [selectedSlug, setSelectedSlug] = useState(countries[0]?.slug ?? "");
  const [scale, setScale] = useState(1);
  const [offset, setOffset] = useState({ x: 0, y: 0 });

  const filteredCountries = useMemo(() => {
    const normalizedQuery = normalize(query);
    return countries.filter((country) => {
      const regionMatch = region === "Toutes les régions" || country.region === region;
      const queryMatch = !normalizedQuery || normalize([
        country.officialName,
        country.capital,
        country.region,
        country.regionalOrganizations.join(" "),
        country.geopoliticalStatus
      ].join(" ")).includes(normalizedQuery);
      return regionMatch && queryMatch;
    });
  }, [query, region]);

  const selectedCountry = filteredCountries.find((country) => country.slug === selectedSlug) ?? filteredCountries[0] ?? countries[0];

  function selectCountry(country: GeopoliticalCountryMapProfile) {
    setSelectedSlug(country.slug);
    setScale(1.55);
    setOffset({
      x: (50 - country.mapPosition.x) * 5,
      y: (50 - country.mapPosition.y) * 5
    });
  }

  function zoomRegion(nextRegion: string) {
    setRegion(nextRegion);
    if (nextRegion === "Toutes les régions") {
      setScale(1);
      setOffset({ x: 0, y: 0 });
      return;
    }
    setScale(1.35);
    const regionCountries = countries.filter((country) => country.region === nextRegion);
    if (!regionCountries.length) return;
    const avgX = regionCountries.reduce((total, country) => total + country.mapPosition.x, 0) / regionCountries.length;
    const avgY = regionCountries.reduce((total, country) => total + country.mapPosition.y, 0) / regionCountries.length;
    setOffset({ x: (50 - avgX) * 4, y: (50 - avgY) * 4 });
  }

  function toggleLayer(layer: string) {
    setActiveLayers((current) => current.includes(layer) ? current.filter((item) => item !== layer) : [...current, layer]);
  }

  return (
    <main className="min-h-screen bg-ink px-5 py-8 text-neutral-100">
      <section className="mx-auto max-w-7xl space-y-6">
        <header className="flex items-start justify-between gap-5 border-b border-line pb-5 max-lg:grid">
          <div>
            <p className="text-xs font-semibold uppercase tracking-[0.24em] text-gold">Atlas Afrique</p>
            <h1 className="mt-3 text-3xl font-semibold text-gold-soft">Africa Geopolitical Map</h1>
            <p className="mt-2 max-w-3xl text-sm leading-6 text-neutral-400">
              Carte interactive pour l'analyse géopolitique, économique et sécuritaire. Les données réelles restent à intégrer et valider avant publication.
            </p>
          </div>
          <Link href="/atlas" className="rounded-md border border-gold/40 bg-gold/10 px-4 py-2 text-sm font-semibold text-gold-soft transition hover:bg-gold/20">
            Retour Atlas
          </Link>
        </header>

        <section className="grid gap-3 rounded-lg border border-line bg-panel p-4 lg:grid-cols-[minmax(0,1fr)_260px]">
          <label className="group flex items-center gap-3 rounded-lg border border-gold/20 bg-black/25 px-4 py-3 transition focus-within:border-gold focus-within:shadow-[0_0_0_3px_rgba(214,170,77,0.12)]">
            <Search size={18} className="text-gold" aria-hidden="true" />
            <span className="sr-only">Recherche rapide par pays</span>
            <input
              type="search"
              value={query}
              onChange={(event) => setQuery(event.target.value)}
              aria-label="Recherche rapide par pays"
              placeholder="Rechercher un pays, une capitale, une organisation..."
              className="h-9 w-full bg-transparent text-sm text-neutral-100 outline-none placeholder:text-neutral-500"
            />
          </label>
          <select
            value={region}
            onChange={(event) => zoomRegion(event.target.value)}
            aria-label="Zoom par région"
            className="rounded-lg border border-line bg-black/25 px-3 py-3 text-sm text-neutral-100 outline-none focus:border-gold"
          >
            {regions.map((item) => <option key={item}>{item}</option>)}
          </select>
        </section>

        <section className="grid gap-6 xl:grid-cols-[minmax(0,1fr)_390px]">
          <div className="space-y-4">
            <section className="rounded-lg border border-line bg-panel p-4">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div>
                  <p className="text-xs font-semibold uppercase tracking-[0.22em] text-gold">Couches activables</p>
                  <p className="mt-1 text-sm text-neutral-400">{filteredCountries.length} pays affiché{filteredCountries.length > 1 ? "s" : ""}</p>
                </div>
                <div className="flex flex-wrap gap-2">
                  {geopoliticalMapLayers.map((layer) => (
                    <button
                      key={layer}
                      type="button"
                      onClick={() => toggleLayer(layer)}
                      className={`rounded-md border px-3 py-2 text-xs font-semibold transition ${
                        activeLayers.includes(layer)
                          ? "border-gold bg-gold/15 text-gold-soft"
                          : "border-line bg-black/20 text-neutral-400 hover:border-gold/50 hover:text-gold-soft"
                      }`}
                    >
                      {layer}
                    </button>
                  ))}
                </div>
              </div>
            </section>

            <section className="overflow-hidden rounded-lg border border-gold/20 bg-[#070707] shadow-[0_18px_45px_rgba(0,0,0,0.28)]">
              <div className="flex flex-wrap items-center justify-between gap-3 border-b border-line bg-black/30 px-4 py-3">
                <div>
                  <p className="text-sm font-semibold text-gold-soft">Carte complète de l'Afrique</p>
                  <p className="text-xs text-neutral-500">Positionnement schématique, prêt pour données géographiques réelles.</p>
                </div>
                <div className="flex items-center gap-2">
                  <IconButton label="Zoom avant" onClick={() => setScale((value) => Math.min(2.4, value + 0.15))} icon={<Plus size={16} />} />
                  <IconButton label="Zoom arrière" onClick={() => setScale((value) => Math.max(0.8, value - 0.15))} icon={<Minus size={16} />} />
                  <IconButton label="Réinitialiser" onClick={() => { setScale(1); setOffset({ x: 0, y: 0 }); setRegion("Toutes les régions"); }} icon={<RotateCcw size={16} />} />
                </div>
              </div>

              <div className="relative h-[620px] overflow-hidden bg-[radial-gradient(circle_at_50%_45%,rgba(214,170,77,0.16),transparent_32%),linear-gradient(135deg,#080808,#141414)] max-md:h-[460px]">
                <div
                  className="absolute left-1/2 top-1/2 h-[760px] w-[760px] max-w-none origin-center -translate-x-1/2 -translate-y-1/2 transition-transform duration-200"
                  style={{ transform: `translate(calc(-50% + ${offset.x}px), calc(-50% + ${offset.y}px)) scale(${scale})` }}
                >
                  <AfricaSilhouette />
                  {filteredCountries.map((country) => (
                    <button
                      key={country.slug}
                      type="button"
                      onClick={() => selectCountry(country)}
                      className={`absolute -translate-x-1/2 -translate-y-1/2 rounded-md border bg-black/85 px-2 py-1 text-xs font-semibold transition hover:scale-110 ${
                        selectedCountry?.slug === country.slug ? "border-gold text-gold-soft shadow-[0_0_0_5px_rgba(214,170,77,0.18)]" : "border-line text-neutral-200"
                      }`}
                      style={{ left: `${country.mapPosition.x}%`, top: `${country.mapPosition.y}%` }}
                    >
                      <span className={`mr-1 inline-block h-2 w-2 rounded-full ${getRiskColorClass(country.riskColor)}`} />
                      {country.flag} {country.officialName}
                    </button>
                  ))}
                </div>
              </div>
            </section>

            <section className="grid gap-3 md:grid-cols-2 xl:grid-cols-4">
              {filteredCountries.map((country) => (
                <button key={country.slug} type="button" onClick={() => selectCountry(country)} className="rounded-lg border border-line bg-panel p-4 text-left text-sm transition hover:border-gold/50">
                  <span className="font-semibold text-neutral-100">{country.flag} {country.officialName}</span>
                  <span className="mt-1 block text-xs text-neutral-500">{country.region}</span>
                  <span className="mt-2 block text-gold-soft">{country.geopoliticalStatus}</span>
                </button>
              ))}
            </section>
          </div>

          <CountryPanel country={selectedCountry} activeLayers={activeLayers} />
        </section>
      </section>
    </main>
  );
}

function CountryPanel({ country, activeLayers }: { country?: GeopoliticalCountryMapProfile; activeLayers: string[] }) {
  if (!country) return null;

  return (
    <aside className="space-y-6">
      <section className="rounded-lg border border-gold/30 bg-gold/10 p-5">
        <p className="text-xs font-semibold uppercase tracking-[0.22em] text-gold">Fiche pays</p>
        <h2 className="mt-2 text-2xl font-semibold text-gold-soft">{country.flag} {country.officialName}</h2>
        <dl className="mt-4 grid gap-3 text-sm">
          <Meta label="Capitale" value={country.capital} />
          <Meta label="Population" value={country.population} />
          <Meta label="PIB" value={country.gdp} />
          <Meta label="Régime politique" value={country.politicalRegime} />
          <Meta label="Organisation régionale" value={country.regionalOrganizations.join(", ")} />
          <Meta label="Note de risque" value={country.riskNote} />
          <Meta label="Note d'opportunité" value={country.opportunityNote} />
          <Meta label="Statut géopolitique" value={country.geopoliticalStatus} />
        </dl>
        <Link href={`/atlas/${country.slug}`} className="mt-4 inline-flex rounded-md border border-gold/40 bg-black/20 px-3 py-2 text-sm font-semibold text-gold-soft transition hover:border-gold hover:bg-gold/15">
          Voir la Note Pays complète
        </Link>
      </section>

      <section className="rounded-lg border border-line bg-panel p-5">
        <p className="text-xs font-semibold uppercase tracking-[0.22em] text-gold">Analyse stratégique</p>
        <div className="mt-4 space-y-4 text-sm text-neutral-300">
          <Block title="Résumé stratégique">{country.strategicSummary}</Block>
          <Block title="Forces"><List values={country.strengths} /></Block>
          <Block title="Vulnérabilités"><List values={country.vulnerabilities} /></Block>
          <Block title="Opportunités"><List values={country.opportunities} /></Block>
          <Block title="Risques"><List values={country.risks} /></Block>
          <Block title="Derniers signaux faibles"><List values={country.weakSignals} /></Block>
        </div>
      </section>

      <section className="rounded-lg border border-line bg-panel p-5">
        <p className="text-xs font-semibold uppercase tracking-[0.22em] text-gold">Couches actives</p>
        <div className="mt-4 space-y-4 text-sm text-neutral-300">
          {activeLayers.map((layer) => (
            <Block key={layer} title={layer}>
              <List values={getLayerValues(country, layer)} />
            </Block>
          ))}
        </div>
      </section>
    </aside>
  );
}

function getLayerValues(country: GeopoliticalCountryMapProfile, layer: string) {
  if (layer === "Géopolitique") return country.layers.geopolitics;
  if (layer === "Économie") return country.layers.economy;
  if (layer === "Sécurité") return country.layers.security;
  if (layer === "Ressources") return country.layers.resources;
  if (layer === "Influence") return country.layers.influence;
  return ["Donnée à vérifier"];
}

function IconButton({ label, icon, onClick }: { label: string; icon: ReactNode; onClick: () => void }) {
  return (
    <button type="button" onClick={onClick} aria-label={label} title={label} className="inline-flex h-9 w-9 items-center justify-center rounded-md border border-line bg-black/25 text-gold-soft transition hover:border-gold hover:bg-gold/10">
      {icon}
    </button>
  );
}

function Block({ title, children }: { title: string; children: ReactNode }) {
  return (
    <section>
      <h3 className="text-xs font-semibold uppercase tracking-[0.18em] text-gold">{title}</h3>
      <div className="mt-2 leading-6">{children}</div>
    </section>
  );
}

function Meta({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-md border border-line bg-black/20 p-3">
      <dt className="text-xs uppercase tracking-wide text-neutral-500">{label}</dt>
      <dd className="mt-1 font-medium text-neutral-200">{value}</dd>
    </div>
  );
}

function List({ values }: { values: string[] }) {
  return (
    <ul className="list-inside list-disc space-y-1">
      {values.map((value) => <li key={value}>{value}</li>)}
    </ul>
  );
}

function AfricaSilhouette() {
  return (
    <svg viewBox="0 0 720 720" className="absolute inset-0 h-full w-full" aria-hidden="true">
      <path
        d="M302 58 246 86l-34 56-58 50-12 80 50 58 16 88 58 50 34 72 62 76 82-32 36-82 72-22 22-76 62-56-18-68 34-78-50-50-28-78-84-26-50-56-78 10Z"
        fill="rgba(214,170,77,0.12)"
        stroke="rgba(214,170,77,0.55)"
        strokeWidth="3"
      />
    </svg>
  );
}

function normalize(value: string) {
  return value
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[’']/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}
