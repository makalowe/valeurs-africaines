"use client";

import Link from "next/link";
import { Bar, BarChart, CartesianGrid, PolarAngleAxis, PolarGrid, Radar, RadarChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import type { ReactNode } from "react";
import { useMemo, useState } from "react";
import {
  getAfricanPowerIndexCountries,
  powerPillarWeights,
  type PowerIndexCountry,
  type PowerPillar
} from "@/lib/africanPowerIndex";

const countries = getAfricanPowerIndexCountries();
const pillars = powerPillarWeights.map((item) => item.pillar);

export default function AfricanPowerIndexPage() {
  const [selectedPillar, setSelectedPillar] = useState<PowerPillar | "Classement général">("Classement général");
  const [selectedSlug, setSelectedSlug] = useState(countries[0]?.slug ?? "");
  const [comparisonSlugs, setComparisonSlugs] = useState<string[]>(countries.slice(0, 3).map((country) => country.slug));

  const selectedCountry = countries.find((country) => country.slug === selectedSlug) ?? countries[0];
  const ranking = useMemo(() => getRanking(selectedPillar), [selectedPillar]);
  const comparedCountries = comparisonSlugs
    .map((slug) => countries.find((country) => country.slug === slug))
    .filter((country): country is PowerIndexCountry => Boolean(country));

  const radarData = pillars.map((pillar) => ({
    pillar,
    score: selectedCountry?.pillarScores[pillar] ?? 0
  }));

  const comparisonData = pillars.map((pillar) => {
    const row: Record<string, string | number> = { pillar };
    comparedCountries.forEach((country) => {
      row[country.country] = country.pillarScores[pillar] ?? 0;
    });
    return row;
  });

  function toggleComparison(slug: string) {
    setComparisonSlugs((current) => {
      if (current.includes(slug)) return current.filter((item) => item !== slug);
      if (current.length >= 4) return current;
      return [...current, slug];
    });
  }

  return (
    <main className="min-h-screen bg-ink px-5 py-8 text-neutral-100">
      <section className="mx-auto max-w-7xl space-y-6">
        <header className="flex items-start justify-between gap-5 border-b border-line pb-5 max-lg:grid">
          <div>
            <p className="text-xs font-semibold uppercase tracking-[0.24em] text-gold">Atlas Afrique</p>
            <h1 className="mt-3 text-3xl font-semibold text-gold-soft">Indice de Puissance Africaine</h1>
            <p className="mt-2 max-w-3xl text-sm leading-6 text-neutral-400">
              Classement méthodologique des États africains selon leur puissance globale. Aucun score définitif n'est calculé tant que les sources ne sont pas validées.
            </p>
          </div>
          <Link href="/atlas" className="rounded-md border border-gold/40 bg-gold/10 px-4 py-2 text-sm font-semibold text-gold-soft transition hover:bg-gold/20">
            Retour Atlas
          </Link>
        </header>

        <section className="grid gap-4 md:grid-cols-3">
          <Kpi title="Pays suivis" value={String(countries.length)} detail="Portefeuille Atlas prioritaire" />
          <Kpi title="Piliers" value={String(pillars.length)} detail="Économie, défense, diplomatie, ressources..." />
          <Kpi title="Statut" value="À calculer" detail="Sources et validation humaine requises" />
        </section>

        <section className="grid gap-6 xl:grid-cols-[minmax(0,1.2fr)_minmax(360px,0.8fr)]">
          <section className="rounded-lg border border-line bg-panel p-5">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div>
                <p className="text-xs font-semibold uppercase tracking-[0.22em] text-gold">Classement dynamique</p>
                <h2 className="mt-2 text-xl font-semibold text-gold-soft">Classement général et par catégorie</h2>
              </div>
              <select
                value={selectedPillar}
                onChange={(event) => setSelectedPillar(event.target.value as PowerPillar | "Classement général")}
                aria-label="Choisir un classement"
                className="rounded-md border border-line bg-black/25 px-3 py-2 text-sm text-neutral-100 outline-none focus:border-gold"
              >
                <option>Classement général</option>
                {pillars.map((pillar) => <option key={pillar}>{pillar}</option>)}
              </select>
            </div>

            <div className="mt-5 overflow-x-auto">
              <table className="w-full min-w-[760px] border-collapse text-sm">
                <thead>
                  <tr className="border-b border-line text-left text-xs uppercase tracking-[0.16em] text-neutral-500">
                    <th className="py-3 pr-3">Rang</th>
                    <th className="py-3 pr-3">Pays</th>
                    <th className="py-3 pr-3">Score</th>
                    <th className="py-3 pr-3">Évolution</th>
                    <th className="py-3 pr-3">Tendance</th>
                    <th className="py-3 pr-3">Statut</th>
                  </tr>
                </thead>
                <tbody>
                  {ranking.map((country) => (
                    <tr key={country.slug} className="border-b border-line/70 text-neutral-300">
                      <td className="py-3 pr-3 font-semibold text-gold-soft">{country.rank ?? "À calculer"}</td>
                      <td className="py-3 pr-3">
                        <button type="button" onClick={() => setSelectedSlug(country.slug)} className="font-semibold text-neutral-100 hover:text-gold-soft">
                          {country.flag} {country.country}
                        </button>
                      </td>
                      <td className="py-3 pr-3">{formatScore(getScoreForRanking(country, selectedPillar))}</td>
                      <td className="py-3 pr-3">{country.annualEvolution === null ? "Donnée à vérifier" : `${country.annualEvolution}`}</td>
                      <td className="py-3 pr-3 capitalize">{country.trend}</td>
                      <td className="py-3 pr-3">
                        <span className="rounded-md border border-yellow-500/30 bg-yellow-500/10 px-2 py-1 text-xs font-semibold text-yellow-100">
                          Non calculé
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </section>

          <CountryDetail country={selectedCountry} />
        </section>

        <section className="grid gap-6 xl:grid-cols-2">
          <section className="rounded-lg border border-line bg-panel p-5">
            <p className="text-xs font-semibold uppercase tracking-[0.22em] text-gold">Radar chart</p>
            <h2 className="mt-2 text-xl font-semibold text-gold-soft">{selectedCountry?.flag} {selectedCountry?.country}</h2>
            <p className="mt-2 text-sm text-neutral-400">Graphique prêt pour données validées. Les scores sont maintenus à zéro tant que les sources restent absentes.</p>
            <div className="mt-4 min-h-[340px] min-w-0">
              <ResponsiveContainer width="100%" height={340} minWidth={0}>
                <RadarChart data={radarData}>
                  <PolarGrid stroke="rgba(255,255,255,0.16)" />
                  <PolarAngleAxis dataKey="pillar" tick={{ fill: "#d6aa4d", fontSize: 11 }} />
                  <Radar dataKey="score" stroke="#d6aa4d" fill="#d6aa4d" fillOpacity={0.18} />
                  <Tooltip contentStyle={{ background: "#111", border: "1px solid rgba(214,170,77,0.35)", color: "#fff" }} />
                </RadarChart>
              </ResponsiveContainer>
            </div>
          </section>

          <section className="rounded-lg border border-line bg-panel p-5">
            <div className="flex flex-wrap items-start justify-between gap-3">
              <div>
                <p className="text-xs font-semibold uppercase tracking-[0.22em] text-gold">Comparaison multi-pays</p>
                <h2 className="mt-2 text-xl font-semibold text-gold-soft">2 à 4 pays</h2>
              </div>
              <p className="text-xs text-neutral-500">{comparisonSlugs.length} / 4 sélectionnés</p>
            </div>
            <div className="mt-4 flex flex-wrap gap-2">
              {countries.map((country) => (
                <label key={country.slug} className="inline-flex cursor-pointer items-center gap-2 rounded-md border border-line bg-black/20 px-3 py-2 text-xs text-neutral-300 transition hover:border-gold/50">
                  <input
                    type="checkbox"
                    checked={comparisonSlugs.includes(country.slug)}
                    onChange={() => toggleComparison(country.slug)}
                    className="accent-gold"
                    aria-label={`Comparer ${country.country}`}
                  />
                  {country.flag} {country.country}
                </label>
              ))}
            </div>
            <div className="mt-5 min-h-[340px] min-w-0">
              <ResponsiveContainer width="100%" height={340} minWidth={0}>
                <BarChart data={comparisonData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.1)" />
                  <XAxis dataKey="pillar" tick={{ fill: "#a3a3a3", fontSize: 10 }} />
                  <YAxis domain={[0, 100]} tick={{ fill: "#a3a3a3", fontSize: 11 }} />
                  <Tooltip contentStyle={{ background: "#111", border: "1px solid rgba(214,170,77,0.35)", color: "#fff" }} />
                  {comparedCountries.map((country, index) => (
                    <Bar key={country.slug} dataKey={country.country} fill={["#d6aa4d", "#38bdf8", "#a78bfa", "#22c55e"][index] ?? "#d6aa4d"} />
                  ))}
                </BarChart>
              </ResponsiveContainer>
            </div>
          </section>
        </section>

        <section className="rounded-lg border border-line bg-panel p-5">
          <p className="text-xs font-semibold uppercase tracking-[0.22em] text-gold">Méthodologie</p>
          <div className="mt-4 grid gap-3 md:grid-cols-2 xl:grid-cols-4">
            {powerPillarWeights.map((pillar) => (
              <article key={pillar.pillar} className="rounded-md border border-line bg-black/20 p-4">
                <h3 className="font-semibold text-gold-soft">{pillar.pillar}</h3>
                <p className="mt-1 text-sm text-neutral-400">Poids : {pillar.weight} %</p>
                <ul className="mt-3 list-inside list-disc space-y-1 text-sm text-neutral-300">
                  {pillar.variables.map((variable) => <li key={variable}>{variable}</li>)}
                </ul>
              </article>
            ))}
          </div>
        </section>
      </section>
    </main>
  );
}

function CountryDetail({ country }: { country?: PowerIndexCountry }) {
  if (!country) return null;

  return (
    <aside className="rounded-lg border border-gold/30 bg-gold/10 p-5">
      <p className="text-xs font-semibold uppercase tracking-[0.22em] text-gold">Fiche détaillée</p>
      <h2 className="mt-2 text-2xl font-semibold text-gold-soft">{country.flag} {country.country}</h2>
      <dl className="mt-4 grid gap-3 text-sm">
        <Meta label="Score total" value={formatScore(country.totalScore)} />
        <Meta label="Région" value={country.region} />
        <Meta label="Tendance" value={country.trend} />
        <Meta label="Statut" value="Non calculé - validation humaine obligatoire" />
      </dl>

      <div className="mt-5 space-y-4 text-sm text-neutral-300">
        <Section title="Score par pilier">
          <div className="grid gap-2">
            {pillars.map((pillar) => (
              <div key={pillar} className="flex items-center justify-between rounded-md border border-line bg-black/20 px-3 py-2">
                <span>{pillar}</span>
                <span className="font-semibold text-gold-soft">{formatScore(country.pillarScores[pillar])}</span>
              </div>
            ))}
          </div>
        </Section>
        <Section title="Forces"><List values={country.strengths} /></Section>
        <Section title="Vulnérabilités"><List values={country.vulnerabilities} /></Section>
        <Section title="Analyse stratégique">{country.strategicAnalysis}</Section>
        <Section title="Sources utilisées"><List values={country.sources} /></Section>
      </div>
    </aside>
  );
}

function Kpi({ title, value, detail }: { title: string; value: string; detail: string }) {
  return (
    <article className="rounded-lg border border-gold/20 bg-panel p-5">
      <p className="text-xs font-semibold uppercase tracking-[0.18em] text-gold">{title}</p>
      <p className="mt-2 text-2xl font-semibold text-gold-soft">{value}</p>
      <p className="mt-1 text-sm text-neutral-400">{detail}</p>
    </article>
  );
}

function Meta({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-md border border-line bg-black/20 p-3">
      <dt className="text-xs uppercase tracking-wide text-neutral-500">{label}</dt>
      <dd className="mt-1 font-medium text-neutral-200">{value}</dd>
    </div>
  );
}

function Section({ title, children }: { title: string; children: ReactNode }) {
  return (
    <section>
      <h3 className="text-xs font-semibold uppercase tracking-[0.18em] text-gold">{title}</h3>
      <div className="mt-2 leading-6">{children}</div>
    </section>
  );
}

function List({ values }: { values: string[] }) {
  return (
    <ul className="list-inside list-disc space-y-1">
      {values.map((value) => <li key={value}>{value}</li>)}
    </ul>
  );
}

function getRanking(pillar: PowerPillar | "Classement général") {
  return [...countries].sort((left, right) => {
    const leftScore = getScoreForRanking(left, pillar);
    const rightScore = getScoreForRanking(right, pillar);
    if (leftScore === null && rightScore === null) return left.country.localeCompare(right.country);
    if (leftScore === null) return 1;
    if (rightScore === null) return -1;
    return rightScore - leftScore;
  });
}

function getScoreForRanking(country: PowerIndexCountry, pillar: PowerPillar | "Classement général") {
  if (pillar === "Classement général") return country.totalScore;
  return country.pillarScores[pillar];
}

function formatScore(score: number | null) {
  return score === null ? "Donnée à vérifier" : `${score} / 100`;
}
