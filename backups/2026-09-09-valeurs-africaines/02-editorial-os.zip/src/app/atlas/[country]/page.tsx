import { notFound } from "next/navigation";
import Link from "next/link";
import { generateCountryBrief, getAllCountryProfiles, getCountryProfile } from "@/lib/atlas";

type CountryPageProps = {
  params: Promise<{ country: string }>;
};

export async function generateStaticParams() {
  const countries = await getAllCountryProfiles();
  return countries.map((country) => ({ country: country.slug }));
}

export default async function CountryPage({ params }: CountryPageProps) {
  const { country } = await params;
  const profile = await getCountryProfile(country);
  if (!profile) notFound();

  const brief = generateCountryBrief(profile);

  return (
    <main className="min-h-screen bg-ink px-5 py-8 text-neutral-100">
      <section className="mx-auto max-w-6xl space-y-6">
        <header className="border-b border-line pb-5">
          <p className="text-xs font-semibold uppercase tracking-[0.24em] text-gold">Atlas Afrique</p>
          <h1 className="mt-3 text-3xl font-semibold text-gold-soft">{profile.flag} {profile.country}</h1>
          <p className="mt-2 max-w-3xl text-sm leading-6 text-neutral-400">{profile.region}</p>
          <Link
            href={`/atlas?compare=${profile.slug}`}
            className="mt-4 inline-flex h-10 items-center justify-center rounded-md border border-gold/50 bg-gold/10 px-4 text-sm font-semibold text-gold-soft transition hover:bg-gold/20"
          >
            Comparer
          </Link>
        </header>

        <section className="grid grid-cols-4 gap-3 max-lg:grid-cols-2 max-sm:grid-cols-1">
          <Metric label="Capitale" value={profile.capital} />
          <Metric label="Population" value={profile.population} />
          <Metric label="PIB" value={profile.gdp} />
          <Metric label="Monnaie" value={profile.currency} />
        </section>

        <section className="rounded-lg border border-line bg-panel p-4">
          <h2 className="font-semibold text-gold-soft">Fiche synthétique</h2>
          <div className="mt-3 grid gap-3 text-sm text-neutral-300 md:grid-cols-2">
            <p>Langues : {profile.languages.join(", ")}</p>
            <p>Organisations régionales : {profile.regionalOrganizations.join(", ")}</p>
            <p>Partenaires stratégiques : {profile.strategicPartners.join(", ")}</p>
            <p>ODD : {profile.odd.join(", ")}</p>
          </div>
        </section>

        <article className="rounded-lg border border-line bg-panel">
          <div className="border-b border-line bg-[#171717] px-4 py-3">
            <h2 className="font-semibold text-gold-soft">Note pays Atlas</h2>
            <p className="text-sm text-neutral-400">Données à vérifier, validation humaine obligatoire.</p>
          </div>
          <pre className="max-h-[900px] overflow-auto whitespace-pre-wrap p-5 text-sm leading-6 text-neutral-200">{brief}</pre>
        </article>
      </section>
    </main>
  );
}

function Metric({ label, value }: { label: string; value: string }) {
  return (
    <article className="rounded-lg border border-line bg-panel p-4">
      <p className="text-xs uppercase tracking-wide text-gold">{label}</p>
      <p className="mt-2 font-semibold text-gold-soft">{value}</p>
    </article>
  );
}
