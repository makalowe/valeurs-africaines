import Link from "next/link";
import {
  calculateObservatoryHealth,
  getLatestReports,
  getMonthlyTrends,
  getObservatoryOverview,
  getStrategicAlerts
} from "@/lib/observatories";
import { formatDisplayDate } from "@/lib/dateDisplay";

const alertClass = {
  critique: "border-red-400/40 bg-red-400/10 text-red-100",
  attention: "border-orange-400/40 bg-orange-400/10 text-orange-100",
  normal: "border-green-400/40 bg-green-400/10 text-green-100"
};

export default async function ObservatoiresPage() {
  const [overview, alerts, reports, trends] = await Promise.all([
    getObservatoryOverview(),
    getStrategicAlerts(),
    getLatestReports(),
    getMonthlyTrends()
  ]);
  const health = calculateObservatoryHealth(overview);

  return (
    <main className="min-h-screen bg-ink px-5 py-8 text-neutral-100">
      <section className="mx-auto max-w-7xl space-y-6">
        <header className="border-b border-line pb-5">
          <p className="text-xs font-semibold uppercase tracking-[0.24em] text-gold">Centre stratégique</p>
          <h1 className="mt-3 text-3xl font-semibold text-gold-soft">Observatoires</h1>
          <p className="mt-2 max-w-3xl text-sm leading-6 text-neutral-400">
            Centre unique pour suivre les grands dossiers permanents de Valeurs Africaines. Aucune publication automatique, validation humaine obligatoire.
          </p>
        </header>

        <section className="grid grid-cols-[260px_minmax(0,1fr)] gap-5 max-lg:grid-cols-1">
          <article className="rounded-lg border border-gold/40 bg-gold/10 p-5">
            <p className="text-xs font-semibold uppercase tracking-[0.2em] text-gold">Santé globale</p>
            <div className="mt-3 text-4xl font-bold text-gold-soft">{health} %</div>
            <p className="mt-2 text-sm text-neutral-300">Score moyen des observatoires.</p>
          </article>
          <section className="grid grid-cols-4 gap-3 max-xl:grid-cols-2 max-sm:grid-cols-1">
            {overview.map((item) => (
              <Link key={item.name} href={item.href} className="rounded-lg border border-line bg-panel p-4 transition hover:border-gold">
                <h2 className="text-sm font-semibold text-gold-soft">{item.name}</h2>
                <div className="mt-3 flex items-center gap-3">
                  <div className="h-2 flex-1 rounded-full bg-neutral-800">
                    <div className="h-full rounded-full bg-gold" style={{ width: `${item.score}%` }} />
                  </div>
                  <span className="text-sm font-bold text-gold">{item.score}%</span>
                </div>
                <p className="mt-2 text-xs text-neutral-500">{item.status} · maj {formatDisplayDate(item.latestUpdate)}</p>
              </Link>
            ))}
          </section>
        </section>

        <section className="grid grid-cols-[0.9fr_1.1fr] gap-5 max-xl:grid-cols-1">
          <Panel title="Alertes stratégiques">
            <div className="grid gap-3">
              {alerts.map((alert) => (
                <article key={`${alert.observatory}-${alert.message}`} className={`rounded-md border p-3 ${alertClass[alert.level]}`}>
                  <p className="text-xs font-bold uppercase tracking-wide">{alert.level}</p>
                  <h3 className="mt-1 font-semibold">{alert.observatory}</h3>
                  <p className="mt-1 text-sm opacity-90">{alert.message}</p>
                </article>
              ))}
            </div>
          </Panel>

          <Panel title="Derniers rapports">
            <div className="grid gap-3">
              {reports.map((report) => (
                <article key={report.title} className="rounded-md border border-line bg-black/20 p-3">
                  <h3 className="font-semibold text-gold-soft">{report.title}</h3>
                  <p className="mt-1 text-sm text-neutral-400">{report.observatory} · {formatDisplayDate(report.date)} · {report.status}</p>
                </article>
              ))}
            </div>
          </Panel>
        </section>

        <Panel title="Évolutions mensuelles">
          <div className="grid gap-3 md:grid-cols-2">
            {trends.map((trend) => (
              <article key={trend.observatory} className="rounded-md border border-line bg-black/20 p-4">
                <div className="flex items-center justify-between gap-3">
                  <h3 className="text-sm font-semibold text-gold-soft">{trend.observatory}</h3>
                  <span className="text-sm font-bold text-gold">{trend.evolution >= 0 ? "+" : ""}{trend.evolution}</span>
                </div>
                <p className="mt-2 text-xs text-neutral-500">Mois précédent {trend.previous}% · actuel {trend.current}%</p>
              </article>
            ))}
          </div>
        </Panel>

        <Panel title="Sources à vérifier">
          <div className="grid gap-3 md:grid-cols-2">
            {overview.map((item) => (
              <div key={item.name} className="rounded-md border border-line bg-black/20 p-3 text-sm">
                <span className="font-semibold text-gold-soft">{item.name}</span>
                <p className="mt-1 text-neutral-400">{item.sourcesToVerify.join(", ")}</p>
              </div>
            ))}
          </div>
        </Panel>
      </section>
    </main>
  );
}

function Panel({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <section className="rounded-lg border border-line bg-panel">
      <div className="border-b border-line bg-[#171717] px-4 py-3">
        <h2 className="font-semibold text-gold-soft">{title}</h2>
      </div>
      <div className="p-4">{children}</div>
    </section>
  );
}
