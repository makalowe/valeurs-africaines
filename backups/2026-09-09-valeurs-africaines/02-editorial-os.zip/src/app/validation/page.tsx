"use client";

import { FormEvent, useEffect, useState } from "react";
import type { PlanningRow } from "@/lib/googleSheets";
import { formatDisplayDate } from "@/lib/dateDisplay";

type ApiRowResponse = {
  row?: PlanningRow;
  error?: string;
};

type ArchiveResponse = {
  row?: PlanningRow;
  record?: unknown;
  error?: string;
};

export default function ValidationPage() {
  const [editorialId, setEditorialId] = useState("VA-001");
  const [row, setRow] = useState<PlanningRow | null>(null);
  const [draft, setDraft] = useState("");
  const [message, setMessage] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [rows, setRows] = useState<PlanningRow[]>([]);
  const [source, setSource] = useState<"sheets" | "local" | null>(null);

  useEffect(() => {
    let cancelled = false;
    void fetch("/api/planning", { cache: "no-store" })
      .then(async (response) => {
        const payload = (await response.json()) as { rows?: PlanningRow[]; source?: "sheets" | "local" };
        if (!cancelled && Array.isArray(payload.rows)) {
          setRows(payload.rows);
          setSource(payload.source ?? null);
        }
      })
      .catch(() => undefined);
    return () => {
      cancelled = true;
    };
  }, []);

  async function loadRow(event?: FormEvent<HTMLFormElement>, forcedId?: string) {
    event?.preventDefault();
    const id = (forcedId ?? editorialId).trim();

    if (!id) {
      setError("Saisis un ID editorial.");
      return;
    }

    setIsLoading(true);
    setError(null);
    setMessage(null);

    try {
      const response = await fetch(`/api/planning/${encodeURIComponent(id)}`);
      const payload = (await response.json()) as ApiRowResponse;

      if (!response.ok) {
        setError(payload.error ?? "Impossible de charger la ligne.");
        setRow(null);
        return;
      }

      setRow(payload.row ?? null);
      setDraft((current) => current || buildDraftPlaceholder(payload.row));
    } catch {
      setError("Impossible de contacter l'API interne.");
    } finally {
      setIsLoading(false);
    }
  }

  async function validateContent(decision: "approved" | "correction") {
    const id = editorialId.trim();

    if (!id) {
      setError("Saisis un ID editorial.");
      return;
    }

    setIsLoading(true);
    setError(null);
    setMessage(null);

    try {
      const response = await fetch("/api/validate-content", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ editorialId: id, decision })
      });
      const payload = (await response.json()) as ApiRowResponse;

      if (!response.ok) {
        setError(payload.error ?? "Erreur pendant la validation.");
        return;
      }

      setRow(payload.row ?? null);
      setMessage(decision === "approved" ? "Contenu validé humainement." : "Contenu marqué à corriger.");
    } catch {
      setError("Impossible de contacter l'API interne.");
    } finally {
      setIsLoading(false);
    }
  }

  async function archiveContent() {
    const id = editorialId.trim();

    if (!id) {
      setError("Saisis un ID editorial.");
      return;
    }

    setIsLoading(true);
    setError(null);
    setMessage(null);

    try {
      const response = await fetch("/api/archive-content", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ editorialId: id })
      });
      const payload = (await response.json()) as ArchiveResponse;

      if (!response.ok) {
        setError(payload.error ?? "Erreur pendant l'archivage.");
        return;
      }

      setRow(payload.row ?? null);
      setMessage("Contenu archivé dans la base de connaissances.");
    } catch {
      setError("Impossible de contacter l'API interne.");
    } finally {
      setIsLoading(false);
    }
  }

  function selectPlanningRow(id: string) {
    setEditorialId(id);
    void loadRow(undefined, id);
  }

  return (
    <main className="min-h-screen bg-ink px-5 py-8 text-neutral-100">
      <section className="mx-auto max-w-6xl space-y-6">
        <header className="border-b border-line pb-5">
          <p className="text-xs font-semibold uppercase tracking-[0.24em] text-gold">Valeurs Africaines Editorial OS</p>
          <h1 className="mt-3 text-3xl font-semibold text-gold-soft">Validation humaine & archivage</h1>
          <p className="mt-2 max-w-3xl text-sm leading-6 text-neutral-400">
            Workflow interne : planning, génération, validation humaine, archivage, base de connaissances. Aucune publication automatique.
          </p>
        </header>

        {source === "local" ? (
          <div className="rounded-lg border border-gold/30 bg-gold/5 p-4 text-sm text-neutral-200">
            <p className="font-semibold text-gold-soft">Mode planning local (feuille « Planning » absente)</p>
            <p className="mt-1 leading-5 text-neutral-400">
              Les lignes sont vos <span className="font-semibold text-neutral-200">brouillons réels</span> — choisis-en une pour la relire, la valider ou demander une correction.
            </p>
          </div>
        ) : null}

        <form onSubmit={loadRow} className="rounded-lg border border-line bg-panel p-4">
          {rows.length > 0 ? (
            <div>
              <label htmlFor="planningRowSelect" className="block text-sm font-semibold text-gold">
                Ligne du planning ({rows.length} disponible{rows.length > 1 ? "s" : ""})
              </label>
              <select
                id="planningRowSelect"
                onChange={(event) => {
                  if (event.target.value) selectPlanningRow(event.target.value);
                }}
                className="mt-2 min-h-11 w-full rounded-md border border-line bg-black px-3 text-neutral-100 outline-none focus:border-gold"
              >
                <option value="">— Choisir une ligne —</option>
                {rows.map((row) => (
                  <option key={row.id} value={row.id}>
                    {row.id} · {row.sujet.slice(0, 60)} · {row.statut}
                  </option>
                ))}
              </select>
            </div>
          ) : null}
          <label htmlFor="editorialId" className="mt-4 block text-sm font-semibold text-gold">
            ID editorial
          </label>
          <div className="mt-3 flex gap-3 max-sm:grid">
            <input
              id="editorialId"
              value={editorialId}
              onChange={(event) => setEditorialId(event.target.value)}
              placeholder={source === "local" ? "nom-du-brouillon.md sans extension" : "VA-001"}
              className="min-h-11 flex-1 rounded-md border border-line bg-black px-3 text-neutral-100 outline-none focus:border-gold"
            />
            <button
              type="submit"
              disabled={isLoading}
              className="rounded-md bg-gold px-5 py-2.5 font-bold text-black disabled:opacity-50"
            >
              Charger
            </button>
          </div>
        </form>

        {error ? <Alert tone="error" text={error} /> : null}
        {message ? <Alert tone="success" text={message} /> : null}

        <section className="grid grid-cols-[330px_minmax(0,1fr)] gap-5 max-lg:grid-cols-1">
          <aside className="space-y-4 rounded-lg border border-line bg-panel p-4">
            <div>
              <h2 className="font-semibold text-gold-soft">Statut actuel</h2>
              <dl className="mt-4 space-y-3 text-sm">
                <Info label="Sujet" value={row?.sujet ?? "-"} />
                <Info label="Statut" value={row?.statut ?? "-"} />
                <Info label="Validation humaine" value={row?.validation_humaine ?? "-"} />
                <Info label="Format" value={row?.format ?? "-"} />
                <Info label="Rubrique" value={row?.rubrique ?? "-"} />
                <Info label="Visuel proposé" value={row?.visuel_propose ?? "-"} />
                <Info label="Visuel choisi" value={row?.visuel_choisi ?? "-"} />
                <Info label="Type visuel" value={row?.type_visuel ?? "-"} />
                <Info label="Prompt visuel" value={row?.prompt_visuel ?? "-"} />
                <Info label="Date sélection" value={formatDisplayDate(row?.date_selection) || "-"} />
                <Info label="Droits visuels vérifiés" value={row?.droits_visuels_verifies ?? "-"} />
                <Info label="Validation visuelle" value={row?.validation_visuelle_humaine ?? "-"} />
              </dl>
            </div>

            <div className="grid gap-3">
              <div className="rounded-md border border-line bg-black/20 p-3 text-sm leading-6 text-neutral-200">
                <p className="font-semibold text-gold-soft">Article prêt.</p>
                <p>Souhaitez-vous le valider ?</p>
                <p className="font-semibold text-gold">OUI / NON</p>
                <p className="mt-2 text-xs text-neutral-400">Validation humaine requise avant publication finale.</p>
              </div>
              <button
                type="button"
                disabled={isLoading || !row}
                onClick={() => validateContent("correction")}
                className="rounded-md border border-line bg-[#171717] px-4 py-3 text-left text-sm font-semibold hover:border-gold disabled:opacity-50"
              >
                À corriger
              </button>
              <button
                type="button"
                disabled={isLoading || !row}
                onClick={() => validateContent("approved")}
                className="rounded-md border border-green-500/40 bg-green-500/10 px-4 py-3 text-left text-sm font-semibold text-green-100 disabled:opacity-50"
              >
                Validation humaine
              </button>
              <button
                type="button"
                disabled={isLoading || !row}
                onClick={archiveContent}
                className="rounded-md bg-gold px-4 py-3 text-left text-sm font-bold text-black disabled:opacity-50"
              >
                Archiver
              </button>
            </div>

            <div className="rounded-md border border-red-400/30 bg-red-400/10 p-3 text-xs leading-5 text-red-100">
              Validation finale impossible sans trois propositions visuelles, choix humain du visuel ou décision type_visuel = aucun, et validation visuelle humaine.
            </div>
          </aside>

          <article className="rounded-lg border border-line bg-panel">
            <div className="border-b border-line bg-[#171717] px-4 py-3">
              <h2 className="font-semibold text-gold-soft">Brouillon généré</h2>
              <p className="text-sm text-neutral-400">Zone de revue éditoriale. Le texte affiché ici n'est jamais publié automatiquement.</p>
            </div>
            <textarea
              value={draft}
              onChange={(event) => setDraft(event.target.value)}
              className="min-h-[620px] w-full resize-y bg-black/40 p-5 text-sm leading-6 text-neutral-100 outline-none"
              placeholder="Collez ou chargez ici le brouillon généré."
            />
          </article>
        </section>
      </section>
    </main>
  );
}

function buildDraftPlaceholder(row?: PlanningRow): string {
  if (!row) return "";

  return `# ${row.sujet}

Format : ${row.format}
Rubrique : ${row.rubrique}
Angle stratégique : ${row.angle_strategique}

Brouillon à relire, vérifier et valider humainement avant archivage.`;
}

function Info({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <dt className="text-xs uppercase tracking-wide text-gold">{label}</dt>
      <dd className="mt-1 text-neutral-200">{value || "-"}</dd>
    </div>
  );
}

function Alert({ tone, text }: { tone: "error" | "success"; text: string }) {
  const className =
    tone === "error"
      ? "border-red-400/40 bg-red-400/10 text-red-100"
      : "border-green-400/40 bg-green-400/10 text-green-100";

  return <div className={`rounded-lg border p-4 text-sm ${className}`}>{text}</div>;
}
