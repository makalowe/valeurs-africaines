import {
  calculateStabilityScore,
  detectEscalationRisk,
  generateConflictVisualProposals,
  generateMonthlyConflictBrief,
  getConflictZones
} from "@/lib/conflictObserver";

const sections = [
  "Carte des tensions africaines",
  "Conflits actifs",
  "Risques politiques",
  "Terrorisme et insurrections",
  "Conflits liés aux ressources",
  "Médiations et processus de paix",
  "Impact humain et ODD",
  "Alertes récentes",
  "Rapports mensuels"
];

const levelIcon: Record<string, string> = {
  Stable: "🟢",
  Vigilance: "🟡",
  "Tension élevée": "🟠",
  "Conflit actif": "🔴",
  "Effondrement critique": "⚫"
};

export default async function ConflitsPage() {
  const zones = await getConflictZones();
  const report = generateMonthlyConflictBrief(zones);
  const visuals = generateConflictVisualProposals();

  return (
    <main className="min-h-screen bg-ink px-5 py-8 text-neutral-100">
      <section className="mx-auto max-w-7xl space-y-6">
        <header className="border-b border-line pb-5">
          <p className="text-xs font-semibold uppercase tracking-[0.24em] text-gold">Observatoire permanent</p>
          <h1 className="mt-3 text-3xl font-semibold text-gold-soft">Observatoire des Conflits et de la Stabilité</h1>
          <p className="mt-2 max-w-3xl text-sm leading-6 text-neutral-400">
            Suivre, analyser et visualiser les conflits, tensions politiques, risques sécuritaires et processus de paix en Afrique.
          </p>
        </header>

        <section className="grid grid-cols-3 gap-3 max-lg:grid-cols-2 max-sm:grid-cols-1">
          {sections.map((section) => (
            <article key={section} className="rounded-lg border border-line bg-panel p-4">
              <h2 className="text-sm font-semibold text-gold-soft">{section}</h2>
            </article>
          ))}
        </section>

        <section className="rounded-lg border border-line bg-panel">
          <div className="border-b border-line bg-[#171717] px-4 py-3">
            <h2 className="font-semibold text-gold-soft">Carte des tensions africaines</h2>
            <p className="text-sm text-neutral-400">Données indicatives à vérifier avant publication.</p>
          </div>
          <div className="grid gap-3 p-4 md:grid-cols-2">
            {zones.map((zone) => (
              <article key={zone.zone} className="rounded-md border border-line bg-black/20 p-4">
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <h3 className="font-semibold text-gold-soft">{zone.zone}</h3>
                    <p className="mt-1 text-sm text-neutral-400">{zone.pays.join(", ")}</p>
                  </div>
                  <span className="text-sm font-bold text-gold">{levelIcon[zone.niveau]} {zone.niveau}</span>
                </div>
                <div className="mt-4 grid grid-cols-3 gap-2 text-xs">
                  <Metric label="Évolution" value={zone.evolution} />
                  <Metric label="Stabilité" value={`${calculateStabilityScore(zone)}/100`} />
                  <Metric label="Escalade" value={detectEscalationRisk(zone)} />
                </div>
                <p className="mt-3 text-sm text-neutral-300">Impact humain : {zone.impact_humain}</p>
                <p className="mt-2 text-xs text-neutral-500">ODD : {zone.odd_impactes.join(" · ")}</p>
              </article>
            ))}
          </div>
        </section>

        <section className="rounded-lg border border-line bg-panel">
          <div className="border-b border-line bg-[#171717] px-4 py-3">
            <h2 className="font-semibold text-gold-soft">Visuels obligatoires</h2>
            <p className="text-sm text-neutral-400">Le rédacteur choisit A, B ou C avant validation.</p>
          </div>
          <div className="grid gap-3 p-4 md:grid-cols-3">
            {visuals.map((visual) => (
              <article key={visual.id} className="rounded-md border border-line bg-black/20 p-4">
                <p className="text-xs font-bold uppercase tracking-[0.2em] text-gold">Option {visual.id}</p>
                <h3 className="mt-2 font-semibold text-gold-soft">{visual.title}</h3>
                <p className="mt-2 text-sm leading-6 text-neutral-300">{visual.description}</p>
                <p className="mt-3 rounded-md border border-line p-3 text-xs leading-5 text-neutral-400">{visual.prompt}</p>
              </article>
            ))}
          </div>
        </section>

        <article className="rounded-lg border border-line bg-panel">
          <div className="border-b border-line bg-[#171717] px-4 py-3">
            <h2 className="font-semibold text-gold-soft">Rapport mensuel</h2>
            <p className="text-sm text-neutral-400">Format Observatoire des Conflits — Afrique.</p>
          </div>
          <pre className="max-h-[760px] overflow-auto whitespace-pre-wrap p-5 text-sm leading-6 text-neutral-200">{report}</pre>
        </article>
      </section>
    </main>
  );
}

function Metric({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-md border border-line bg-[#101010] p-2">
      <div className="font-semibold text-gold-soft">{value}</div>
      <div className="mt-1 text-neutral-500">{label}</div>
    </div>
  );
}
