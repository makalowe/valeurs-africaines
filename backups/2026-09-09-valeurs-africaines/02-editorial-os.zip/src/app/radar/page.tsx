import { generateMorningBrief, radarSources, type RadarTopic } from "@/lib/radar";

const sections = [
  "Top 10 sujets du jour",
  "Alertes stratégiques",
  "Signaux faibles",
  "Innovation & Recherche",
  "Business & Investissements",
  "Géopolitique",
  "Conflits & Sécurité",
  "ODD & Afrique 2030",
  "Diaspora",
  "Personnalités à surveiller"
];

export default async function RadarPage() {
  const brief = await generateMorningBrief();

  return (
    <main className="min-h-screen bg-ink px-5 py-8 text-neutral-100">
      <section className="mx-auto max-w-7xl space-y-6">
        <header className="border-b border-line pb-5">
          <p className="text-xs font-semibold uppercase tracking-[0.24em] text-gold">Radar Afrique</p>
          <h1 className="mt-3 text-3xl font-semibold text-gold-soft">Veille stratégique quotidienne</h1>
          <p className="mt-2 max-w-3xl text-sm leading-6 text-neutral-400">
            Identifier automatiquement les sujets importants pour Valeurs Africaines, les scorer et les classer avant validation humaine.
          </p>
        </header>

        <section className="grid grid-cols-5 gap-3 max-xl:grid-cols-3 max-md:grid-cols-1">
          {sections.map((section) => (
            <article key={section} className="rounded-lg border border-line bg-panel p-4">
              <h2 className="text-sm font-semibold text-gold-soft">{section}</h2>
            </article>
          ))}
        </section>

        <Panel title="Top 10 sujets du jour">
          <TopicList topics={brief.top10Sujets} />
        </Panel>

        <section className="grid grid-cols-2 gap-5 max-xl:grid-cols-1">
          <Panel title="Top 3 alertes stratégiques">
            <TopicList topics={brief.top3AlertesStrategiques} compact />
          </Panel>
          <Panel title="Top 5 signaux faibles">
            <TopicList topics={brief.top5SignauxFaibles} compact />
          </Panel>
        </section>

        <section className="grid grid-cols-2 gap-5 max-xl:grid-cols-1">
          <Panel title="Top 3 personnalités à suivre">
            <TopicList topics={brief.top3Personnalites} compact />
          </Panel>
          <Panel title="Top 3 pays à surveiller">
            <div className="grid gap-3">
              {brief.top3Pays.map((item) => (
                <article key={item.pays} className="rounded-md border border-line bg-black/20 p-3">
                  <div className="flex items-center justify-between gap-3">
                    <h3 className="font-semibold text-gold-soft">{item.pays}</h3>
                    <span className="text-sm font-bold text-gold">{item.score}</span>
                  </div>
                  <p className="mt-1 text-sm text-neutral-400">{item.raison}</p>
                </article>
              ))}
            </div>
          </Panel>
        </section>

        <Panel title="Sources préparées">
          <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-3">
            {radarSources.map((group) => (
              <article key={group.group} className="rounded-md border border-line bg-black/20 p-4">
                <h3 className="font-semibold text-gold-soft">{group.group}</h3>
                <p className="mt-2 text-sm leading-6 text-neutral-400">{group.sources.join(", ")}</p>
              </article>
            ))}
          </div>
        </Panel>

        <div className="rounded-lg border border-red-400/30 bg-red-400/10 p-4 text-sm font-semibold text-red-100">
          Aucune publication automatique. Validation humaine obligatoire. Sources à vérifier.
        </div>
      </section>
    </main>
  );
}

function TopicList({ topics, compact = false }: { topics: RadarTopic[]; compact?: boolean }) {
  if (topics.length === 0) {
    return <div className="rounded-md border border-line bg-black/20 p-4 text-sm text-neutral-500">Aucun sujet disponible.</div>;
  }

  return (
    <div className={`grid gap-3 ${compact ? "" : "xl:grid-cols-2"}`}>
      {topics.map((topic) => (
        <article key={topic.title} className="rounded-md border border-line bg-black/20 p-4">
          <div className="flex items-start justify-between gap-3">
            <div>
              <h3 className="font-semibold text-gold-soft">{topic.title}</h3>
              <p className="mt-1 text-sm leading-6 text-neutral-400">{topic.summary}</p>
            </div>
            <span className="rounded-md bg-gold/10 px-2 py-1 text-sm font-bold text-gold">{topic.scoreVA}</span>
          </div>
          <div className="mt-3 grid gap-2 text-xs text-neutral-400 md:grid-cols-2">
            <span>Catégorie : {topic.category}</span>
            <span>Urgence : {topic.urgency}</span>
            <span>ODD : {topic.oddConcernes.join(", ")}</span>
            <span>Pays : {topic.paysConcernes.join(", ")}</span>
          </div>
        </article>
      ))}
    </div>
  );
}

function Panel({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <section className="rounded-lg border border-line bg-panel">
      <div className="border-b border-line bg-[#171717] px-4 py-3">
        <h2 className="font-semibold text-gold-soft">{title}</h2>
      </div>
      <div className="p-4">{children}</div>
    </section>
  );
}
