import {
  getAgenda2063Aspirations,
  getAgendaCoverageScores,
  getAllSDGSheets,
  getSDGAgendaAlerts,
  getSDGCoverageScores
} from "@/lib/sdgAgendaObserver";

const mapCountries = [
  { name: "Maroc", status: "couvert", color: "bg-emerald-400" },
  { name: "Sénégal", status: "couvert", color: "bg-emerald-400" },
  { name: "Côte d'Ivoire", status: "à renforcer", color: "bg-amber-400" },
  { name: "Nigeria", status: "couvert", color: "bg-emerald-400" },
  { name: "RDC", status: "à renforcer", color: "bg-amber-400" },
  { name: "Tchad", status: "peu couvert", color: "bg-red-400" },
  { name: "Angola", status: "peu couvert", color: "bg-red-400" },
  { name: "Kenya", status: "couvert", color: "bg-emerald-400" }
];

export default function ODDAgenda2063Page() {
  const sdgs = getAllSDGSheets();
  const aspirations = getAgenda2063Aspirations();
  const sdgCoverage = getSDGCoverageScores();
  const agendaCoverage = getAgendaCoverageScores();
  const alerts = getSDGAgendaAlerts();

  return (
    <main className="mx-auto flex w-full max-w-[1680px] flex-col gap-6 px-5 py-6">
      <section className="rounded-md border border-gold/20 bg-[#111]/80 p-6">
        <p className="text-xs font-semibold uppercase tracking-[0.28em] text-gold">Observatoire stratégique</p>
        <div className="mt-3 grid gap-5 lg:grid-cols-[1.6fr_1fr] lg:items-end">
          <div>
            <h1 className="font-serif text-3xl font-bold text-gold-soft md:text-4xl">
              Observatoire ODD & Agenda 2063
            </h1>
            <p className="mt-3 max-w-4xl text-sm leading-6 text-neutral-300">
              Suivi éditorial des 17 Objectifs de Développement Durable et des 7 aspirations de l&apos;Agenda 2063.
              Chaque analyse distingue les faits, l&apos;analyse et les hypothèses, avec validation humaine obligatoire
              avant toute publication.
            </p>
          </div>
          <div className="rounded-md border border-red-400/30 bg-red-400/10 p-4 text-sm text-red-100">
            Aucune publication automatique. Les scores servent à orienter la rédaction, pas à remplacer la décision
            éditoriale.
          </div>
        </div>
      </section>

      <section className="grid gap-4 lg:grid-cols-4">
        <Kpi label="ODD suivis" value="17 / 17" detail="fiches documentaires" />
        <Kpi label="Agenda 2063" value="7 / 7" detail="aspirations suivies" />
        <Kpi label="Alertes actives" value={String(alerts.length)} detail="couverture ou données à vérifier" />
        <Kpi label="Validation" value="100 %" detail="humaine obligatoire" />
      </section>

      <section className="grid gap-6 xl:grid-cols-[1.2fr_1fr]">
        <Panel title="Carte Afrique" subtitle="Couverture éditoriale par pays">
          <div className="grid gap-3 sm:grid-cols-2">
            {mapCountries.map((country) => (
              <div key={country.name} className="flex items-center justify-between rounded-md border border-line bg-black/25 p-3">
                <div>
                  <p className="font-semibold text-neutral-100">{country.name}</p>
                  <p className="text-xs text-neutral-500">{country.status}</p>
                </div>
                <span className={`h-3 w-3 rounded-full ${country.color}`} />
              </div>
            ))}
          </div>
          <p className="mt-4 text-xs text-neutral-500">
            Carte opérationnelle préparée pour synchronisation avec Atlas Afrique, Knowledge Hub, Google Drive et GitHub.
          </p>
        </Panel>

        <Panel title="Alertes" subtitle="ODD et aspirations sous-couverts">
          <div className="space-y-3">
            {alerts.map((alert) => (
              <div key={alert} className="rounded-md border border-amber-400/25 bg-amber-400/10 p-3 text-sm text-amber-100">
                {alert}
              </div>
            ))}
          </div>
        </Panel>
      </section>

      <Panel title="Scores de couverture ODD" subtitle="Nombre relatif d'articles, briefs et fiches Knowledge Hub liés à chaque ODD">
        <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-3">
          {sdgCoverage.map((item) => (
            <CoverageBar key={item.id} id={item.id} label={item.label} coverage={item.coverage} count={item.articlesCount} />
          ))}
        </div>
      </Panel>

      <Panel title="Fiches complètes des 17 ODD" subtitle="Objectifs, indicateurs, acteurs, projets, progrès et blocages">
        <div className="grid gap-4 lg:grid-cols-2">
          {sdgs.map((sdg) => (
            <article key={sdg.id} className="rounded-md border border-line bg-black/20 p-4">
              <div className="flex items-start justify-between gap-3">
                <div>
                  <h2 className="font-serif text-lg font-semibold text-gold-soft">
                    {sdg.id} : {sdg.title}
                  </h2>
                  <p className="mt-1 text-xs text-neutral-500">Score d&apos;avancement : {sdg.scoreAvancement} %</p>
                </div>
                <span className="rounded-md border border-gold/30 px-2 py-1 text-xs text-gold">{sdg.paysConcernes[0]}</span>
              </div>
              <Field label="Objectifs" value={sdg.objectifs.join(" ")} />
              <Field label="Indicateurs" value={sdg.indicateurs.join(", ")} />
              <Field label="Acteurs impliqués" value={sdg.acteursImpliques.join(", ")} />
              <Field label="Progrès" value={sdg.progres} />
              <Field label="Blocages" value={sdg.blocages.join(", ")} />
            </article>
          ))}
        </div>
      </Panel>

      <Panel title="Agenda 2063" subtitle="Suivi des 7 aspirations de l'Union africaine">
        <div className="grid gap-4 lg:grid-cols-2">
          {aspirations.map((aspiration) => (
            <article key={aspiration.id} className="rounded-md border border-line bg-black/20 p-4">
              <h2 className="font-serif text-lg font-semibold text-gold-soft">{aspiration.id}</h2>
              <p className="mt-2 text-sm leading-6 text-neutral-300">{aspiration.description}</p>
              <Field label="Objectifs" value={aspiration.objectifs.join(", ")} />
              <Field label="Projets associés" value={aspiration.projetsAssocies.join(", ")} />
              <Field label="État d'avancement" value={aspiration.etatAvancement} />
              <CoverageBar id={aspiration.id} label="Score" coverage={aspiration.score} count={Math.round(aspiration.score / 12)} />
            </article>
          ))}
        </div>
      </Panel>

      <section className="grid gap-6 xl:grid-cols-2">
        <Panel title="Couverture Agenda 2063" subtitle="Scores éditoriaux par aspiration">
          <div className="space-y-3">
            {agendaCoverage.map((item) => (
              <CoverageBar key={item.id} id={item.id} label={item.label} coverage={item.coverage} count={item.articlesCount} />
            ))}
          </div>
        </Panel>

        <Panel title="Fil rouge éditorial" subtitle="Contrôle avant proposition d'article">
          <div className="grid gap-3 text-sm text-neutral-300">
            {[
              "1. Intérêt stratégique pour l'Afrique",
              "2. Impact pour l'Afrique",
              "3. Lien ODD",
              "4. Lien Agenda 2063",
              "5. Priorité : Faible, Moyenne, Élevée ou Critique",
              "6. Séparation obligatoire : faits, analyse, hypothèses"
            ].map((rule) => (
              <div key={rule} className="rounded-md border border-line bg-black/20 p-3">
                {rule}
              </div>
            ))}
          </div>
        </Panel>
      </section>

      <Panel title="Intégrations" subtitle="Synchronisation documentaire prévue">
        <div className="grid gap-3 md:grid-cols-4">
          {["Obsidian", "Google Drive", "GitHub", "Base documentaire VA"].map((item) => (
            <div key={item} className="rounded-md border border-line bg-black/20 p-4">
              <p className="font-semibold text-neutral-100">{item}</p>
              <p className="mt-1 text-xs text-neutral-500">Synchronisation préparée, validation humaine requise.</p>
            </div>
          ))}
        </div>
      </Panel>
    </main>
  );
}

function Kpi({ label, value, detail }: { label: string; value: string; detail: string }) {
  return (
    <div className="rounded-md border border-line bg-[#111]/80 p-4">
      <p className="text-xs font-semibold uppercase tracking-[0.18em] text-neutral-500">{label}</p>
      <p className="mt-2 text-3xl font-bold text-gold-soft">{value}</p>
      <p className="mt-1 text-sm text-neutral-400">{detail}</p>
    </div>
  );
}

function Panel({ title, subtitle, children }: { title: string; subtitle: string; children: React.ReactNode }) {
  return (
    <section className="rounded-md border border-line bg-[#111]/80 p-5">
      <div className="mb-4">
        <h2 className="font-serif text-xl font-semibold text-neutral-100">{title}</h2>
        <p className="mt-1 text-sm text-neutral-500">{subtitle}</p>
      </div>
      {children}
    </section>
  );
}

function Field({ label, value }: { label: string; value: string }) {
  return (
    <div className="mt-3">
      <p className="text-[11px] font-semibold uppercase tracking-[0.18em] text-neutral-500">{label}</p>
      <p className="mt-1 text-sm leading-6 text-neutral-300">{value}</p>
    </div>
  );
}

function CoverageBar({ id, label, coverage, count }: { id: string; label: string; coverage: number; count: number }) {
  return (
    <div className="rounded-md border border-line bg-black/20 p-3">
      <div className="flex items-center justify-between gap-3">
        <div>
          <p className="text-sm font-semibold text-neutral-100">{id}</p>
          <p className="line-clamp-2 text-xs text-neutral-500">{label}</p>
        </div>
        <span className="text-sm font-bold text-gold-soft">{coverage} %</span>
      </div>
      <div className="mt-3 h-2 overflow-hidden rounded-full bg-neutral-800">
        <div className="h-full rounded-full bg-gold" style={{ width: `${Math.max(0, Math.min(100, coverage))}%` }} />
      </div>
      <p className="mt-2 text-xs text-neutral-500">{count} contenus liés</p>
    </div>
  );
}
