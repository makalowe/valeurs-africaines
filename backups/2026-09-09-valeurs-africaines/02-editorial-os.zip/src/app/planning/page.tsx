"use client";

import { FormEvent, useEffect, useState } from "react";
import type { PlanningRow } from "@/lib/googleSheets";

type ApiState = {
  row: PlanningRow | null;
  error: string | null;
  isLoading: boolean;
  brief: string | null;
};

const STATUS_ACTIONS = [
  { label: "Passer en Recherche", status: "Recherche" },
  { label: "Passer en Rédaction", status: "Rédaction" },
  { label: "Validation humaine", status: "Validation humaine" }
];

export default function PlanningPage() {
  const [editorialId, setEditorialId] = useState("VA-001");
  const [state, setState] = useState<ApiState>({
    row: null,
    error: null,
    isLoading: false,
    brief: null
  });
  const [rows, setRows] = useState<PlanningRow[]>([]);
  const [source, setSource] = useState<"sheets" | "local" | null>(null);

  useEffect(() => {
    let cancelled = false;
    void fetch("/api/planning", { cache: "no-store" })
      .then(async (response) => {
        const payload = (await response.json()) as { rows?: PlanningRow[]; source?: "sheets" | "local" };
        if (!cancelled && Array.isArray(payload.rows)) {
          setRows(payload.rows);
          setSource(payload.source ?? null);
        }
      })
      .catch(() => undefined);
    return () => {
      cancelled = true;
    };
  }, []);

  async function fetchPlanningRow(event?: FormEvent<HTMLFormElement>, forcedId?: string) {
    event?.preventDefault();
    const id = (forcedId ?? editorialId).trim();

    if (!id) {
      setState({ row: null, error: "Saisis un ID editorial.", isLoading: false, brief: null });
      return;
    }

    setState((current) => ({ ...current, error: null, isLoading: true }));

    try {
      const response = await fetch(`/api/planning/${encodeURIComponent(id)}`);
      const payload = (await response.json()) as { row?: PlanningRow; error?: string };

      if (!response.ok) {
        setState({ row: null, error: payload.error ?? "Erreur pendant la lecture de la ligne.", isLoading: false, brief: null });
        return;
      }

      setState({ row: payload.row ?? null, error: null, isLoading: false, brief: null });
    } catch {
      setState({ row: null, error: "Impossible de contacter l'API interne.", isLoading: false, brief: null });
    }
  }

  async function updateStatus(status: string) {
    const id = editorialId.trim();

    if (!id) {
      setState((current) => ({ ...current, error: "Saisis un ID editorial." }));
      return;
    }

    setState((current) => ({ ...current, error: null, isLoading: true }));

    try {
      const response = await fetch(`/api/planning/${encodeURIComponent(id)}/status`, {
        method: "PATCH",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({ status })
      });
      const payload = (await response.json()) as { row?: PlanningRow; error?: string };

      if (!response.ok) {
        setState((current) => ({
          row: current.row,
          error: payload.error ?? "Erreur pendant la mise a jour du statut.",
          isLoading: false,
          brief: current.brief
        }));
        return;
      }

      setState((current) => ({ row: payload.row ?? null, error: null, isLoading: false, brief: current.brief }));
    } catch {
      setState((current) => ({
        row: current.row,
        error: "Impossible de contacter l'API interne.",
        isLoading: false,
        brief: current.brief
      }));
    }
  }

  async function generateBriefFromRow() {
    if (!state.row) {
      setState((current) => ({ ...current, error: "Charge d'abord une ligne du planning." }));
      return;
    }

    setState((current) => ({ ...current, error: null, isLoading: true }));

    try {
      const response = await fetch("/api/research-brief/generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          titre: state.row.sujet,
          categorie: state.row.rubrique,
          pays: state.row.rubrique,
          resume: state.row.angle_strategique
        })
      });
      const payload = (await response.json()) as { research_brief?: { markdown?: string }; error?: string };

      if (!response.ok) {
        setState((current) => ({
          ...current,
          error: payload.error ?? "Erreur pendant la génération du brief.",
          isLoading: false
        }));
        return;
      }

      setState((current) => ({
        ...current,
        brief: payload.research_brief?.markdown ?? "Brief généré sans contenu exploitable.",
        isLoading: false
      }));
    } catch {
      setState((current) => ({
        ...current,
        error: "Impossible de contacter l'API interne.",
        isLoading: false
      }));
    }
  }

  function createVisualFromRow() {
    if (!state.row) {
      setState((current) => ({ ...current, error: "Charge d'abord une ligne du planning." }));
      return;
    }

    window.localStorage.setItem(
      "va-visual-prefill",
      JSON.stringify({
        type: "diagramme_strategique",
        titre: state.row.sujet,
        contenu: `${state.row.rubrique}\n${state.row.format}\n${state.row.angle_strategique}`
      })
    );
    window.location.assign("/visuals");
  }

  function selectPlanningRow(id: string) {
    setEditorialId(id);
    void fetchPlanningRow(undefined, id);
  }

  return (
    <main className="min-h-screen bg-ink px-5 py-8 text-neutral-100">
      <section className="mx-auto max-w-5xl space-y-6">
        <header className="border-b border-line pb-5">
          <p className="text-xs font-semibold uppercase tracking-[0.24em] text-gold">Valeurs Africaines Editorial OS</p>
          <h1 className="mt-3 text-3xl font-semibold text-gold-soft">Planning editorial</h1>
          <p className="mt-2 max-w-2xl text-sm leading-6 text-neutral-400">
            Saisis un ID editorial pour lire une ligne du planning (Google Sheet si configuré, sinon repli local sur les brouillons réels). Les cles restent cote serveur.
          </p>
        </header>

        {source === "local" ? (
          <div className="rounded-lg border border-gold/30 bg-gold/5 p-4 text-sm text-neutral-200">
            <p className="font-semibold text-gold-soft">Mode planning local (feuille « Planning » absente)</p>
            <p className="mt-1 leading-5 text-neutral-400">
              Les lignes sont vos <span className="font-semibold text-neutral-200">brouillons réels</span> du dossier Valeurs Africaines — l'ID est le nom du fichier
              (ex. <code className="text-gold-soft">2026-09-02-sujet-5-maroc-prevention-conflits-sud-sud-luanda</code>). Choisis une ligne ci-dessous ou saisis son ID.
            </p>
          </div>
        ) : null}

        <form onSubmit={fetchPlanningRow} className="rounded-lg border border-line bg-panel p-4">
          {rows.length > 0 ? (
            <div>
              <label htmlFor="planningRowSelect" className="block text-sm font-semibold text-gold">
                Ligne du planning ({rows.length} disponible{rows.length > 1 ? "s" : ""})
              </label>
              <select
                id="planningRowSelect"
                onChange={(event) => {
                  if (event.target.value) selectPlanningRow(event.target.value);
                }}
                className="mt-2 min-h-11 w-full rounded-md border border-line bg-black px-3 text-neutral-100 outline-none focus:border-gold"
              >
                <option value="">— Choisir une ligne —</option>
                {rows.map((row) => (
                  <option key={row.id} value={row.id}>
                    {row.id} · {row.sujet.slice(0, 60)} · {row.statut}
                  </option>
                ))}
              </select>
            </div>
          ) : null}
          <label htmlFor="editorialId" className="mt-4 block text-sm font-semibold text-gold">
            ID editorial
          </label>
          <div className="mt-3 flex gap-3 max-sm:grid">
            <input
              id="editorialId"
              value={editorialId}
              onChange={(event) => setEditorialId(event.target.value)}
              placeholder={source === "local" ? "nom-du-brouillon.md sans extension" : "VA-001"}
              className="min-h-11 flex-1 rounded-md border border-line bg-black px-3 text-neutral-100 outline-none focus:border-gold"
            />
            <button
              type="submit"
              disabled={state.isLoading}
              className="rounded-md bg-gold px-5 py-2.5 font-bold text-black disabled:opacity-50"
            >
              {state.isLoading ? "Traitement..." : "Traiter une ligne"}
            </button>
          </div>
        </form>

        {state.error ? (
          <div className="rounded-lg border border-red-400/40 bg-red-400/10 p-4 text-sm text-red-100">
            {state.error}
          </div>
        ) : null}

        <section className="grid grid-cols-[minmax(0,1fr)_320px] gap-5 max-lg:grid-cols-1">
          <article className="rounded-lg border border-line bg-panel">
            <div className="border-b border-line bg-[#171717] px-4 py-3">
              <h2 className="font-semibold text-gold-soft">Ligne recuperee</h2>
              <p className="text-sm text-neutral-400">Affichage JSON lisible de la ligne du planning editorial.</p>
            </div>
            <pre className="min-h-[360px] overflow-auto p-4 text-sm leading-6 text-neutral-200">
              {state.row ? JSON.stringify(state.row, null, 2) : "Aucune ligne chargee."}
            </pre>
          </article>

          <aside className="rounded-lg border border-line bg-panel p-4">
            <h2 className="font-semibold text-gold-soft">Statut editorial</h2>
            <p className="mt-2 text-sm leading-6 text-neutral-400">
              Ces boutons changent uniquement le statut dans le planning. Ils ne publient rien et ne generent aucun contenu.
            </p>
            <div className="mt-5 grid gap-3">
              <button
                type="button"
                disabled={state.isLoading || !state.row}
                onClick={generateBriefFromRow}
                className="rounded-md bg-gold px-4 py-3 text-left text-sm font-bold text-black disabled:cursor-not-allowed disabled:opacity-50"
              >
                Générer Brief
              </button>
              <button
                type="button"
                disabled={state.isLoading || !state.row}
                onClick={createVisualFromRow}
                className="rounded-md border border-gold bg-gold/10 px-4 py-3 text-left text-sm font-bold text-gold-soft hover:bg-gold/15 disabled:cursor-not-allowed disabled:opacity-50"
              >
                Créer un visuel
              </button>
              {STATUS_ACTIONS.map((action) => (
                <button
                  key={action.status}
                  type="button"
                  disabled={state.isLoading || !editorialId.trim()}
                  onClick={() => updateStatus(action.status)}
                  className="rounded-md border border-line bg-[#171717] px-4 py-3 text-left text-sm font-semibold text-neutral-100 hover:border-gold disabled:cursor-not-allowed disabled:opacity-50"
                >
                  {action.label}
                </button>
              ))}
            </div>
            <div className="mt-5 rounded-md border border-red-400/30 bg-red-400/10 p-3 text-xs leading-5 text-red-100">
              Publication automatique interdite. Validation humaine obligatoire.
            </div>
          </aside>
        </section>

        {state.brief ? (
          <section className="rounded-lg border border-line bg-panel">
            <div className="border-b border-line bg-[#171717] px-4 py-3">
              <h2 className="font-semibold text-gold-soft">Research Brief généré</h2>
              <p className="text-sm text-neutral-400">Brouillon uniquement. Validation humaine obligatoire.</p>
            </div>
            <pre className="max-h-[620px] overflow-auto whitespace-pre-wrap p-4 text-sm leading-6 text-neutral-200">
              {state.brief}
            </pre>
          </section>
        ) : null}
      </section>
    </main>
  );
}
