"use client";

import { useEffect, useState } from "react";
import { buildPilotageAlerts, usePilotageData } from "@/lib/usePilotageData";
import { formatDisplayDate } from "@/lib/dateDisplay";

export default function EditorialCommandCenterPage() {
  const { loading, error, dashboard, store, day, refresh } = usePilotageData();
  const [driveDetail, setDriveDetail] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;
    void fetch("/api/drive/status", { cache: "no-store" })
      .then(async (response) => {
        const data = await response.json().catch(() => null);
        if (!cancelled && data) {
          setDriveDetail(data.configured ? `Connecté serveur (${data.method === "OAuth" ? "OAuth" : data.method ?? ""})` : `À configurer — manquant : ${(data.missing ?? []).join(", ")}`);
        }
      })
      .catch(() => {
        if (!cancelled) setDriveDetail("Statut indisponible");
      });
    return () => {
      cancelled = true;
    };
  }, []);

  const watchSubjects = dashboard?.watch.subjects ?? [];
  const reviewDate = dashboard?.review?.date ?? dashboard?.watch.date ?? "";
  const reviewDateLabel = formatDisplayDate(reviewDate);
  const decisions = dashboard?.workflow.decisions ?? {};
  const retainedCount = watchSubjects.length > 0
    ? Object.entries(decisions).filter(([key, value]) => key.startsWith(`veille-${dashboard?.watch.date}-`) && value === "Retenir").length
    : 0;
  const alerts = buildPilotageAlerts(dashboard, day, retainedCount);
  const publishedToday = store?.publishedToday ?? 0;

  // Couverture par rubrique (sujets de la veille du jour).
  const rubricCounts = new Map<string, number>();
  for (const subject of watchSubjects) rubricCounts.set(subject.rubric, (rubricCounts.get(subject.rubric) ?? 0) + 1);
  const rubricRows = [...rubricCounts.entries()]
    .map(([rubric, count]) => ({ label: rubric, value: watchSubjects.length > 0 ? Math.round((count / watchSubjects.length) * 100) : 0 }))
    .sort((a, b) => b.value - a.value);

  const countryCounts = new Map<string, number>();
  for (const subject of watchSubjects) {
    for (const country of subject.countries) countryCounts.set(country, (countryCounts.get(country) ?? 0) + 1);
  }
  const africaRows = [...countryCounts.entries()]
    .sort((a, b) => b[1] - a[1])
    .map(([country, count]) => ({ country, status: `couvert · ${count} sujet(s)` }));

  const humanChecks = dashboard?.workflow.humanValidation ?? {};
  const humanCheckRows = Object.entries(humanChecks).map(([label, done]) => ({ label, done }));

  const production = [
    { label: "Articles publiés (total)", value: String(store?.published ?? "—") },
    { label: "Publiés aujourd'hui", value: String(publishedToday) },
    { label: "Brouillons (tous)", value: String(dashboard?.drafts.length ?? "—") },
    { label: "Brouillons du jour", value: String(dashboard?.draftsForToday.length ?? "—") },
    { label: "Sujets de veille", value: String(watchSubjects.length) },
    { label: "Sujets retenus", value: `${retainedCount}/3` }
  ];

  const integrations = [
    { label: "Obsidian", status: dashboard?.obsidianArchive?.present ? `Connecté (${dashboard.obsidianArchive.count} fichier(s) archivés)` : "À configurer — archive non détectée" },
    { label: "Google Drive", status: driveDetail ?? "Vérification…" },
    { label: "GitHub", status: "Local uniquement — commit sur demande explicite" },
    { label: "Google Sheets", status: "Donnée à vérifier" }
  ];

  return (
    <main className="min-h-screen bg-ink px-5 py-8 text-neutral-100">
      <section className="mx-auto max-w-[1680px] space-y-6">
        <header className="rounded-lg border border-line bg-panel p-6">
          <p className="text-xs font-semibold uppercase tracking-[0.28em] text-gold">Valeurs Africaines</p>
          <h1 className="mt-3 text-3xl font-semibold uppercase tracking-wide text-gold-soft">Editorial Command Center</h1>
          <p className="mt-2 max-w-4xl text-sm leading-6 text-neutral-400">
            Centre de commandement branché sur les données réelles (veille, brouillons, publications locales).
            {reviewDate ? ` Journée de référence : ${reviewDateLabel}.` : ""}
          </p>
          <div className="mt-4 flex flex-wrap items-center gap-2">
            <button onClick={refresh} className="rounded-md border border-gold/40 bg-gold/10 px-3 py-2 text-sm font-semibold text-gold-soft transition hover:bg-gold/20">
              Actualiser les données
            </button>
            {loading && <span className="text-sm text-neutral-500">Chargement…</span>}
            {error && <span className="rounded-md border border-red-400/30 bg-red-400/10 px-3 py-2 text-sm text-red-100">{error}</span>}
          </div>
          <div className="mt-4 rounded-md border border-red-400/30 bg-red-400/10 p-3 text-sm font-semibold text-red-100">
            Aucune publication automatique. Validation humaine obligatoire avant toute diffusion.
          </div>
        </header>

        <Panel title="Production éditoriale (données réelles)">
          <KpiGrid items={production} />
        </Panel>

        <Panel title="Couverture stratégique (rubriques de la veille)">
          {rubricRows.length > 0 ? (
            <div className="grid gap-3 md:grid-cols-2">
              {rubricRows.map((item) => (
                <ProgressRow key={item.label} label={item.label} value={item.value} />
              ))}
            </div>
          ) : (
            <p className="text-sm text-neutral-500">Aucune veille détectée — « Donnée à vérifier ».</p>
          )}
        </Panel>

        <section className="grid gap-6 xl:grid-cols-[0.85fr_1.15fr]">
          <Panel title="Alertes éditoriales (réelles)">
            <div className="grid gap-3">
              {alerts.map((alert) => (
                <article
                  key={alert}
                  className={`rounded-md border p-3 text-sm ${alert.startsWith("Aucune alerte") ? "border-emerald-400/40 bg-emerald-400/10 text-emerald-100" : "border-orange-400/40 bg-orange-400/10 text-orange-100"}`}
                >
                  <p>{alert}</p>
                </article>
              ))}
            </div>
          </Panel>

          <Panel title="Carte Afrique — pays couverts aujourd'hui">
            {africaRows.length > 0 ? (
              <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
                {africaRows.map((item) => (
                  <article key={item.country} className="rounded-md border border-emerald-400/30 bg-emerald-400/5 p-4">
                    <h3 className="font-semibold text-emerald-100">{item.country}</h3>
                    <p className="mt-1 text-sm opacity-90">{item.status}</p>
                  </article>
                ))}
              </div>
            ) : (
              <p className="text-sm text-neutral-500">Aucun pays détecté dans la veille — « Donnée à vérifier ».</p>
            )}
          </Panel>
        </section>

        <section className="grid gap-6 xl:grid-cols-[1.1fr_0.9fr]">
          <Panel title="Workflow et validation humaine (réels)">
            <div className="space-y-2">
              <p className="text-sm text-neutral-300">
                Workflow courant : <span className="font-semibold text-gold-soft">{dashboard?.workflow.workflow ?? "—"}</span>
              </p>
              <p className="text-sm text-neutral-400">Prochaine action : {dashboard?.nextAction.daily ?? "—"}</p>
              {humanCheckRows.length > 0 ? (
                <ul className="mt-3 space-y-1.5">
                  {humanCheckRows.map((row) => (
                    <li key={row.label} className={`rounded-md border px-3 py-2 text-sm ${row.done ? "border-emerald-400/30 bg-emerald-400/5 text-emerald-100" : "border-amber-400/30 bg-amber-400/5 text-amber-100"}`}>
                      {row.done ? "☑" : "☐"} {row.label}
                    </li>
                  ))}
                </ul>
              ) : (
                <p className="text-sm text-neutral-500">Aucun critère de validation enregistré.</p>
              )}
            </div>
          </Panel>

          <Panel title="Knowledge Hub">
            <p className="rounded-md border border-line bg-black/20 p-3 text-sm text-neutral-500">
              Compteurs du Knowledge Hub non branchés sur une source réelle — « Donnée à vérifier ». (Fiches réelles consultables dans le vault Obsidian.)
            </p>
          </Panel>
        </section>

        <section className="grid gap-6 xl:grid-cols-2">
          <Panel title="Intégrations">
            <div className="grid gap-3 sm:grid-cols-2">
              {integrations.map((item) => {
                const ok = /connecté|actif/i.test(item.status);
                return (
                  <article key={item.label} className={`rounded-md border p-4 ${ok ? "border-emerald-400/30 bg-emerald-400/5" : "border-amber-400/30 bg-amber-400/5"}`}>
                    <h3 className="font-semibold text-gold-soft">{item.label}</h3>
                    <p className={`mt-2 break-words text-sm ${ok ? "text-emerald-100" : "text-amber-100"}`}>{item.status}</p>
                  </article>
                );
              })}
            </div>
          </Panel>

          <Panel title="Exports">
            <p className="rounded-md border border-line bg-black/20 p-3 text-sm text-neutral-500">
              Exports PDF hebdomadaire / mensuel et rapport trimestriel : à implémenter sur les données réelles ci-dessus (aucune génération automatique).
            </p>
            <div className="mt-3 space-y-2 text-sm text-neutral-400">
              <p>• Données chargées depuis les APIs locales (veille, brouillons, store du site Flask).</p>
              <p>• Publications du jour : {publishedToday}</p>
              <p>
                • Article(s) prêt(s) non publié(s) : {(day ?? []).filter((article) => article.publishedId === null && article.ready).length}
              </p>
            </div>
          </Panel>
        </section>
      </section>
    </main>
  );
}

function Panel({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <section className="rounded-lg border border-line bg-panel">
      <div className="border-b border-line bg-[#171717] px-4 py-3">
        <h2 className="font-semibold text-gold-soft">{title}</h2>
      </div>
      <div className="p-4">{children}</div>
    </section>
  );
}

function KpiGrid({ items }: { items: Array<{ label: string; value: string }> }) {
  return (
    <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6">
      {items.map((item) => (
        <article key={item.label} className="rounded-md border border-line bg-black/20 p-4">
          <div className="text-2xl font-bold text-gold-soft">{item.value}</div>
          <div className="mt-1 text-sm text-neutral-400">{item.label}</div>
        </article>
      ))}
    </div>
  );
}

function ProgressRow({ label, value }: { label: string; value: number }) {
  return (
    <article className="rounded-md border border-line bg-black/20 p-4">
      <div className="flex items-center justify-between gap-3">
        <h3 className="font-semibold text-gold-soft">{label}</h3>
        <span className="text-sm font-bold text-gold">{value} %</span>
      </div>
      <div className="mt-3 h-2 rounded-full bg-neutral-800">
        <div className="h-full rounded-full bg-gold" style={{ width: `${Math.min(100, Math.max(0, value))}%` }} />
      </div>
    </article>
  );
}
