"use client";

import { FormEvent, useState } from "react";

type Channel = "linkedin" | "x" | "newsletter" | "instagram";

type MultichannelResponse = {
  linkedin?: string;
  x?: string[];
  newsletter?: string;
  instagram?: string[];
  markdown?: string;
  html?: string;
  sources?: string[];
  error?: string;
};

const channelOptions: Array<{ value: Channel; label: string }> = [
  { value: "linkedin", label: "LinkedIn" },
  { value: "x", label: "X / Twitter" },
  { value: "newsletter", label: "Newsletter" },
  { value: "instagram", label: "Instagram carousel" }
];

export default function MulticanalPage() {
  const [editorialId, setEditorialId] = useState("VA-001");
  const [channels, setChannels] = useState<Channel[]>(["linkedin", "x", "newsletter", "instagram"]);
  const [sourceContent, setSourceContent] = useState("");
  const [sources, setSources] = useState("Sources internes à vérifier");
  const [drafts, setDrafts] = useState<MultichannelResponse | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  async function generate(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const id = editorialId.trim();

    if (!id) {
      setError("Saisis un ID editorial.");
      return;
    }

    setIsLoading(true);
    setError(null);
    setDrafts(null);

    try {
      const response = await fetch("/api/multicanal/generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          editorialId: id,
          channels,
          sourceContent,
          sources
        })
      });
      const payload = (await response.json()) as MultichannelResponse;

      if (!response.ok) {
        setError(payload.error ?? "Erreur pendant la préparation multicanale.");
        return;
      }

      setDrafts(payload);
    } catch {
      setError("Impossible de contacter l'API interne.");
    } finally {
      setIsLoading(false);
    }
  }

  function toggleChannel(channel: Channel) {
    setChannels((current) =>
      current.includes(channel)
        ? current.filter((item) => item !== channel)
        : [...current, channel]
    );
  }

  async function copyExport(kind: "markdown" | "html") {
    if (!drafts) return;
    await navigator.clipboard.writeText(kind === "markdown" ? drafts.markdown ?? "" : drafts.html ?? "");
  }

  return (
    <main className="min-h-screen bg-ink px-5 py-8 text-neutral-100">
      <section className="mx-auto max-w-7xl space-y-6">
        <header className="border-b border-line pb-5">
          <p className="text-xs font-semibold uppercase tracking-[0.24em] text-gold">Valeurs Africaines Editorial OS</p>
          <h1 className="mt-3 text-3xl font-semibold text-gold-soft">Préparation multicanale</h1>
          <p className="mt-2 max-w-3xl text-sm leading-6 text-neutral-400">
            Transformer un contenu validé en brouillons LinkedIn, X, newsletter et carousel Instagram. Aucun envoi externe n'est effectué.
          </p>
        </header>

        {error ? <div className="rounded-lg border border-red-400/40 bg-red-400/10 p-4 text-sm text-red-100">{error}</div> : null}

        <section className="grid grid-cols-[380px_minmax(0,1fr)] gap-5 max-xl:grid-cols-1">
          <aside className="space-y-5">
            <form onSubmit={generate} className="rounded-lg border border-line bg-panel p-4">
              <h2 className="font-semibold text-gold-soft">Contenu source</h2>
              <div className="mt-4 space-y-3">
                <Field label="ID éditorial">
                  <input value={editorialId} onChange={(event) => setEditorialId(event.target.value)} className="w-full rounded-md border border-line bg-black px-3 py-2 text-sm text-neutral-100 outline-none focus:border-gold" />
                </Field>
                <Field label="Extrait source optionnel">
                  <textarea value={sourceContent} onChange={(event) => setSourceContent(event.target.value)} placeholder="Coller ici le contenu validé si disponible." className="min-h-32 w-full rounded-md border border-line bg-black px-3 py-2 text-sm text-neutral-100 outline-none focus:border-gold" />
                </Field>
                <Field label="Sources à conserver">
                  <textarea value={sources} onChange={(event) => setSources(event.target.value)} className="min-h-20 w-full rounded-md border border-line bg-black px-3 py-2 text-sm text-neutral-100 outline-none focus:border-gold" />
                </Field>
                <div>
                  <div className="mb-2 text-sm font-semibold text-gold">Canaux</div>
                  <div className="grid grid-cols-2 gap-2">
                    {channelOptions.map((option) => (
                      <label key={option.value} className="flex items-center gap-2 rounded-md border border-line bg-black/20 px-3 py-2 text-sm">
                        <input type="checkbox" checked={channels.includes(option.value)} onChange={() => toggleChannel(option.value)} />
                        {option.label}
                      </label>
                    ))}
                  </div>
                </div>
                <button type="submit" disabled={isLoading || channels.length === 0} className="w-full rounded-md bg-gold px-4 py-2.5 font-bold text-black disabled:opacity-50">
                  {isLoading ? "Préparation..." : "Générer les brouillons"}
                </button>
              </div>
            </form>

            <div className="rounded-lg border border-red-400/30 bg-red-400/10 p-4 text-sm leading-6 text-red-100">
              Brouillons uniquement. Validation humaine obligatoire. Publication automatique interdite.
            </div>
          </aside>

          <section className="space-y-5">
            <div className="flex flex-wrap justify-end gap-2 rounded-lg border border-line bg-panel p-3">
              <button onClick={() => copyExport("markdown")} disabled={!drafts?.markdown} className="rounded-md border border-line px-3 py-2 text-sm font-semibold hover:border-gold disabled:opacity-50">Export Markdown</button>
              <button onClick={() => copyExport("html")} disabled={!drafts?.html} className="rounded-md border border-line px-3 py-2 text-sm font-semibold hover:border-gold disabled:opacity-50">Export HTML</button>
            </div>

            <div className="grid grid-cols-2 gap-5 max-lg:grid-cols-1">
              <DraftBlock title="LinkedIn" content={drafts?.linkedin} />
              <DraftBlock title="Newsletter" content={drafts?.newsletter} />
              <ListBlock title="X / Twitter" items={drafts?.x ?? []} />
              <ListBlock title="Instagram carousel" items={drafts?.instagram ?? []} />
            </div>

            <article className="rounded-lg border border-line bg-panel">
              <div className="border-b border-line bg-[#171717] px-4 py-3">
                <h2 className="font-semibold text-gold-soft">Export Markdown</h2>
                <p className="text-sm text-neutral-400">Version consolidée pour revue éditoriale.</p>
              </div>
              <pre className="max-h-[480px] min-h-[220px] overflow-auto whitespace-pre-wrap p-4 text-sm leading-6 text-neutral-200">
                {drafts?.markdown ?? "Les exports apparaîtront ici après génération."}
              </pre>
            </article>
          </section>
        </section>
      </section>
    </main>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="block text-sm">
      <span className="mb-1 block font-semibold text-gold">{label}</span>
      {children}
    </label>
  );
}

function DraftBlock({ title, content }: { title: string; content?: string }) {
  return (
    <article className="rounded-lg border border-line bg-panel">
      <div className="border-b border-line bg-[#171717] px-4 py-3">
        <h2 className="font-semibold text-gold-soft">{title}</h2>
      </div>
      <pre className="max-h-[420px] min-h-[260px] overflow-auto whitespace-pre-wrap p-4 text-sm leading-6 text-neutral-200">
        {content || "Aucun brouillon généré pour ce canal."}
      </pre>
    </article>
  );
}

function ListBlock({ title, items }: { title: string; items: string[] }) {
  return (
    <article className="rounded-lg border border-line bg-panel">
      <div className="border-b border-line bg-[#171717] px-4 py-3">
        <h2 className="font-semibold text-gold-soft">{title}</h2>
      </div>
      <div className="max-h-[420px] min-h-[260px] overflow-auto p-4">
        {items.length > 0 ? (
          <div className="space-y-3">
            {items.map((item, index) => (
              <pre key={`${title}-${index}`} className="whitespace-pre-wrap rounded-md border border-line bg-black/20 p-3 text-sm leading-6 text-neutral-200">
                {item}
              </pre>
            ))}
          </div>
        ) : (
          <p className="text-sm text-neutral-500">Aucun brouillon généré pour ce canal.</p>
        )}
      </div>
    </article>
  );
}
