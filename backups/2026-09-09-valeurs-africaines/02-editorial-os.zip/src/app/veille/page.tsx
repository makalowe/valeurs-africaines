"use client";

import { useEffect, useState } from "react";
import type { WeakSignal } from "@/lib/signals";
import { formatDisplayDate } from "@/lib/dateDisplay";

const geopoliticalCategories = ["Afrique", "Europe", "États-Unis", "Chine", "Russie", "Moyen-Orient"];
const economicCategories = ["Énergie", "Mines", "Agriculture", "Finance", "Infrastructures", "Commerce"];
const technologyCategories = ["IA", "Cloud", "Cybersécurité", "Spatial", "Télécommunications"];

export default function VeillePage() {
  const [signals, setSignals] = useState<WeakSignal[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    async function loadSignals() {
      try {
        const response = await fetch("/api/signaux-faibles");
        const payload = (await response.json()) as WeakSignal[] | { error?: string };

        if (!response.ok || !Array.isArray(payload)) {
          setError(Array.isArray(payload) ? "Erreur API." : payload.error ?? "Impossible de charger les signaux.");
          return;
        }

        setSignals(payload);
      } catch {
        setError("Impossible de contacter l'API interne.");
      } finally {
        setIsLoading(false);
      }
    }

    void loadSignals();
  }, []);

  return (
    <main className="min-h-screen bg-ink px-5 py-8 text-neutral-100">
      <section className="mx-auto max-w-7xl space-y-6">
        <header className="border-b border-line pb-5">
          <p className="text-xs font-semibold uppercase tracking-[0.24em] text-gold">Valeurs Africaines Editorial OS</p>
          <h1 className="mt-3 text-3xl font-semibold text-gold-soft">Centre de veille stratégique</h1>
          <p className="mt-2 max-w-3xl text-sm leading-6 text-neutral-400">
            Visualiser les signaux émergents avant qu'ils deviennent des sujets majeurs. Aucune publication automatique.
          </p>
        </header>

        {error ? (
          <div className="rounded-lg border border-red-400/40 bg-red-400/10 p-4 text-sm text-red-100">
            {error}
          </div>
        ) : null}

        <section className="rounded-lg border border-line bg-panel">
          <div className="border-b border-line bg-[#171717] px-4 py-3">
            <h2 className="font-semibold text-gold-soft">Signaux faibles</h2>
            <p className="text-sm text-neutral-400">
              Source et date obligatoires. Score de confiance conserve pour prioriser la veille.
            </p>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full min-w-[1040px] border-collapse text-left text-sm">
              <thead className="bg-[#12100b] text-xs uppercase tracking-wide text-gold">
                <tr>
                  <th className="px-4 py-3">Signal</th>
                  <th className="px-4 py-3">Région</th>
                  <th className="px-4 py-3">Acteurs</th>
                  <th className="px-4 py-3">Importance</th>
                  <th className="px-4 py-3">Horizon temporel</th>
                  <th className="px-4 py-3">Source</th>
                  <th className="px-4 py-3">Date</th>
                  <th className="px-4 py-3">Confiance</th>
                </tr>
              </thead>
              <tbody>
                {isLoading ? (
                  <tr>
                    <td className="px-4 py-5 text-neutral-400" colSpan={8}>Chargement...</td>
                  </tr>
                ) : signals.length ? (
                  signals.map((signal) => (
                    <tr key={`${signal.signal}-${signal.date}`} className="border-t border-line">
                      <td className="px-4 py-3 font-semibold text-neutral-100">{signal.signal}</td>
                      <td className="px-4 py-3 text-neutral-300">{signal.region}</td>
                      <td className="px-4 py-3 text-neutral-300">{signal.acteurs}</td>
                      <td className="px-4 py-3">
                        <Importance value={signal.importance} />
                      </td>
                      <td className="px-4 py-3 text-neutral-300">{signal.horizon}</td>
                      <td className="px-4 py-3 text-neutral-300">{signal.source}</td>
                      <td className="px-4 py-3 text-neutral-300">{formatDisplayDate(signal.date)}</td>
                      <td className="px-4 py-3 text-gold-soft">{signal.scoreConfiance}/100</td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td className="px-4 py-5 text-neutral-400" colSpan={8}>Aucun signal disponible.</td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </section>

        <section className="grid grid-cols-3 gap-5 max-xl:grid-cols-1">
          <CategoryPanel title="Veille géopolitique" categories={geopoliticalCategories} />
          <CategoryPanel title="Veille économique" categories={economicCategories} />
          <CategoryPanel title="Veille technologique" categories={technologyCategories} />
        </section>
      </section>
    </main>
  );
}

function Importance({ value }: { value: WeakSignal["importance"] }) {
  const className =
    value === "forte"
      ? "border-red-400/40 bg-red-400/10 text-red-100"
      : value === "moyenne"
        ? "border-gold/40 bg-gold/10 text-gold-soft"
        : "border-line bg-black/20 text-neutral-300";

  return <span className={`rounded-full border px-2.5 py-1 text-xs font-semibold ${className}`}>{value}</span>;
}

function CategoryPanel({ title, categories }: { title: string; categories: string[] }) {
  return (
    <article className="rounded-lg border border-line bg-panel p-4">
      <h2 className="font-semibold text-gold-soft">{title}</h2>
      <div className="mt-4 grid gap-2">
        {categories.map((category) => (
          <div key={category} className="rounded-md border border-line bg-black/20 px-3 py-2 text-sm text-neutral-200">
            {category}
          </div>
        ))}
      </div>
    </article>
  );
}
