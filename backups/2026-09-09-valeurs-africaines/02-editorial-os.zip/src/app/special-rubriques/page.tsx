"use client";

import { FormEvent, useState } from "react";
import type { SpecialRubriqueId, SpecialRubriqueProposal } from "@/lib/specialRubriques";

const rubriques: Array<{ id: SpecialRubriqueId; label: string }> = [
  { id: "elles-de-la-semaine", label: "Elles de la semaine" },
  { id: "entrepreneuriat-feminin", label: "Entrepreneuriat féminin" },
  { id: "initiatives-innovation", label: "Initiatives & Innovation" },
  { id: "pulse-des-jeunes", label: "Pulse des Jeunes" },
  { id: "afrique-creative", label: "Afrique Créative" },
  { id: "afrique-diaspora", label: "Afrique Diaspora" },
  { id: "analyse-independante", label: "Analyse indépendante" },
  { id: "souverainete-narrative", label: "Souveraineté narrative" }
];

export default function SpecialRubriquesPage() {
  const [rubrique, setRubrique] = useState<SpecialRubriqueId>("elles-de-la-semaine");
  const [sujet, setSujet] = useState("Leadership féminin africain et souveraineté économique");
  const [sources, setSources] = useState("actualités, CV, rapports, interviews");
  const [result, setResult] = useState<SpecialRubriqueProposal | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  async function generate(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setIsLoading(true);
    setError(null);
    setResult(null);

    try {
      const response = await fetch("/api/special-rubriques/generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          rubrique,
          sujet,
          sources: splitList(sources)
        })
      });
      const payload = (await response.json()) as { proposal?: SpecialRubriqueProposal; error?: string };

      if (!response.ok) {
        setError(payload.error ?? "Erreur pendant la génération.");
        return;
      }

      setResult(payload.proposal ?? null);
    } catch {
      setError("Impossible de contacter l'API interne.");
    } finally {
      setIsLoading(false);
    }
  }

  return (
    <main className="min-h-screen bg-ink px-5 py-8 text-neutral-100">
      <section className="mx-auto max-w-7xl space-y-6">
        <header className="border-b border-line pb-5">
          <p className="text-xs font-semibold uppercase tracking-[0.24em] text-gold">Rubriques spéciales</p>
          <h1 className="mt-3 text-3xl font-semibold text-gold-soft">Propositions éditoriales ciblées</h1>
          <p className="mt-2 max-w-3xl text-sm leading-6 text-neutral-400">
            Générer des angles cadrés pour les rubriques différenciantes de Valeurs Africaines, sans inventer de sources ni publier automatiquement.
          </p>
        </header>

        {error ? <div className="rounded-lg border border-red-400/40 bg-red-400/10 p-4 text-sm text-red-100">{error}</div> : null}

        <section className="grid grid-cols-[360px_minmax(0,1fr)] gap-5 max-lg:grid-cols-1">
          <form onSubmit={generate} className="rounded-lg border border-line bg-panel p-4">
            <h2 className="font-semibold text-gold-soft">Paramètres</h2>
            <label className="mt-4 block text-sm">
              <span className="mb-1 block font-semibold text-gold">Rubrique</span>
              <select value={rubrique} onChange={(event) => setRubrique(event.target.value as SpecialRubriqueId)} className="w-full rounded-md border border-line bg-black px-3 py-2 text-sm text-neutral-100 outline-none focus:border-gold">
                {rubriques.map((item) => <option key={item.id} value={item.id}>{item.label}</option>)}
              </select>
            </label>
            <label className="mt-3 block text-sm">
              <span className="mb-1 block font-semibold text-gold">Sujet</span>
              <textarea value={sujet} onChange={(event) => setSujet(event.target.value)} className="min-h-24 w-full rounded-md border border-line bg-black px-3 py-2 text-sm text-neutral-100 outline-none focus:border-gold" />
            </label>
            <label className="mt-3 block text-sm">
              <span className="mb-1 block font-semibold text-gold">Sources à vérifier</span>
              <textarea value={sources} onChange={(event) => setSources(event.target.value)} className="min-h-20 w-full rounded-md border border-line bg-black px-3 py-2 text-sm text-neutral-100 outline-none focus:border-gold" />
            </label>
            <button type="submit" disabled={isLoading} className="mt-4 w-full rounded-md bg-gold px-4 py-2.5 font-bold text-black disabled:opacity-50">
              {isLoading ? "Génération..." : "Créer proposition"}
            </button>
          </form>

          <section className="rounded-lg border border-line bg-panel">
            <div className="border-b border-line bg-[#171717] px-4 py-3">
              <h2 className="font-semibold text-gold-soft">Proposition</h2>
              <p className="text-sm text-neutral-400">Validation humaine et propositions visuelles obligatoires avant publication.</p>
            </div>
            <pre className="min-h-[560px] overflow-auto whitespace-pre-wrap p-5 text-sm leading-6 text-neutral-200">
              {result ? `${result.title}\n\nObjectif: ${result.objective}\nAngle: ${result.angle}\n\nContrôles:\n- ${result.requiredChecks.join("\n- ")}\n\n${result.draftStructure}` : "La proposition apparaîtra ici."}
            </pre>
          </section>
        </section>
      </section>
    </main>
  );
}

function splitList(value: string): string[] {
  return value.split(/[,;\n]/).map((item) => item.trim()).filter(Boolean);
}
