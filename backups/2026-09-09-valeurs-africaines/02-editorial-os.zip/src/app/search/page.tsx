"use client";

import { FormEvent, useMemo, useState } from "react";
import type { RetrievedContext, SearchMode, SearchResult } from "@/lib/rag";
import { formatDisplayDate } from "@/lib/dateDisplay";

type ApiResponse = RetrievedContext & {
  error?: string;
};

const examples = ["Niger", "Russie + Sahel", "Souveraineté numérique", "CEDEAO", "BRICS"];

export default function SearchPage() {
  const [query, setQuery] = useState("Russie + Sahel");
  const [mode, setMode] = useState<SearchMode>("hybrid");
  const [pays, setPays] = useState("");
  const [acteur, setActeur] = useState("");
  const [theme, setTheme] = useState("");
  const [date, setDate] = useState("");
  const [categorie, setCategorie] = useState("");
  const [retrieved, setRetrieved] = useState<RetrievedContext | null>(null);
  const [selected, setSelected] = useState<SearchResult | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const results = useMemo(() => retrieved?.results ?? [], [retrieved]);

  async function search(event?: FormEvent<HTMLFormElement>) {
    event?.preventDefault();
    setIsLoading(true);
    setError(null);
    setRetrieved(null);
    setSelected(null);

    try {
      const response = await fetch("/api/search", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          query,
          mode,
          limit: 8,
          filters: {
            pays,
            acteur,
            theme,
            date,
            categorie
          }
        })
      });
      const payload = (await response.json()) as ApiResponse;

      if (!response.ok) {
        setError(payload.error ?? "Erreur pendant la recherche documentaire.");
        return;
      }

      setRetrieved(payload);
      setSelected(payload.results[0] ?? null);
    } catch {
      setError("Impossible de contacter l'API interne.");
    } finally {
      setIsLoading(false);
    }
  }

  function openInObsidian(result: SearchResult) {
    const vault = encodeURIComponent("Valeurs Africaines");
    const file = encodeURIComponent(result.document.obsidianPath.replace(/\.md$/, ""));
    window.location.href = `obsidian://open?vault=${vault}&file=${file}`;
  }

  return (
    <main className="min-h-screen bg-ink px-5 py-8 text-neutral-100">
      <section className="mx-auto max-w-7xl space-y-6">
        <header className="border-b border-line pb-5">
          <p className="text-xs font-semibold uppercase tracking-[0.24em] text-gold">Valeurs Africaines Editorial OS</p>
          <h1 className="mt-3 text-3xl font-semibold text-gold-soft">RAG éditorial</h1>
          <p className="mt-2 max-w-3xl text-sm leading-6 text-neutral-400">
            Recherche documentaire interne sur le Knowledge Hub avant rédaction. Les réponses doivent citer les sources internes et signaler les informations absentes.
          </p>
        </header>

        <section className="grid grid-cols-[380px_minmax(0,1fr)] gap-5 max-xl:grid-cols-1">
          <aside className="space-y-5">
            <form onSubmit={search} className="rounded-lg border border-line bg-panel p-4">
              <h2 className="font-semibold text-gold-soft">Recherche</h2>
              <div className="mt-4 space-y-3">
                <Field label="Question utilisateur">
                  <textarea value={query} onChange={(event) => setQuery(event.target.value)} className="min-h-24 w-full rounded-md border border-line bg-black px-3 py-2 text-sm text-neutral-100 outline-none focus:border-gold" />
                </Field>
                <Field label="Mode">
                  <select value={mode} onChange={(event) => setMode(event.target.value as SearchMode)} className="w-full rounded-md border border-line bg-black px-3 py-2 text-sm text-neutral-100 outline-none focus:border-gold">
                    <option value="hybrid">Recherche hybride</option>
                    <option value="semantic">Recherche sémantique</option>
                    <option value="fulltext">Plein texte</option>
                  </select>
                </Field>
                <div className="grid grid-cols-2 gap-3">
                  <Field label="Pays"><input value={pays} onChange={(event) => setPays(event.target.value)} className="w-full rounded-md border border-line bg-black px-3 py-2 text-sm text-neutral-100 outline-none focus:border-gold" /></Field>
                  <Field label="Acteur"><input value={acteur} onChange={(event) => setActeur(event.target.value)} className="w-full rounded-md border border-line bg-black px-3 py-2 text-sm text-neutral-100 outline-none focus:border-gold" /></Field>
                  <Field label="Thème"><input value={theme} onChange={(event) => setTheme(event.target.value)} className="w-full rounded-md border border-line bg-black px-3 py-2 text-sm text-neutral-100 outline-none focus:border-gold" /></Field>
                  <Field label="Date"><input value={date} onChange={(event) => setDate(event.target.value)} placeholder="2026" className="w-full rounded-md border border-line bg-black px-3 py-2 text-sm text-neutral-100 outline-none focus:border-gold" /></Field>
                </div>
                <Field label="Catégorie">
                  <input value={categorie} onChange={(event) => setCategorie(event.target.value)} className="w-full rounded-md border border-line bg-black px-3 py-2 text-sm text-neutral-100 outline-none focus:border-gold" />
                </Field>
                <button type="submit" disabled={isLoading} className="w-full rounded-md bg-gold px-4 py-2.5 font-bold text-black disabled:opacity-50">
                  {isLoading ? "Recherche..." : "Rechercher dans la mémoire"}
                </button>
              </div>
            </form>

            <div className="rounded-lg border border-line bg-panel p-4">
              <h2 className="font-semibold text-gold-soft">Exemples</h2>
              <div className="mt-3 flex flex-wrap gap-2">
                {examples.map((example) => (
                  <button key={example} onClick={() => setQuery(example)} className="rounded-md border border-line px-3 py-2 text-sm hover:border-gold">
                    {example}
                  </button>
                ))}
              </div>
            </div>

            <div className="rounded-lg border border-red-400/30 bg-red-400/10 p-4 text-sm leading-6 text-red-100">
              Le RAG fournit un contexte interne. Il ne publie rien et ne doit pas inventer d'information absente du Knowledge Hub.
            </div>
          </aside>

          <section className="rounded-lg border border-line bg-panel">
            <div className="border-b border-line bg-[#171717] px-4 py-3">
              <h2 className="font-semibold text-gold-soft">Résultats & contexte</h2>
              <p className="text-sm text-neutral-400">Top résultats, citations internes et contexte prêt à injecter dans le GPT.</p>
            </div>

            {error ? <div className="m-4 rounded-md border border-red-400/40 bg-red-400/10 p-3 text-sm text-red-100">{error}</div> : null}

            <div className="grid grid-cols-[minmax(0,0.95fr)_minmax(0,1.05fr)] gap-4 p-4 max-lg:grid-cols-1">
              <div className="space-y-3">
                {results.map((result) => (
                  <button key={result.document.id} onClick={() => setSelected(result)} className="w-full rounded-md border border-line bg-black/20 p-4 text-left hover:border-gold">
                    <div className="flex items-start justify-between gap-3">
                      <div>
                        <h3 className="font-semibold text-neutral-100">{result.document.titre}</h3>
                        <p className="mt-1 text-xs text-neutral-400">{result.document.obsidianPath}</p>
                      </div>
                      <span className="rounded bg-gold/10 px-2 py-1 text-xs font-bold text-gold">{result.score}</span>
                    </div>
                    <p className="mt-3 line-clamp-3 text-sm leading-6 text-neutral-300">{result.excerpt || "Aucun extrait disponible."}</p>
                    <div className="mt-3 grid grid-cols-3 gap-2 text-xs text-neutral-400">
                      <span>Sém. {result.semanticScore}</span>
                      <span>Texte {result.lexicalScore}</span>
                      <span>Filtre {result.filterScore}</span>
                    </div>
                  </button>
                ))}
                {retrieved && results.length === 0 ? <p className="rounded-md border border-line p-4 text-sm text-neutral-400">Aucun résultat interne. Le GPT doit signaler que la mémoire ne contient pas assez d'éléments.</p> : null}
                {!retrieved ? <p className="rounded-md border border-line p-4 text-sm text-neutral-400">Lance une recherche pour consulter la mémoire stratégique.</p> : null}
              </div>

              <article className="rounded-md border border-line bg-black/20">
                <div className="flex items-center justify-between gap-3 border-b border-line px-4 py-3 max-sm:grid">
                  <h3 className="font-semibold text-gold-soft">Aperçu document</h3>
                  <button onClick={() => selected && openInObsidian(selected)} disabled={!selected} className="rounded-md border border-line px-3 py-2 text-sm font-semibold hover:border-gold disabled:opacity-50">
                    Ouvrir dans Obsidian
                  </button>
                </div>
                {selected ? (
                  <div className="space-y-4 p-4">
                    <div className="grid grid-cols-2 gap-3 text-sm max-sm:grid-cols-1">
                      <Info label="Titre" value={selected.document.titre} />
                      <Info label="Catégorie" value={selected.document.categorie} />
                      <Info label="Date" value={formatDisplayDate(selected.document.date) || "-"} />
                      <Info label="Fiabilité" value={selected.document.fiabilite || "A verifier"} />
                    </div>
                    <div>
                      <h4 className="text-sm font-semibold text-gold">Citations internes</h4>
                      <ul className="mt-2 space-y-1 text-sm text-neutral-300">
                        {selected.citations.map((citation) => <li key={citation}>- {citation}</li>)}
                      </ul>
                    </div>
                    <pre className="max-h-[520px] overflow-auto whitespace-pre-wrap rounded-md border border-line bg-black/40 p-4 text-sm leading-6 text-neutral-200">
                      {selected.document.markdown}
                    </pre>
                  </div>
                ) : (
                  <div className="grid min-h-[520px] place-items-center p-5 text-sm text-neutral-500">
                    Aucun document sélectionné.
                  </div>
                )}
              </article>
            </div>

            {retrieved ? (
              <div className="border-t border-line p-4">
                <h3 className="font-semibold text-gold-soft">Contexte injecté</h3>
                <p className="mt-1 text-sm text-neutral-400">{retrieved.instruction}</p>
                <pre className="mt-3 max-h-[340px] overflow-auto whitespace-pre-wrap rounded-md border border-line bg-black/40 p-4 text-sm leading-6 text-neutral-200">
                  {retrieved.context || "Aucun contexte disponible."}
                </pre>
              </div>
            ) : null}
          </section>
        </section>
      </section>
    </main>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="block text-sm">
      <span className="mb-1 block font-semibold text-gold">{label}</span>
      {children}
    </label>
  );
}

function Info({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-md border border-line bg-black/30 p-3">
      <div className="text-xs uppercase tracking-wide text-gold">{label}</div>
      <div className="mt-1 text-neutral-200">{value}</div>
    </div>
  );
}
