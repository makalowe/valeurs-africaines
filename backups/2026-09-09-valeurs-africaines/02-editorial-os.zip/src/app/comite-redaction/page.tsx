"use client";

import { useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import {
  Archive,
  CalendarDays,
  CheckCircle2,
  ChevronRight,
  Clock3,
  FileCheck2,
  Link2,
  Newspaper,
  RotateCcw,
  ShieldCheck,
  TriangleAlert,
  UserRoundCheck
} from "lucide-react";
import type { LucideIcon } from "lucide-react";
import type { DailyReview, DailyReviewSubject } from "@/lib/dailyReview";
import type { DailyWatchSubject } from "@/lib/dailyWatch";
import type { EditorialDashboardData } from "@/lib/editorialDashboardData";
import { buildCodexDraftPrompt, buildHarnessWatchPrompt, CODEX_DRAFT_THREAD_URL, formatLocalDate } from "@/lib/harnessPrompts";
import { formatDisplayDate } from "@/lib/dateDisplay";
import {
  fetchEditorialWorkflowState,
  readEditorialWorkflowState,
  saveEditorialWorkflowState,
  type EditorialWorkflowState,
  type VisualWorkflowState
} from "@/lib/editorialWorkflowState";

type WorkflowStatus = "Idees" | "Selection" | "Redaction" | "Revision" | "Validation" | "Pret a publier" | "Publie" | "Archive";
type SubjectDecision = "A decider" | "Retenir" | "Reporter" | "Abandonner";
type WatchChoice = "selection" | "reporter" | "abandonner";

const WATCH_CHOICE_LABELS: Record<WatchChoice, string> = {
  selection: "Sélectionner pour la revue",
  reporter: "Reporter",
  abandonner: "Abandonner"
};

const VEILLE_CADENCE_MS = 2 * 60 * 60 * 1000;

const VISUAL_KINDS: Array<{ value: string; label: string }> = [
  { value: "", label: "— Choisir le type de visuel —" },
  { value: "image generee IA", label: "Image générée IA" },
  { value: "photo web (droits a verifier)", label: "Photo web (droits à vérifier)" },
  { value: "carte", label: "Carte" },
  { value: "infographie", label: "Infographie" },
  { value: "aucun visuel", label: "Aucun visuel (publier sans image)" }
];

const EDITORIAL_AUTHORS = ["Beno Sori", "Elise Mbon", "Mimi Ndele", "Sori Mbele"];

function watchPartsFromId(id: string): { date: string; index: number } | null {
  const rest = id.replace(/^veille-/, "");
  const match = rest.match(/^(\d{4}-\d{2}-\d{2})-(\d+)$/);
  return match ? { date: match[1], index: Number(match[2]) } : null;
}

function ageLabel(timestamp: number, now = Date.now()): string {
  const minutes = Math.max(0, Math.floor((now - timestamp) / 60000));
  if (minutes < 60) return `${minutes} min`;
  const hours = Math.floor(minutes / 60);
  const rest = minutes % 60;
  return rest > 0 ? `${hours} h ${rest} min` : `${hours} h`;
}

function timeUntilLabel(targetTimestamp: number, now = Date.now()): string {
  const minutes = Math.max(0, Math.ceil((targetTimestamp - now) / 60000));
  if (minutes <= 0) return "maintenant";
  if (minutes < 60) return `dans ${minutes} min`;
  const hours = Math.floor(minutes / 60);
  const rest = minutes % 60;
  return rest > 0 ? `dans ${hours} h ${rest} min` : `dans ${hours} h`;
}

function formatDatesInText(value: string): string {
  return value.replace(/\b(\d{4})-(\d{2})-(\d{2})\b/g, (_match, year: string, month: string, day: string) => `${day}/${month}/${year}`);
}

type Subject = {
  id: string;
  rubrique: string;
  title: string;
  risk: string;
  sourceState: string;
  googleDocUrl?: string;
};

type SubjectState = {
  decision: SubjectDecision;
  note: string;
};

type SubjectReadingEntry = {
  open: boolean;
  status: "idle" | "loading" | "success" | "error";
  title: string;
  content: string;
  source?: string;
  filePath?: string;
  error?: string;
};

type DashboardState = {
  workflow: WorkflowStatus;
  subjects: Record<string, SubjectState>;
  checks: Record<string, boolean>;
  rhythm: "Quotidien" | "Hebdomadaire";
};

const workflowSteps: WorkflowStatus[] = ["Idees", "Selection", "Redaction", "Revision", "Validation", "Pret a publier", "Publie", "Archive"];

const subjects: Subject[] = [
  {
    id: "ua-luanda",
    rubrique: "Actualite strategique",
    title: "UA / Luanda / securite africaine",
    risk: "Financement concret des reformes a confirmer",
    sourceState: "Sources institutionnelles et media"
  },
  {
    id: "senegal-fmi",
    rubrique: "Economie, securite et diplomatie",
    title: "Senegal / FMI / accord technique",
    risk: "Accord soumis au Conseil d'administration du FMI",
    sourceState: "Source FMI officielle",
    googleDocUrl: "https://docs.google.com/document/d/1D8idJKxCJfYkAwFNkkcX3g_ao30mD4K-INHqALxpwlw/edit?usp=drivesdk"
  },
  {
    id: "chine-afrique-ia",
    rubrique: "Innovation, gouvernance, culture et medias",
    title: "Chine-Afrique / medias / IA",
    risk: "Equilibre entre source chinoise et contrepoint africain",
    sourceState: "The Sun Nigeria ajoute"
  }
];

const qualityChecks = [
  "Sources verifiees",
  "Source africaine ou institutionnelle presente",
  "Contrepoint ajoute pour les sujets sensibles",
  "Faits separes de l'analyse",
  "Hypotheses signalees explicitement",
  "Risque plateforme evalue",
  "Charte editoriale respectee",
  "Validation humaine faite"
];

const dailyRhythm = [
  { time: "08:00", label: "Veille et collecte", output: "Sujets candidats" },
  { time: "09:00", label: "Conference courte", output: "3 sujets retenus" },
  { time: "10:00", label: "Redaction", output: "Brouillon complet" },
  { time: "14:00", label: "Revision", output: "Sources, contrepoints, risques" },
  { time: "16:00", label: "Validation humaine", output: "Feu vert ou corrections" },
  { time: "17:00", label: "Publication / archive", output: "Obsidian, Drive, Git" }
];

type PublicationTrack = {
  name: string;
  rhythm: "Quotidien" | "Hebdomadaire";
  status: string;
  progress: number;
  nextAction: string;
  deadline: string;
};

function buildPublicationTracks(dashboard: EditorialDashboardData | null, workflow: WorkflowStatus): PublicationTrack[] {
  const subjectCount = dashboard?.review?.subjectCount ?? 3;
  const draftsForToday = dashboard?.draftsForToday.length ?? 0;
  const dailyDone = draftsForToday >= subjectCount;
  const dailyStatus = workflow === "Pret a publier" ? "Pret a publier apres validation" : dailyDone ? "Brouillons produits — validation humaine requise" : "Production des brouillons en cours";
  const weeklyStatus = (dashboard?.progress.weekly ?? 0) >= 100 ? "Production suffisante : edition a consolider" : "En preparation";
  return [
    {
      name: "Aujourd'hui en Afrique",
      rhythm: "Quotidien",
      status: dailyStatus,
      progress: dashboard?.progress.daily ?? 0,
      nextAction: dashboard?.nextAction.daily ?? "Valider humainement puis archiver",
      deadline: "Aujourd'hui 17:00"
    },
    {
      name: "Edition hebdomadaire",
      rhythm: "Hebdomadaire",
      status: weeklyStatus,
      progress: dashboard?.progress.weekly ?? 0,
      nextAction: dashboard?.nextAction.weekly ?? "Consolider les sujets forts de la semaine",
      deadline: "Vendredi"
    }
  ];
}

const weeklyRhythm = [
  { day: "Lundi", label: "Bilan precedent", output: "Retours, sujets a suivre" },
  { day: "Mardi", label: "Angles forts", output: "Dossiers et rubriques prioritaires" },
  { day: "Mercredi", label: "Production longue", output: "Edition hebdomadaire en cours" },
  { day: "Jeudi", label: "Comite de lecture", output: "Qualite, sources, coherence" },
  { day: "Vendredi", label: "Validation finale", output: "Edition prete" },
  { day: "Weekend", label: "Publication et archivage", output: "Diffusion + sauvegarde" }
];

const weeklyTasks = [
  {
    day: "Lundi",
    focus: "Bilan et cadrage",
    tasks: ["Verifier les publications de la semaine precedente", "Lister les sujets a suivre", "Choisir les priorites de la semaine"]
  },
  {
    day: "Mardi",
    focus: "Recherche et angles",
    tasks: ["Qualifier les sources fortes", "Definir les angles VA", "Decider les sujets longs hebdomadaires"]
  },
  {
    day: "Mercredi",
    focus: "Production",
    tasks: ["Rediger les brouillons longs", "Preparer les visuels ou donnees utiles", "Mettre a jour le pipeline"]
  },
  {
    day: "Jeudi",
    focus: "Comite de lecture",
    tasks: ["Verifier faits et sources", "Ajouter contrepoints", "Corriger biais et hypotheses"]
  },
  {
    day: "Vendredi",
    focus: "Validation",
    tasks: ["Relire les titres et chapos", "Valider humainement", "Preparer publication et archive"]
  },
  {
    day: "Weekend",
    focus: "Publication et memoire",
    tasks: ["Publier ce qui est valide", "Archiver Obsidian / Drive", "Commit Git et bilan hebdomadaire"]
  }
];

const quickLinks = [
  { label: "Revue du jour", path: "01-ACTUALITE-QUOTIDIENNE/Aujourd'hui en Afrique/2026-09-01.md" },
  { label: "Edition hebdomadaire", path: "02-EDITION-HEBDOMADAIRE/" },
  { label: "Template quotidien", path: "VALEURS_AFRICAINES/00_TEMPLATES/Revue Quotidienne - Aujourd'hui en Afrique.md" },
  { label: "Dashboard Obsidian", path: "VALEURS_AFRICAINES/00_DASHBOARD/Comite de redaction.md" },
  { label: "Pilotage CTO", path: "VALEURS_AFRICAINES/99_SYSTEME/pilotage_cto.md" }
];

const initialState: DashboardState = {
  workflow: "Validation",
  rhythm: "Quotidien",
  subjects: {
    "ua-luanda": { decision: "Retenir", note: "Verifier que le financement reste presente comme incertitude." },
    "senegal-fmi": { decision: "Retenir", note: "Garder la mention: soumis au Conseil d'administration du FMI." },
    "chine-afrique-ia": { decision: "Retenir", note: "Contrepoint africain ajoute, controle final requis." }
  },
  checks: Object.fromEntries(qualityChecks.map((check, index) => [check, index < 6]))
};

export default function ComiteRedactionPage() {
  const [state, setState] = useState<DashboardState>(initialState);
  const [review, setReview] = useState<DailyReview | null>(null);
  const [reviewError, setReviewError] = useState<string | null>(null);
  const [selectedSubjectId, setSelectedSubjectId] = useState<string | null>(null);
  const [dashboard, setDashboard] = useState<EditorialDashboardData | null>(null);
  const [, setDashboardError] = useState<string | null>(null);
  const [refreshNonce, setRefreshNonce] = useState(0);
  const watchInfoRef = useRef<{ date: string | null; subjects: Array<{ index: number }> }>({ date: null, subjects: [] });
  const [watchPrompt, setWatchPrompt] = useState<string | null>(null);
  const [copyState, setCopyState] = useState<"idle" | "copied" | "error">("idle");
  const [veilleNotice, setVeilleNotice] = useState<string | null>(null);
  const [watchSelections, setWatchSelections] = useState<Record<string, WatchChoice>>({});
  const [selectedWatchArticleKey, setSelectedWatchArticleKey] = useState<string | null>(null);
  const [subjectReadings, setSubjectReadings] = useState<Record<string, SubjectReadingEntry>>({});
  const [codexPrompt, setCodexPrompt] = useState<string | null>(null);
  const [codexCopyState, setCodexCopyState] = useState<"idle" | "copied" | "error">("idle");

  function setWatchChoice(subject: DailyWatchSubject, choice: WatchChoice) {
    const key = `${dashboard?.watch.date ?? "veille"}-${subject.index}`;
    if (choice === "selection") {
      const currentlySelected = Object.entries(watchSelections).filter(([candidateKey, value]) => value === "selection" && candidateKey !== key).length;
      if (currentlySelected >= 3) {
        setVeilleNotice("3 sujets maximum pour la revue — désélectionne d'abord un sujet avant d'en choisir un autre.");
        return;
      }
    }
    setWatchSelections((current) => {
      const next = { ...current };
      if (next[key] === choice) {
        delete next[key];
      } else {
        next[key] = choice;
      }
      return next;
    });
  }

  function openCodexDraft(subject: DailyWatchSubject) {
    setCodexCopyState("idle");
    setCodexPrompt(buildCodexDraftPrompt({ date: dashboard?.watch.date ?? "à préciser", ...subject }));
    window.open(CODEX_DRAFT_THREAD_URL, "_blank", "noopener,noreferrer");
  }

  function toggleWatchArticle(key: string) {
    setSelectedWatchArticleKey((current) => (current === key ? null : key));
  }

  async function toggleSubjectReading(subject: Subject) {
    const current = subjectReadings[subject.id];
    if (current?.open) {
      setSubjectReadings((items) => ({ ...items, [subject.id]: { ...current, open: false } }));
      if (selectedSubjectId === subject.id) setSelectedSubjectId(null);
      return;
    }

    setSelectedSubjectId(subject.id);
    const parts = watchPartsFromId(subject.id);
    if (!parts) return;

    setSubjectReadings((items) => ({
      ...items,
      [subject.id]: { open: true, status: "loading", title: subject.title, content: "" }
    }));

    try {
      const response = await fetch(`/api/watch-subject?date=${encodeURIComponent(parts.date)}&index=${parts.index}`, { cache: "no-store" });
      const data = await response.json().catch(() => null);
      if (!response.ok || !data?.ok) {
        setSubjectReadings((items) => ({
          ...items,
          [subject.id]: { open: true, status: "error", title: subject.title, content: "", error: data?.error ?? `HTTP ${response.status}` }
        }));
        return;
      }
      setSubjectReadings((items) => ({
        ...items,
        [subject.id]: {
          open: true,
          status: "success",
          title: data.title ?? subject.title,
          content: data.content ?? "",
          source: data.source,
          filePath: data.filePath
        }
      }));
    } catch {
      setSubjectReadings((items) => ({
        ...items,
        [subject.id]: { open: true, status: "error", title: subject.title, content: "", error: "Erreur réseau lors de la lecture du sujet." }
      }));
    }
  }

  async function copyCodexPrompt() {
    if (!codexPrompt) return;
    try {
      await navigator.clipboard.writeText(codexPrompt);
      setCodexCopyState("copied");
    } catch {
      setCodexCopyState("error");
    }
  }

  const [reviewArticleKey, setReviewArticleKey] = useState<string | null>(null);
  const [articlesCache, setArticlesCache] = useState<Record<string, { title: string; content: string; ready: boolean }>>({});
  const [articleError, setArticleError] = useState<string | null>(null);
  const [reviewGenState, setReviewGenState] = useState<"idle" | "loading" | "success" | "error">("idle");
  const [reviewGenMessage, setReviewGenMessage] = useState<string | null>(null);
  const [articleDraftState, setArticleDraftState] = useState<Record<string, { status: "idle" | "loading" | "success" | "error"; message: string }>>({});

  type PublishInfoEntry = { ready: boolean; slug: string; publishedId: number | null; publishedAt: string | null; imageFile: string | null; publishedSlug: string | null };
  const [publishInfo, setPublishInfo] = useState<Record<string, PublishInfoEntry>>({});
  const [publishHumanOk, setPublishHumanOk] = useState<Record<string, boolean>>({});
  const [authorByKey, setAuthorByKey] = useState<Record<string, string>>({});
  const [publishImageMode, setPublishImageMode] = useState<Record<string, "proposal" | "none">>({});
  const [publishBusy, setPublishBusy] = useState<Record<string, boolean>>({});
  const [publishMessages, setPublishMessages] = useState<Record<string, { kind: "error" | "success"; text: string } | null>>({});
  const [visualState, setVisualState] = useState<Record<string, VisualWorkflowState>>({});
  const [visualInput, setVisualInput] = useState<Record<string, string>>({});
  const [visualCopiedKey, setVisualCopiedKey] = useState<string | null>(null);
  const [visualNotice, setVisualNotice] = useState<Record<string, string | null>>({});
  const [publishAllResult, setPublishAllResult] = useState<string | null>(null);
  const [nowMs, setNowMs] = useState(() => Date.now());

  async function handleGenerateReview() {
    const date = dashboard?.watch.date;
    if (!date) return;
    setReviewGenState("loading");
    setReviewGenMessage(null);
    try {
      const response = await fetch("/api/review/generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ date })
      });
      const data = await response.json().catch(() => null);
      if (!response.ok || !data?.ok) {
        setReviewGenState("error");
        setReviewGenMessage(data?.error ?? `HTTP ${response.status}`);
        return;
      }
      setReviewGenState("success");
      const articlesSummary = Array.isArray(data.articles)
        ? data.articles.map((article: { position: number; created: boolean }) => `sujet ${article.position} : ${article.created ? "article créé" : "article déjà existant (conservé)"}`).join(" · ")
        : "";
      setReviewGenMessage(
        `Revue du ${formatDisplayDate(date)} créée : ${data.filePath}${articlesSummary ? ` — ${articlesSummary} (validation humaine requise avant publication).` : ""}`
      );
      setRefreshNonce((value) => value + 1);
    } catch {
      setReviewGenState("error");
      setReviewGenMessage("Erreur réseau lors de la génération de la revue.");
    }
  }

  async function handleGenerateWatchArticle(subject: DailyWatchSubject) {
    const date = dashboard?.watch.date;
    if (!date) return;
    const key = `${date}-${subject.index}`;
    setArticleDraftState((current) => ({ ...current, [key]: { status: "loading", message: "" } }));
    try {
      const response = await fetch("/api/watch-article/draft", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ date, watchIndex: subject.index })
      });
      const data = (await response.json().catch(() => null)) as { ok?: boolean; created?: boolean; filename?: string; filePath?: string; error?: string } | null;
      if (!response.ok || !data?.ok) {
        setArticleDraftState((current) => ({
          ...current,
          [key]: { status: "error", message: data?.error ?? `HTTP ${response.status}` }
        }));
        return;
      }
      if (data.filePath) void openDraftFile(data.filePath);
      setArticleDraftState((current) => ({
        ...current,
        [key]: {
          status: "success",
          message: data.created === false ? `Article déjà existant : ${data.filename}` : `Article généré : ${data.filename}`
        }
      }));
      setRefreshNonce((value) => value + 1);
    } catch {
      setArticleDraftState((current) => ({
        ...current,
        [key]: { status: "error", message: "Erreur réseau lors de la génération de l'article." }
      }));
    }
  }

  function draftFor(date: string | null | undefined, subjectIndex: number | null) {
    if (!date || !subjectIndex || !dashboard) return null;
    return dashboard.drafts.find((draft) => draft.filename.startsWith(`${date}-sujet-${subjectIndex}-`)) ?? null;
  }

  function draftForWatchSubject(date: string | null | undefined, title: string) {
    if (!date || !dashboard) return null;
    const slug = slugifyLoose(title).slice(0, 70);
    const exactMatch = dashboard.drafts.find((draft) => draft.filename.startsWith(`${date}-sujet-`) && draft.filename.endsWith(`-${slug}.md`));
    if (exactMatch) return exactMatch;
    const titleTokens = new Set(slug.split("-").filter((token) => token.length >= 4));
    if (titleTokens.size === 0) return null;
    return (
      dashboard.drafts.find((draft) => {
        if (!draft.filename.startsWith(`${date}-`)) return false;
        const draftSlug = slugifyLoose(draft.filename.replace(/^\d{4}-\d{2}-\d{2}-(?:sujet-\d+-)?/, "").replace(/\.md$/, ""));
        const draftTokens = new Set(draftSlug.split("-").filter((token) => token.length >= 4));
        const overlap = [...titleTokens].filter((token) => draftTokens.has(token)).length;
        return overlap >= Math.min(3, titleTokens.size);
      }) ?? null
    );
  }

  function slugifyLoose(value: string): string {
    return value
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "")
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, "-")
      .replace(/^-+|-+$/g, "")
      .replace(/-+/g, "-");
  }

  async function toggleReviewArticle(filename: string, title: string) {
    if (reviewArticleKey === filename) {
      setReviewArticleKey(null);
      return;
    }
    if (!articlesCache[filename]) {
      setArticleError(null);
      try {
        const response = await fetch(`/api/draft-article?filename=${encodeURIComponent(filename)}`, { cache: "no-store" });
        const data = await response.json().catch(() => null);
        if (!response.ok || !data?.ok) {
          setArticleError(data?.error ?? `HTTP ${response.status}`);
          return;
        }
        setArticlesCache((current) => ({
          ...current,
          [filename]: { title, content: data.content as string, ready: data.ready === true }
        }));
      } catch {
        setArticleError("Erreur réseau lors de la lecture de l'article.");
        return;
      }
    }
    setReviewArticleKey(filename);
  }

  function generateWatchPrompt() {
    setCopyState("idle");
    const lastModified = dashboard?.watch.fileModifiedAt ? new Date(dashboard.watch.fileModifiedAt).getTime() : null;
    const now = Date.now();
    if (lastModified && now - lastModified < VEILLE_CADENCE_MS) {
      const remainingMin = Math.ceil((VEILLE_CADENCE_MS - (now - lastModified)) / 60000);
      const nextSlot = new Date(lastModified + VEILLE_CADENCE_MS).toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" });
      setWatchPrompt(null);
      setVeilleNotice(`Veille déjà actualisée (il y a ${ageLabel(lastModified)}). Prochaine mise à jour possible à ${nextSlot} (dans ~${remainingMin} min) — cadence 2 h.`);
      return;
    }
    const date = formatLocalDate(new Date());
    const prompt = buildHarnessWatchPrompt(date);
    setVeilleNotice("Envoi de la demande à DeepSeek Harness…");
    void fetch("/api/veille/run", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ date, prompt })
    })
      .then(async (response) => {
        const data = await response.json().catch(() => null);
        if (!response.ok || !data?.ok) throw new Error(data?.error ?? `HTTP ${response.status}`);
        setVeilleNotice(
          `Demande de veille du ${formatDisplayDate(date)} enregistrée. Écris maintenant « go » dans la discussion DeepSeek Harness : il doit lire seulement 00-INBOX, produire 6 sujets candidats (un par rubrique), puis s'arrêter. Sélectionne ensuite 3 sujets ici.`
        );
      })
      .catch((requestError) => {
        setVeilleNotice(`Échec de l'envoi (${requestError instanceof Error ? requestError.message : "erreur"}) — colle le prompt ci-dessous manuellement.`);
        setWatchPrompt(prompt);
      });
  }

  async function copyWatchPrompt() {
    if (!watchPrompt) return;
    try {
      await navigator.clipboard.writeText(watchPrompt);
      setCopyState("copied");
    } catch {
      setCopyState("error");
    }
  }

  useEffect(() => {
    let cancelled = false;
    let timer: ReturnType<typeof setInterval> | undefined;

    async function loadDashboard() {
      try {
        const response = await fetch("/api/editorial-dashboard", { cache: "no-store" });
        if (!response.ok) throw new Error(`HTTP ${response.status}`);
        const data = (await response.json()) as EditorialDashboardData;
        if (!cancelled) {
          setDashboard(data);
          watchInfoRef.current = { date: data.watch.date, subjects: data.watch.subjects.map((subject) => ({ index: subject.index })) };
          setDashboardError(null);
        }
      } catch {
        if (!cancelled) setDashboardError("Données réelles indisponibles : l'API /api/editorial-dashboard ne répond pas.");
      }
    }

    void loadDashboard();
    timer = setInterval(() => void loadDashboard(), 15000);

    return () => {
      cancelled = true;
      if (timer) clearInterval(timer);
    };
  }, [refreshNonce]);

  useEffect(() => {
    const timer = setInterval(() => setNowMs(Date.now()), 60_000);
    return () => clearInterval(timer);
  }, []);

  async function loadPublishInfo(date: string) {
    try {
      const response = await fetch(`/api/publish?date=${encodeURIComponent(date)}`, { cache: "no-store" });
      if (!response.ok) return;
      const data = (await response.json()) as {
        articles: Array<{
          filename: string;
          ready: boolean;
          slug: string;
          publishedId: number | null;
          publishedAt: string | null;
          imageFile: string | null;
          publishedSlug: string | null;
        }>;
      };
      // Fusion (ne pas écraser) : les cartes du jour peuvent mélanger la revue
      // (ex. 2026-09-02) et les articles classés de la veille du jour (ex. 2026-09-03).
      setPublishInfo((current) => ({ ...current, ...Object.fromEntries(data.articles.map((article) => [article.filename, article])) }));
    } catch {
      // état de publication indisponible : les cartes restent sans bloc publication
    }
  }

  useEffect(() => {
    const dates = [dashboard?.watch.date, dashboard?.review?.date].filter((value): value is string => Boolean(value));
    for (const date of [...new Set(dates)]) void loadPublishInfo(date);
  }, [refreshNonce, dashboard?.review?.date, dashboard?.watch.date]);

  async function publishOne(filename: string, date: string, humanOverride?: boolean): Promise<void> {
    // La date de publication est celle du fichier (les brouillons/classés commencent
    // par AAAA-MM-JJ) — la date de revue peut différer (ex. revue 02/09, classé 03/09).
    const fileDate = /^\d{4}-\d{2}-\d{2}/.test(filename) ? filename.slice(0, 10) : date;
    const author = (authorByKey[filename] ?? "").trim();
    if (!author) throw new Error("Choisir le rédacteur (pseudonyme éditorial) avant de publier.");
    const info = publishInfo[filename];
    const visual = visualState[filename];
    if (visual?.decision !== "validee" && visual?.decision !== "aucune") {
      throw new Error("Publication bloquée : valider l'illustration ou choisir « Publier sans image » avant de publier.");
    }
    const image =
      visual.decision === "validee" && visual.file
        ? visual.file
        : publishImageMode[filename] === "proposal" && info?.imageFile
          ? info.imageFile
          : "";
    const response = await fetch("/api/publish", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        date: fileDate,
        filename,
        author,
        image,
        visualDecision: visual.decision,
        visualFile: visual.file,
        humanConfirmed: humanOverride ?? (publishHumanOk[filename] === true)
      })
    });
    const data = (await response.json().catch(() => null)) as { ok?: boolean; error?: string; id?: number; url?: string } | null;
    if (!response.ok || !data?.ok) {
      throw new Error(data?.error ?? `HTTP ${response.status}`);
    }
    setPublishMessages((current) => ({
      ...current,
      [filename]: { kind: "success", text: `Publié sur le site local — id ${data.id} · ${data.url}` }
    }));
  }

  async function publishWithFeedback(filename: string, date: string, humanOverride: boolean) {
    setPublishBusy((current) => ({ ...current, [filename]: true }));
    setPublishMessages((current) => ({ ...current, [filename]: null }));
    try {
      await publishOne(filename, date, humanOverride);
      setRefreshNonce((value) => value + 1);
    } catch (error) {
      setPublishMessages((current) => ({
        ...current,
        [filename]: { kind: "error", text: error instanceof Error ? error.message : "Erreur réseau lors de la publication." }
      }));
    } finally {
      setPublishBusy((current) => ({ ...current, [filename]: false }));
    }
  }

  async function handlePublish(filename: string, date: string) {
    await publishWithFeedback(filename, date, false);
  }

  /** Bouton unique de validation humaine : le clic de Pierre valide ET publie localement. */
  async function handleValidateAndPublish(filename: string, date: string) {
    setPublishHumanOk((current) => ({ ...current, [filename]: true }));
    await publishWithFeedback(filename, date, true);
  }

  async function handlePublishAll() {
    const date = pilotDate;
    if (!date) {
      setPublishAllResult("Aucune date de revue disponible pour la publication.");
      return;
    }
    if (retainedCount < 3) {
      setPublishAllResult(`Publication bloquée : ${retainedCount}/3 sujets retenus. Sélectionne les 3 sujets du jour avant de publier localement.`);
      return;
    }
    let published = 0;
    const errors: string[] = [];
    for (const filename of Object.keys(publishInfo)) {
      const info = publishInfo[filename];
      if (!info || info.publishedId !== null || !info.ready) continue;
      const visualDecision = visualState[filename]?.decision ?? "";
      const humanOk = publishHumanOk[filename] === true;
      if (!humanOk || (visualDecision !== "validee" && visualDecision !== "aucune")) {
        errors.push(`${filename} : validation humaine ou décision visuelle manquante`);
        continue;
      }
      try {
        await publishOne(filename, date);
        published += 1;
      } catch (error) {
        errors.push(`${filename} : ${error instanceof Error ? error.message : "erreur"}`);
      }
    }
    if (published > 0) setRefreshNonce((value) => value + 1);
    setPublishAllResult(
      published > 0
        ? `✅ ${published} article(s) publié(s) localement.${errors.length > 0 ? ` Non publiés : ${errors.join(" · ")}` : ""}`
        : `Aucune publication : ${errors.length > 0 ? errors.join(" · ") : "aucun article prêt, validé et au visuel tranché."}`
    );
  }

  function watchSubjectForCard(subject: Subject): DailyWatchSubject | null {
    const parts = watchPartsFromId(subject.id);
    if (!parts || !dashboard) return null;
    return dashboard.watch.subjects.find((item) => item.index === parts.index && item.title === subject.title) ?? null;
  }

  function extractLeadParagraph(content: string): string {
    const body = content.replace(/^---[\s\S]*?---\s*/, "").replace(/^#.*$/m, "");
    const paragraphs = body
      .split(/\n\s*\n/)
      .map((paragraph) => paragraph.replace(/^#{1,6}\s+/, "").replace(/^>\s?/, "").trim())
      .filter((paragraph) => paragraph.length > 0 && !paragraph.startsWith("Rubrique"));
    return (paragraphs[0] ?? "").slice(0, 500);
  }

  function frontmatterActors(content: string | null): string {
    if (!content) return "";
    const match = content.match(/^actors:\s*\[([^\]]*)\]/m);
    if (!match) return "";
    return match[1].split(",").map((actor) => actor.trim().replace(/^"|"$/g, "")).filter(Boolean).join(", ").slice(0, 300);
  }

  function buildIllustrationPrompt(subject: Subject, content: string | null, kind: string): string {
    const watchSubject = watchSubjectForCard(subject);
    const lead = content ? extractLeadParagraph(content) : "";
    const resume = lead || watchSubject?.pourquoi || subject.risk || "Donnée à vérifier — voir la veille et le brouillon.";
    const pays = watchSubject && watchSubject.countries.length > 0 ? watchSubject.countries.join(", ") : "Donnée à vérifier";
    const acteurs = frontmatterActors(content) || "Donnée à vérifier";
    const typeLine =
      kind === "image generee IA"
        ? "Illustration éditoriale générée (pas de photo d'archive non sourcée)."
        : kind === "photo web (droits a verifier)"
          ? "Photo institutionnelle ou de presse à rechercher sur le web — droits à vérifier, source et crédit obligatoires."
          : kind === "carte"
            ? "Carte ou schéma géographique analytique."
            : kind === "infographie"
              ? "Graphique ou infographie analytique (chiffres vérifiés uniquement)."
              : "Proposer une illustration éditoriale, une photo institutionnelle à rechercher, ou un graphique analytique selon le sujet.";
    return `ChatGPT/Codex, crée une illustration éditoriale pour Valeurs Africaines à partir du sujet suivant :

Titre :
${subject.title}

Rubrique :
${subject.rubrique}

Résumé :
${resume}

Angle stratégique :
${subject.risk || "À définir à partir de l'analyse Valeurs Africaines du brouillon."}

Pays concernés :
${pays}

Acteurs concernés :
${acteurs}

Style souhaité :
Magazine panafricain de géopolitique, sobre, professionnel, niveau think tank, palette noir/or Valeurs Africaines.

Type de visuel :
${typeLine}

Contraintes :
- ne pas inventer de faits ;
- ne pas afficher de chiffres non vérifiés ;
- ne pas utiliser de logo officiel sans droit ;
- ne pas représenter fidèlement une personnalité réelle sans source ;
- fournir un visuel adapté à un article web 16:9 ;
- validation humaine obligatoire avant publication.`;
  }

  function requestIllustration(filename: string, subject: Subject, content: string | null) {
    const kind = visualState[filename]?.kind ?? "";
    const prompt = buildIllustrationPrompt(subject, content, kind);
    setVisualState((current) => ({
      ...current,
      [filename]: {
        ...(current[filename] ?? { decision: "", kind: "", file: "", prompt: "", updatedAt: "" }),
        decision: "demandee",
        kind,
        prompt,
        updatedAt: new Date().toISOString()
      }
    }));
    setVisualNotice((current) => ({
      ...current,
      [filename]: "Prompt prêt — clique « Copier prompt illustration » puis envoie-le à ChatGPT/Codex. Dépose le fichier reçu puis « Ajouter image générée »."
    }));
  }

  function setVisualKind(filename: string, kind: string) {
    setVisualState((current) => {
      const existing = current[filename] ?? { decision: "", kind: "", file: "", prompt: "", updatedAt: "" };
      const nextKind = kind;
      const decision = kind === "aucun visuel" ? "aucune" : existing.decision;
      return { ...current, [filename]: { ...existing, kind: nextKind, decision, updatedAt: new Date().toISOString() } };
    });
  }

  async function copyIllustrationPrompt(filename: string) {
    const prompt = visualState[filename]?.prompt;
    if (!prompt) return;
    try {
      await navigator.clipboard.writeText(prompt);
      setVisualCopiedKey(filename);
    } catch {
      setVisualCopiedKey(null);
      setVisualNotice((current) => ({ ...current, [filename]: "Échec de la copie — sélectionne le texte manuellement." }));
    }
  }

  function addVisualFile(filename: string) {
    const file = (visualInput[filename] ?? "").trim().split(/[\\/]/).pop() ?? "";
    if (!file || !/^[A-Za-z0-9][A-Za-z0-9._-]*\.(png|jpe?g|svg|webp)$/i.test(file)) {
      setVisualNotice((current) => ({ ...current, [filename]: "Nom de fichier invalide — attendu ex. mon-visuel.png (déposé dans static/img ou public/propositions)." }));
      return;
    }
    setVisualState((current) => ({
      ...current,
      [filename]: {
        ...(current[filename] ?? { decision: "", kind: "", file: "", prompt: "", updatedAt: "" }),
        decision: "recue",
        file,
        updatedAt: new Date().toISOString()
      }
    }));
    setVisualNotice((current) => ({ ...current, [filename]: `Image enregistrée : ${file} — vérifie l'aperçu puis « Valider ce visuel ».` }));
  }

  function decideVisual(filename: string, decision: VisualWorkflowState["decision"]) {
    setVisualState((current) => ({
      ...current,
      [filename]: {
        ...(current[filename] ?? { decision: "", kind: "", file: "", prompt: "", updatedAt: "" }),
        decision,
        updatedAt: new Date().toISOString()
      }
    }));
    setVisualNotice((current) => ({
      ...current,
      [filename]: decision === "validee" ? "Visuel validé ✅ — la validation humaine de l'article est maintenant possible." : decision === "aucune" ? "Décision « Aucun visuel » enregistrée — l'article sera publié sans illustration." : "Visuel refusé — demande une nouvelle proposition à ChatGPT/Codex."
    }));
  }

  function visualDecisionLabel(key: string): string {
    const decision = visualState[key]?.decision ?? "";
    switch (decision) {
      case "validee":
        return "Illustration validée";
      case "refusee":
        return "Illustration refusée";
      case "aucune":
        return "Aucun visuel (publication sans image)";
      case "recue":
        return "Illustration reçue";
      case "demandee":
        return "Illustration demandée";
      default:
        return "Aucune illustration";
    }
  }

  function publishWithoutImage(filename: string) {
    decideVisual(filename, "aucune");
    if (publishHumanOk[filename] === true) {
      void handlePublish(filename, pilotDate);
    } else {
      setVisualNotice((current) => ({
        ...current,
        [filename]: "Décision « Publier sans image » enregistrée — coche la validation humaine dans le bloc Publication puis clique « Publier sur le site local »."
      }));
    }
  }

  function prepareAllIllustrationPrompts() {
    const date = dashboard?.review?.date ?? dashboard?.watch.date ?? "2026-09-01";
    let prepared = 0;
    for (const subject of sectionSubjects) {
      const draft = subject.id.startsWith("veille-")
        ? draftForWatchSubject(dashboard?.watch.date, subject.title)
        : draftFor(date, sectionSubjects.indexOf(subject) + 1);
      if (!draft) continue;
      if (visualState[draft.filename]?.prompt) continue;
      requestIllustration(draft.filename, subject, articlesCache[draft.filename]?.content ?? null);
      prepared += 1;
    }
    setVisualNotice((current) => ({
      ...current,
      all: prepared > 0 ? `${prepared} prompt(s) d'illustration préparé(s) — copie chacun vers ChatGPT/Codex.` : "Aucun nouveau prompt : tous les brouillons du jour ont déjà un prompt ou aucun brouillon détecté."
    }));
  }

  function scrollToSection(id: string) {
    document.getElementById(id)?.scrollIntoView({ behavior: "smooth", block: "start" });
  }

  useEffect(() => {
    let cancelled = false;
    void fetch("/api/daily-review")
      .then(async (response) => {
        if (!response.ok) throw new Error(`HTTP ${response.status}`);
        return (await response.json()) as DailyReview;
      })
      .then((data) => {
        if (!cancelled) setReview(data);
      })
      .catch(() => {
        if (!cancelled) setReviewError("Revue du jour indisponible : fichier Markdown non lu (l'API /api/daily-review est-elle disponible ?).");
      });
    return () => {
      cancelled = true;
    };
  }, []);

  useEffect(() => {
    let cancelled = false;
    const reconcile = (shared: EditorialWorkflowState) => {
      if (!shared.updatedAt) return;
      const veilleEntries = Object.entries(shared.decisions).filter(([key]) => key.startsWith("veille-"));
      setState((current) => ({
        ...current,
        workflow: shared.workflow,
        rhythm: shared.rhythm,
        subjects: {
          ...current.subjects,
          ...Object.fromEntries(
            Object.entries(current.subjects).map(([id, subject]) => [id, { ...subject, decision: shared.decisions[id] ?? subject.decision }])
          ),
          ...Object.fromEntries(
            veilleEntries.map(([key, decision]) => [key, { decision: decision as SubjectDecision, note: current.subjects[key]?.note ?? "" }])
          )
        },
        checks: Object.fromEntries(qualityChecks.map((check) => [check, shared.humanValidation[check] ?? current.checks[check]]))
      }));
      setWatchSelections((current) => {
        const next = { ...current };
        for (const [key, decision] of veilleEntries) {
          const parts = watchPartsFromId(key);
          if (!parts) continue;
          const watchKey = `${parts.date}-${parts.index}`;
          if (decision === "Retenir") next[watchKey] = "selection";
          else if (decision === "Reporter") next[watchKey] = "reporter";
          else if (decision === "Abandonner") next[watchKey] = "abandonner";
          else delete next[watchKey];
        }
        return next;
      });
      if (shared.visuals) setVisualState(shared.visuals);
    };
    reconcile(readEditorialWorkflowState());
    void fetchEditorialWorkflowState().then(({ state: server }) => {
      if (!cancelled) reconcile(server);
    });
    return () => {
      cancelled = true;
    };
  }, []);

  useEffect(() => {
    const reviewDecisions = Object.fromEntries(Object.entries(state.subjects).map(([id, subject]) => [id, subject.decision]));
    const watchDecisions: Record<string, SubjectDecision> = {};
    const watch = watchInfoRef.current;
    if (watch.date) {
      for (const subject of watch.subjects) {
        const key = `${watch.date}-${subject.index}`;
        const choice = watchSelections[key];
        if (choice) {
          watchDecisions[`veille-${key}`] = choice === "selection" ? "Retenir" : choice === "reporter" ? "Reporter" : "Abandonner";
        }
      }
    }
    void saveEditorialWorkflowState({
      workflow: state.workflow,
      rhythm: state.rhythm,
      decisions: { ...reviewDecisions, ...watchDecisions },
      humanValidation: state.checks,
      visuals: visualState,
      updatedAt: new Date().toISOString()
    });
  }, [state, watchSelections, visualState]);

  const sectionSubjects: Subject[] = useMemo(() => {
    const date = dashboard?.watch.date;
    if (date && dashboard.watch.subjects.length > 0) {
      const all = dashboard.watch.subjects;
      const selected = all
        .filter((subject) => watchSelections[`${date}-${subject.index}`] === "selection")
        .sort((a, b) => a.index - b.index);
      const fillers =
        selected.length < 3 ? all.filter((subject) => !watchSelections[`${date}-${subject.index}`]).slice(0, 3 - selected.length) : [];
      const cards = [...selected, ...fillers].slice(0, 3);
      if (cards.length > 0) {
        return cards.map((subject) => ({
          id: `veille-${date}-${subject.index}`,
          rubrique: subject.rubric,
          title: subject.title,
          risk: subject.risk,
          sourceState: `${subject.sourceUrls.length} source(s) · ${subject.countries.length > 0 ? subject.countries.join(", ") : "Afrique"}`
        }));
      }
    }
    return subjects;
  }, [dashboard, watchSelections]);

  const checkedCount = useMemo(() => Object.values(state.checks).filter(Boolean).length, [state.checks]);
  const retainedCount = useMemo(
    () => sectionSubjects.filter((subject) => decisionForId(subject.id) === "Retenir").length,
    [sectionSubjects, state.subjects, watchSelections]
  );
  const blockers = useMemo(() => {
    const allSubjectsRetained = sectionSubjects.length === 3 && sectionSubjects.every((subject) => decisionForId(subject.id) === "Retenir");
    return [
      !state.checks["Validation humaine faite"] ? "Validation humaine manquante" : "",
      !allSubjectsRetained ? "Decision sujet incomplete (3 sujets retenus requis)" : "",
      state.workflow !== "Pret a publier" ? "Workflow pas encore pret a publier" : ""
    ].filter(Boolean);
  }, [state.checks, state.subjects, state.workflow, sectionSubjects, watchSelections]);
  const readyToPublish = blockers.length === 0;
  const activeIndex = workflowSteps.indexOf(state.workflow);
  const lastVeilleTimestamp = dashboard?.watch.fileModifiedAt ? new Date(dashboard.watch.fileModifiedAt).getTime() : null;
  const nextVeilleTimestamp = lastVeilleTimestamp ? lastVeilleTimestamp + VEILLE_CADENCE_MS : null;
  const lastVeilleLabel = lastVeilleTimestamp
    ? `${ageLabel(lastVeilleTimestamp, nowMs)} (${new Date(lastVeilleTimestamp).toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" })})`
    : "aucune";
  const nextVeilleSlot = nextVeilleTimestamp
    ? nextVeilleTimestamp <= nowMs
      ? "disponible maintenant"
      : `${new Date(nextVeilleTimestamp).toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" })} (${timeUntilLabel(nextVeilleTimestamp, nowMs)})`
    : "dès maintenant";
  const selectedReviewSubject: DailyReviewSubject | null = useMemo(() => {
    if (!selectedSubjectId || !review) return null;
    const card = sectionSubjects.find((subject) => subject.id === selectedSubjectId);
    if (!card) return null;
    if (selectedSubjectId.startsWith("veille-")) {
      return review.subjects.find((subject) => subject.title.trim().toLowerCase() === card.title.trim().toLowerCase()) ?? null;
    }
    const index = subjects.findIndex((subject) => subject.id === selectedSubjectId);
    return index >= 0 ? (review.subjects[index] ?? null) : null;
  }, [selectedSubjectId, review, sectionSubjects]);

  const tracks = useMemo(() => buildPublicationTracks(dashboard, state.workflow), [dashboard, state.workflow]);

  const pilotDate = dashboard?.review?.date ?? dashboard?.watch.date ?? "";
  const pilotDateLabel = formatDisplayDate(pilotDate);
  const publishedTodayCount = Object.values(publishInfo).filter((info) => info.publishedId !== null && info.publishedAt === pilotDate).length;
  const watchSubjectCount = dashboard?.watch.subjects.length ?? sectionSubjects.length;
  const draftsCountForDate = dashboard?.draftsForToday.length ?? 0;
  const visualValues = Object.values(visualState);
  const visualsRequestedCount = visualValues.filter((item) => item.decision === "demandee" || item.decision === "recue" || item.decision === "validee").length;
  const visualsValidatedCount = visualValues.filter((item) => item.decision === "validee").length;
  const humanValidatedCount = Object.values(publishHumanOk).filter(Boolean).length;
  const archiveInfo = dashboard?.obsidianArchive ?? null;
  const alerts: string[] = [];
  if (pilotDate && retainedCount < 3) alerts.push(`Moins de 3 sujets retenus (${retainedCount}/3) pour ${pilotDateLabel}.`);
  for (const filename of Object.keys(publishInfo)) {
    const info = publishInfo[filename];
    if (!info || info.publishedId !== null) continue;
    const label = info.slug;
    if (!info.ready) {
      alerts.push(`Brouillon non prêt : ${label} (chapo à rédiger / texte à compléter).`);
      continue;
    }
    const visualDecision = visualState[filename]?.decision ?? "";
    if (!visualState[filename]?.prompt) alerts.push(`Illustration non demandée : ${label}.`);
    else if (visualDecision !== "validee" && visualDecision !== "aucune") alerts.push(`Illustration non tranchée : ${label}.`);
    if (publishHumanOk[filename] !== true) alerts.push(`Validation humaine absente : ${label}.`);
  }
  if (publishedTodayCount > 0 && archiveInfo && !archiveInfo.present) alerts.push("Journée publiée sans archive Obsidian détectée.");
  if (!state.checks["Validation humaine faite"]) alerts.push("Checklist « Validation humaine faite » non cochée (verrou global de publication).");

  const watchSelectedCount = useMemo(() => {
    if (!dashboard?.watch.date || !dashboard.watch.subjects.length) return 0;
    const date = dashboard.watch.date;
    return dashboard.watch.subjects.filter((subject) => watchSelections[`${date}-${subject.index}`] === "selection").length;
  }, [dashboard, watchSelections]);

  function decisionForId(id: string): SubjectDecision {
    const parts = watchPartsFromId(id);
    if (parts) {
      const key = `${parts.date}-${parts.index}`;
      const choice = watchSelections[key];
      if (choice) return choice === "selection" ? "Retenir" : choice === "reporter" ? "Reporter" : "Abandonner";
    }
    return state.subjects[id]?.decision ?? "A decider";
  }

  function setDecisionForId(id: string, decision: SubjectDecision) {
    setState((current) => ({
      ...current,
      subjects: { ...current.subjects, [id]: { ...(current.subjects[id] ?? { decision: "A decider", note: "" }), decision } }
    }));
    const parts = watchPartsFromId(id);
    if (parts) {
      const key = `${parts.date}-${parts.index}`;
      setWatchSelections((current) => {
        const next = { ...current };
        if (decision === "Retenir") next[key] = "selection";
        else if (decision === "Reporter") next[key] = "reporter";
        else if (decision === "Abandonner") next[key] = "abandonner";
        else delete next[key];
        return next;
      });
    }
  }

  const [draftState, setDraftState] = useState<{ status: "idle" | "loading" | "success" | "error"; message: string }>({ status: "idle", message: "" });

  async function handleDraft() {
    if (!selectedReviewSubject || !review || !selectedSubjectId) return;
    const decision = state.subjects[selectedSubjectId]?.decision ?? "A decider";
    if (decision !== "Retenir") {
      setDraftState({ status: "error", message: "Sujet non retenu : passer la décision à « Retenir » avant de rédiger le brouillon." });
      return;
    }
    const selectedSubject = subjects.find((subject) => subject.id === selectedSubjectId);
    if (selectedSubject?.googleDocUrl) {
      window.open(selectedSubject.googleDocUrl, "_blank", "noopener,noreferrer");
      setDraftState({ status: "success", message: `Google Doc ouvert : ${selectedSubject.googleDocUrl}` });
      return;
    }
    setDraftState({ status: "loading", message: "" });
    try {
      const response = await fetch("/api/draft-article", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ date: review.date, subjectIndex: selectedReviewSubject.index })
      });
      const data = await response.json().catch(() => null);
      if (!response.ok || !data?.ok) {
        setDraftState({ status: "error", message: data?.error ?? `HTTP ${response.status}` });
        return;
      }
      const filePath = data.filePath as string;
      const opened = await openDraftFile(filePath);
      setDraftState({
        status: "success",
        message: opened ? `${filePath} — ouvert sur le PC` : `${filePath} — créé, ouverture automatique indisponible`
      });
    } catch {
      setDraftState({ status: "error", message: "Erreur réseau lors de la génération du brouillon." });
    }
  }

  async function openDraftFile(filePath: string): Promise<boolean> {
    try {
      const response = await fetch("/api/open-local-file", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ filePath })
      });
      return response.ok;
    } catch {
      return false;
    }
  }

  function setWorkflow(workflow: WorkflowStatus) {
    setState((current) => ({ ...current, workflow }));
  }

  function advanceWorkflow() {
    setState((current) => {
      const nextIndex = Math.min(workflowSteps.indexOf(current.workflow) + 1, workflowSteps.length - 1);
      return { ...current, workflow: workflowSteps[nextIndex] };
    });
  }

  function updateDecision(id: string, decision: SubjectDecision) {
    setState((current) => ({
      ...current,
      subjects: { ...current.subjects, [id]: { ...current.subjects[id], decision } }
    }));
  }

  function markSelectedSubjectRetained() {
    if (!selectedSubjectId) return;
    updateDecision(selectedSubjectId, "Retenir");
  }

  function toggleCheck(check: string) {
    setState((current) => ({
      ...current,
      checks: { ...current.checks, [check]: !current.checks[check] }
    }));
  }

  function setRhythm(rhythm: DashboardState["rhythm"]) {
    setState((current) => ({ ...current, rhythm }));
  }

  function resetDashboard() {
    setState(initialState);
  }

  return (
    <main className="min-h-screen bg-ink px-5 py-8 text-neutral-100">
      <section className="mx-auto max-w-[1680px] space-y-6">
        <header className="border-b border-line pb-5">
          <p className="text-xs font-semibold uppercase tracking-[0.24em] text-gold">Poste de pilotage editorial</p>
          <div className="mt-3 flex flex-wrap items-start justify-between gap-4">
            <div>
              <h1 className="text-3xl font-semibold text-gold-soft">Poste de pilotage du comite de redaction</h1>
              <p className="mt-2 max-w-3xl text-sm leading-6 text-neutral-400">
                Controle quotidien et hebdomadaire pour choisir, produire, valider, publier et archiver Valeurs Africaines.
              </p>
            </div>
            <div className={`rounded-md border px-4 py-3 text-sm font-semibold ${readyToPublish ? "border-green-400/40 bg-green-400/10 text-green-100" : "border-red-400/30 bg-red-400/10 text-red-100"}`}>
              {readyToPublish ? "Feu vert possible : pret a publier." : "Publication bloquee tant que le workflow n'est pas complet."}
            </div>
          </div>
        </header>

        <section id="etat-du-jour" className="rounded-lg border border-line bg-panel">
          <div className="border-b border-line bg-[#171717] px-4 py-3">
            <h2 className="font-semibold text-gold-soft">État du jour{pilotDate ? ` — ${pilotDateLabel}` : ""}</h2>
            <p className="text-sm text-neutral-400">Toute la chaîne quotidienne passe par ce poste de pilotage (rubrique « Aujourd'hui en Afrique », 3 articles par jour).</p>
          </div>
          <div className="grid gap-3 p-4 sm:grid-cols-2 lg:grid-cols-5">
            <Kpi icon={CalendarDays} label="Date du jour" value={pilotDate ? pilotDate.split("-").reverse().join("/") : "—"} detail={pilotDate ? "" : "en attente de veille"} />
            <Kpi icon={UserRoundCheck} label="Sujets retenus" value={`${Math.min(retainedCount, 3)}/3`} detail="choisis parmi les candidats" />
            <Kpi icon={FileCheck2} label="Articles générés" value={`${Math.min(draftsCountForDate, 3)}/3`} detail="brouillons du jour" />
            <Kpi icon={CheckCircle2} label="Images validées" value={`${Math.min(visualsValidatedCount, 3)}/3`} detail="visuels approuvés" />
            <Kpi icon={Newspaper} label="Publications du jour" value={`${Math.min(publishedTodayCount, 3)}/3`} detail="site localhost:5000" />
          </div>
          {alerts.length > 0 && (
            <div className="border-t border-line p-4">
              <p className="flex items-center gap-2 text-xs font-semibold uppercase tracking-[0.16em] text-amber-100">
                <TriangleAlert size={14} /> Alertes ({alerts.length})
              </p>
              <ul className="mt-2 space-y-1">
                {alerts.map((alert) => (
                  <li key={alert} className="text-xs leading-5 text-amber-100/80">
                    • {alert}
                  </li>
                ))}
              </ul>
            </div>
          )}
          <div className="flex flex-wrap items-center gap-2 border-t border-line p-4">
            <button
              type="button"
              onClick={generateWatchPrompt}
              className="rounded-md border border-gold/40 bg-gold/10 px-3 py-2 text-xs font-semibold text-gold-soft transition hover:bg-gold/20"
            >
              1 · Lancer la veille du jour
            </button>
            <button
              type="button"
              onClick={() => scrollToSection("sujets-du-jour")}
              className="rounded-md border border-gold/40 bg-gold/10 px-3 py-2 text-xs font-semibold text-gold-soft transition hover:bg-gold/20"
            >
              2 · Sélectionner les 3 sujets
            </button>
            <button
              type="button"
              onClick={() => void handleGenerateReview()}
              disabled={reviewGenState === "loading"}
              className="rounded-md border border-gold/40 bg-gold/10 px-3 py-2 text-xs font-semibold text-gold-soft transition hover:bg-gold/20 disabled:cursor-not-allowed disabled:opacity-40"
            >
              3 · Générer les 3 brouillons
            </button>
            <button
              type="button"
              onClick={prepareAllIllustrationPrompts}
              className="rounded-md border border-gold/40 bg-gold/10 px-3 py-2 text-xs font-semibold text-gold-soft transition hover:bg-gold/20"
            >
              4 · Préparer les prompts illustration
            </button>
            <button
              type="button"
              onClick={() => setRefreshNonce((value) => value + 1)}
              className="rounded-md border border-gold/40 bg-gold/10 px-3 py-2 text-xs font-semibold text-gold-soft transition hover:bg-gold/20"
            >
              5 · Vérifier les 3 articles
            </button>
            <button
              type="button"
              onClick={() => void handlePublishAll()}
              className="rounded-md border border-emerald-400/40 bg-emerald-400/10 px-3 py-2 text-xs font-semibold text-emerald-100 transition hover:bg-emerald-400/20"
            >
              6 · Publier les articles validés (local)
            </button>
            <button
              type="button"
              onClick={() => scrollToSection("archive-journee")}
              className="rounded-md border border-gold/40 bg-gold/10 px-3 py-2 text-xs font-semibold text-gold-soft transition hover:bg-gold/20"
            >
              7 · Archiver la journée
            </button>
          </div>
          {visualNotice.all && <p className="border-t border-line px-4 pb-2 text-xs leading-5 text-gold-soft">{visualNotice.all}</p>}
          {publishAllResult && <p className="border-t border-line px-4 pb-2 text-xs leading-5 text-emerald-100">{publishAllResult}</p>}
        </section>

        {veilleNotice && (
          <div className="flex items-start gap-2 rounded-md border border-gold/30 bg-gold/10 px-3 py-2 text-xs leading-5 text-gold-soft">
            <span>ℹ</span>
            <span>{veilleNotice}</span>
          </div>
        )}

        <section id="sujets-veille" className="rounded-lg border border-line bg-panel">
          <div className="border-b border-line bg-[#171717] px-4 py-3">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div>
                <h2 className="font-semibold text-gold-soft">Sujets sélectionnés par la veille</h2>
                <p className="text-sm text-neutral-400">
                  Source amont de sélection : la veille du jour (00-INBOX), sans toucher à la revue existante. Tableau auto-actualisé toutes les 15 s dès
                  que le fichier Veille existe.
                </p>
              </div>
              <div className="flex items-center gap-3">
                {dashboard?.watch.present && (
                  <span className="rounded-md border border-gold/40 bg-gold/10 px-3 py-1.5 text-sm font-semibold text-gold-soft">
                    {formatDisplayDate(dashboard.watch.date)} · {dashboard.watch.subjects.length} sujets notés
                  </span>
                )}
                <button
                  type="button"
                  onClick={() => setRefreshNonce((value) => value + 1)}
                  className="rounded-md border border-line bg-black/20 px-3 py-1.5 text-sm text-neutral-300 transition hover:border-gold"
                >
                  Actualiser
                </button>
              </div>
            </div>
          </div>
          {dashboard?.watch.present && (
            <div className="flex flex-wrap items-center justify-between gap-3 border-b border-line bg-black/10 px-4 py-3">
              <p className="text-sm text-neutral-300">
                Sélectionnés pour la revue : <span className="font-bold text-gold-soft">{watchSelectedCount}/3</span>
                {watchSelectedCount === 3
                  ? " — prêt à générer."
                  : watchSelectedCount > 0
                    ? " (la génération exige exactement 3 sujets)."
                    : " (choisis 3 sujets pour générer la revue)."}
              </p>
              <button
                type="button"
                disabled={watchSelectedCount !== 3 || reviewGenState === "loading"}
                onClick={() => void handleGenerateReview()}
                className={`rounded-md border px-4 py-2 text-sm font-semibold transition ${
                  watchSelectedCount === 3
                    ? "border-gold/40 bg-gold/10 text-gold-soft hover:bg-gold/20"
                    : "cursor-not-allowed border-line bg-[#101010] text-neutral-500"
                }`}
              >
                {reviewGenState === "loading" ? "Génération…" : "Générer la revue du jour"}
              </button>
            </div>
          )}
          {reviewGenState === "success" && reviewGenMessage && (
            <div className="border-b border-line bg-emerald-400/10 px-4 py-2 text-sm leading-5 text-emerald-100">{reviewGenMessage}</div>
          )}
          {reviewGenState === "error" && reviewGenMessage && (
            <div className="border-b border-line bg-red-400/10 px-4 py-2 text-sm leading-5 text-red-100">{reviewGenMessage}</div>
          )}
          {dashboard?.watch.present && dashboard.watch.subjects.length > 0 ? (
            <div className="grid gap-3 p-4 lg:grid-cols-2">
              {dashboard.watch.subjects.map((subject) => {
                const key = `${dashboard.watch.date}-${subject.index}`;
                const choice = watchSelections[key] ?? null;
                const active = choice === "selection";
                const draftFile = draftForWatchSubject(dashboard.watch.date, subject.title);
                const border = active ? "border-gold/50 bg-gold/5" : "border-line bg-black/20";
                return (
                  <article key={key} className={`rounded-md border p-4 ${border}`}>
                    <div className="flex flex-wrap items-center gap-2 text-xs">
                      <span className="rounded border border-gold/25 bg-gold/10 px-2 py-0.5 font-semibold text-gold-soft">Sujet {subject.index}</span>
                      <span className="rounded border border-line bg-[#101010] px-2 py-0.5 text-neutral-400">{subject.rubric}</span>
                      {subject.countries.map((country) => (
                        <span key={country} className="rounded border border-line bg-[#101010] px-2 py-0.5 text-neutral-400">{country}</span>
                      ))}
                    </div>
                    <h3 className="mt-3 font-semibold text-neutral-100">{subject.title}</h3>
                    {subject.relevance && (
                      <RelevanceBlock
                        stars={subject.relevance.stars}
                        score={subject.relevance.score}
                        criteria={subject.relevance.criteria}
                        reasons={subject.relevance.reason}
                      />
                    )}
                    {subject.pourquoi && <p className="mt-2 text-sm leading-6 text-neutral-400">{subject.pourquoi.slice(0, 220)}{subject.pourquoi.length > 220 ? "…" : ""}</p>}
                    <p className="mt-2 text-xs leading-5 text-amber-100/90">Risque : {subject.risk}</p>
                    {subject.sourceUrls.length > 0 && (
                      <a
                        className="mt-2 block break-all text-xs text-gold-soft underline decoration-gold/40 underline-offset-2"
                        href={subject.sourceUrls[0]}
                        target="_blank"
                        rel="noreferrer"
                      >
                        {subject.sourceUrls[0]}
                      </a>
                    )}
                    {draftFile && (
                      <div className="mt-3">
                        <button
                          type="button"
                          onClick={() => void toggleReviewArticle(draftFile.filename, subject.title)}
                          className={`w-full rounded-md border px-3 py-2 text-sm font-semibold transition ${
                            articlesCache[draftFile.filename] && !articlesCache[draftFile.filename].ready
                              ? "border-amber-400/40 bg-amber-400/10 text-amber-100 hover:bg-amber-400/20"
                              : reviewArticleKey === draftFile.filename
                                ? "border-emerald-400/60 bg-emerald-400/20 text-emerald-50"
                                : "border-emerald-400/40 bg-emerald-400/10 text-emerald-100 hover:bg-emerald-400/20"
                          }`}
                        >
                          {articlesCache[draftFile.filename] && !articlesCache[draftFile.filename].ready
                            ? reviewArticleKey === draftFile.filename
                              ? "Fermer le brouillon"
                              : "Voir le brouillon (rédaction en cours)"
                            : reviewArticleKey === draftFile.filename
                              ? "Fermer l'article complet"
                              : "Lire l'article complet prêt à relire"}
                        </button>
                        {reviewArticleKey === draftFile.filename && articlesCache[draftFile.filename] && (
                          <div className="mt-2 rounded-md border border-line bg-black/25 p-4">
                            <p className={`text-xs font-semibold ${articlesCache[draftFile.filename].ready ? "text-emerald-100" : "text-amber-100"}`}>
                              {articlesCache[draftFile.filename].ready
                                ? `Article complet — ${draftFile.filename} (validation humaine requise avant publication)`
                                : `Brouillon en cours de rédaction — ${draftFile.filename}`}
                            </p>
                            <MarkdownText text={articlesCache[draftFile.filename].content} />
                          </div>
                        )}
                      </div>
                    )}
                    {subject.completeArticle && (
                      <div className="mt-3">
                        <button
                          type="button"
                          onClick={() => toggleWatchArticle(key)}
                          className="rounded-md border border-emerald-400/40 bg-emerald-400/10 px-3 py-1.5 text-xs font-semibold text-emerald-100 transition hover:bg-emerald-400/20"
                        >
                          {selectedWatchArticleKey === key ? "Fermer l'article complet" : "Lire l'article complet prêt à relire"}
                        </button>
                        {selectedWatchArticleKey === key && subject.completeArticle && (
                          <div className="mt-3 rounded-md border border-line bg-black/25 p-4">
                            <p className="text-sm font-semibold text-gold-soft">{subject.completeArticle.title}</p>
                            <MarkdownText text={subject.completeArticle.body} />
                          </div>
                        )}
                      </div>
                    )}
                    <div className="mt-4 flex flex-wrap gap-2">
                      {(["selection", "reporter", "abandonner"] as WatchChoice[]).map((option) => {
                        const isActive = choice === option;
                        const tone =
                          option === "selection"
                            ? "border-gold/40 bg-gold/10 text-gold-soft hover:bg-gold/20"
                            : option === "reporter"
                              ? "border-amber-400/40 bg-amber-400/10 text-amber-100 hover:bg-amber-400/20"
                              : "border-red-400/40 bg-red-400/10 text-red-100 hover:bg-red-400/20";
                        return (
                          <button
                            key={option}
                            type="button"
                            onClick={() => setWatchChoice(subject, option)}
                            className={`rounded-md border px-3 py-1.5 text-xs font-semibold transition ${tone} ${isActive ? "ring-1 ring-current" : "opacity-70 hover:opacity-100"}`}
                          >
                            {WATCH_CHOICE_LABELS[option]}
                          </button>
                        );
                      })}
                    </div>
                    <div className="mt-3 border-t border-line pt-3">
                      <button
                        type="button"
                        disabled={choice !== "selection"}
                        onClick={() => void handleGenerateWatchArticle(subject)}
                        className={`w-full rounded-md border px-3 py-2 text-sm font-semibold transition ${
                          choice === "selection"
                            ? "border-gold/40 bg-gold/10 text-gold-soft hover:bg-gold/20"
                            : "cursor-not-allowed border-line bg-[#101010] text-neutral-500"
                        }`}
                      >
                        {articleDraftState[key]?.status === "loading" ? "Génération de l'article…" : draftFile ? "Article généré — ouvrir / relire" : "Générer l'article"}
                      </button>
                      {articleDraftState[key]?.message && (
                        <p className={`mt-1.5 text-xs leading-5 ${articleDraftState[key].status === "error" ? "text-red-100" : "text-emerald-100"}`}>
                          {articleDraftState[key].message}
                        </p>
                      )}
                      {choice !== "selection" && (
                        <p className="mt-1.5 text-xs text-neutral-500">Disponible après « Sélectionner pour la revue ».</p>
                      )}
                    </div>
                  </article>
                );
              })}
            </div>
          ) : (
            <div className="p-4 text-sm leading-6 text-neutral-400">
              Aucune veille trouvée dans 00-INBOX/ (Veille - YYYY-MM-DD.md). Utiliser le bouton « Veille » puis faire produire la veille du
              jour — elle apparaîtra ici dès que le fichier existera. Les choix restent locaux au dashboard : la revue Markdown n'est jamais modifiée
              automatiquement.
            </div>
          )}
          {codexPrompt && (
            <div className="border-t border-line p-4">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div>
                  <p className="text-sm font-semibold text-gold-soft">Thread Codex ouvert — colle ce prompt dans le fil</p>
                  <p className="text-xs leading-5 text-neutral-500">
                    Le bouton a ouvert le thread {CODEX_DRAFT_THREAD_URL.replace("codex://threads/", "")} — rien n'est rédigé ni publié automatiquement.
                  </p>
                </div>
                <div className="flex items-center gap-3">
                  {codexCopyState === "copied" && <span className="text-sm font-semibold text-emerald-100">Copié ✓</span>}
                  {codexCopyState === "error" && <span className="text-sm font-semibold text-red-100">Échec de la copie — copier manuellement</span>}
                  <button
                    type="button"
                    onClick={() => void copyCodexPrompt()}
                    className="rounded-md border border-gold/40 bg-gold/10 px-3 py-1.5 text-sm font-semibold text-gold-soft transition hover:bg-gold/20"
                  >
                    Copier le prompt
                  </button>
                  <button
                    type="button"
                    onClick={() => setCodexPrompt(null)}
                    className="rounded-md border border-line bg-black/20 px-3 py-1.5 text-sm text-neutral-300 transition hover:border-gold"
                  >
                    Fermer
                  </button>
                </div>
              </div>
              <pre className="mt-3 max-h-[320px] overflow-auto whitespace-pre-wrap rounded-md border border-line bg-black/25 p-4 text-sm leading-6 text-neutral-200">{codexPrompt}</pre>
            </div>
          )}
        </section>

        <section id="sujets-du-jour" className="rounded-lg border border-line bg-panel">
          <div className="border-b border-line bg-[#171717] px-4 py-3">
            <h2 className="font-semibold text-gold-soft">Sujets du jour</h2>
            <p className="text-sm text-neutral-400">
              Le comite decide sujet par sujet : retenir, reporter ou abandonner.
              {pilotDate ? (
                <span className="ml-2 font-semibold text-emerald-100">
                  · Publications du {pilotDateLabel} : {publishedTodayCount}/3
                </span>
              ) : null}
            </p>
          </div>
          <div className="grid gap-3 p-4 lg:grid-cols-3">
            {sectionSubjects.map((subject) => {
              const subjectDecision = decisionForId(subject.id);
              const isVeilleCard = subject.id.startsWith("veille-");
              const draft = isVeilleCard
                ? draftForWatchSubject(dashboard?.watch.date, subject.title)
                : draftFor(dashboard?.review?.date ?? "2026-09-01", sectionSubjects.indexOf(subject) + 1);
              const watchSubject = watchSubjectForCard(subject);
              const draftKey = watchSubject && dashboard?.watch.date ? `${dashboard.watch.date}-${watchSubject.index}` : subject.id;
              return (
                <article key={subject.id} className="rounded-md border border-line bg-black/20 p-4">
                  <p className="text-xs font-semibold uppercase tracking-[0.18em] text-gold">{subject.rubrique}</p>
                  <h3 className="mt-3 min-h-12 text-base font-semibold text-neutral-100">{subject.title}</h3>
                  <dl className="mt-4 space-y-3 text-sm">
                    <Info label="Sources" value={subject.sourceState} />
                    <Info label="Risque" value={subject.risk} />
                  </dl>
                  <div className="mt-4">
                    <label className="text-xs font-semibold uppercase tracking-[0.14em] text-neutral-500">Decision</label>
                    <select
                      value={subjectDecision}
                      onChange={(event) => setDecisionForId(subject.id, event.target.value as SubjectDecision)}
                      className="mt-2 w-full rounded-md border border-line bg-[#101010] px-3 py-2 text-sm text-neutral-100 outline-none focus:border-gold"
                    >
                      <option>A decider</option>
                      <option>Retenir</option>
                      <option>Reporter</option>
                      <option>Abandonner</option>
                    </select>
                  </div>
                  {!draft && watchSubject && subjectDecision === "Retenir" ? (
                    <div className="mt-4 rounded-md border border-gold/30 bg-gold/5 p-3">
                      <p className="text-[11px] font-semibold uppercase tracking-[0.14em] text-gold">Rédaction article</p>
                      <p className="mt-1 text-xs leading-5 text-neutral-400">
                        Le sujet est retenu. Génère maintenant le brouillon complet avant l'image, la validation et la publication locale.
                      </p>
                      <button
                        type="button"
                        onClick={() => void handleGenerateWatchArticle(watchSubject)}
                        disabled={articleDraftState[draftKey]?.status === "loading"}
                        className="mt-3 w-full rounded-md border border-gold/50 bg-gold/15 px-3 py-2 text-sm font-semibold text-gold-soft transition hover:bg-gold/25 disabled:cursor-not-allowed disabled:opacity-50"
                      >
                        {articleDraftState[draftKey]?.status === "loading" ? "Génération de l'article…" : "Générer l'article"}
                      </button>
                      {articleDraftState[draftKey]?.message ? (
                        <p className={`mt-2 text-xs leading-5 ${articleDraftState[draftKey].status === "error" ? "text-red-100" : "text-emerald-100"}`}>
                          {articleDraftState[draftKey].message}
                        </p>
                      ) : null}
                    </div>
                  ) : null}
                  {draft ? (
                    <div className="mt-4 rounded-md border border-line bg-black/15 p-3">
                      <p className="text-[11px] font-semibold uppercase tracking-[0.14em] text-gold">Image proposée pour l'article</p>
                      {publishInfo[draft.filename]?.imageFile ? (
                        <VisualPreview file={publishInfo[draft.filename].imageFile ?? ""} />
                      ) : (
                        <ArticleImageProposal
                          proposal={articlesCache[draft.filename] ? extractImageProposal(articlesCache[draft.filename].content) : null}
                          filename={draft.filename}
                        />
                      )}
                      {!articlesCache[draft.filename] && !publishInfo[draft.filename]?.imageFile ? (
                        <p className="mt-2 text-xs leading-5 text-neutral-500">
                          Le visuel s'affiche directement. Ouvre l'article complet ci-dessous pour charger aussi la note éditoriale associée.
                        </p>
                      ) : null}
                    </div>
                  ) : (
                    (() => {
                      const preKey = `pre-${subject.id}`;
                      const visual = visualState[preKey];
                      const decision = visual?.decision ?? "";
                      const tone =
                        decision === "validee"
                          ? "border-emerald-400/40 bg-emerald-400/10 text-emerald-100"
                          : decision === "refusee"
                            ? "border-red-400/40 bg-red-400/10 text-red-100"
                            : decision === "aucune"
                              ? "border-line bg-black/20 text-neutral-300"
                              : decision === "recue"
                                ? "border-sky-400/40 bg-sky-400/10 text-sky-100"
                                : decision === "demandee"
                                  ? "border-amber-400/40 bg-amber-400/10 text-amber-100"
                                  : "border-line bg-black/20 text-neutral-400";
                      const label =
                        decision === "validee"
                          ? "Illustration validée"
                          : decision === "refusee"
                            ? "Illustration refusée"
                            : decision === "aucune"
                              ? "Aucun visuel"
                              : decision === "recue"
                                ? "Illustration reçue"
                                : decision === "demandee"
                                  ? "Illustration demandée"
                                  : "Aucune illustration";
                      return (
                        <div className="mt-4 space-y-3 rounded-md border border-line bg-black/15 p-3">
                          <div className="flex flex-wrap items-center justify-between gap-2">
                            <p className="text-[11px] font-semibold uppercase tracking-[0.14em] text-gold">Illustration (ChatGPT/Codex)</p>
                            <span className={`rounded-md border px-2 py-0.5 text-[10px] font-semibold ${tone}`}>{label}</span>
                          </div>
                          <div>
                            <label className="text-[10px] font-semibold uppercase tracking-[0.14em] text-neutral-500">Type de visuel</label>
                            <select
                              value={visual?.kind ?? ""}
                              onChange={(event) => setVisualKind(preKey, event.target.value)}
                              className="mt-1 w-full rounded-md border border-line bg-[#101010] px-2 py-1.5 text-xs text-neutral-100 outline-none focus:border-gold"
                            >
                              {VISUAL_KINDS.map((kind) => (
                                <option key={kind.value} value={kind.value}>
                                  {kind.label}
                                </option>
                              ))}
                            </select>
                          </div>
                          {!visual?.prompt ? (
                            <button
                              type="button"
                              onClick={() => requestIllustration(preKey, subject, null)}
                              className="w-full rounded-md border border-gold/50 bg-gold/15 px-3 py-2 text-xs font-semibold text-gold-soft transition hover:bg-gold/25"
                            >
                              🎨 Générer le prompt illustration
                            </button>
                          ) : (
                            <>
                              <pre className="max-h-40 overflow-auto whitespace-pre-wrap rounded-md border border-line bg-[#101010] p-2 text-[10px] leading-4 text-neutral-400">{visual?.prompt}</pre>
                              <button
                                type="button"
                                onClick={() => void copyIllustrationPrompt(preKey)}
                                className="w-full rounded-md border border-line bg-[#101010] px-3 py-2 text-xs font-semibold text-neutral-200 transition hover:border-gold/40"
                              >
                                {visualCopiedKey === preKey ? "Prompt copié ✓" : "Copier prompt illustration"}
                              </button>
                              <div className="flex gap-2">
                                <input
                                  value={visualInput[preKey] ?? visual?.file ?? ""}
                                  onChange={(event) => setVisualInput((current) => ({ ...current, [preKey]: event.target.value }))}
                                  placeholder="nom-du-fichier.png (déposé dans static/img ou public/propositions)"
                                  className="min-w-0 flex-1 rounded-md border border-line bg-[#101010] px-3 py-2 text-xs text-neutral-100 outline-none focus:border-gold"
                                />
                                <button
                                  type="button"
                                  onClick={() => addVisualFile(preKey)}
                                  className="shrink-0 rounded-md border border-gold/40 bg-gold/10 px-3 py-2 text-xs font-semibold text-gold-soft transition hover:bg-gold/20"
                                >
                                  Ajouter image
                                </button>
                              </div>
                              {visual?.file ? <VisualPreview file={visual.file} /> : null}
                              <div className="grid grid-cols-3 gap-2">
                                <button
                                  type="button"
                                  onClick={() => decideVisual(preKey, "validee")}
                                  className="rounded-md border border-emerald-400/40 bg-emerald-400/10 px-2 py-1.5 text-[11px] font-semibold text-emerald-100 transition hover:bg-emerald-400/20"
                                >
                                  ✅ Valider l'illustration
                                </button>
                                <button
                                  type="button"
                                  onClick={() => decideVisual(preKey, "refusee")}
                                  className="rounded-md border border-red-400/40 bg-red-400/10 px-2 py-1.5 text-[11px] font-semibold text-red-100 transition hover:bg-red-400/20"
                                >
                                  ✕ Refuser
                                </button>
                                <button
                                  type="button"
                                  onClick={() => decideVisual(preKey, "aucune")}
                                  className="rounded-md border border-line bg-black/20 px-2 py-1.5 text-[11px] font-semibold text-neutral-300 transition hover:border-neutral-500"
                                >
                                  Aucun visuel
                                </button>
                              </div>
                            </>
                          )}
                          {visualNotice[preKey] && <p className="text-[11px] leading-5 text-neutral-400">{visualNotice[preKey]}</p>}
                          <p className="text-[10px] leading-4 text-neutral-600">
                            Le brouillon de l'article n'existe pas encore : après « Générer les 3 brouillons », la gestion de l'illustration continue depuis la
                            carte de l'article. Droits à vérifier — validation humaine obligatoire.
                          </p>
                        </div>
                      );
                    })()
                  )}
                  <button
                    type="button"
                    onClick={() => void toggleSubjectReading(subject)}
                    className="mt-4 w-full rounded-md border border-gold/40 bg-gold/10 px-3 py-2 text-sm font-semibold text-gold-soft transition hover:bg-gold/20"
                  >
                    {subjectReadings[subject.id]?.open ? "Fermer la lecture" : "Lire le sujet complet"}
                  </button>
                                    {subjectReadings[subject.id]?.open ? (
                    <div className="mt-3 rounded-md border border-gold/30 bg-black/30 p-4">
                      {subjectReadings[subject.id].status === "loading" ? (
                        <p className="text-sm text-neutral-400">Chargement du sujet complet…</p>
                      ) : subjectReadings[subject.id].status === "error" ? (
                        <p className="text-sm text-red-100">{subjectReadings[subject.id].error ?? "Lecture impossible."}</p>
                      ) : (
                        <>
                          <p className="text-xs font-semibold uppercase tracking-[0.14em] text-gold">
                            {subjectReadings[subject.id].source === "article-classe" ? "Article classé" : "Sujet de veille"}
                          </p>
                          {subjectReadings[subject.id].filePath ? (
                            <p className="mt-1 break-all text-[11px] text-neutral-500">{subjectReadings[subject.id].filePath}</p>
                          ) : null}
                          <MarkdownText text={subjectReadings[subject.id].content} />
                        </>
                      )}
                    </div>
                  ) : null}
                  {draft && (
                    <div className="mt-2">
                      <button
                        type="button"
                        onClick={() => void toggleReviewArticle(draft.filename, subject.title)}
                        className={`w-full rounded-md border px-3 py-2 text-sm font-semibold transition ${
                          articlesCache[draft.filename] && !articlesCache[draft.filename].ready
                            ? "border-amber-400/40 bg-amber-400/10 text-amber-100 hover:bg-amber-400/20"
                            : reviewArticleKey === draft.filename
                              ? "border-emerald-400/60 bg-emerald-400/20 text-emerald-50"
                              : "border-emerald-400/40 bg-emerald-400/10 text-emerald-100 hover:bg-emerald-400/20"
                        }`}
                      >
                        {articlesCache[draft.filename] && !articlesCache[draft.filename].ready
                          ? reviewArticleKey === draft.filename
                            ? "Fermer le brouillon"
                            : "Voir le brouillon (rédaction en cours)"
                          : reviewArticleKey === draft.filename
                            ? "Fermer l'article complet"
                            : "Lire l'article complet prêt à relire"}
                      </button>
                      {articleError && <p className="mt-1.5 text-xs text-red-100">{articleError}</p>}
                      {reviewArticleKey === draft.filename && articlesCache[draft.filename] && (
                        <div className="mt-2 rounded-md border border-line bg-black/25 p-4">
                          <p className={`text-xs font-semibold ${articlesCache[draft.filename].ready ? "text-emerald-100" : "text-amber-100"}`}>
                            {articlesCache[draft.filename].ready
                              ? `Article complet — ${draft.filename} (validation humaine requise avant publication)`
                              : `Brouillon en cours de rédaction — ${draft.filename} (chapo et relecture à compléter)`}
                          </p>
                          <MarkdownText text={articlesCache[draft.filename].content} />
                        </div>
                      )}
                      <div className="mt-2 space-y-3 rounded-md border border-line bg-black/15 p-3">
                        <div className="flex flex-wrap items-center justify-between gap-2">
                          <p className="text-[11px] font-semibold uppercase tracking-[0.14em] text-gold">Illustration (ChatGPT/Codex)</p>
                          {(() => {
                            const decision = visualState[draft.filename]?.decision ?? "";
                            const tone =
                              decision === "validee"
                                ? "border-emerald-400/40 bg-emerald-400/10 text-emerald-100"
                                : decision === "refusee"
                                  ? "border-red-400/40 bg-red-400/10 text-red-100"
                                  : decision === "aucune"
                                    ? "border-line bg-black/20 text-neutral-300"
                                    : decision === "recue"
                                      ? "border-sky-400/40 bg-sky-400/10 text-sky-100"
                                      : decision === "demandee"
                                        ? "border-amber-400/40 bg-amber-400/10 text-amber-100"
                                        : "border-line bg-black/20 text-neutral-400";
                            const label =
                              decision === "validee"
                                ? "Validé"
                                : decision === "refusee"
                                  ? "Refusé"
                                  : decision === "aucune"
                                    ? "Aucun visuel"
                                    : decision === "recue"
                                      ? "Reçu"
                                      : decision === "demandee"
                                    ? "Demandé"
                                    : "Aucune illustration";
                            return <span className={`rounded-md border px-2 py-0.5 text-[10px] font-semibold ${tone}`}>{label}</span>;
                          })()}
                        </div>
                        <div>
                          <label className="text-[10px] font-semibold uppercase tracking-[0.14em] text-neutral-500">Type de visuel</label>
                          <select
                            value={visualState[draft.filename]?.kind ?? ""}
                            onChange={(event) => setVisualKind(draft.filename, event.target.value)}
                            className="mt-1 w-full rounded-md border border-line bg-[#101010] px-2 py-1.5 text-xs text-neutral-100 outline-none focus:border-gold"
                          >
                            {VISUAL_KINDS.map((kind) => (
                              <option key={kind.value} value={kind.value}>
                                {kind.label}
                              </option>
                            ))}
                          </select>
                        </div>
                        {!visualState[draft.filename]?.prompt ? (
                          <button
                            type="button"
                            onClick={() => requestIllustration(draft.filename, subject, articlesCache[draft.filename]?.content ?? null)}
                            className="w-full rounded-md border border-gold/50 bg-gold/15 px-3 py-2 text-xs font-semibold text-gold-soft transition hover:bg-gold/25"
                          >
                            🎨 Demander une illustration à ChatGPT/Codex
                          </button>
                        ) : (
                          <>
                            <div>
                              <p className="text-[10px] font-semibold uppercase tracking-[0.14em] text-neutral-500">Prompt généré</p>
                              <pre className="mt-1 max-h-44 overflow-auto whitespace-pre-wrap rounded-md border border-line bg-[#101010] p-2 text-[10px] leading-4 text-neutral-400">
                                {visualState[draft.filename]?.prompt}
                              </pre>
                            </div>
                            <button
                              type="button"
                              onClick={() => void copyIllustrationPrompt(draft.filename)}
                              className="w-full rounded-md border border-line bg-[#101010] px-3 py-2 text-xs font-semibold text-neutral-200 transition hover:border-gold/40"
                            >
                              {visualCopiedKey === draft.filename ? "Prompt copié ✓" : "Copier prompt illustration"}
                            </button>
                            <div className="flex gap-2">
                              <input
                                value={visualInput[draft.filename] ?? visualState[draft.filename]?.file ?? ""}
                                onChange={(event) => setVisualInput((current) => ({ ...current, [draft.filename]: event.target.value }))}
                                placeholder="nom-du-fichier.png (déposé dans static/img ou public/propositions)"
                                className="min-w-0 flex-1 rounded-md border border-line bg-[#101010] px-3 py-2 text-xs text-neutral-100 outline-none focus:border-gold"
                              />
                              <button
                                type="button"
                                onClick={() => addVisualFile(draft.filename)}
                                className="shrink-0 rounded-md border border-gold/40 bg-gold/10 px-3 py-2 text-xs font-semibold text-gold-soft transition hover:bg-gold/20"
                              >
                                Ajouter image générée
                              </button>
                            </div>
                            {visualState[draft.filename]?.file ? <VisualPreview file={visualState[draft.filename]?.file ?? ""} /> : null}
                            <div className="grid grid-cols-3 gap-2">
                              <button
                                type="button"
                                onClick={() => decideVisual(draft.filename, "validee")}
                                className="rounded-md border border-emerald-400/40 bg-emerald-400/10 px-2 py-1.5 text-[11px] font-semibold text-emerald-100 transition hover:bg-emerald-400/20"
                              >
                                ✅ Valider ce visuel
                              </button>
                              <button
                                type="button"
                                onClick={() => decideVisual(draft.filename, "refusee")}
                                className="rounded-md border border-red-400/40 bg-red-400/10 px-2 py-1.5 text-[11px] font-semibold text-red-100 transition hover:bg-red-400/20"
                              >
                                ✕ Refuser ce visuel
                              </button>
                              <button
                                type="button"
                                onClick={() => decideVisual(draft.filename, "aucune")}
                                className="rounded-md border border-line bg-black/20 px-2 py-1.5 text-[11px] font-semibold text-neutral-300 transition hover:border-neutral-500"
                              >
                                Aucun visuel
                              </button>
                            </div>
                          </>
                        )}
                        {visualNotice[draft.filename] && <p className="text-[11px] leading-5 text-neutral-400">{visualNotice[draft.filename]}</p>}
                        {publishInfo[draft.filename]?.publishedId == null && (
                          <button
                            type="button"
                            onClick={() => publishWithoutImage(draft.filename)}
                            className="w-full rounded-md border border-neutral-500/40 bg-neutral-500/10 px-3 py-2 text-xs font-semibold text-neutral-300 transition hover:bg-neutral-500/20"
                          >
                            🚫 Publier sans image
                          </button>
                        )}
                        <p className="text-[10px] leading-4 text-neutral-600">
                          Le dashboard prépare le prompt et reçoit l'image — il ne génère jamais le visuel seul. Droits à vérifier (source, crédit, légende) ;
                          validation humaine obligatoire.
                        </p>
                      </div>
                      {(() => {
                        const info = publishInfo[draft.filename];
                        if (!info) {
                          return (
                            <div className="mt-2 rounded-md border border-line bg-black/15 p-3">
                              <p className="text-xs text-neutral-500">État de publication : chargement…</p>
                            </div>
                          );
                        }
                        if (info.publishedId !== null) {
                          const publishedSlug = info.publishedSlug ?? info.slug;
                          return (
                            <div className="mt-2 rounded-md border border-emerald-400/40 bg-emerald-400/10 p-3">
                              <p className="text-xs font-semibold text-emerald-100">
                                ✅ Publié — id {info.publishedId} · {formatDisplayDate(info.publishedAt) || "date inconnue"}
                              </p>
                              <a
                                href={`http://127.0.0.1:5000/articles/${encodeURIComponent(publishedSlug)}`}
                                target="_blank"
                                rel="noreferrer"
                                className="mt-1 block break-all text-[11px] text-gold-soft underline decoration-gold/40 underline-offset-2"
                              >
                                http://127.0.0.1:5000/articles/{publishedSlug}
                              </a>
                            </div>
                          );
                        }
                        if (!info.ready) {
                          return (
                            <div className="mt-2 rounded-md border border-amber-400/30 bg-amber-400/5 p-3">
                              <p className="text-xs leading-5 text-amber-100/90">
                                Brouillon non prêt pour la publication : le chapo doit être rédigé ([x]) et le texte ne doit plus contenir « à compléter ».
                                Le bloc de publication s'activera ici automatiquement.
                              </p>
                            </div>
                          );
                        }
                        const message = publishMessages[draft.filename];
                        const visualDecision = visualState[draft.filename]?.decision ?? "";
                        const visualDecided = visualDecision === "validee" || visualDecision === "aucune";
                        const dailySelectionComplete = retainedCount >= 3;
                        return (
                          <div className="mt-2 space-y-3 rounded-md border border-gold/30 bg-gold/5 p-3">
                            <p className="text-[11px] font-semibold uppercase tracking-[0.14em] text-gold">Publication locale (localhost:5000)</p>
                            <dl className="grid grid-cols-2 gap-x-3 gap-y-1.5 rounded-md border border-line bg-black/20 p-2 text-[11px]">
                              <div className="col-span-2">
                                <dt className="font-semibold uppercase tracking-[0.12em] text-neutral-500">Titre</dt>
                                <dd className="mt-0.5 text-neutral-200">{subject.title}</dd>
                              </div>
                              <div>
                                <dt className="font-semibold uppercase tracking-[0.12em] text-neutral-500">Rubrique</dt>
                                <dd className="mt-0.5 text-neutral-300">{subject.rubrique}</dd>
                              </div>
                              <div>
                                <dt className="font-semibold uppercase tracking-[0.12em] text-neutral-500">Pays</dt>
                                <dd className="mt-0.5 text-neutral-300">
                                  {(() => {
                                    const watchSubject = watchSubjectForCard(subject);
                                    return watchSubject && watchSubject.countries.length > 0 ? watchSubject.countries.join(", ") : "—";
                                  })()}
                                </dd>
                              </div>
                              <div>
                                <dt className="font-semibold uppercase tracking-[0.12em] text-neutral-500">Sources</dt>
                                <dd className="mt-0.5 text-neutral-300">{subject.sourceState}</dd>
                              </div>
                              <div>
                                <dt className="font-semibold uppercase tracking-[0.12em] text-neutral-500">Statut illustration</dt>
                                <dd className="mt-0.5 text-neutral-300">{visualDecisionLabel(draft.filename)}</dd>
                              </div>
                            </dl>
                            <div>
                              <p className="text-xs font-semibold text-neutral-300">Illustration</p>
                              {info.imageFile ? (
                                <div className="mt-2 space-y-1.5">
                                  <label className="flex items-start gap-2 text-xs text-neutral-200">
                                    <input
                                      type="radio"
                                      className="mt-0.5 accent-[#c9a441]"
                                      checked={publishImageMode[draft.filename] !== "none"}
                                      onChange={() => setPublishImageMode((current) => ({ ...current, [draft.filename]: "proposal" }))}
                                    />
                                    <span>
                                      Image proposée dans le brouillon : <code className="text-gold-soft">{info.imageFile}</code>
                                    </span>
                                  </label>
                                  <label className="flex items-start gap-2 text-xs text-neutral-300">
                                    <input
                                      type="radio"
                                      className="mt-0.5 accent-[#c9a441]"
                                      checked={publishImageMode[draft.filename] === "none"}
                                      onChange={() => setPublishImageMode((current) => ({ ...current, [draft.filename]: "none" }))}
                                    />
                                    <span>Sans illustration</span>
                                  </label>
                                </div>
                              ) : (
                                <p className="mt-1.5 text-xs text-neutral-500">Aucune illustration proposée dans le brouillon — publication possible sans image.</p>
                              )}
                            </div>
                            {visualDecided ? (
                              <div className="space-y-3">
                                <div>
                                  <p className="text-xs font-semibold text-neutral-300">Rédacteur (pseudonyme éditorial)</p>
                                  <select
                                    value={authorByKey[draft.filename] ?? ""}
                                    onChange={(event) => setAuthorByKey((current) => ({ ...current, [draft.filename]: event.target.value }))}
                                    className="mt-1 w-full rounded-md border border-line bg-[#101010] px-3 py-2 text-sm text-neutral-100 outline-none focus:border-gold"
                                  >
                                    <option value="">— Choisir le rédacteur —</option>
                                    {EDITORIAL_AUTHORS.map((author) => (
                                      <option key={author} value={author}>
                                        {author}
                                      </option>
                                    ))}
                                  </select>
                                  <p className="mt-1 text-[10px] leading-4 text-neutral-600">
                                    Pseudonyme éditorial sobre — jamais présenté comme une personne réelle vérifiée.
                                  </p>
                                </div>
                                <p className="text-[10px] leading-4 text-neutral-600">
                                  Ce bouton enregistre ta validation humaine (Pierre) et publie localement — jamais automatique, jamais vers un site distant, les
                                  réseaux, une newsletter, Git ou Obsidian.
                                </p>
                              </div>
                            ) : (
                              <p className="rounded-md border border-amber-400/30 bg-amber-400/5 p-2 text-[11px] leading-5 text-amber-100/90">
                                Visuel non tranché : valider l'illustration ou enregistrer « Aucun visuel » (panneau Illustration ci-dessus) avant la validation
                                humaine de l'article.
                              </p>
                            )}
                            <button
                              type="button"
                              disabled={publishBusy[draft.filename] === true || !visualDecided}
                              onClick={() => void handleValidateAndPublish(draft.filename, pilotDate)}
                              className="w-full rounded-md border border-emerald-400/60 bg-emerald-400/15 px-3 py-2.5 text-sm font-bold text-emerald-50 transition hover:bg-emerald-400/25 disabled:cursor-not-allowed disabled:opacity-40"
                            >
                              {publishBusy[draft.filename] === true
                                ? "Publication en cours…"
                                : "✅ Valider humainement et publier (local)"}
                            </button>
                            {message && (
                              <p className={`text-xs leading-5 ${message.kind === "success" ? "text-emerald-100" : "text-red-100"}`}>
                                {message.kind === "success" ? "✅ " : "⚠️ "}
                                {message.text}
                              </p>
                            )}
                          </div>
                        );
                      })()}
                    </div>
                  )}
                </article>
              );
            })}
          </div>
        </section>

        <section id="archive-journee" className="rounded-lg border border-line bg-panel">
          <div className="border-b border-line bg-[#171717] px-4 py-3">
            <h2 className="font-semibold text-gold-soft">Archivage de la journée</h2>
            <p className="text-sm text-neutral-400">Après publication locale : archiver la production du jour (jamais automatique).</p>
          </div>
          <div className="grid gap-3 p-4 md:grid-cols-3">
            <div className="rounded-md border border-line bg-black/20 p-3">
              <p className="text-[11px] font-semibold uppercase tracking-[0.14em] text-gold">Archive Obsidian (vault)</p>
              <p className="mt-2 break-all text-xs leading-5 text-neutral-300">{archiveInfo?.path ?? "VALEURS_AFRICAINES/01_ACTUALITES/Aujourd'hui en Afrique/"}</p>
              <p className={`mt-1 text-xs font-semibold ${archiveInfo?.present ? "text-emerald-100" : "text-amber-100"}`}>
                {archiveInfo?.present ? `Présente — ${archiveInfo.count} fichier(s)` : "Absente — copier la revue et les brouillons du jour après publication"}
              </p>
            </div>
            <div className="rounded-md border border-line bg-black/20 p-3">
              <p className="text-[11px] font-semibold uppercase tracking-[0.14em] text-gold">Sauvegarde Drive</p>
              <p className="mt-2 break-all text-xs leading-5 text-neutral-300">{dashboard?.driveExport?.path ?? "google-drive-export/"}</p>
              <p className={`mt-1 text-xs font-semibold ${dashboard?.driveExport?.present ? "text-emerald-100" : "text-amber-100"}`}>
                {dashboard?.driveExport?.present ? `Présente — ${dashboard.driveExport.count} fichier(s)` : "Non détectée — vérifier le miroir Drive"}
              </p>
            </div>
            <div className="rounded-md border border-line bg-black/20 p-3">
              <p className="text-[11px] font-semibold uppercase tracking-[0.14em] text-gold">Commit Git</p>
              <p className="mt-2 text-xs leading-5 text-neutral-400">Commit local uniquement sur demande explicite de Pierre (jamais automatique).</p>
              <p className="mt-1 text-xs text-neutral-500">Date cible : {pilotDateLabel || "aujourd'hui"} — après validation finale.</p>
            </div>
          </div>
        </section>

        <section className="rounded-lg border border-gold/25 bg-panel">
          <div className="flex flex-wrap items-start justify-between gap-3 border-b border-line bg-[#171717] px-4 py-3">
            <div>
              <h2 className="font-semibold text-gold-soft">Lecture de la revue du jour</h2>
              <p className="text-sm text-neutral-400">
                {review ? `${formatDatesInText(review.title)}${review.status.length > 0 ? ` — statut : ${review.status.join(" · ")}` : ""}` : "Revue du jour non chargée"}
              </p>
            </div>
            {reviewError && <p className="text-xs leading-5 text-red-100">{reviewError}</p>}
          </div>
          {selectedReviewSubject ? (
            <ReadingPanel
              subject={selectedReviewSubject}
              decision={selectedSubjectId ? (state.subjects[selectedSubjectId]?.decision ?? "A decider") : "A decider"}
              googleDocUrl={subjects.find((subject) => subject.id === selectedSubjectId)?.googleDocUrl}
              draftState={draftState}
              onRetain={markSelectedSubjectRetained}
              onDraft={() => void handleDraft()}
              onClose={() => setSelectedSubjectId(null)}
            />
          ) : (
            <div className="p-4 text-sm leading-6 text-neutral-400">
              Cliquez sur « Lire le sujet complet » sur l'un des trois sujets ci-dessus pour afficher son contenu intégral : titre, pourquoi maintenant, faits
              établis, analyse Valeurs Africaines, incertitudes/hypothèses, sources et décision éditoriale (lecture seule — le fichier Markdown source n'est
              jamais modifié).
            </div>
          )}
        </section>
      </section>
    </main>
  );
}

function Kpi({ icon: Icon, label, value, detail }: { icon: LucideIcon; label: string; value: string; detail: string }) {
  return (
    <article className="rounded-md border border-line bg-panel p-4">
      <div className="flex items-start justify-between gap-3">
        <div>
          <div className="text-2xl font-bold text-gold-soft">{value}</div>
          <div className="mt-1 text-sm font-semibold text-neutral-100">{label}</div>
          <p className="mt-2 text-xs leading-5 text-neutral-400">{detail}</p>
        </div>
        <div className="grid h-10 w-10 place-items-center rounded-md border border-gold/40 bg-gold/10">
          <Icon size={18} className="text-gold" />
        </div>
      </div>
    </article>
  );
}

function Panel({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <section className="rounded-lg border border-line bg-panel">
      <div className="border-b border-line bg-[#171717] px-4 py-3">
        <h2 className="font-semibold text-gold-soft">{title}</h2>
      </div>
      <div className="p-4">{children}</div>
    </section>
  );
}

function Info({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <dt className="text-xs font-semibold uppercase tracking-[0.14em] text-neutral-500">{label}</dt>
      <dd className="mt-1 leading-5 text-neutral-300">{value}</dd>
    </div>
  );
}

function DecisionRows({ rows }: { rows: Array<[string, string]> }) {
  return (
    <div className="space-y-2">
      {rows.map(([label, question]) => (
        <div key={label} className="rounded-md border border-line bg-black/20 p-3">
          <p className="text-sm font-semibold text-gold-soft">{label}</p>
          <p className="mt-1 text-sm leading-5 text-neutral-400">{question}</p>
        </div>
      ))}
    </div>
  );
}

function Task({ icon: Icon, label, status }: { icon: LucideIcon; label: string; status: string }) {
  return (
    <div className="flex items-center justify-between gap-3 rounded-md border border-line bg-black/20 p-3">
      <div className="flex items-center gap-3">
        <Icon size={17} className="text-gold" />
        <span className="text-sm text-neutral-200">{label}</span>
      </div>
      <span className="rounded border border-line bg-[#101010] px-2 py-1 text-xs font-semibold text-neutral-300">{status}</span>
    </div>
  );
}

function ReadingPanel({
  subject,
  decision,
  googleDocUrl,
  draftState,
  onRetain,
  onDraft,
  onClose
}: {
  subject: DailyReviewSubject;
  decision: SubjectDecision;
  googleDocUrl?: string;
  draftState: { status: "idle" | "loading" | "success" | "error"; message: string };
  onRetain: () => void;
  onDraft: () => void;
  onClose: () => void;
}) {
  const retained = decision === "Retenir";
  return (
    <div className="space-y-4 p-4">
      <div className="flex flex-wrap items-start justify-between gap-4">
        <div>
          <p className="text-xs font-semibold uppercase tracking-[0.18em] text-gold">Sujet {subject.index} — {subject.rubric}</p>
          <h3 className="mt-1 text-lg font-semibold text-gold-soft">{subject.title || "Titre non extrait"}</h3>
          <p className="mt-1 text-xs text-neutral-500">Décision du comité : {decision}</p>
        </div>
        <button
          type="button"
          onClick={onClose}
          className="shrink-0 rounded-md border border-line bg-black/20 px-3 py-1.5 text-sm text-neutral-300 transition hover:border-gold"
        >
          Fermer
        </button>
      </div>

      <div className="flex flex-wrap items-center gap-3 rounded-md border border-line bg-black/20 p-3">
        <button
          type="button"
          onClick={onRetain}
          disabled={retained}
          className={`rounded-md border px-4 py-2 text-sm font-semibold transition ${
            retained
              ? "cursor-not-allowed border-emerald-400/40 bg-emerald-400/10 text-emerald-100"
              : "border-gold/40 bg-gold/10 text-gold-soft hover:bg-gold/20"
          }`}
        >
          {retained ? "Sujet retenu" : "Lu et retenu"}
        </button>
        <button
          type="button"
          onClick={onDraft}
          disabled={!retained || draftState.status === "loading"}
          className={`rounded-md border px-4 py-2 text-sm font-semibold transition ${
            retained
              ? "border-gold/40 bg-gold/10 text-gold-soft hover:bg-gold/20"
              : "cursor-not-allowed border-line bg-[#101010] text-neutral-500"
          }`}
        >
          {draftState.status === "loading" ? "Génération…" : googleDocUrl ? "Ouvrir Google Doc" : "Rédiger le brouillon"}
        </button>
        <p className="text-xs leading-5 text-neutral-500">
          {googleDocUrl && retained
            ? "Ouvre le Google Doc lié à ce sujet pour correction et rédaction."
            : retained
            ? "Génère le brouillon Markdown, puis ouvre le fichier local sur le PC pour correction."
            : "Lisez le sujet, cliquez sur « Lu et retenu », puis rédigez le brouillon."}
        </p>
      </div>

      {draftState.status === "success" && (
        <div className="rounded-md border border-emerald-400/40 bg-emerald-400/10 p-3 text-sm text-emerald-100">
          Brouillon créé : <span className="break-all font-semibold">{draftState.message}</span>
        </div>
      )}
      {draftState.status === "error" && (
        <div className="rounded-md border border-red-400/40 bg-red-400/10 p-3 text-sm text-red-100">{draftState.message}</div>
      )}

      <ReadingBlock title="Pourquoi maintenant" body={subject.pourquoisMaintenant} />
      <ReadingBlock title="Faits établis" items={subject.faitsEtablis} />
      <ReadingBlock title="Analyse Valeurs Africaines" body={subject.analyse} />
      <ReadingBlock title="Incertitudes / hypothèses" items={subject.incertitudes} />
      <ReadingBlock title="Sources" items={subject.sources} links />
      <ReadingBlock title="Décision éditoriale" items={subject.decisionEditoriale} />
    </div>
  );
}


const CRITERION_LABELS: Record<string, string> = {
  urgence: "Urgence",
  impactAfricain: "Impact africain",
  adequationLigneVA: "Ligne VA",
  qualiteSources: "Sources",
  potentielAnalyse: "Analyse"
};

function RelevanceBlock({ stars, score, criteria, reasons }: { stars: string; score: number; criteria: Record<string, number>; reasons: string[] }) {
  const category =
    score >= 4
      ? { label: "Prioritaire", tone: "border-emerald-400/40 bg-emerald-400/10 text-emerald-100" }
      : score >= 3
        ? { label: "À discuter", tone: "border-amber-400/40 bg-amber-400/10 text-amber-100" }
        : { label: "Faible / à reporter", tone: "border-line bg-black/20 text-neutral-400" };
  return (
    <div className="mt-3 rounded-md border border-line bg-black/10 p-3">
      <div className="flex flex-wrap items-center gap-3">
        <span className="text-base tracking-wider text-gold-soft">{stars}</span>
        <span className="text-sm font-bold text-gold-soft">{score}/5</span>
        <span className={`rounded border px-2 py-0.5 text-xs font-semibold ${category.tone}`}>{category.label}</span>
      </div>
      <details className="mt-2">
        <summary className="cursor-pointer text-xs text-neutral-500 hover:text-gold-soft">Pourquoi cette note ?</summary>
        <ul className="mt-2 space-y-1 text-xs leading-5 text-neutral-400">
          {reasons.map((reason) => (
            <li key={reason}>• {reason}</li>
          ))}
          <li className="pt-1 text-neutral-500">
            {Object.entries(criteria)
              .map(([key, value]) => `${CRITERION_LABELS[key] ?? key} ${value}/5`)
              .join(" · ")}
          </li>
        </ul>
      </details>
    </div>
  );
}

function ReadingBlock({ title, body, items, links = false }: { title: string; body?: string; items?: string[]; links?: boolean }) {
  return (
    <div className="rounded-md border border-line bg-black/20 p-4">
      <p className="text-xs font-semibold uppercase tracking-[0.18em] text-gold">{title}</p>
      {body ? <p className="mt-2 text-sm leading-6 text-neutral-200">{body}</p> : null}
      {items ? (
        items.length > 0 ? (
          <ul className="mt-2 space-y-1.5 text-sm leading-6 text-neutral-300">
            {items.map((item, index) => (
              <li key={`${title}-${index}`} className="flex gap-2">
                <span className="mt-2 h-1 w-1 shrink-0 rounded-full bg-gold" />
                {links && item.startsWith("http") ? (
                  <a className="break-all text-gold-soft underline decoration-gold/40 underline-offset-2" href={item} target="_blank" rel="noreferrer">
                    {item}
                  </a>
                ) : (
                  <span>{item}</span>
                )}
              </li>
            ))}
          </ul>
        ) : (
          <p className="mt-2 text-sm text-neutral-500">Section vide dans le fichier source.</p>
        )
      ) : null}
    </div>
  );
}

const INLINE_PATTERN = /(\*\*[^*]+\*\*|\[[^\]]+\]\([^)]+\))/g;

function extractImageProposal(content: string): string | null {
  const match = content.match(/^## Image proposée\s*\n([\s\S]*?)(?=^## |\z)/m);
  if (!match) return null;
  const lines = match[1]
    .split("\n")
    .map((line) => line.trim().replace(/^>+\s?/, "").replace(/^\*\*([^*]+)\*\*:\s*/, "• $1 : "))
    .filter((line) => line.length > 0 && !line.startsWith("À générer ou commander"));
  return lines.length > 0 ? lines.join("\n") : null;
}

function ArticleImageProposal({ proposal, filename }: { proposal: string | null; filename: string | null }) {
  const slug = filename
    ? filename
        .replace(/^\d{4}-\d{2}-\d{2}-sujet-\d+-/, "")
        .replace(/\.md$/, "")
    : null;
  const imageSrc = slug ? `/propositions/${encodeURIComponent(slug)}.png` : null;
  const fallbackImageSrc = slug ? `/propositions/${encodeURIComponent(slug)}.svg` : null;
  if (!proposal && !imageSrc) {
    return <p className="mt-1.5 text-xs text-neutral-500">Aucune proposition d'image dans cet article.</p>;
  }
  return (
    <div className="mt-2">
      {imageSrc ? (
        <img
          src={imageSrc}
          alt="Illustration proposée pour l'article"
          className="w-full rounded-md border border-gold/25 bg-black/20"
          onError={(event) => {
            const image = event.currentTarget as HTMLImageElement;
            if (fallbackImageSrc && image.src !== fallbackImageSrc) {
              image.src = fallbackImageSrc;
              return;
            }
            image.style.display = "none";
          }}
        />
      ) : (
        <div className="grid aspect-[16/9] place-items-center rounded-md border border-dashed border-gold/40 bg-gradient-to-br from-gold/15 via-black/20 to-emerald-900/10 text-center">
          <p className="px-4 text-[10px] uppercase leading-5 tracking-[0.18em] text-gold-soft">🖼 Illustration à générer après validation</p>
        </div>
      )}
      {proposal && <pre className="mt-2 whitespace-pre-wrap text-[11px] leading-5 text-neutral-400">{proposal}</pre>}
      <p className="mt-1 text-[10px] text-neutral-600">Proposée automatiquement dès l'écriture de l'article — à valider avec Pierre.</p>
    </div>
  );
}

function VisualPreview({ file }: { file: string }) {
  const flaskSrc = `http://127.0.0.1:5000/static/img/${encodeURIComponent(file)}`;
  const localSrc = `/propositions/${encodeURIComponent(file)}`;
  return (
    <div>
      <img
        src={flaskSrc}
        alt={`Visuel ${file}`}
        className="w-full rounded-md border border-gold/25 bg-black/20"
        onError={(event) => {
          const image = event.currentTarget as HTMLImageElement;
          if (image.src !== localSrc) {
            image.src = localSrc;
            return;
          }
          image.style.display = "none";
        }}
      />
      <p className="mt-1 break-all text-[10px] text-neutral-500">Fichier : {file}</p>
    </div>
  );
}

function renderInline(value: string): ReactNode[] {
  const parts = value.split(INLINE_PATTERN).filter(Boolean);
  return parts.map((part, index) => {
    const bold = part.match(/^\*\*([^*]+)\*\*$/);
    if (bold) return <strong key={index} className="font-semibold text-neutral-100">{bold[1]}</strong>;
    const link = part.match(/^\[([^\]]+)\]\(([^)]+)\)$/);
    if (link) {
      return (
        <a key={index} className="break-all text-gold-soft underline decoration-gold/40 underline-offset-2" href={link[2]} target="_blank" rel="noreferrer">
          {link[1]}
        </a>
      );
    }
    return <span key={index}>{part}</span>;
  });
}

function stripFrontmatter(text: string): string {
  const lines = text.split("\n");
  if (lines[0]?.trim() !== "---") return text;
  const end = lines.findIndex((line, index) => index > 0 && line.trim() === "---");
  return end > 0 ? lines.slice(end + 1).join("\n") : text;
}

function MarkdownText({ text }: { text: string }) {
  const lines = stripFrontmatter(text).split("\n");
  const out: ReactNode[] = [];
  let i = 0;
  let key = 0;
  while (i < lines.length) {
    const trimmed = lines[i].trim();
    if (!trimmed || /^[-*_]{3,}$/.test(trimmed)) {
      i += 1;
      continue;
    }
    const heading = trimmed.match(/^(#{1,3})\s+(.*)$/);
    if (heading) {
      const level = heading[1].length;
      const Tag = level === 1 ? "h1" : level === 2 ? "h2" : "h3";
      const className =
        level === 1
          ? "mt-1 text-xl font-bold text-gold-soft"
          : level === 2
            ? "mt-4 text-base font-bold text-gold-soft"
            : "mt-3 text-sm font-bold text-neutral-100";
      out.push(<Tag key={key++} className={className}>{renderInline(heading[2])}</Tag>);
      i += 1;
      continue;
    }
    const listItem = trimmed.match(/^[-*]\s+(\[[ xX]\]\s+)?(.*)$/);
    if (listItem) {
      const items: Array<{ checked: boolean | null; text: ReactNode[] }> = [];
      while (i < lines.length) {
        const match = lines[i].trim().match(/^[-*]\s+(\[[ xX]\]\s+)?(.*)$/);
        if (!match) break;
        const checked = match[1] ? /\[[xX]\]/.test(match[1]) : null;
        items.push({ checked, text: renderInline(match[2]) });
        i += 1;
      }
      out.push(
        <ul key={key++} className="mt-2 space-y-1.5 pl-1">
          {items.map((item, index) => (
            <li key={`${key}-${index}`} className="flex items-start gap-2">
              <span className="mt-1.5 h-1 w-1 shrink-0 rounded-full bg-gold" />
              {item.checked === null ? (
                <span>{item.text}</span>
              ) : (
                <span className={item.checked ? "text-emerald-200" : "text-neutral-500"}>
                  {item.checked ? "☑" : "☐"} {item.text}
                </span>
              )}
            </li>
          ))}
        </ul>
      );
      continue;
    }
    if (trimmed.startsWith(">")) {
      const quote: string[] = [];
      while (i < lines.length && lines[i].trim().startsWith(">")) {
        quote.push(lines[i].trim().replace(/^>\s?/, ""));
        i += 1;
      }
      out.push(
        <blockquote key={key++} className="mt-2 border-l-2 border-gold/50 pl-3 text-neutral-400">
          {quote.map((line, index) => (
            <p key={`${key}-${index}`}>{renderInline(line)}</p>
          ))}
        </blockquote>
      );
      continue;
    }
    const paragraph: string[] = [];
    while (i < lines.length && lines[i].trim() !== "") {
      paragraph.push(lines[i].trim());
      i += 1;
    }
    out.push(<p key={key++} className="mt-2 text-[13px] leading-6">{renderInline(paragraph.join(" "))}</p>);
  }
  return <div className="max-h-[520px] space-y-1 overflow-auto pr-1">{out}</div>;
}
