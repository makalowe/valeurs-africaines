import { getMagazineArticles } from "@/lib/magazineContent";
import { formatDisplayDate } from "@/lib/dateDisplay";

const RUBRIQUE_COLORS: Record<string, string> = {
  "Actualité stratégique": "text-red-900",
  "Economie, securite et diplomatie": "text-blue-900",
  "Innovation, gouvernance, culture et medias": "text-green-900"
};

export default async function MagazinePage() {
  const { articles, archiveNames } = await getMagazineArticles();
  const lead = articles.find((article) => article.date === "2026-09-02") ?? articles[0] ?? null;
  const others = articles.filter((article) => article.id !== lead?.id);

  const rubriques = Array.from(new Set(articles.map((article) => article.rubrique)));

  return (
    <main className="mx-auto max-w-6xl bg-[#faf6ec] px-6 py-8 font-serif text-neutral-900">
      {/* Masthead */}
      <header className="border-b-4 border-t-4 border-neutral-900 py-6 text-center">
        <p className="text-[11px] uppercase tracking-[0.5em] text-neutral-600">Le magazine panafricain de géopolitique & de souveraineté narrative</p>
        <h1 className="mt-3 text-6xl font-black uppercase tracking-[0.12em]">Valeurs Africaines</h1>
        <div className="mx-auto mt-4 flex max-w-3xl items-center justify-between border-y border-neutral-400 py-1.5 text-[11px] uppercase tracking-[0.25em] text-neutral-700">
          <span>Édition du mardi 2 septembre 2026</span>
          <span>N° 1 — Maquette de la une</span>
          <span>Panafricain</span>
        </div>
      </header>

      {/* À la une */}
      {lead && (
        <section className="grid gap-8 border-b border-neutral-900 py-8 lg:grid-cols-[1.2fr_1fr]">
          <article>
            <p className={`text-xs font-bold uppercase tracking-[0.3em] ${RUBRIQUE_COLORS[lead.rubrique] ?? "text-neutral-800"}`}>{lead.rubrique}</p>
            <h2 className="mt-3 text-4xl font-black leading-tight">{lead.title}</h2>
            <p className="mt-4 text-sm leading-7 text-neutral-800 first-letter:float-left first-letter:mr-2 first-letter:text-6xl first-letter:font-black first-letter:leading-none">
              {lead.intro}
            </p>
            <div className="mt-5 flex flex-wrap items-center gap-3 text-[11px] uppercase tracking-widest text-neutral-600">
              <span>Publié le {formatDisplayDate(lead.date)}</span>
              <span>·</span>
              <span>{lead.statusLabel}</span>
              <span>·</span>
              <span>Dossier {lead.sourceFile.split("-sujet-")[1]?.split("-")[0] ?? "hebdo"}</span>
            </div>
          </article>
          <PhotoPlaceholder caption={`Illustration « ${lead.title.slice(0, 42)}… » — photo à venir (VISUELS-PROPOSES/)`} tall />
        </section>
      )}

      {/* Rubriques en colonnes */}
      <section className="grid gap-8 py-8 lg:grid-cols-3">
        {rubriques.map((rubrique) => {
          const items = others.filter((article) => article.rubrique === rubrique);
          if (items.length === 0) return null;
          return (
            <div key={rubrique} className="border-neutral-900 lg:border-r lg:pr-6 last:border-r-0">
              <h3 className={`border-b-2 border-neutral-900 pb-2 text-xs font-black uppercase tracking-[0.3em] ${RUBRIQUE_COLORS[rubrique] ?? "text-neutral-800"}`}>
                {rubrique}
              </h3>
              <div className="mt-4 space-y-5">
                {items.map((article) => (
                  <article key={article.id}>
                    <PhotoPlaceholder caption="Photo à venir" />
                    <h4 className="mt-2 text-lg font-bold leading-snug">{article.title}</h4>
                    <p className="mt-1.5 text-[13px] leading-6 text-neutral-700">{article.intro.slice(0, 180)}</p>
                    <p className="mt-2 text-[10px] uppercase tracking-widest text-neutral-500">Le {formatDisplayDate(article.date)} · {article.statusLabel}</p>
                  </article>
                ))}
              </div>
            </div>
          );
        })}
      </section>

      {/* Encart revue quotidienne */}
      <section className="border-y-4 border-neutral-900 py-6">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <h3 className="text-2xl font-black uppercase">Aujourd&apos;hui en Afrique</h3>
            <p className="mt-1 text-sm text-neutral-700">La revue quotidienne du magazine : 3 sujets analysés chaque matin, validés humainement.</p>
          </div>
          <div className="text-right text-xs uppercase tracking-widest text-neutral-600">
            {archiveNames.length > 0 ? (
              <>
                <p>Archives Obsidian :</p>
                {archiveNames.slice(0, 3).map((name) => <p key={name} className="mt-1">{name.replace(/\.md$/, "")}</p>)}
              </>
            ) : (
              <p>Aucune revue archivée</p>
            )}
          </div>
        </div>
      </section>

      <footer className="py-6 text-center text-[11px] leading-5 text-neutral-500">
        <p>
          Maquette de la une du site public — contenus réels issus des dossiers Valeurs Africaines (brouillons 02-EDITION-HEBDOMADAIRE). Aucune publication
          automatique : les articles paraîtront après validation humaine.
        </p>
        <p className="mt-1">Valeurs Africaines · souveraineté narrative · {articles.length} article(s) disponibles · photos en attente</p>
      </footer>
    </main>
  );
}

function PhotoPlaceholder({ caption, tall = false }: { caption: string; tall?: boolean }) {
  return (
    <figure className={`grid place-items-center border border-neutral-400 bg-neutral-200/60 text-center ${tall ? "aspect-[4/3]" : "aspect-[16/9]"}`}>
      <figcaption className="px-4 text-[10px] uppercase leading-5 tracking-[0.2em] text-neutral-500">📷 {caption}</figcaption>
    </figure>
  );
}
