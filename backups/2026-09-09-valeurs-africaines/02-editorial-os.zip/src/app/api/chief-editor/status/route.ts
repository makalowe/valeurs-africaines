import { NextResponse } from "next/server";
import { runChiefStatusCommand } from "@/lib/chiefEditorialOfficer";

export async function GET() {
  try {
    const status = await runChiefStatusCommand();
    return NextResponse.json(status);
  } catch (error) {
    console.error("[chief-editor] Unable to build status.", error);
    return NextResponse.json({ error: "Unable to build chief editor status." }, { status: 500 });
  }
}
