import { NextRequest, NextResponse } from "next/server";
import { listDayArticles, publishDraftToStore, siteUrl } from "@/lib/siteStore";

export const dynamic = "force-dynamic";

const DATE_PATTERN = /^\d{4}-\d{2}-\d{2}$/;
const FILENAME_PATTERN = /^\d{4}-\d{2}-\d{2}-(?:sujet-\d+-)?[a-z0-9-]+\.md$/;

/** État de publication des brouillons du jour (croisé avec data_store.json du site Flask). Sans date : résumé du store. */
export async function GET(request: NextRequest) {
  const date = request.nextUrl.searchParams.get("date");
  if (date === null) {
    try {
      const { readSiteStoreSummary } = await import("@/lib/siteStore");
      const summary = await readSiteStoreSummary();
      return NextResponse.json({ ok: true, summary });
    } catch (error) {
      return NextResponse.json(
        { ok: false, error: error instanceof Error ? error.message : "Erreur de lecture du store." },
        { status: 500 }
      );
    }
  }
  if (!DATE_PATTERN.test(date)) {
    return NextResponse.json({ ok: false, error: "Date invalide (format AAAA-MM-JJ)." }, { status: 400 });
  }
  try {
    const articles = await listDayArticles(date);
    return NextResponse.json({ ok: true, date, articles });
  } catch (error) {
    return NextResponse.json(
      { ok: false, error: error instanceof Error ? error.message : "Erreur de lecture de l'état de publication." },
      { status: 500 }
    );
  }
}

/**
 * Publie localement un brouillon validé dans data_store.json (site Flask).
 * Publication unitaire : chaque article est publié individuellement dès qu'il est
 * prêt, visuel tranché et validé humainement — sans attendre les 3 sujets du jour.
 * Garde-fous conservés : validation humaine explicite (humanConfirmed), brouillon
 * prêt (chapo rédigé, pas de « à compléter »), slug unique, backup préalable.
 */
export async function POST(request: NextRequest) {
  let body: {
    date?: unknown;
    filename?: unknown;
    author?: unknown;
    image?: unknown;
    visualDecision?: unknown;
    visualFile?: unknown;
    humanConfirmed?: unknown;
  } = {};
  try {
    body = (await request.json()) as typeof body;
  } catch {
    return NextResponse.json({ ok: false, error: "Corps JSON invalide." }, { status: 400 });
  }
  const date = typeof body.date === "string" ? body.date : "";
  const filename = typeof body.filename === "string" ? body.filename : "";
  if (!DATE_PATTERN.test(date)) return NextResponse.json({ ok: false, error: "Date invalide (format AAAA-MM-JJ)." }, { status: 400 });
  if (!FILENAME_PATTERN.test(filename)) return NextResponse.json({ ok: false, error: "Nom de brouillon invalide." }, { status: 400 });
  try {
    const result = await publishDraftToStore({
      date,
      filename,
      author: typeof body.author === "string" ? body.author : "",
      image: typeof body.image === "string" ? body.image : "",
      visualDecision: typeof body.visualDecision === "string" ? body.visualDecision : "",
      visualFile: typeof body.visualFile === "string" ? body.visualFile : "",
      humanConfirmed: body.humanConfirmed === true
    });
    return NextResponse.json({ ok: true, ...result, url: siteUrl(result.slug) });
  } catch (error) {
    const message = error instanceof Error ? error.message : "Erreur inconnue lors de la publication.";
    const status = message.includes("déjà publié") ? 409 : 400;
    return NextResponse.json({ ok: false, error: message }, { status });
  }
}
