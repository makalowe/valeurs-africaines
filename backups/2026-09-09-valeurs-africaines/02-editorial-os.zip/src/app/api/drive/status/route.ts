import { NextResponse } from "next/server";

export const dynamic = "force-dynamic";

export async function GET() {
  const hasOAuth = Boolean(process.env.GOOGLE_CLIENT_ID && process.env.GOOGLE_CLIENT_SECRET && process.env.GOOGLE_REFRESH_TOKEN);
  const hasServiceAccount = Boolean(process.env.GOOGLE_SERVICE_ACCOUNT_EMAIL && process.env.GOOGLE_PRIVATE_KEY);
  const hasRootFolder = Boolean(process.env.GOOGLE_DRIVE_ROOT_FOLDER_ID);
  const missing: string[] = [];
  if (!hasOAuth && !hasServiceAccount) {
    missing.push("GOOGLE_CLIENT_ID + GOOGLE_CLIENT_SECRET + GOOGLE_REFRESH_TOKEN (OAuth) ou compte de service");
  }
  if (!hasRootFolder) missing.push("GOOGLE_DRIVE_ROOT_FOLDER_ID");

  return NextResponse.json({
    configured: missing.length === 0,
    method: hasOAuth ? "OAuth (refresh token)" : hasServiceAccount ? "compte de service" : "aucune",
    missing,
    rootFolderId: hasRootFolder ? `${process.env.GOOGLE_DRIVE_ROOT_FOLDER_ID!.slice(0, 8)}…` : null,
    archiveMode: process.env.GOOGLE_DRIVE_ARCHIVE_MODE ?? "folder|year-month",
    createDocs: process.env.GOOGLE_DRIVE_CREATE_GOOGLE_DOCS === "true"
  });
}
