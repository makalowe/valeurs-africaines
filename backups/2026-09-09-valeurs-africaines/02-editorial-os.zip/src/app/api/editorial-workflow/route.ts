import { NextResponse } from "next/server";
import { mkdir, readFile, writeFile } from "node:fs/promises";
import path from "node:path";
import type { EditorialWorkflowState, SubjectDecision, VisualDecision, VisualWorkflowState, WorkflowStatus } from "@/lib/editorialWorkflowState";

export const dynamic = "force-dynamic";

const DATA_DIR = path.join(process.cwd(), "data");
const DATA_FILE = path.join(DATA_DIR, "editorial-workflow.json");

const WORKFLOWS: WorkflowStatus[] = ["Idees", "Selection", "Redaction", "Revision", "Validation", "Pret a publier", "Publie", "Archive"];
const DECISIONS: SubjectDecision[] = ["A decider", "Retenir", "Reporter", "Abandonner"];
const VISUAL_DECISIONS: VisualDecision[] = ["", "demandee", "recue", "validee", "refusee", "aucune"];

const DEFAULT_STATE: EditorialWorkflowState = {
  workflow: "Validation",
  rhythm: "Quotidien",
  decisions: {},
  humanValidation: {},
  updatedAt: null,
  visuals: {}
};

async function readState(): Promise<EditorialWorkflowState> {
  try {
    const raw = await readFile(DATA_FILE, "utf-8");
    return { ...DEFAULT_STATE, ...(JSON.parse(raw) as Partial<EditorialWorkflowState>) };
  } catch {
    return { ...DEFAULT_STATE };
  }
}

async function persistState(state: EditorialWorkflowState): Promise<void> {
  await mkdir(DATA_DIR, { recursive: true });
  await writeFile(DATA_FILE, JSON.stringify(state, null, 2), "utf-8");
}

function sanitizeState(body: unknown): EditorialWorkflowState | null {
  if (typeof body !== "object" || body === null) return null;
  const candidate = body as Record<string, unknown>;
  const workflow = WORKFLOWS.includes(candidate.workflow as WorkflowStatus) ? (candidate.workflow as WorkflowStatus) : DEFAULT_STATE.workflow;
  const rhythm = candidate.rhythm === "Hebdomadaire" ? "Hebdomadaire" : "Quotidien";
  const decisions: Record<string, SubjectDecision> = {};
  if (candidate.decisions !== null && typeof candidate.decisions === "object") {
    for (const [id, value] of Object.entries(candidate.decisions as Record<string, unknown>)) {
      if (DECISIONS.includes(value as SubjectDecision)) decisions[id] = value as SubjectDecision;
    }
  }
  const humanValidation: Record<string, boolean> = {};
  if (candidate.humanValidation !== null && typeof candidate.humanValidation === "object") {
    for (const [key, value] of Object.entries(candidate.humanValidation as Record<string, unknown>)) {
      humanValidation[key] = Boolean(value);
    }
  }
  const updatedAt = typeof candidate.updatedAt === "string" ? candidate.updatedAt : new Date().toISOString();
  const visuals: Record<string, VisualWorkflowState> = {};
  if (candidate.visuals !== null && typeof candidate.visuals === "object") {
    for (const [filename, value] of Object.entries(candidate.visuals as Record<string, unknown>)) {
      if (typeof value !== "object" || value === null) continue;
      const visual = value as Record<string, unknown>;
      const decision = VISUAL_DECISIONS.includes(visual.decision as VisualDecision) ? (visual.decision as VisualDecision) : "";
      const kind = typeof visual.kind === "string" ? visual.kind.slice(0, 80) : "";
      const file = typeof visual.file === "string" ? visual.file.slice(0, 240) : "";
      const prompt = typeof visual.prompt === "string" ? visual.prompt.slice(0, 12000) : "";
      const visualUpdatedAt = typeof visual.updatedAt === "string" ? visual.updatedAt : updatedAt;
      visuals[filename] = { decision, kind, file, prompt, updatedAt: visualUpdatedAt };
    }
  }
  return { workflow, rhythm, decisions, humanValidation, updatedAt, visuals };
}

export async function GET() {
  try {
    const state = await readState();
    return NextResponse.json(state);
  } catch (error) {
    console.error("[editorial-workflow] Failed to read state.", error);
    return NextResponse.json({ error: "Unable to read editorial workflow state." }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json().catch(() => null);
    const next = sanitizeState(body);
    if (!next) {
      return NextResponse.json({ error: "Invalid payload." }, { status: 400 });
    }
    await persistState(next);
    return NextResponse.json(next);
  } catch (error) {
    console.error("[editorial-workflow] Failed to persist state.", error);
    return NextResponse.json({ error: "Unable to persist editorial workflow state." }, { status: 500 });
  }
}
