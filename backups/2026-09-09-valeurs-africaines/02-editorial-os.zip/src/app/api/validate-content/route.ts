import { NextResponse } from "next/server";
import {
  getPlanningRowById,
  updatePlanningHumanValidation,
  updatePlanningStatus
} from "@/lib/googleSheets";

type ValidationDecision = "approved" | "correction";

type ValidationPayload = {
  editorialId?: unknown;
  decision?: unknown;
};

function isValidationDecision(value: unknown): value is ValidationDecision {
  return value === "approved" || value === "correction";
}

function isYes(value?: string): boolean {
  return value?.trim().toLowerCase() === "oui";
}

function getVisualValidationError(row: NonNullable<Awaited<ReturnType<typeof getPlanningRowById>>>): string | null {
  if (!isYes(row.visuel_propose)) {
    return "Validation finale impossible: au moins trois propositions visuelles doivent d'abord être présentées au rédacteur.";
  }

  if (!row.visuel_choisi?.trim() || !row.type_visuel?.trim()) {
    return "Validation finale impossible: le visuel choisi ou la décision 'aucun visuel' doit être enregistré dans les métadonnées.";
  }

  if (!row.date_selection?.trim()) {
    return "Validation finale impossible: la date de sélection visuelle doit être enregistrée.";
  }

  if (row.type_visuel !== "aucun" && !row.prompt_visuel?.trim()) {
    return "Validation finale impossible: le prompt du visuel retenu doit être enregistré.";
  }

  if (row.type_visuel === "photo" && !isYes(row.droits_visuels_verifies)) {
    return "Validation finale impossible: les droits de la photo doivent être vérifiés avant validation.";
  }

  if (!isYes(row.validation_visuelle_humaine)) {
    return "Validation finale impossible: la validation visuelle humaine est obligatoire.";
  }

  return null;
}

export async function POST(request: Request) {
  let payload: ValidationPayload;

  try {
    payload = (await request.json()) as ValidationPayload;
  } catch {
    return NextResponse.json({ error: "Invalid JSON payload." }, { status: 400 });
  }

  if (typeof payload.editorialId !== "string" || !payload.editorialId.trim()) {
    return NextResponse.json({ error: "editorialId is required." }, { status: 400 });
  }

  if (!isValidationDecision(payload.decision)) {
    return NextResponse.json({ error: "decision must be approved or correction." }, { status: 400 });
  }

  const editorialId = payload.editorialId.trim();

  try {
    console.info(`[validation] Decision for ${editorialId}: ${payload.decision}`);
    const existingRow = await getPlanningRowById(editorialId);

    if (!existingRow) {
      return NextResponse.json({ error: `Planning row not found: ${editorialId}` }, { status: 404 });
    }

    if (payload.decision === "correction") {
      const row = await updatePlanningStatus(editorialId, "À corriger");
      console.info(`[validation] Row ${editorialId} marked as À corriger.`);
      return NextResponse.json({ row });
    }

    const visualError = getVisualValidationError(existingRow);
    if (visualError) {
      return NextResponse.json({ error: visualError }, { status: 409 });
    }

    await updatePlanningHumanValidation(editorialId, "Oui");
    const row = await updatePlanningStatus(editorialId, "Validé");
    console.info(`[validation] Row ${editorialId} approved by human validation.`);

    return NextResponse.json({ row });
  } catch (error) {
    console.error(`[validation] Failed to validate ${editorialId}.`, error);
    return NextResponse.json({ error: "Unable to validate content." }, { status: 500 });
  }
}
