import { NextResponse } from "next/server";
import { getDashboardData } from "@/lib/dashboard";

export async function GET() {
  try {
    console.info("[dashboard] Reading dashboard data.");
    const data = await getDashboardData();

    return NextResponse.json({
      total: data.stats.total,
      validation: data.stats.validation,
      archives: data.stats.archives,
      en_retard: data.stats.en_retard,
      haute_priorite: data.stats.haute_priorite,
      source: data.isMock ? "mock" : "live",
      data
    });
  } catch (error) {
    console.error("[dashboard] Failed to read dashboard data.", error);
    return NextResponse.json({ error: "Unable to read dashboard data." }, { status: 500 });
  }
}
