import { NextResponse } from "next/server";
import { generateThinkTankDraft, type ThinkTankInput } from "@/lib/thinkTank";

type Payload = {
  type?: unknown;
  sujet?: unknown;
  pays?: unknown;
  acteurs?: unknown;
  themes?: unknown;
  horizon?: unknown;
};

function parseStringArray(value: unknown): string[] {
  if (Array.isArray(value)) return value.filter((item): item is string => typeof item === "string");
  if (typeof value === "string") return value.split(/[,;\n]/).map((item) => item.trim()).filter(Boolean);
  return [];
}

function parsePayload(payload: Payload): ThinkTankInput {
  return {
    type: typeof payload.type === "string" ? payload.type : "observatoire-souverainete",
    sujet: typeof payload.sujet === "string" ? payload.sujet : "",
    pays: parseStringArray(payload.pays),
    acteurs: parseStringArray(payload.acteurs),
    themes: parseStringArray(payload.themes),
    horizon: typeof payload.horizon === "string" ? payload.horizon : ""
  };
}

export async function POST(request: Request) {
  let payload: Payload;

  try {
    payload = (await request.json()) as Payload;
  } catch {
    return NextResponse.json({ error: "Invalid JSON payload." }, { status: 400 });
  }

  const input = parsePayload(payload);

  if (!input.sujet.trim()) {
    return NextResponse.json({ error: "Le sujet est obligatoire." }, { status: 400 });
  }

  try {
    console.info(`[think-tank] Draft generation request: ${input.type} - ${input.sujet}`);
    return NextResponse.json(generateThinkTankDraft(input));
  } catch (error) {
    console.error("[think-tank] Failed to generate draft.", error);
    return NextResponse.json({ error: "Unable to generate think tank draft." }, { status: 500 });
  }
}
