import { NextResponse } from "next/server";
import { updatePlanningVisualMetadata } from "@/lib/googleSheets";
import { attachVisualToContent, type VisualProposalType } from "@/lib/visualProposals";

type VisualChoicePayload = {
  editorialId?: unknown;
  visualId?: unknown;
  type?: unknown;
  prompt_visuel?: unknown;
  droits_visuels_verifies?: unknown;
  validation_visuelle_humaine?: unknown;
};

function isVisualType(value: unknown): value is VisualProposalType | "aucun" {
  return value === "photo" || value === "illustration" || value === "diagramme" || value === "aucun";
}

export async function POST(request: Request) {
  let payload: VisualChoicePayload;

  try {
    payload = (await request.json()) as VisualChoicePayload;
  } catch {
    return NextResponse.json({ error: "Invalid JSON payload." }, { status: 400 });
  }

  if (typeof payload.editorialId !== "string" || !payload.editorialId.trim()) {
    return NextResponse.json({ error: "editorialId is required." }, { status: 400 });
  }

  if (typeof payload.visualId !== "string" || !payload.visualId.trim()) {
    return NextResponse.json({ error: "visualId is required." }, { status: 400 });
  }

  if (!isVisualType(payload.type)) {
    return NextResponse.json({ error: "type must be photo, illustration, diagramme or aucun." }, { status: 400 });
  }

  try {
    const attached = attachVisualToContent({
      editorialId: payload.editorialId.trim(),
      visualId: payload.visualId.trim(),
      type: payload.type,
      prompt_visuel: typeof payload.prompt_visuel === "string" ? payload.prompt_visuel : "",
      droits_visuels_verifies: payload.droits_visuels_verifies === true,
      validation_visuelle_humaine: payload.validation_visuelle_humaine === true
    });

    console.info(`[visual-proposals] Visual choice for ${attached.editorialId}: ${attached.type_visuel}/${attached.visuel_choisi}.`);
    const row = await updatePlanningVisualMetadata(attached.editorialId, {
      visuel_propose: "Oui",
      visuel_choisi: attached.visuel_choisi,
      type_visuel: attached.type_visuel,
      prompt_visuel: attached.prompt_visuel,
      date_selection: attached.date_selection,
      droits_visuels_verifies: attached.droits_visuels_verifies ? "Oui" : "Non",
      validation_visuelle_humaine: attached.validation_visuelle_humaine ? "Oui" : "Non"
    });

    return NextResponse.json({ row, visual: attached });
  } catch (error) {
    const message = error instanceof Error ? error.message : "Unable to attach visual choice.";
    console.error("[visual-proposals] Failed to attach visual choice.", error);
    return NextResponse.json({ error: message }, { status: 400 });
  }
}
