import { NextResponse } from "next/server";
import { getPlanningRowById } from "@/lib/googleSheets";
import { generateVisualProposals } from "@/lib/visualProposals";

type GenerateVisualProposalsInput = {
  editorialId?: string;
};

export async function POST(request: Request) {
  try {
    const body = (await request.json()) as GenerateVisualProposalsInput;
    const editorialId = body.editorialId?.trim();

    if (!editorialId) {
      return NextResponse.json({ error: "editorialId is required." }, { status: 400 });
    }

    console.info(`[visual-proposals] Generating visual proposals for ${editorialId}.`);
    const row = await getPlanningRowById(editorialId);

    if (!row) {
      return NextResponse.json({ error: `Planning row not found: ${editorialId}` }, { status: 404 });
    }

    return NextResponse.json(generateVisualProposals(row));
  } catch (error) {
    console.error("[visual-proposals] Failed to generate visual proposals.", error);
    return NextResponse.json({ error: "Unable to generate visual proposals." }, { status: 500 });
  }
}
