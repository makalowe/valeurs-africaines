import { NextResponse } from "next/server";
import { generateVisual, type VisualInput } from "@/lib/visualGenerator";

type Payload = {
  type?: unknown;
  titre?: unknown;
  contenu?: unknown;
  donnees?: unknown;
};

function parsePayload(payload: Payload): VisualInput {
  return {
    type: typeof payload.type === "string" ? payload.type : "diagramme_strategique",
    titre: typeof payload.titre === "string" ? payload.titre : "",
    contenu: typeof payload.contenu === "string" ? payload.contenu : "",
    donnees: isRecord(payload.donnees) ? payload.donnees : {}
  };
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

export async function POST(request: Request) {
  let payload: Payload;

  try {
    payload = (await request.json()) as Payload;
  } catch {
    return NextResponse.json({ error: "Invalid JSON payload." }, { status: 400 });
  }

  const input = parsePayload(payload);

  if (!input.titre.trim() || !input.contenu.trim()) {
    return NextResponse.json({ error: "Le titre et le contenu sont obligatoires." }, { status: 400 });
  }

  try {
    console.info(`[visuals] Generation request: ${input.type} - ${input.titre}`);
    const visual = generateVisual(input);
    return NextResponse.json({ visual });
  } catch (error) {
    console.error("[visuals] Failed to generate visual.", error);
    return NextResponse.json({ error: "Unable to generate visual." }, { status: 500 });
  }
}
