import { spawn } from "node:child_process";
import path from "node:path";
import { NextResponse } from "next/server";
import { DRAFTS_DIR } from "@/lib/draftArticle";

export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  try {
    const body = await request.json().catch(() => null);
    const filePath = typeof body?.filePath === "string" ? body.filePath : "";
    if (!filePath) {
      return NextResponse.json({ error: "filePath requis." }, { status: 400 });
    }

    const resolvedFile = path.resolve(filePath);
    const draftsRoot = path.resolve(DRAFTS_DIR);
    if (!resolvedFile.startsWith(`${draftsRoot}${path.sep}`)) {
      return NextResponse.json({ error: "Ouverture refusee : fichier hors dossier Brouillons." }, { status: 403 });
    }

    const child = spawn("cmd.exe", ["/c", "start", "", resolvedFile], {
      detached: true,
      stdio: "ignore",
      windowsHide: true
    });
    child.unref();

    return NextResponse.json({ ok: true, filePath: resolvedFile });
  } catch (error) {
    console.error("[open-local-file] Failed to open local file.", error);
    const message = error instanceof Error ? error.message : "Unknown error";
    return NextResponse.json({ error: `Impossible d'ouvrir le fichier : ${message}` }, { status: 500 });
  }
}
