import { NextResponse } from "next/server";
import { buildAfrica2030Analysis } from "@/lib/africa2030";

type Payload = {
  titre?: unknown;
  rubrique?: unknown;
  contenu?: unknown;
  pays?: unknown;
  themes?: unknown;
};

function toString(value: unknown): string {
  return typeof value === "string" ? value.trim() : "";
}

function toStringArray(value: unknown): string[] {
  return Array.isArray(value) ? value.filter((item): item is string => typeof item === "string" && item.trim().length > 0) : [];
}

export async function POST(request: Request) {
  try {
    const payload = (await request.json()) as Payload;
    const titre = toString(payload.titre);
    const contenu = toString(payload.contenu);

    if (!titre && !contenu) {
      return NextResponse.json({ error: "titre or contenu is required." }, { status: 400 });
    }

    console.info("[afrique-2030] Analyzing SDG editorial thread.");
    return NextResponse.json(buildAfrica2030Analysis({
      titre,
      rubrique: toString(payload.rubrique),
      contenu,
      pays: toStringArray(payload.pays),
      themes: toStringArray(payload.themes)
    }));
  } catch (error) {
    console.error("[afrique-2030] Failed to analyze article.", error);
    return NextResponse.json({ error: "Unable to analyze Africa 2030 impact." }, { status: 500 });
  }
}
