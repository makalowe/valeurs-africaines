import { NextResponse } from "next/server";
import { getStrategicDossierCoverage } from "@/lib/strategicDossiers";

export async function GET() {
  try {
    const dossiers = await getStrategicDossierCoverage();
    return NextResponse.json({ dossiers });
  } catch (error) {
    console.error("[strategic-dossiers] Failed to load coverage.", error);
    return NextResponse.json({ error: "Unable to load strategic dossiers." }, { status: 500 });
  }
}
