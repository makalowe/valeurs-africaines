import { NextResponse } from "next/server";
import { getPlanningRowById } from "@/lib/googleSheets";
import {
  generateMultichannelDrafts,
  isHumanValidated,
  type MultichannelChannel
} from "@/lib/multichannel";

type Payload = {
  editorialId?: unknown;
  channels?: unknown;
  sourceContent?: unknown;
  sources?: unknown;
};

const allowedChannels: MultichannelChannel[] = ["linkedin", "x", "newsletter", "instagram"];

function parseChannels(value: unknown): MultichannelChannel[] {
  if (!Array.isArray(value)) return allowedChannels;
  const channels = value.filter((item): item is MultichannelChannel => allowedChannels.includes(item as MultichannelChannel));
  return channels.length > 0 ? channels : allowedChannels;
}

function parseSources(value: unknown): string[] {
  if (Array.isArray(value)) return value.filter((item): item is string => typeof item === "string");
  if (typeof value === "string") return value.split(/[,;\n]/).map((item) => item.trim()).filter(Boolean);
  return [];
}

export async function POST(request: Request) {
  let payload: Payload;

  try {
    payload = (await request.json()) as Payload;
  } catch {
    return NextResponse.json({ error: "Invalid JSON payload." }, { status: 400 });
  }

  if (typeof payload.editorialId !== "string" || !payload.editorialId.trim()) {
    return NextResponse.json({ error: "editorialId is required." }, { status: 400 });
  }

  const editorialId = payload.editorialId.trim();

  try {
    console.info(`[multicanal] Draft generation request for ${editorialId}`);
    const row = await getPlanningRowById(editorialId);

    if (!row) {
      return NextResponse.json({ error: `Planning row not found: ${editorialId}` }, { status: 404 });
    }

    if (!isHumanValidated(row)) {
      return NextResponse.json(
        { error: "Content must be human validated before multichannel preparation." },
        { status: 409 }
      );
    }

    const drafts = generateMultichannelDrafts(
      {
        row,
        sourceContent: typeof payload.sourceContent === "string" ? payload.sourceContent : undefined,
        sources: parseSources(payload.sources)
      },
      parseChannels(payload.channels)
    );

    return NextResponse.json({
      linkedin: drafts.linkedin,
      x: drafts.x,
      newsletter: drafts.newsletter,
      instagram: drafts.instagram,
      markdown: drafts.markdown,
      html: drafts.html,
      sources: drafts.sources,
      validation_humaine_obligatoire: drafts.validation_humaine_obligatoire,
      publication_automatique: drafts.publication_automatique
    });
  } catch (error) {
    console.error(`[multicanal] Failed to generate drafts for ${editorialId}.`, error);
    return NextResponse.json({ error: "Unable to generate multichannel drafts." }, { status: 500 });
  }
}
