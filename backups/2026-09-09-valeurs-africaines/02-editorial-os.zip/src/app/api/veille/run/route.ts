import { mkdir, writeFile } from "node:fs/promises";
import path from "node:path";
import { NextResponse } from "next/server";

export const dynamic = "force-dynamic";

const INBOX_DIR = path.join(process.cwd(), "..", "00-INBOX");

export async function POST(request: Request) {
  try {
    const body = await request.json().catch(() => null);
    const date = typeof body?.date === "string" && /^\d{4}-\d{2}-\d{2}$/.test(body.date) ? body.date : null;
    const prompt = typeof body?.prompt === "string" ? body.prompt : null;
    if (!date || !prompt) {
      return NextResponse.json({ error: "date et prompt requis." }, { status: 400 });
    }
    await mkdir(INBOX_DIR, { recursive: true });
    const requestFile = path.join(INBOX_DIR, `.veille-request-${date}.md`);
    await writeFile(
      requestFile,
      `# Demande de veille — ${date}\n\n> Fichier de déclenchement créé par le bouton « Veille » du poste de pilotage.\n> L'assistant exécute la veille à la prochaine interaction et crée « Veille - ${date}.md ».\n\n${prompt}\n`,
      "utf-8"
    );
    return NextResponse.json({ ok: true, date, requestFile });
  } catch (error) {
    console.error("[veille] Failed to record the watch request.", error);
    const message = error instanceof Error ? error.message : "Unknown error";
    return NextResponse.json({ error: `Impossible d'enregistrer la demande : ${message}` }, { status: 500 });
  }
}
