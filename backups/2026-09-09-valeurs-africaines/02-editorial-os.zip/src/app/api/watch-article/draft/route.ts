import { mkdir, readFile, writeFile } from "node:fs/promises";
import path from "node:path";
import { NextResponse } from "next/server";
import { DRAFTS_DIR } from "@/lib/draftArticle";
import { buildArticleMarkdown, readWatchSubjects, slugifyArticleTitle } from "@/lib/reviewBuilder";

export const dynamic = "force-dynamic";

const WORKFLOW_FILE = path.join(process.cwd(), "data", "editorial-workflow.json");

export async function POST(request: Request) {
  try {
    const body = await request.json().catch(() => null);
    const date = typeof body?.date === "string" && /^\d{4}-\d{2}-\d{2}$/.test(body.date) ? body.date : null;
    const watchIndex = typeof body?.watchIndex === "number" ? body.watchIndex : Number(body?.watchIndex);
    if (!date || !Number.isInteger(watchIndex) || watchIndex < 1) {
      return NextResponse.json({ error: "date et watchIndex requis." }, { status: 400 });
    }

    const rawWorkflow = await readFile(WORKFLOW_FILE, "utf-8").catch(() => null);
    const decisions: Record<string, string> = rawWorkflow ? (JSON.parse(rawWorkflow).decisions ?? {}) : {};
    if (decisions[`veille-${date}-${watchIndex}`] !== "Retenir") {
      return NextResponse.json({ error: "Sujet non retenu : décision « Retenir » requise avant génération." }, { status: 403 });
    }

    const subjects = await readWatchSubjects(date);
    const subject = subjects.find((entry) => entry.index === watchIndex);
    if (!subject) {
      return NextResponse.json({ error: "Sujet introuvable dans la veille du jour." }, { status: 404 });
    }

    const retainedIndexes = Object.entries(decisions)
      .filter(([key, value]) => key.startsWith(`veille-${date}-`) && value === "Retenir")
      .map(([key]) => Number(key.split("-").pop()))
      .filter((index) => Number.isInteger(index))
      .sort((left, right) => left - right);
    const position = Math.max(1, retainedIndexes.indexOf(watchIndex) + 1 || watchIndex);
    const filename = `${date}-sujet-${position}-${slugifyArticleTitle(subject.title)}.md`;
    const filePath = path.join(DRAFTS_DIR, filename);

    await mkdir(DRAFTS_DIR, { recursive: true });
    try {
      await writeFile(filePath, buildArticleMarkdown(date, subject, position), { encoding: "utf-8", flag: "wx" });
    } catch (error) {
      if ((error as { code?: string }).code === "EEXIST") {
        return NextResponse.json({ ok: true, created: false, filename, filePath, title: subject.title });
      }
      throw error;
    }

    return NextResponse.json({ ok: true, created: true, filename, filePath, title: subject.title });
  } catch (error) {
    console.error("[watch-article] Failed to draft article.", error);
    const message = error instanceof Error ? error.message : "Erreur inconnue";
    return NextResponse.json({ error: `Impossible de générer l'article : ${message}` }, { status: 500 });
  }
}
