import { NextResponse } from "next/server";
import { getPlanningRowById, updatePlanningStatus } from "@/lib/googleSheets";
import { createKnowledgeRecord } from "@/lib/knowledgeBase";
import { createKnowledgeEntry } from "@/lib/knowledgeHub";

type ArchivePayload = {
  editorialId?: unknown;
};

function isHumanValidated(value: string): boolean {
  return value.trim().toLowerCase() === "oui";
}

export async function POST(request: Request) {
  let payload: ArchivePayload;

  try {
    payload = (await request.json()) as ArchivePayload;
  } catch {
    return NextResponse.json({ error: "Invalid JSON payload." }, { status: 400 });
  }

  if (typeof payload.editorialId !== "string" || !payload.editorialId.trim()) {
    return NextResponse.json({ error: "editorialId is required." }, { status: 400 });
  }

  const editorialId = payload.editorialId.trim();

  try {
    console.info(`[archive] Archive request for ${editorialId}`);
    const row = await getPlanningRowById(editorialId);

    if (!row) {
      return NextResponse.json({ error: `Planning row not found: ${editorialId}` }, { status: 404 });
    }

    if (!isHumanValidated(row.validation_humaine) && row.statut !== "Validé") {
      console.warn(`[archive] Refused archive for ${editorialId}: content is not human validated.`);
      return NextResponse.json(
        { error: "Content must be human validated before archiving." },
        { status: 409 }
      );
    }

    const record = await createKnowledgeRecord(row);
    const knowledgeEntry = await createKnowledgeEntry(row);
    const updatedRow = await updatePlanningStatus(editorialId, "Archivé");
    console.info(`[archive] Row ${editorialId} archived into knowledge base and Knowledge Hub.`);

    return NextResponse.json({ row: updatedRow, record, knowledgeEntry });
  } catch (error) {
    console.error(`[archive] Failed to archive ${editorialId}.`, error);
    return NextResponse.json({ error: "Unable to archive content." }, { status: 500 });
  }
}
