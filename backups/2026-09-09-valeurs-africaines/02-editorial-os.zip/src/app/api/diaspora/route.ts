import { NextResponse } from "next/server";
import {
  calculateDiasporaInfluenceScore,
  detectDiasporaSignals,
  getDiasporaProfiles,
  identifyStrategicInstitutions,
  mapDiasporaNetworks
} from "@/lib/diasporaObserver";

export async function GET() {
  try {
    const profiles = getDiasporaProfiles();

    return NextResponse.json({
      profiles,
      signals: detectDiasporaSignals(),
      networks: mapDiasporaNetworks(),
      institutions: identifyStrategicInstitutions(),
      scores: profiles.map((profile) => ({
        nom: profile.nom,
        score: calculateDiasporaInfluenceScore(profile)
      })),
      validation_humaine_requise: true,
      publication_automatique: false
    });
  } catch (error) {
    console.error("[diaspora] Unable to load diaspora observer", error);
    return NextResponse.json({ error: "Unable to load diaspora observer" }, { status: 500 });
  }
}
