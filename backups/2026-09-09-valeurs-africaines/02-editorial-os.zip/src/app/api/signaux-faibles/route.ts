import { NextResponse } from "next/server";
import { collectSignals } from "@/lib/signals";

export async function GET() {
  try {
    console.info("[signals] GET /api/signaux-faibles");
    const signals = await collectSignals();
    return NextResponse.json(signals);
  } catch (error) {
    console.error("[signals] Failed to collect weak signals.", error);
    return NextResponse.json({ error: "Unable to collect weak signals." }, { status: 500 });
  }
}

