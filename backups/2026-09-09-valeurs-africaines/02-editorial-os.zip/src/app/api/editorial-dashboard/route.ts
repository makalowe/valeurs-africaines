import { NextResponse } from "next/server";
import { getEditorialDashboardData } from "@/lib/editorialDashboardData";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const data = await getEditorialDashboardData();
    return NextResponse.json({ source: "filesystem", ...data });
  } catch (error) {
    console.error("[editorial-dashboard] Failed to read dashboard data.", error);
    const message = error instanceof Error ? error.message : "Unknown error";
    return NextResponse.json({ error: `Unable to read editorial dashboard data: ${message}` }, { status: 500 });
  }
}
