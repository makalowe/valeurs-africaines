import { readFile, readdir } from "node:fs/promises";
import path from "node:path";
import { NextResponse } from "next/server";
import { readWatchSubjects } from "@/lib/reviewBuilder";

export const dynamic = "force-dynamic";

const VA_ROOT = path.join(process.cwd(), "..");
const DAILY_DIR = path.join(VA_ROOT, "01-ACTUALITE-QUOTIDIENNE", "Aujourd'hui en Afrique");

type Candidate = {
  filePath: string;
  filename: string;
  content: string;
  score: number;
};

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const date = searchParams.get("date") ?? "";
    const index = Number(searchParams.get("index") ?? "0");
    if (!/^\d{4}-\d{2}-\d{2}$/.test(date) || !Number.isInteger(index) || index < 1) {
      return NextResponse.json({ error: "date ou index invalide." }, { status: 400 });
    }

    const subjects = await readWatchSubjects(date);
    const subject = subjects.find((entry) => entry.index === index);
    if (!subject) {
      return NextResponse.json({ error: "Sujet introuvable dans la veille." }, { status: 404 });
    }

    const classified = await findClassifiedArticle(date, subject.title);
    if (classified) {
      return NextResponse.json({
        ok: true,
        source: "article-classe",
        title: frontmatterTitle(classified.content) ?? subject.title,
        filePath: classified.filePath,
        content: classified.content
      });
    }

    return NextResponse.json({
      ok: true,
      source: "veille",
      title: subject.title,
      filePath: path.join(VA_ROOT, "00-INBOX", `Veille - ${date}.md`),
      content: buildSubjectReading(subject)
    });
  } catch (error) {
    console.error("[watch-subject] Failed to read subject.", error);
    const message = error instanceof Error ? error.message : "Unknown error";
    return NextResponse.json({ error: `Impossible de lire le sujet complet : ${message}` }, { status: 500 });
  }
}

async function findClassifiedArticle(date: string, title: string): Promise<Candidate | null> {
  const files = await listMarkdownFiles(DAILY_DIR).catch(() => []);
  const terms = significantTerms(title);
  const candidates: Candidate[] = [];

  for (const filePath of files.filter((entry) => path.basename(entry).startsWith(date))) {
    const content = await readFile(filePath, "utf-8").catch(() => "");
    const haystack = normalize(`${path.basename(filePath)} ${content.slice(0, 1200)}`);
    const score = terms.filter((term) => haystack.includes(term)).length;
    if (score > 0) {
      candidates.push({ filePath, filename: path.basename(filePath), content, score });
    }
  }

  return candidates.sort((left, right) => right.score - left.score || left.filename.localeCompare(right.filename))[0] ?? null;
}

async function listMarkdownFiles(dir: string): Promise<string[]> {
  const entries = await readdir(dir, { withFileTypes: true });
  const files: string[] = [];
  for (const entry of entries) {
    const fullPath = path.join(dir, entry.name);
    if (entry.isDirectory()) {
      files.push(...(await listMarkdownFiles(fullPath)));
    } else if (entry.isFile() && entry.name.endsWith(".md")) {
      files.push(fullPath);
    }
  }
  return files;
}

function buildSubjectReading(subject: Awaited<ReturnType<typeof readWatchSubjects>>[number]): string {
  return [
    `# ${subject.title}`,
    "",
    `> Rubrique : ${subject.rubric}`,
    "",
    "## Pourquoi maintenant",
    "",
    subject.pourquoi || "À compléter.",
    "",
    "## Faits établis",
    "",
    bullets(subject.faits),
    "",
    "## Analyse Valeurs Africaines",
    "",
    subject.angle || "À compléter.",
    "",
    "## Incertitudes / hypothèses",
    "",
    bullets(subject.hypotheses),
    "",
    "## Sources",
    "",
    bullets(subject.sources)
  ].join("\n");
}

function bullets(items: string[]): string {
  return items.length > 0 ? items.map((item) => `- ${item}`).join("\n") : "- À compléter.";
}

function frontmatterTitle(content: string): string | null {
  const match = content.match(/^title:\s*"(.+)"$/m);
  return match?.[1] ?? null;
}

function significantTerms(title: string): string[] {
  const stop = new Set(["actualite", "strategique", "economie", "securite", "diplomatie", "innovation", "gouvernance", "culture", "medias"]);
  return normalize(title)
    .split(/[^a-z0-9]+/)
    .filter((term) => term.length >= 3 && !stop.has(term))
    .slice(0, 10);
}

function normalize(value: string): string {
  return value.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase();
}
