import { NextResponse } from "next/server";
import { getPlanningRows, isPlanningLocalMode } from "@/lib/googleSheets";

export const dynamic = "force-dynamic";

/** Liste toutes les lignes du planning (feuille Sheets ou repli local brouillons). */
export async function GET() {
  try {
    const rows = await getPlanningRows();
    return NextResponse.json({ rows, source: isPlanningLocalMode() ? "local" : "sheets" });
  } catch (error) {
    console.error("[api/planning] Failed to list planning rows.", error);
    return NextResponse.json({ error: "Unable to list planning rows." }, { status: 500 });
  }
}
