import { NextResponse } from "next/server";
import { getPlanningRowById } from "@/lib/googleSheets";

type RouteContext = {
  params: Promise<{
    id: string;
  }>;
};

export async function GET(_request: Request, context: RouteContext) {
  const { id } = await context.params;
  const editorialId = decodeURIComponent(id).trim();

  if (!editorialId) {
    return NextResponse.json({ error: "Editorial ID is required." }, { status: 400 });
  }

  try {
    console.info(`[api/planning] GET row ${editorialId}`);
    const row = await getPlanningRowById(editorialId);

    if (!row) {
      return NextResponse.json({ error: `Planning row not found: ${editorialId}` }, { status: 404 });
    }

    return NextResponse.json({ row });
  } catch (error) {
    console.error(`[api/planning] Failed to fetch row ${editorialId}.`, error);
    return NextResponse.json({ error: "Internal server error." }, { status: 500 });
  }
}

