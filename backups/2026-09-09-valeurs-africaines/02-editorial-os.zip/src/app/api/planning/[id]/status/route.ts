import { NextResponse } from "next/server";
import { updatePlanningStatus } from "@/lib/googleSheets";
import { ALLOWED_PLANNING_STATUSES, isAllowedPlanningStatus } from "@/lib/planningStatus";

type RouteContext = {
  params: Promise<{
    id: string;
  }>;
};

type StatusPayload = {
  status?: unknown;
};

export async function PATCH(request: Request, context: RouteContext) {
  const { id } = await context.params;
  const editorialId = decodeURIComponent(id).trim();

  if (!editorialId) {
    return NextResponse.json({ error: "Editorial ID is required." }, { status: 400 });
  }

  let payload: StatusPayload;

  try {
    payload = (await request.json()) as StatusPayload;
  } catch {
    return NextResponse.json({ error: "Invalid JSON payload." }, { status: 400 });
  }

  if (typeof payload.status !== "string" || !payload.status.trim()) {
    return NextResponse.json({ error: "A non-empty status is required." }, { status: 400 });
  }

  const status = payload.status.trim();

  if (!isAllowedPlanningStatus(status)) {
    return NextResponse.json(
      {
        error: "Status is not allowed.",
        allowedStatuses: ALLOWED_PLANNING_STATUSES
      },
      { status: 400 }
    );
  }

  try {
    console.info(`[api/planning] PATCH status ${editorialId} -> ${status}`);
    const row = await updatePlanningStatus(editorialId, status);
    return NextResponse.json({ row });
  } catch (error) {
    console.error(`[api/planning] Failed to update status for ${editorialId}.`, error);
    return NextResponse.json({ error: "Internal server error." }, { status: 500 });
  }
}

