import { readFile } from "node:fs/promises";
import path from "node:path";
import { NextResponse } from "next/server";
import { DRAFTS_DIR, draftArticle } from "@/lib/draftArticle";

export const dynamic = "force-dynamic";

const FILENAME_PATTERN = /^[0-9]{4}-[0-9]{2}-[0-9]{2}-sujet-\d+-[a-z0-9-]+\.md$/i;

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const filename = searchParams.get("filename") ?? "";
    if (!FILENAME_PATTERN.test(filename) || filename.includes("..") || filename.includes("/") || filename.includes("\\")) {
      return NextResponse.json({ error: "filename invalide." }, { status: 400 });
    }
    const filePath = path.join(DRAFTS_DIR, filename);
    const content = await readFile(filePath, "utf-8");
    const ready = /\[x\]\s*Chapo rédigé/.test(content) && !/Chapo \(à compléter\)|à compléter/i.test(content);
    return NextResponse.json({ ok: true, filename, content, ready });
  } catch (error) {
    console.error("[draft-article] Failed to read the draft.", error);
    const message = error instanceof Error ? error.message : "Unknown error";
    return NextResponse.json({ error: `Impossible de lire le brouillon : ${message}` }, { status: 404 });
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json().catch(() => null);
    const subjectIndex = typeof body?.subjectIndex === "number" ? body.subjectIndex : Number(body?.subjectIndex);
    if (!Number.isInteger(subjectIndex) || subjectIndex < 1) {
      return NextResponse.json({ error: "subjectIndex invalide : entier >= 1 requis." }, { status: 400 });
    }
    const date = typeof body?.date === "string" ? body.date : undefined;
    const result = await draftArticle({ date, subjectIndex });
    return NextResponse.json(result);
  } catch (error) {
    console.error("[draft-article] Failed to draft the article.", error);
    const message = error instanceof Error ? error.message : "Unknown error";
    const status = message.includes("Index de sujet invalide") ? 400 : message.includes("existe déjà") ? 409 : message.includes("retenu") || message.includes("Retenir") ? 403 : 500;
    return NextResponse.json({ error: `Impossible de générer le brouillon : ${message}` }, { status });
  }
}
