import { NextResponse } from "next/server";
import { analyzeArticleAgainstSDGAgenda } from "@/lib/sdgAgendaObserver";

export async function POST(request: Request) {
  try {
    const body = (await request.json()) as {
      title?: string;
      content?: string;
      themes?: string[];
    };

    if (!body.title && !body.content) {
      return NextResponse.json(
        { error: "title or content is required for ODD / Agenda 2063 analysis" },
        { status: 400 }
      );
    }

    const analysis = analyzeArticleAgainstSDGAgenda({
      title: body.title ?? "",
      content: body.content ?? "",
      themes: body.themes ?? []
    });

    console.info("[odd-agenda-2063] Article analyzed", {
      impactODD: analysis.impactODD,
      impactAgenda2063: analysis.impactAgenda2063,
      priorite: analysis.priorite,
      validation_humaine_requise: analysis.validation_humaine_requise
    });

    return NextResponse.json(analysis);
  } catch (error) {
    console.error("[odd-agenda-2063] Analysis failed", error);
    return NextResponse.json({ error: "Unable to analyze article" }, { status: 500 });
  }
}
