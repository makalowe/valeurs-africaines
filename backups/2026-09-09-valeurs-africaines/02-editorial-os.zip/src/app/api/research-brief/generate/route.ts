import { NextResponse } from "next/server";
import { generateResearchBrief, type ResearchBriefInput } from "@/lib/researchBrief";

type Payload = {
  titre?: unknown;
  categorie?: unknown;
  pays?: unknown;
  resume?: unknown;
};

function parsePayload(payload: Payload): ResearchBriefInput | null {
  if (typeof payload.titre !== "string" || typeof payload.categorie !== "string") {
    return null;
  }

  return {
    titre: payload.titre,
    categorie: payload.categorie,
    pays: typeof payload.pays === "string" ? payload.pays : "",
    resume: typeof payload.resume === "string" ? payload.resume : ""
  };
}

export async function POST(request: Request) {
  let payload: Payload;

  try {
    payload = (await request.json()) as Payload;
  } catch {
    return NextResponse.json({ error: "Invalid JSON payload." }, { status: 400 });
  }

  const input = parsePayload(payload);

  if (!input) {
    return NextResponse.json({ error: "titre and categorie are required." }, { status: 400 });
  }

  try {
    console.info(`[researchBrief] API generation request: ${input.titre}`);
    const researchBrief = await generateResearchBrief(input);
    return NextResponse.json({ research_brief: researchBrief });
  } catch (error) {
    console.error("[researchBrief] Failed to generate Research Brief.", error);
    return NextResponse.json({ error: "Unable to generate Research Brief." }, { status: 500 });
  }
}

