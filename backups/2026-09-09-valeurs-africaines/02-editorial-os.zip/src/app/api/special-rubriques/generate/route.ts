import { NextResponse } from "next/server";
import { generateSpecialRubriqueProposal, type SpecialRubriqueId } from "@/lib/specialRubriques";

type Payload = {
  rubrique?: unknown;
  sujet?: unknown;
  sources?: unknown;
  pays?: unknown;
  acteurs?: unknown;
};

const allowedRubriques: SpecialRubriqueId[] = [
  "elles-de-la-semaine",
  "entrepreneuriat-feminin",
  "initiatives-innovation",
  "pulse-des-jeunes",
  "afrique-creative",
  "afrique-diaspora",
  "analyse-independante",
  "souverainete-narrative"
];

function asStringArray(value: unknown): string[] {
  return Array.isArray(value) ? value.filter((item): item is string => typeof item === "string") : [];
}

export async function POST(request: Request) {
  try {
    const payload = (await request.json()) as Payload;

    if (typeof payload.rubrique !== "string" || !allowedRubriques.includes(payload.rubrique as SpecialRubriqueId)) {
      return NextResponse.json({ error: "rubrique is invalid." }, { status: 400 });
    }

    if (typeof payload.sujet !== "string" || !payload.sujet.trim()) {
      return NextResponse.json({ error: "sujet is required." }, { status: 400 });
    }

    console.info(`[special-rubriques] Generating proposal for ${payload.rubrique}.`);
    return NextResponse.json({
      proposal: generateSpecialRubriqueProposal({
        rubrique: payload.rubrique as SpecialRubriqueId,
        sujet: payload.sujet.trim(),
        sources: asStringArray(payload.sources),
        pays: asStringArray(payload.pays),
        acteurs: asStringArray(payload.acteurs)
      })
    });
  } catch (error) {
    console.error("[special-rubriques] Failed to generate proposal.", error);
    return NextResponse.json({ error: "Unable to generate special rubrique proposal." }, { status: 500 });
  }
}
