import { NextResponse } from "next/server";
import { getConflictZones } from "@/lib/conflictObserver";

export async function GET() {
  try {
    const zones = await getConflictZones();
    return NextResponse.json({ zones });
  } catch (error) {
    console.error("[conflits] Failed to load conflict zones.", error);
    return NextResponse.json({ error: "Unable to load conflict observer data." }, { status: 500 });
  }
}
