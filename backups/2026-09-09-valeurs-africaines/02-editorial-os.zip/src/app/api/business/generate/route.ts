import { NextResponse } from "next/server";
import { generateBusinessDraft, type BusinessFormat } from "@/lib/business";

type BusinessPayload = {
  sujet?: unknown;
  format?: unknown;
  secteur?: unknown;
  pays?: unknown;
  acteurs?: unknown;
  sources?: unknown;
};

const formats: BusinessFormat[] = [
  "Entreprise de la semaine",
  "Entrepreneur du mois",
  "Analyse de marché",
  "Levées de fonds",
  "Success stories africaines",
  "Business Brief"
];

function toString(value: unknown): string {
  return typeof value === "string" ? value.trim() : "";
}

function toStringArray(value: unknown): string[] {
  return Array.isArray(value) ? value.filter((item): item is string => typeof item === "string" && item.trim().length > 0) : [];
}

export async function POST(request: Request) {
  try {
    const payload = (await request.json()) as BusinessPayload;
    const format = formats.includes(payload.format as BusinessFormat) ? payload.format as BusinessFormat : "Business Brief";
    const sujet = toString(payload.sujet);

    if (!sujet) {
      return NextResponse.json({ error: "sujet is required." }, { status: 400 });
    }

    console.info(`[business] Generating ${format}: ${sujet}.`);
    return NextResponse.json(generateBusinessDraft({
      sujet,
      format,
      secteur: toString(payload.secteur),
      pays: toString(payload.pays),
      acteurs: toStringArray(payload.acteurs),
      sources: toStringArray(payload.sources)
    }));
  } catch (error) {
    console.error("[business] Failed to generate draft.", error);
    return NextResponse.json({ error: "Unable to generate business draft." }, { status: 500 });
  }
}
