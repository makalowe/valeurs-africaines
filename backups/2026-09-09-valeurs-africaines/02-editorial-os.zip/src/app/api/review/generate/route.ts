import { mkdir, readFile, writeFile } from "node:fs/promises";
import path from "node:path";
import { NextResponse } from "next/server";
import { DRAFTS_DIR } from "@/lib/draftArticle";
import { buildArticleMarkdown, buildReviewMarkdown, readWatchSubjects, reviewTargetPath, slugifyArticleTitle } from "@/lib/reviewBuilder";

export const dynamic = "force-dynamic";

const WORKFLOW_FILE = path.join(process.cwd(), "data", "editorial-workflow.json");

export async function POST(request: Request) {
  try {
    const body = await request.json().catch(() => null);
    const date = typeof body?.date === "string" && /^\d{4}-\d{2}-\d{2}$/.test(body.date) ? body.date : null;
    if (!date) {
      return NextResponse.json({ error: "date requise (AAAA-MM-JJ)." }, { status: 400 });
    }

    // 1. Lire les décisions du comité (workflow partagé)
    const rawWorkflow = await readFile(WORKFLOW_FILE, "utf-8").catch(() => null);
    const decisions: Record<string, string> = rawWorkflow ? (JSON.parse(rawWorkflow).decisions ?? {}) : {};
    const retained = Object.entries(decisions)
      .filter(([key, value]) => key.startsWith(`veille-${date}-`) && value === "Retenir")
      .map(([key]) => Number(key.split("-").pop()))
      .filter((index) => Number.isInteger(index))
      .sort((a, b) => a - b);
    if (retained.length !== 3) {
      return NextResponse.json(
        { error: `${retained.length}/3 sujets sélectionnés (décisions « Retenir » pour la veille du ${date}). Sélectionne exactement 3 sujets.` },
        { status: 400 }
      );
    }

    // 2. Lire la veille et construire la revue
    const watchSubjects = await readWatchSubjects(date);
    const selected = retained
      .map((index) => watchSubjects.find((subject) => subject.index === index))
      .filter((subject) => subject !== undefined) as NonNullable<typeof watchSubjects[number]>[];
    if (selected.length !== 3) {
      return NextResponse.json({ error: "Impossible de retrouver les sujets sélectionnés dans la veille." }, { status: 404 });
    }

    const content = buildReviewMarkdown(date, selected);
    const targetPath = await reviewTargetPath(date);

    // 3. Écrire la revue (sans écraser une revue existante)
    await mkdir(path.dirname(targetPath), { recursive: true });
    try {
      await writeFile(targetPath, content, { encoding: "utf-8", flag: "wx" });
    } catch (writeError) {
      const code = (writeError as { code?: string })?.code;
      if (code === "EEXIST") {
        return NextResponse.json({ error: `La revue du ${date} existe déjà : ${targetPath}. Aucun écrasement.` }, { status: 409 });
      }
      throw writeError;
    }

    // 4. Générer un article (brouillon) par sujet sélectionné — en attente de validation
    await mkdir(DRAFTS_DIR, { recursive: true });
    const articles = [];
    for (let position = 1; position <= selected.length; position += 1) {
      const subject = selected[position - 1];
      const filename = `${date}-sujet-${position}-${slugifyArticleTitle(subject.title)}.md`;
      const filePath = path.join(DRAFTS_DIR, filename);
      let created = true;
      try {
        await writeFile(filePath, buildArticleMarkdown(date, subject, position), { encoding: "utf-8", flag: "wx" });
      } catch (writeError) {
        const code = (writeError as { code?: string })?.code;
        if (code === "EEXIST") {
          created = false; // brouillon déjà existant : conservé tel quel
        } else {
          throw writeError;
        }
      }
      articles.push({ position, title: subject.title, rubric: subject.rubric, filename, filePath, created });
    }

    return NextResponse.json({
      ok: true,
      date,
      filePath: targetPath,
      subjects: selected.map((subject, position) => ({ position: position + 1, title: subject.title, rubric: subject.rubric })),
      articles
    });
  } catch (error) {
    console.error("[review] Failed to generate the review.", error);
    const message = error instanceof Error ? error.message : "Unknown error";
    const status = message.includes("ENOENT") || message.includes("Veille") ? 404 : 500;
    return NextResponse.json({ error: `Impossible de générer la revue : ${message}` }, { status });
  }
}
