import { NextResponse } from "next/server";
import { createKnowledgeEntry, type KnowledgeEntryInput, type KnowledgeEntryType } from "@/lib/knowledgeHub";

type Payload = Partial<KnowledgeEntryInput>;

const ALLOWED_TYPES: KnowledgeEntryType[] = [
  "article",
  "research-brief",
  "note-pays",
  "signal-faible",
  "infographie",
  "fiche-pays",
  "fiche-acteur",
  "fiche-entreprise",
  "fiche-organisation",
  "fiche-theme",
  "think-tank",
  "observatoire",
  "scenario",
  "portrait",
  "chercheur",
  "innovateur",
  "conflict-observer",
  "country-profile"
];

function parseStringArray(value: unknown): string[] {
  if (Array.isArray(value)) return value.filter((item): item is string => typeof item === "string");
  if (typeof value === "string") return value.split(/[,;\n]/).map((item) => item.trim()).filter(Boolean);
  return [];
}

function isType(value: unknown): value is KnowledgeEntryType {
  return typeof value === "string" && ALLOWED_TYPES.includes(value as KnowledgeEntryType);
}

export async function POST(request: Request) {
  let payload: Payload;

  try {
    payload = (await request.json()) as Payload;
  } catch {
    return NextResponse.json({ error: "Invalid JSON payload." }, { status: 400 });
  }

  if (!isType(payload.type)) {
    return NextResponse.json({ error: "Type de fiche invalide." }, { status: 400 });
  }

  if (typeof payload.titre !== "string" || !payload.titre.trim()) {
    return NextResponse.json({ error: "Le titre est obligatoire." }, { status: 400 });
  }

  if (typeof payload.contenu !== "string" || !payload.contenu.trim()) {
    return NextResponse.json({ error: "Le contenu est obligatoire." }, { status: 400 });
  }

  if (!payload.validation_humaine) {
    return NextResponse.json({ error: "Validation humaine obligatoire avant creation Knowledge Hub." }, { status: 409 });
  }

  try {
    const entry = await createKnowledgeEntry({
      type: payload.type,
      titre: payload.titre,
      date: typeof payload.date === "string" ? payload.date : undefined,
      auteur: typeof payload.auteur === "string" ? payload.auteur : undefined,
      categorie: typeof payload.categorie === "string" ? payload.categorie : undefined,
      rubrique: typeof payload.rubrique === "string" ? payload.rubrique : undefined,
      pays: parseStringArray(payload.pays),
      acteurs: parseStringArray(payload.acteurs),
      organisations: parseStringArray(payload.organisations),
      themes: parseStringArray(payload.themes),
      fiabilite: typeof payload.fiabilite === "string" ? payload.fiabilite : undefined,
      sources: parseStringArray(payload.sources),
      contenu: payload.contenu,
      validation_humaine: true
    });
    return NextResponse.json({ entry });
  } catch (error) {
    console.error("[knowledgeHub] Failed to create entry.", error);
    return NextResponse.json({ error: "Unable to create knowledge entry." }, { status: 500 });
  }
}
