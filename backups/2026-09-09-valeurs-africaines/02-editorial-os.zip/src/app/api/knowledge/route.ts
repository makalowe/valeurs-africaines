import { NextResponse } from "next/server";
import { getKnowledgeEntries } from "@/lib/knowledgeHub";

export async function GET() {
  try {
    const entries = await getKnowledgeEntries();
    return NextResponse.json({ entries });
  } catch (error) {
    console.error("[knowledgeHub] Failed to list entries.", error);
    return NextResponse.json({ error: "Unable to list knowledge entries." }, { status: 500 });
  }
}
