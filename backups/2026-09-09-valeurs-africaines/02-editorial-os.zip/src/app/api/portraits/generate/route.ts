import { NextResponse } from "next/server";
import { generateAcademicProfile, generatePortraitVisualProposals } from "@/lib/portraits";

type PortraitPayload = {
  nom?: unknown;
  pays?: unknown;
  domaine?: unknown;
  institution?: unknown;
  fonction?: unknown;
  sources?: unknown;
};

function toString(value: unknown): string {
  return typeof value === "string" ? value.trim() : "";
}

function toSources(value: unknown): string[] {
  return Array.isArray(value) ? value.filter((item): item is string => typeof item === "string" && item.trim().length > 0) : [];
}

export async function POST(request: Request) {
  try {
    const payload = (await request.json()) as PortraitPayload;
    const input = {
      nom: toString(payload.nom),
      pays: toString(payload.pays),
      domaine: toString(payload.domaine),
      institution: toString(payload.institution),
      fonction: toString(payload.fonction),
      sources: toSources(payload.sources)
    };

    if (!input.nom) {
      return NextResponse.json({ error: "nom is required." }, { status: 400 });
    }

    console.info(`[portraits] Generating portrait draft for ${input.nom}.`);
    const result = generateAcademicProfile(input);

    return NextResponse.json({
      ...result,
      visual_proposals: generatePortraitVisualProposals(input)
    });
  } catch (error) {
    console.error("[portraits] Failed to generate portrait.", error);
    return NextResponse.json({ error: "Unable to generate portrait." }, { status: 500 });
  }
}
