import { NextResponse } from "next/server";
import { readDailyReview } from "@/lib/dailyReview";

export const dynamic = "force-dynamic";

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const date = searchParams.get("date") ?? undefined;
    const review = await readDailyReview(date);
    return NextResponse.json({ source: "file", ...review });
  } catch (error) {
    console.error("[daily-review] Failed to read the daily review.", error);
    const message = error instanceof Error ? error.message : "Unknown error";
    return NextResponse.json({ error: `Unable to read the daily review: ${message}` }, { status: 500 });
  }
}
