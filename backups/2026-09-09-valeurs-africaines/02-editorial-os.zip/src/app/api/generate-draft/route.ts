import { NextResponse } from "next/server";
import { getPlanningRowById } from "@/lib/googleSheets";
import { generateArticleDraft, generateResearchBriefDraft } from "@/lib/openai";

type GenerateDraftPayload = {
  editorialId?: unknown;
};

function isResearchBriefFormat(format: string): boolean {
  return format.trim().toLowerCase().includes("research");
}

export async function POST(request: Request) {
  let payload: GenerateDraftPayload;

  try {
    payload = (await request.json()) as GenerateDraftPayload;
  } catch {
    return NextResponse.json({ error: "Invalid JSON payload." }, { status: 400 });
  }

  if (typeof payload.editorialId !== "string" || !payload.editorialId.trim()) {
    return NextResponse.json({ error: "editorialId is required." }, { status: 400 });
  }

  const editorialId = payload.editorialId.trim();

  try {
    console.info(`[api/generate-draft] Requested draft for ${editorialId}`);
    const row = await getPlanningRowById(editorialId);

    if (!row) {
      return NextResponse.json({ error: `Planning row not found: ${editorialId}` }, { status: 404 });
    }

    const result = isResearchBriefFormat(row.format)
      ? await generateResearchBriefDraft(row)
      : await generateArticleDraft(row);

    return NextResponse.json({ row, result });
  } catch (error) {
    console.error(`[api/generate-draft] Failed to generate draft for ${editorialId}.`, error);
    const message = error instanceof Error ? error.message : "Unable to generate draft.";
    const code = error instanceof Error ? (error as Error & { code?: string }).code : undefined;
    if (code === "AI_API_KEY_MISSING" || message.includes("clé IA") || message.includes("OPENAI_API_KEY") || message.includes("DEEPSEEK_API_KEY")) {
      return NextResponse.json({ error: message, code: "AI_API_KEY_MISSING" }, { status: 503 });
    }
    return NextResponse.json({ error: "Unable to generate draft." }, { status: 500 });
  }
}

