import { NextResponse } from "next/server";
import { generateSustainableDraft, type SustainableFormat } from "@/lib/sustainableEconomy";

type Payload = {
  sujet?: unknown;
  format?: unknown;
  axe?: unknown;
  pays?: unknown;
  acteurs?: unknown;
  sources?: unknown;
};

const formats: SustainableFormat[] = [
  "Green Brief",
  "Analyse sectorielle",
  "Projet innovant",
  "Initiative locale",
  "Cartographie environnementale"
];

function toString(value: unknown): string {
  return typeof value === "string" ? value.trim() : "";
}

function toStringArray(value: unknown): string[] {
  return Array.isArray(value) ? value.filter((item): item is string => typeof item === "string" && item.trim().length > 0) : [];
}

export async function POST(request: Request) {
  try {
    const payload = (await request.json()) as Payload;
    const sujet = toString(payload.sujet);
    const format = formats.includes(payload.format as SustainableFormat) ? payload.format as SustainableFormat : "Green Brief";

    if (!sujet) {
      return NextResponse.json({ error: "sujet is required." }, { status: 400 });
    }

    console.info(`[sustainable-economy] Generating ${format}: ${sujet}.`);
    return NextResponse.json(generateSustainableDraft({
      sujet,
      format,
      axe: toString(payload.axe),
      pays: toString(payload.pays),
      acteurs: toStringArray(payload.acteurs),
      sources: toStringArray(payload.sources)
    }));
  } catch (error) {
    console.error("[sustainable-economy] Failed to generate draft.", error);
    return NextResponse.json({ error: "Unable to generate sustainable economy draft." }, { status: 500 });
  }
}
