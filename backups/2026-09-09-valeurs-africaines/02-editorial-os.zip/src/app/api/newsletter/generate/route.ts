import { NextResponse } from "next/server";
import { generateNewsletter, type NewsletterInput } from "@/lib/newsletter";

type Payload = {
  periode?: unknown;
  articles?: unknown;
  briefs?: unknown;
  signaux?: unknown;
};

function parseStringArray(value: unknown): string[] {
  return Array.isArray(value) ? value.filter((item): item is string => typeof item === "string") : [];
}

function parsePayload(payload: Payload): NewsletterInput {
  return {
    periode: typeof payload.periode === "string" ? payload.periode : "",
    articles: parseStringArray(payload.articles),
    briefs: parseStringArray(payload.briefs),
    signaux: parseStringArray(payload.signaux)
  };
}

export async function POST(request: Request) {
  let payload: Payload;

  try {
    payload = (await request.json()) as Payload;
  } catch {
    return NextResponse.json({ error: "Invalid JSON payload." }, { status: 400 });
  }

  const input = parsePayload(payload);

  try {
    console.info(`[newsletter] API generation request for period: ${input.periode || "not provided"}`);
    const newsletter = await generateNewsletter(input);
    return NextResponse.json({ newsletter });
  } catch (error) {
    console.error("[newsletter] Failed to generate newsletter.", error);
    return NextResponse.json({ error: "Unable to generate newsletter." }, { status: 500 });
  }
}

