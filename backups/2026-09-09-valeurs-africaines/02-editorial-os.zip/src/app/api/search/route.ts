import { NextResponse } from "next/server";
import { retrieveContext, type RagFilters, type RetrievedContext, type SearchMode } from "@/lib/rag";

type Payload = {
  query?: unknown;
  mode?: unknown;
  filters?: unknown;
  limit?: unknown;
};

function isMode(value: unknown): value is SearchMode {
  return value === "fulltext" || value === "semantic" || value === "hybrid";
}

function parseFilters(value: unknown): RagFilters {
  if (typeof value !== "object" || value === null || Array.isArray(value)) return {};
  const source = value as Record<string, unknown>;
  return {
    pays: typeof source.pays === "string" ? source.pays : undefined,
    acteur: typeof source.acteur === "string" ? source.acteur : undefined,
    theme: typeof source.theme === "string" ? source.theme : undefined,
    date: typeof source.date === "string" ? source.date : undefined,
    categorie: typeof source.categorie === "string" ? source.categorie : undefined
  };
}

export async function POST(request: Request) {
  let payload: Payload;

  try {
    payload = (await request.json()) as Payload;
  } catch {
    return NextResponse.json({ error: "Invalid JSON payload." }, { status: 400 });
  }

  if (typeof payload.query !== "string" || !payload.query.trim()) {
    return NextResponse.json({ error: "La question est obligatoire." }, { status: 400 });
  }

  const mode = isMode(payload.mode) ? payload.mode : "hybrid";
  const limit = typeof payload.limit === "number" && payload.limit > 0 ? Math.min(payload.limit, 12) : 6;
  const filters = parseFilters(payload.filters);

  try {
    console.info(`[rag] Search request: ${payload.query} (${mode})`);
    const retrieved = await retrieveContext(payload.query, mode, filters, limit);
    return NextResponse.json(sanitizeRetrievedContext(retrieved));
  } catch (error) {
    console.error("[rag] Search failed.", error);
    return NextResponse.json({ error: "Unable to search internal knowledge base." }, { status: 500 });
  }
}

function sanitizeRetrievedContext(retrieved: RetrievedContext) {
  return {
    ...retrieved,
    results: retrieved.results.map((result) => {
      const { embedding: _embedding, text: _text, ...document } = result.document;
      return {
        ...result,
        document
      };
    })
  };
}
