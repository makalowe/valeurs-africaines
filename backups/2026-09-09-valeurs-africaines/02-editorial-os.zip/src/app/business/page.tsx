"use client";

import { FormEvent, useState } from "react";
import { businessAxes, type BusinessFormat } from "@/lib/business";

type BusinessResponse = {
  draft?: string;
  sources_a_verifier?: string[];
  niveau_confiance?: string;
  validation_humaine_requise?: boolean;
  publication_automatique?: false;
  error?: string;
};

const formats: BusinessFormat[] = [
  "Entreprise de la semaine",
  "Entrepreneur du mois",
  "Analyse de marché",
  "Levées de fonds",
  "Success stories africaines",
  "Business Brief"
];

export default function BusinessPage() {
  const [format, setFormat] = useState<BusinessFormat>("Business Brief");
  const [sujet, setSujet] = useState("Fintech et inclusion financière en Afrique de l'Ouest");
  const [secteur, setSecteur] = useState("Fintech");
  const [pays, setPays] = useState("Afrique de l'Ouest");
  const [acteurs, setActeurs] = useState("");
  const [sources, setSources] = useState("");
  const [result, setResult] = useState<BusinessResponse | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  async function generate(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setIsLoading(true);
    setError(null);
    setResult(null);

    try {
      const response = await fetch("/api/business/generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ format, sujet, secteur, pays, acteurs: splitList(acteurs), sources: splitList(sources) })
      });
      const payload = (await response.json()) as BusinessResponse;

      if (!response.ok) {
        setError(payload.error ?? "Erreur pendant la génération business.");
        return;
      }

      setResult(payload);
    } catch {
      setError("Impossible de contacter l'API interne.");
    } finally {
      setIsLoading(false);
    }
  }

  return (
    <main className="min-h-screen bg-ink px-5 py-8 text-neutral-100">
      <section className="mx-auto max-w-7xl space-y-6">
        <header className="border-b border-line pb-5">
          <p className="text-xs font-semibold uppercase tracking-[0.24em] text-gold">Business & Entrepreneuriat</p>
          <h1 className="mt-3 text-3xl font-semibold text-gold-soft">Richesse, marchés et création de valeur en Afrique</h1>
          <p className="mt-2 max-w-3xl text-sm leading-6 text-neutral-400">
            Analyser les entreprises, entrepreneurs, investisseurs, marchés et modèles économiques qui transforment le continent.
          </p>
        </header>

        <section className="grid grid-cols-4 gap-3 max-lg:grid-cols-2 max-sm:grid-cols-1">
          {businessAxes.map((axis) => (
            <div key={axis} className="rounded-lg border border-line bg-panel p-4 text-sm font-semibold text-gold-soft">{axis}</div>
          ))}
        </section>

        {error ? <div className="rounded-lg border border-red-400/40 bg-red-400/10 p-4 text-sm text-red-100">{error}</div> : null}

        <section className="grid grid-cols-[360px_minmax(0,1fr)] gap-5 max-lg:grid-cols-1">
          <form onSubmit={generate} className="rounded-lg border border-line bg-panel p-4">
            <h2 className="font-semibold text-gold-soft">Créer un contenu business</h2>
            <Field label="Format">
              <select value={format} onChange={(event) => setFormat(event.target.value as BusinessFormat)} className={fieldClass}>
                {formats.map((item) => <option key={item} value={item}>{item}</option>)}
              </select>
            </Field>
            <Field label="Sujet"><textarea value={sujet} onChange={(event) => setSujet(event.target.value)} className={`${fieldClass} min-h-20`} /></Field>
            <Field label="Secteur"><input value={secteur} onChange={(event) => setSecteur(event.target.value)} className={fieldClass} /></Field>
            <Field label="Pays / région"><input value={pays} onChange={(event) => setPays(event.target.value)} className={fieldClass} /></Field>
            <Field label="Acteurs"><textarea value={acteurs} onChange={(event) => setActeurs(event.target.value)} className={`${fieldClass} min-h-20`} /></Field>
            <Field label="Sources"><textarea value={sources} onChange={(event) => setSources(event.target.value)} className={`${fieldClass} min-h-20`} /></Field>
            <button type="submit" disabled={isLoading} className="mt-4 w-full rounded-md bg-gold px-4 py-2.5 font-bold text-black disabled:opacity-50">
              {isLoading ? "Génération..." : "Générer brouillon business"}
            </button>
            <div className="mt-4 rounded-md border border-red-400/30 bg-red-400/10 p-3 text-xs leading-5 text-red-100">
              Ne jamais inventer chiffre d'affaires, valorisation, levée de fonds, investisseur ou client. Validation humaine obligatoire.
            </div>
          </form>

          <article className="rounded-lg border border-line bg-panel">
            <div className="border-b border-line bg-[#171717] px-4 py-3">
              <h2 className="font-semibold text-gold-soft">Brouillon</h2>
              <p className="text-sm text-neutral-400">Question centrale : comment créer davantage de richesse et de valeur en Afrique ?</p>
            </div>
            <pre className="max-h-[760px] min-h-[560px] overflow-auto whitespace-pre-wrap p-5 text-sm leading-6 text-neutral-200">
              {result?.draft ?? "Le brouillon business apparaîtra ici."}
            </pre>
          </article>
        </section>
      </section>
    </main>
  );
}

const fieldClass = "w-full rounded-md border border-line bg-black px-3 py-2 text-sm text-neutral-100 outline-none focus:border-gold";

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="mt-3 block text-sm">
      <span className="mb-1 block font-semibold text-gold">{label}</span>
      {children}
    </label>
  );
}

function splitList(value: string): string[] {
  return value.split(/[,;\n]/).map((item) => item.trim()).filter(Boolean);
}
