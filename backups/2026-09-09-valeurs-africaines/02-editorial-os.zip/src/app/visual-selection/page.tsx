"use client";

import { FormEvent, useState } from "react";
import type { VisualProposal, VisualProposalType } from "@/lib/visualProposals";

type VisualProposalResponse = {
  editorialId?: string;
  proposals?: VisualProposal[];
  validation_humaine_requise?: boolean;
  publication_automatique?: false;
  error?: string;
};

type SelectedVisual = {
  id: string;
  type: VisualProposalType | "aucun";
  prompt: string;
};

const typeLabels: Record<VisualProposalType, string> = {
  photo: "Photo",
  illustration: "Illustration / dessin",
  diagramme: "Graphique / diagramme / carte"
};

export default function VisualSelectionPage() {
  const [editorialId, setEditorialId] = useState("VA-001");
  const [result, setResult] = useState<VisualProposalResponse | null>(null);
  const [selectedVisual, setSelectedVisual] = useState<SelectedVisual | null>(null);
  const [photoRightsVerified, setPhotoRightsVerified] = useState(false);
  const [choiceMessage, setChoiceMessage] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  async function generateProposals(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setIsLoading(true);
    setError(null);
    setResult(null);
    setSelectedVisual(null);
    setChoiceMessage(null);
    setPhotoRightsVerified(false);

    try {
      const response = await fetch("/api/visual-proposals/generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ editorialId })
      });
      const payload = (await response.json()) as VisualProposalResponse;

      if (!response.ok) {
        setError(payload.error ?? "Impossible de générer les propositions visuelles.");
        return;
      }

      setResult(payload);
    } catch {
      setError("Impossible de contacter l'API interne.");
    } finally {
      setIsLoading(false);
    }
  }

  async function saveVisualChoice() {
    if (!selectedVisual || !result?.editorialId) {
      setError("Choisissez un visuel ou la décision 'aucun visuel' avant d'enregistrer.");
      return;
    }

    setIsLoading(true);
    setError(null);
    setChoiceMessage(null);

    try {
      const response = await fetch("/api/visual-proposals/choose", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          editorialId: result.editorialId,
          visualId: selectedVisual.id,
          type: selectedVisual.type,
          prompt_visuel: selectedVisual.prompt,
          droits_visuels_verifies: selectedVisual.type === "photo" ? photoRightsVerified : selectedVisual.type !== "aucun",
          validation_visuelle_humaine: true
        })
      });
      const payload = (await response.json()) as { error?: string };

      if (!response.ok) {
        setError(payload.error ?? "Impossible d'enregistrer le choix visuel.");
        return;
      }

      setChoiceMessage("Choix visuel enregistré dans les métadonnées éditoriales.");
    } catch {
      setError("Impossible de contacter l'API interne.");
    } finally {
      setIsLoading(false);
    }
  }

  return (
    <main className="min-h-screen bg-ink px-5 py-8 text-neutral-100">
      <section className="mx-auto max-w-7xl space-y-6">
        <header className="border-b border-line pb-5">
          <p className="text-xs font-semibold uppercase tracking-[0.24em] text-gold">Validation visuelle</p>
          <h1 className="mt-3 text-3xl font-semibold text-gold-soft">Propositions visuelles avant publication</h1>
          <p className="mt-2 max-w-3xl text-sm leading-6 text-neutral-400">
            Avant la validation finale, le rédacteur choisit une photo, une illustration, un diagramme, ou documente explicitement l'absence de visuel.
          </p>
        </header>

        <form onSubmit={generateProposals} className="grid grid-cols-[minmax(220px,360px)_auto] gap-3 rounded-lg border border-line bg-panel p-4 max-sm:grid-cols-1">
          <label className="block text-sm">
            <span className="mb-1 block font-semibold text-gold">ID éditorial</span>
            <input
              value={editorialId}
              onChange={(event) => setEditorialId(event.target.value)}
              className="w-full rounded-md border border-line bg-black px-3 py-2 text-sm text-neutral-100 outline-none focus:border-gold"
              placeholder="VA-001"
            />
          </label>
          <button type="submit" disabled={isLoading} className="self-end rounded-md bg-gold px-4 py-2.5 font-bold text-black disabled:opacity-50">
            {isLoading ? "Génération..." : "Générer propositions visuelles"}
          </button>
        </form>

        {error ? <div className="rounded-lg border border-red-400/40 bg-red-400/10 p-4 text-sm text-red-100">{error}</div> : null}

        <section className="grid grid-cols-3 gap-4 max-lg:grid-cols-1">
          {result?.proposals?.map((proposal, index) => (
            <VisualCard
              key={proposal.id}
              proposal={proposal}
              index={index + 1}
              selected={selectedVisual?.id === proposal.id}
              onSelect={() => setSelectedVisual({ id: proposal.id, type: proposal.type, prompt: proposal.imagePrompt ?? "" })}
            />
          ))}
        </section>

        {result ? (
          <section className="rounded-lg border border-line bg-panel p-4">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div>
                <h2 className="font-semibold text-gold-soft">Décision visuelle</h2>
                <p className="mt-1 text-sm text-neutral-400">
                  Quel visuel souhaitez-vous utiliser ? (1, 2 ou 3)
                </p>
              </div>
              <button
                type="button"
                onClick={() => setSelectedVisual({ id: "aucun-visuel", type: "aucun", prompt: "" })}
                className={`rounded-md border px-3 py-2 text-sm font-semibold ${
                  selectedVisual?.type === "aucun" ? "border-gold bg-gold/10 text-gold-soft" : "border-line text-neutral-300 hover:border-gold"
                }`}
              >
                Décision : aucun visuel
              </button>
            </div>
            {selectedVisual?.type === "photo" ? (
              <label className="mt-4 flex items-start gap-3 rounded-md border border-red-400/30 bg-red-400/10 p-3 text-sm text-red-100">
                <input
                  type="checkbox"
                  checked={photoRightsVerified}
                  onChange={(event) => setPhotoRightsVerified(event.target.checked)}
                  className="mt-1"
                />
                <span>Je confirme que les droits d'utilisation de la photo, la source et le crédit seront vérifiés avant publication.</span>
              </label>
            ) : null}
            <div className="mt-4 grid grid-cols-4 gap-3 max-lg:grid-cols-2 max-sm:grid-cols-1">
              <Metric label="Visuel proposé" value={result.proposals?.length ? "oui" : "non"} />
              <Metric label="Visuel choisi" value={selectedVisual?.id ?? "à choisir"} />
              <Metric label="Validation humaine" value={result.validation_humaine_requise ? "obligatoire" : "-"} />
              <Metric label="Publication auto" value={result.publication_automatique === false ? "interdite" : "-"} />
            </div>
            <div className="mt-4 flex flex-wrap items-center gap-3">
              <button
                type="button"
                onClick={saveVisualChoice}
                disabled={isLoading || !selectedVisual}
                className="rounded-md bg-gold px-4 py-2.5 font-bold text-black disabled:opacity-50"
              >
                Enregistrer le choix dans les métadonnées
              </button>
              {choiceMessage ? <span className="text-sm font-semibold text-green-200">{choiceMessage}</span> : null}
            </div>
          </section>
        ) : (
          <div className="rounded-lg border border-line bg-panel p-8 text-center text-sm text-neutral-400">
            Saisissez un ID éditorial pour générer les trois options visuelles.
          </div>
        )}
      </section>
    </main>
  );
}

function VisualCard({ proposal, index, selected, onSelect }: { proposal: VisualProposal; index: number; selected: boolean; onSelect: () => void }) {
  return (
    <article className={`rounded-lg border bg-panel ${selected ? "border-gold" : "border-line"}`}>
      <div className="border-b border-line bg-[#111] p-4">
        <VisualPreview type={proposal.type} index={index} />
          <div className="mt-4 text-center">
            <div className="text-xs font-semibold uppercase tracking-[0.2em] text-gold">Option {index} · {typeLabels[proposal.type]}</div>
            <div className="mt-2 text-lg font-semibold text-gold-soft">{proposal.title}</div>
            <div className="mt-1 text-xs text-neutral-500">{proposal.previewLabel}</div>
          </div>
      </div>
      <div className="space-y-4 p-4">
        <p className="text-sm leading-6 text-neutral-300">{proposal.description}</p>
        {proposal.imagePrompt ? (
          <DetailBlock title="Prompt image" content={proposal.imagePrompt} />
        ) : null}
        {proposal.searchKeywords?.length ? (
          <DetailBlock title="Mots-clés photo" content={proposal.searchKeywords.join(", ")} />
        ) : null}
        {proposal.chartData ? (
          <DetailBlock
            title="Données du graphique"
            content={`${proposal.chartData.format}\nDonnées nécessaires: ${proposal.chartData.dataNeeded.join(", ")}\nSources à vérifier: ${proposal.chartData.sourcesToVerify.join(", ")}`}
          />
        ) : null}
        <div className="rounded-md border border-red-400/30 bg-red-400/10 p-3 text-xs leading-5 text-red-100">{proposal.rightsNote}</div>
        <button type="button" onClick={onSelect} className="w-full rounded-md bg-gold px-4 py-2.5 font-bold text-black">
          {selected ? "Visuel choisi" : "Choisir ce visuel"}
        </button>
      </div>
    </article>
  );
}

function VisualPreview({ type, index }: { type: VisualProposalType; index: number }) {
  if (type === "photo") {
    return (
      <div className="grid h-36 place-items-center rounded-md border border-line bg-[linear-gradient(135deg,#222,#111)]">
        <div className="h-20 w-28 rounded-sm border border-gold/50 bg-black/30 p-2">
          <div className="h-10 rounded-sm bg-neutral-700" />
          <div className="mt-2 h-2 w-20 bg-gold/60" />
          <div className="mt-1 h-2 w-14 bg-neutral-600" />
        </div>
      </div>
    );
  }

  if (type === "illustration") {
    return (
      <div className="grid h-36 place-items-center rounded-md border border-line bg-[#121212]">
        <div className="grid grid-cols-3 items-end gap-3">
          <div className="h-14 w-10 rounded-t-md bg-gold/40" />
          <div className="h-24 w-10 rounded-t-md bg-gold/70" />
          <div className="h-18 w-10 rounded-t-md bg-neutral-600" />
        </div>
      </div>
    );
  }

  return (
    <div className="grid h-36 place-items-center rounded-md border border-line bg-[#121212]">
      <div className="flex items-center gap-3">
        <div className="rounded-md border border-gold/70 px-3 py-2 text-sm font-bold text-gold">Cause</div>
        <div className="h-px w-8 bg-gold" />
        <div className="rounded-md border border-gold/70 px-3 py-2 text-sm font-bold text-gold">Effet</div>
        <div className="h-px w-8 bg-gold" />
        <div className="rounded-md border border-gold/70 px-3 py-2 text-sm font-bold text-gold">Impact {index}</div>
      </div>
    </div>
  );
}

function DetailBlock({ title, content }: { title: string; content: string }) {
  return (
    <div className="rounded-md border border-line bg-black/20 p-3">
      <h3 className="text-xs font-semibold uppercase tracking-[0.16em] text-gold">{title}</h3>
      <p className="mt-2 whitespace-pre-wrap text-sm leading-6 text-neutral-300">{content}</p>
    </div>
  );
}

function Metric({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-md border border-line bg-black/20 p-3">
      <div className="text-lg font-bold text-gold-soft">{value}</div>
      <div className="text-xs text-neutral-400">{label}</div>
    </div>
  );
}
