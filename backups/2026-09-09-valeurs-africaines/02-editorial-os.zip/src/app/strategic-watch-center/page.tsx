"use client";

import { FileDown, FileSpreadsheet, FileText, Printer, Search } from "lucide-react";
import type { ReactNode } from "react";
import { useMemo, useState } from "react";
import {
  attentionLevels,
  getWeakSignalStats,
  getWeakSignals,
  sortSignalsByPriority,
  watchRegions,
  weakSignalCategories,
  weakSignalStatuses,
  type AttentionLevel,
  type WeakSignalCategory,
  type WeakSignalStatus
} from "@/lib/strategicWatchCenter";

const signals = getWeakSignals();
const stats = getWeakSignalStats();

export default function StrategicWatchCenterPage() {
  const [query, setQuery] = useState("");
  const [category, setCategory] = useState<WeakSignalCategory | "Toutes les catégories">("Toutes les catégories");
  const [region, setRegion] = useState("Toutes les régions");
  const [attention, setAttention] = useState<AttentionLevel | "Tous les niveaux">("Tous les niveaux");
  const [status, setStatus] = useState<WeakSignalStatus | "Tous les statuts">("Tous les statuts");

  const filteredSignals = useMemo(() => {
    const normalized = normalize(query);
    return sortSignalsByPriority(signals.filter((signal) => {
      const categoryMatch = category === "Toutes les catégories" || signal.category === category;
      const regionMatch = region === "Toutes les régions" || signal.region === region || signal.geographicZone === region;
      const attentionMatch = attention === "Tous les niveaux" || signal.attentionLevel === attention;
      const statusMatch = status === "Tous les statuts" || signal.status === status;
      const queryMatch = !normalized || normalize([
        signal.title,
        signal.description,
        signal.actors.join(" "),
        signal.geographicZone,
        signal.whyImportant,
        signal.africaConsequences
      ].join(" ")).includes(normalized);
      return categoryMatch && regionMatch && attentionMatch && statusMatch && queryMatch;
    }));
  }, [attention, category, query, region, status]);

  return (
    <main className="min-h-screen bg-ink px-5 py-8 text-neutral-100">
      <section className="mx-auto max-w-7xl space-y-6">
        <header className="border-b border-line pb-5">
          <p className="text-xs font-semibold uppercase tracking-[0.24em] text-gold">Centre de Recherche</p>
          <h1 className="mt-3 text-3xl font-semibold text-gold-soft">Veille & Signaux Faibles</h1>
          <p className="mt-2 max-w-4xl text-sm leading-6 text-neutral-400">
            Strategic Watch Center pour détecter, suivre et archiver les signaux faibles pouvant avoir un impact sur l'Afrique.
          </p>
        </header>

        <section className="grid gap-4 md:grid-cols-6">
          <Kpi title="Total" value={String(stats.total)} />
          <Kpi title="Critiques" value={String(stats.critical)} />
          <Kpi title="Confirmés" value={String(stats.confirmed)} />
          <Kpi title="Archivés" value={String(stats.archived)} />
          <Kpi title="Catégories" value={String(weakSignalCategories.length)} />
          <Kpi title="Statuts" value={String(weakSignalStatuses.length)} />
        </section>

        <section className="grid gap-6 xl:grid-cols-[420px_minmax(0,1fr)]">
          <aside className="rounded-lg border border-line bg-panel p-5">
            <p className="text-xs font-semibold uppercase tracking-[0.22em] text-gold">Création d'un signal faible</p>
            <div className="mt-4 space-y-3">
              {["Titre", "Description", "Acteurs concernés", "Zone géographique", "Pourquoi c'est important", "Conséquences potentielles pour l'Afrique", "Horizon temporel", "Source(s) à vérifier"].map((field) => (
                <input key={field} disabled placeholder={field} className="w-full rounded-md border border-line bg-black/25 px-3 py-2 text-sm text-neutral-500" />
              ))}
              <div className="grid gap-3 sm:grid-cols-2">
                <Select disabled label="Catégorie" value="Géopolitique" values={weakSignalCategories} onChange={() => undefined} />
                <Select disabled label="Niveau d'attention" value="Faible" values={attentionLevels} onChange={() => undefined} />
                <Select disabled label="Statut" value="Détecté" values={weakSignalStatuses} onChange={() => undefined} />
              </div>
              <button type="button" disabled className="w-full rounded-md border border-gold/40 bg-gold/10 px-3 py-2 text-sm font-semibold text-gold-soft opacity-70">
                Création désactivée jusqu'à connexion API sécurisée
              </button>
            </div>
          </aside>

          <div className="space-y-6">
            <section className="rounded-lg border border-line bg-panel p-4">
              <div className="grid gap-3 xl:grid-cols-[minmax(0,1fr)_190px_190px_190px_170px]">
                <label className="group flex items-center gap-3 rounded-lg border border-gold/20 bg-black/25 px-4 py-3 transition focus-within:border-gold">
                  <Search size={18} className="text-gold" aria-hidden="true" />
                  <span className="sr-only">Recherche plein texte signaux faibles</span>
                  <input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Recherche plein texte..." className="h-9 w-full bg-transparent text-sm outline-none placeholder:text-neutral-500" />
                </label>
                <Select label="Filtrer par catégorie" value={category} values={["Toutes les catégories", ...weakSignalCategories]} onChange={(value) => setCategory(value as WeakSignalCategory | "Toutes les catégories")} />
                <Select label="Filtrer par région" value={region} values={watchRegions} onChange={setRegion} />
                <Select label="Filtrer par attention" value={attention} values={["Tous les niveaux", ...attentionLevels]} onChange={(value) => setAttention(value as AttentionLevel | "Tous les niveaux")} />
                <Select label="Filtrer par statut" value={status} values={["Tous les statuts", ...weakSignalStatuses]} onChange={(value) => setStatus(value as WeakSignalStatus | "Tous les statuts")} />
              </div>
            </section>

            <section className="flex flex-wrap gap-2">
              <Action label="Export PDF" icon={<FileDown size={15} />} />
              <Action label="Export Word" icon={<FileText size={15} />} />
              <Action label="Export Excel" icon={<FileSpreadsheet size={15} />} />
              <Action label="Impression" icon={<Printer size={15} />} />
            </section>

            <section className="rounded-lg border border-line bg-panel p-5">
              <p className="text-xs font-semibold uppercase tracking-[0.22em] text-gold">Signaux à surveiller</p>
              <p className="mt-1 text-sm text-neutral-400">Tri automatique : Critique, Élevé, Moyen, Faible.</p>
              <div className="mt-5 space-y-3">
                {filteredSignals.length ? filteredSignals.map((signal) => (
                  <article key={signal.id} className="rounded-md border border-line bg-black/20 p-4">
                    <h2 className="font-semibold text-gold-soft">{signal.title}</h2>
                    <p className="mt-2 text-sm text-neutral-300">{signal.description}</p>
                  </article>
                )) : (
                  <Empty text="Aucun signal faible sourcé disponible. Le module est prêt pour ingestion RSS, API et IA de veille." />
                )}
              </div>
            </section>

            <section className="grid gap-6 lg:grid-cols-2">
              <DashboardPanel title="Signaux par catégorie" rows={stats.byCategory.map((item) => [item.category, String(item.count)])} />
              <DashboardPanel title="Signaux par région" rows={stats.byRegion.map((item) => [item.region, String(item.count)])} />
            </section>

            <section className="rounded-lg border border-line bg-panel p-5">
              <p className="text-xs font-semibold uppercase tracking-[0.22em] text-gold">Timeline stratégique</p>
              <Empty text="La timeline affichera date de détection, évolution, changements de niveau d'attention et commentaires analystes après ajout de signaux vérifiés." />
            </section>
          </div>
        </section>
      </section>
    </main>
  );
}

function Kpi({ title, value }: { title: string; value: string }) {
  return (
    <article className="rounded-lg border border-gold/20 bg-panel p-4">
      <p className="text-xs font-semibold uppercase tracking-[0.16em] text-gold">{title}</p>
      <p className="mt-2 text-2xl font-semibold text-gold-soft">{value}</p>
    </article>
  );
}

function Select({ label, value, values, onChange, disabled = false }: { label: string; value: string; values: string[]; onChange: (value: string) => void; disabled?: boolean }) {
  return (
    <select disabled={disabled} value={value} onChange={(event) => onChange(event.target.value)} aria-label={label} className="rounded-lg border border-line bg-black/25 px-3 py-3 text-sm text-neutral-100 outline-none focus:border-gold disabled:text-neutral-500">
      {values.map((item) => <option key={item}>{item}</option>)}
    </select>
  );
}

function Action({ label, icon }: { label: string; icon: ReactNode }) {
  return (
    <button type="button" className="inline-flex items-center gap-2 rounded-md border border-gold/40 bg-gold/10 px-3 py-2 text-sm font-semibold text-gold-soft">
      {icon}
      {label}
    </button>
  );
}

function DashboardPanel({ title, rows }: { title: string; rows: string[][] }) {
  return (
    <section className="rounded-lg border border-line bg-panel p-5">
      <p className="text-xs font-semibold uppercase tracking-[0.22em] text-gold">{title}</p>
      <div className="mt-4 space-y-2">
        {rows.map(([label, value]) => (
          <div key={label} className="flex justify-between rounded-md border border-line bg-black/20 px-3 py-2 text-sm">
            <span className="text-neutral-300">{label}</span>
            <span className="font-semibold text-gold-soft">{value}</span>
          </div>
        ))}
      </div>
    </section>
  );
}

function Empty({ text }: { text: string }) {
  return <div className="rounded-md border border-line bg-black/20 p-4 text-sm leading-6 text-neutral-400">{text}</div>;
}

function normalize(value: string) {
  return value.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[’']/g, " ").replace(/\s+/g, " ").trim();
}
