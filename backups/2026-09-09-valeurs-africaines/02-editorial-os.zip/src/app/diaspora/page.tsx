import {
  calculateDiasporaInfluenceScore,
  detectDiasporaSignals,
  generateDiasporaBrief,
  generateDiasporaVisualProposals,
  getDiasporaProfiles,
  identifyStrategicInstitutions,
  mapDiasporaNetworks
} from "@/lib/diasporaObserver";

const categories = [
  "chercheurs",
  "scientifiques",
  "ingénieurs",
  "médecins",
  "économistes",
  "juristes",
  "entrepreneurs",
  "investisseurs",
  "diplomates",
  "hauts fonctionnaires",
  "artistes",
  "créateurs culturels",
  "experts tech",
  "professeurs d'université",
  "dirigeants d'entreprise"
];

export default function DiasporaPage() {
  const profiles = getDiasporaProfiles();
  const signals = detectDiasporaSignals();
  const networks = mapDiasporaNetworks();
  const institutions = identifyStrategicInstitutions();
  const brief = generateDiasporaBrief();
  const firstProfile = profiles[0];
  const visualProposals = generateDiasporaVisualProposals(firstProfile);

  const researcherCount = profiles.filter((profile) => /chercheur|scientifique|professeur/.test(profile.categorie)).length;
  const entrepreneurCount = profiles.filter((profile) => profile.categorie === "entrepreneur").length;
  const investorCount = profiles.filter((profile) => profile.categorie === "investisseur").length;
  const countries = new Set(profiles.map((profile) => profile.pays_residence));

  return (
    <main className="mx-auto flex w-full max-w-[1680px] flex-col gap-6 px-5 py-6">
      <section className="rounded-md border border-gold/20 bg-[#111]/80 p-6">
        <p className="text-xs font-semibold uppercase tracking-[0.28em] text-gold">Observatoire permanent</p>
        <div className="mt-3 grid gap-5 lg:grid-cols-[1.5fr_1fr] lg:items-end">
          <div>
            <h1 className="font-serif text-3xl font-bold text-gold-soft md:text-4xl">
              Observatoire de la Diaspora Africaine
            </h1>
            <p className="mt-3 max-w-4xl text-sm leading-6 text-neutral-300">
              Suivi du capital humain africain mondial : chercheurs, entrepreneurs, investisseurs, hauts fonctionnaires,
              créateurs culturels et réseaux d&apos;influence. Les profils restent à vérifier avant toute publication.
            </p>
          </div>
          <div className="rounded-md border border-red-400/30 bg-red-400/10 p-4 text-sm text-red-100">
            Ne jamais inventer diplôme, poste, université, publication, prix ou distinction. Validation humaine obligatoire.
          </div>
        </div>
      </section>

      <section className="grid gap-4 lg:grid-cols-5">
        <Kpi label="Profils suivis" value={profiles.length} />
        <Kpi label="Chercheurs référencés" value={researcherCount} />
        <Kpi label="Entrepreneurs suivis" value={entrepreneurCount} />
        <Kpi label="Investisseurs suivis" value={investorCount} />
        <Kpi label="Pays couverts" value={countries.size} />
      </section>

      <section className="grid gap-6 xl:grid-cols-[1.2fr_1fr]">
        <Panel title="Cartographie mondiale de la diaspora" subtitle="Pays de résidence, réseaux et institutions à vérifier">
          <div className="grid gap-3 sm:grid-cols-2">
            {profiles.map((profile) => (
              <article key={profile.nom} className="rounded-md border border-line bg-black/20 p-4">
                <p className="font-semibold text-neutral-100">{profile.pays_origine} → {profile.pays_residence}</p>
                <p className="mt-1 text-sm text-neutral-400">{profile.domaine}</p>
                <p className="mt-2 text-xs text-neutral-500">{profile.institution}</p>
              </article>
            ))}
          </div>
        </Panel>

        <Panel title="Alertes diaspora" subtitle="Signaux faibles et sources à vérifier">
          <div className="space-y-3">
            {signals.map((signal) => (
              <div key={signal.signal} className="rounded-md border border-amber-400/25 bg-amber-400/10 p-3">
                <p className="font-semibold text-amber-100">{signal.signal}</p>
                <p className="mt-1 text-xs text-amber-200/80">{signal.region} · {signal.horizon} · importance {signal.importance}</p>
              </div>
            ))}
          </div>
        </Panel>
      </section>

      <Panel title="Talents africains à l'international" subtitle="Chercheurs, universitaires, entrepreneurs, investisseurs et hauts fonctionnaires">
        <div className="grid gap-4 xl:grid-cols-3">
          {profiles.map((profile) => {
            const score = calculateDiasporaInfluenceScore(profile);
            return (
              <article key={profile.nom} className="rounded-md border border-line bg-black/20 p-4">
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <h2 className="font-serif text-lg font-semibold text-gold-soft">{profile.nom}</h2>
                    <p className="mt-1 text-sm text-neutral-400">{profile.fonction}</p>
                  </div>
                  <span className="rounded-md border border-gold/30 px-2 py-1 text-xs text-gold">{score.total}/100</span>
                </div>
                <Field label="Pays" value={`${profile.pays_origine} → ${profile.pays_residence}`} />
                <Field label="Domaine" value={profile.domaine} />
                <Field label="Impact Afrique" value={profile.impact_afrique} />
                <Field label="Sources à vérifier" value={profile.sources_a_verifier.join(", ")} />
              </article>
            );
          })}
        </div>
      </Panel>

      <section className="grid gap-6 xl:grid-cols-2">
        <Panel title="Réseaux d'influence" subtitle="Hubs et réseaux structurants">
          <div className="space-y-3">
            {networks.map((network) => (
              <div key={network.network} className="rounded-md border border-line bg-black/20 p-3">
                <p className="font-semibold text-neutral-100">{network.network}</p>
                <p className="mt-1 text-sm text-neutral-400">{network.hubs.join(", ")}</p>
                <p className="mt-1 text-xs text-neutral-500">{network.status}</p>
              </div>
            ))}
          </div>
        </Panel>

        <Panel title="Institutions stratégiques" subtitle="Institutions à cartographier et vérifier">
          <div className="grid gap-3">
            {institutions.map((institution) => (
              <div key={institution} className="rounded-md border border-line bg-black/20 p-3 text-sm text-neutral-300">
                {institution}
              </div>
            ))}
          </div>
        </Panel>
      </section>

      <Panel title="Catégories suivies" subtitle="Base de classification de l'observatoire diaspora">
        <div className="flex flex-wrap gap-2">
          {categories.map((category) => (
            <span key={category} className="rounded-md border border-gold/20 bg-gold/10 px-3 py-2 text-sm text-gold-soft">
              {category}
            </span>
          ))}
        </div>
      </Panel>

      <Panel title="Visuels obligatoires" subtitle="Trois propositions avant publication d'un portrait ou rapport diaspora">
        <div className="grid gap-4 lg:grid-cols-3">
          {visualProposals.map((proposal) => (
            <article key={proposal.option} className="rounded-md border border-line bg-black/20 p-4">
              <p className="text-xs font-semibold uppercase tracking-[0.18em] text-gold">Option {proposal.option}</p>
              <h3 className="mt-2 font-serif text-lg font-semibold text-neutral-100">{proposal.type}</h3>
              <p className="mt-2 text-sm leading-6 text-neutral-400">{proposal.description}</p>
              <p className="mt-3 rounded-md bg-black/30 p-3 text-xs text-neutral-500">{proposal.prompt}</p>
              <p className="mt-2 text-xs text-amber-200">{proposal.rightsNote}</p>
            </article>
          ))}
        </div>
      </Panel>

      <Panel title="Rapport mensuel" subtitle="Format éditorial généré, à relire avant archivage">
        <pre className="max-h-[460px] overflow-auto whitespace-pre-wrap rounded-md bg-black/30 p-4 text-sm leading-6 text-neutral-300">
          {brief}
        </pre>
      </Panel>

      <Panel title="Knowledge Hub / Obsidian" subtitle="Archivage documentaire préparé">
        <div className="grid gap-3 md:grid-cols-4">
          {["knowledge-hub/diaspora", "chercheurs", "entrepreneurs", "investisseurs", "institutions"].map((item) => (
            <div key={item} className="rounded-md border border-line bg-black/20 p-4">
              <p className="font-semibold text-neutral-100">{item}</p>
              <p className="mt-1 text-xs text-neutral-500">Markdown YAML, liens Obsidian, sources à vérifier.</p>
            </div>
          ))}
        </div>
      </Panel>
    </main>
  );
}

function Kpi({ label, value }: { label: string; value: number }) {
  return (
    <div className="rounded-md border border-line bg-[#111]/80 p-4">
      <p className="text-xs font-semibold uppercase tracking-[0.18em] text-neutral-500">{label}</p>
      <p className="mt-2 text-3xl font-bold text-gold-soft">{value}</p>
    </div>
  );
}

function Panel({ title, subtitle, children }: { title: string; subtitle: string; children: React.ReactNode }) {
  return (
    <section className="rounded-md border border-line bg-[#111]/80 p-5">
      <div className="mb-4">
        <h2 className="font-serif text-xl font-semibold text-neutral-100">{title}</h2>
        <p className="mt-1 text-sm text-neutral-500">{subtitle}</p>
      </div>
      {children}
    </section>
  );
}

function Field({ label, value }: { label: string; value: string }) {
  return (
    <div className="mt-3">
      <p className="text-[11px] font-semibold uppercase tracking-[0.18em] text-neutral-500">{label}</p>
      <p className="mt-1 text-sm leading-6 text-neutral-300">{value}</p>
    </div>
  );
}
