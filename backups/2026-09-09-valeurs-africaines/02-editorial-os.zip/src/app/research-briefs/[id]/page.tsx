import Link from "next/link";
import { Archive, Copy, FileDown, FileText, Printer } from "lucide-react";
import type { ReactNode } from "react";
import { getResearchBriefById } from "@/lib/researchBriefLibrary";

type PageProps = {
  params: Promise<{ id: string }>;
};

export default async function ResearchBriefDetailPage({ params }: PageProps) {
  const { id } = await params;
  const brief = getResearchBriefById(id);

  return (
    <main className="min-h-screen bg-ink px-5 py-8 text-neutral-100">
      <section className="mx-auto max-w-5xl space-y-6">
        <header className="flex items-start justify-between gap-5 border-b border-line pb-5 max-lg:grid">
          <div>
            <p className="text-xs font-semibold uppercase tracking-[0.24em] text-gold">Centre de Recherche</p>
            <h1 className="mt-3 text-3xl font-semibold text-gold-soft">{brief?.title ?? "Research Brief introuvable"}</h1>
            <p className="mt-2 max-w-3xl text-sm leading-6 text-neutral-400">
              Page détaillée Research Brief. Validation humaine obligatoire avant publication.
            </p>
          </div>
          <Link href="/research-briefs" className="rounded-md border border-gold/40 bg-gold/10 px-4 py-2 text-sm font-semibold text-gold-soft transition hover:bg-gold/20">
            Retour bibliothèque
          </Link>
        </header>

        {brief ? (
          <article className="rounded-lg border border-line bg-panel p-6">
            <div className="flex flex-wrap gap-2">
              <ActionButton icon={<FileDown size={15} />} label="Export PDF" />
              <ActionButton icon={<FileText size={15} />} label="Export Word" />
              <ActionButton icon={<Printer size={15} />} label="Imprimer" />
              <ActionButton icon={<Copy size={15} />} label="Dupliquer" />
              <ActionButton icon={<Archive size={15} />} label="Archiver" />
            </div>
            <div className="mt-6 space-y-5 text-sm leading-6 text-neutral-300">
              <Section title="Résumé exécutif">{brief.executiveSummary}</Section>
              <Section title="Contexte">{brief.context}</Section>
              <Section title="Acteurs clés"><List values={brief.keyActors} /></Section>
              <Section title="Analyse stratégique">{brief.strategicAnalysis}</Section>
              <Section title="Conséquences pour l'Afrique">{brief.africaConsequences}</Section>
              <Section title="Points à surveiller"><List values={brief.monitoringPoints} /></Section>
              <Section title="Sources à vérifier"><List values={brief.sourcesToVerify} /></Section>
              <Section title="Conclusion stratégique">{brief.strategicConclusion}</Section>
            </div>
          </article>
        ) : (
          <section className="rounded-lg border border-line bg-panel p-6 text-sm leading-6 text-neutral-300">
            Aucun Research Brief sourcé ne correspond à l'identifiant `{id}`. Aucun contenu fictif n'a été généré.
          </section>
        )}
      </section>
    </main>
  );
}

function ActionButton({ icon, label }: { icon: ReactNode; label: string }) {
  return (
    <button type="button" className="inline-flex items-center gap-2 rounded-md border border-gold/40 bg-black/20 px-3 py-2 text-xs font-semibold text-gold-soft transition hover:border-gold hover:bg-gold/10">
      {icon}
      {label}
    </button>
  );
}

function Section({ title, children }: { title: string; children: ReactNode }) {
  return (
    <section>
      <h2 className="text-sm font-semibold uppercase tracking-[0.18em] text-gold">{title}</h2>
      <div className="mt-2">{children}</div>
    </section>
  );
}

function List({ values }: { values: string[] }) {
  return (
    <ul className="list-inside list-disc space-y-1">
      {values.map((value) => <li key={value}>{value}</li>)}
    </ul>
  );
}
