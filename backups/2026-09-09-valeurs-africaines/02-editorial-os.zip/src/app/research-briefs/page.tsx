"use client";

import Link from "next/link";
import { Archive, Copy, FileDown, FileText, Printer, Search } from "lucide-react";
import type { ReactNode } from "react";
import { useMemo, useState } from "react";
import {
  getResearchBriefs,
  getResearchDashboardStats,
  researchBriefCategories,
  researchBriefCountries,
  researchBriefRegions,
  researchBriefStatuses,
  researchBriefTags,
  type ResearchBriefCategory,
  type ResearchBriefPriority,
  type ResearchBriefRecord,
  type ResearchBriefStatus
} from "@/lib/researchBriefLibrary";
import { formatDisplayDate } from "@/lib/dateDisplay";

const briefs = getResearchBriefs();
const stats = getResearchDashboardStats();
const priorities: Array<ResearchBriefPriority | "Toutes les priorités"> = ["Toutes les priorités", "Faible", "Moyenne", "Haute", "Critique", "À vérifier"];

export default function ResearchBriefLibraryPage() {
  const [view, setView] = useState<"cards" | "table">("cards");
  const [query, setQuery] = useState("");
  const [category, setCategory] = useState<ResearchBriefCategory | "Toutes les catégories">("Toutes les catégories");
  const [region, setRegion] = useState("Toutes les régions");
  const [country, setCountry] = useState("Tous les pays");
  const [date, setDate] = useState("");
  const [priority, setPriority] = useState<ResearchBriefPriority | "Toutes les priorités">("Toutes les priorités");
  const [status, setStatus] = useState<ResearchBriefStatus | "Tous les statuts">("Tous les statuts");
  const [selectedId, setSelectedId] = useState<string | null>(briefs[0]?.id ?? null);

  const filteredBriefs = useMemo(() => {
    const normalizedQuery = normalize(query);
    return briefs.filter((brief) => {
      const categoryMatch = category === "Toutes les catégories" || brief.category === category;
      const regionMatch = region === "Toutes les régions" || brief.region === region;
      const countryMatch = country === "Tous les pays" || brief.countries.includes(country);
      const dateMatch = !date || brief.date === date;
      const priorityMatch = priority === "Toutes les priorités" || brief.priority === priority;
      const statusMatch = status === "Tous les statuts" || brief.status === status;
      const queryMatch = !normalizedQuery || normalize([
        brief.title,
        brief.executiveSummary,
        brief.author,
        brief.category,
        brief.region,
        brief.countries.join(" "),
        brief.tags.join(" ")
      ].join(" ")).includes(normalizedQuery);
      return categoryMatch && regionMatch && countryMatch && dateMatch && priorityMatch && statusMatch && queryMatch;
    });
  }, [category, country, date, priority, query, region, status]);

  const selectedBrief = filteredBriefs.find((brief) => brief.id === selectedId) ?? filteredBriefs[0] ?? null;

  return (
    <main className="min-h-screen bg-ink px-5 py-8 text-neutral-100">
      <section className="mx-auto max-w-7xl space-y-6">
        <header className="border-b border-line pb-5">
          <p className="text-xs font-semibold uppercase tracking-[0.24em] text-gold">Centre de Recherche</p>
          <h1 className="mt-3 text-3xl font-semibold text-gold-soft">Research Brief Library</h1>
          <p className="mt-2 max-w-4xl text-sm leading-6 text-neutral-400">
            Bibliothèque centrale des Research Briefs Valeurs Africaines. Aucun brief n'est préchargé sans source et validation humaine.
          </p>
        </header>

        <section className="grid gap-4 md:grid-cols-5">
          <Kpi title="Total briefs" value={String(stats.total)} />
          <Kpi title="Catégories" value={String(researchBriefCategories.length)} />
          <Kpi title="Publiés ce mois" value={String(stats.publishedThisMonth)} />
          <Kpi title="En validation" value={String(stats.pendingValidation)} />
          <Kpi title="Statuts" value={String(researchBriefStatuses.length)} />
        </section>

        <section className="rounded-lg border border-line bg-panel p-4">
          <div className="grid gap-3 xl:grid-cols-[minmax(0,1fr)_220px_190px_190px]">
            <label className="group flex items-center gap-3 rounded-lg border border-gold/20 bg-black/25 px-4 py-3 transition focus-within:border-gold focus-within:shadow-[0_0_0_3px_rgba(214,170,77,0.12)]">
              <Search size={18} className="text-gold" aria-hidden="true" />
              <span className="sr-only">Recherche plein texte Research Briefs</span>
              <input
                type="search"
                value={query}
                onChange={(event) => setQuery(event.target.value)}
                aria-label="Recherche plein texte Research Briefs"
                placeholder="Rechercher titre, résumé, pays, acteur, tag..."
                className="h-9 w-full bg-transparent text-sm text-neutral-100 outline-none placeholder:text-neutral-500"
              />
            </label>
            <Select label="Filtrer par catégorie" value={category} values={["Toutes les catégories", ...researchBriefCategories]} onChange={(value) => setCategory(value as ResearchBriefCategory | "Toutes les catégories")} />
            <Select label="Filtrer par région" value={region} values={researchBriefRegions} onChange={setRegion} />
            <Select label="Filtrer par pays" value={country} values={researchBriefCountries} onChange={setCountry} />
          </div>
          <div className="mt-3 grid gap-3 lg:grid-cols-[180px_220px_190px_minmax(0,1fr)]">
            <input
              type="date"
              value={date}
              onChange={(event) => setDate(event.target.value)}
              aria-label="Filtrer par date"
              className="rounded-lg border border-line bg-black/25 px-3 py-3 text-sm text-neutral-100 outline-none focus:border-gold"
            />
            <Select label="Filtrer par niveau d'importance" value={priority} values={priorities} onChange={(value) => setPriority(value as ResearchBriefPriority | "Toutes les priorités")} />
            <Select label="Filtrer par statut" value={status} values={["Tous les statuts", ...researchBriefStatuses]} onChange={(value) => setStatus(value as ResearchBriefStatus | "Tous les statuts")} />
            <div className="flex flex-wrap items-center justify-end gap-2 max-lg:justify-start">
              <button type="button" onClick={() => setView("cards")} className={viewButton(view === "cards")}>Vue cartes</button>
              <button type="button" onClick={() => setView("table")} className={viewButton(view === "table")}>Vue tableau</button>
            </div>
          </div>
        </section>

        <section className="grid gap-6 xl:grid-cols-[minmax(0,1fr)_420px]">
          <div className="space-y-6">
            <ResearchDashboard />
            {view === "cards" ? <CardsView briefs={filteredBriefs} onSelect={setSelectedId} /> : <TableView briefs={filteredBriefs} onSelect={setSelectedId} />}
            <TagSystem />
          </div>
          <BriefDetail brief={selectedBrief} />
        </section>
      </section>
    </main>
  );
}

function ResearchDashboard() {
  return (
    <section className="grid gap-4 lg:grid-cols-2">
      <DashboardPanel title="Briefs par catégorie" rows={stats.byCategory.map((item) => [item.category, String(item.count)])} />
      <DashboardPanel title="Briefs par région" rows={stats.byRegion.map((item) => [item.region, String(item.count)])} />
    </section>
  );
}

function CardsView({ briefs, onSelect }: { briefs: ResearchBriefRecord[]; onSelect: (id: string) => void }) {
  if (!briefs.length) return <EmptyState />;
  return (
    <section className="grid gap-4 lg:grid-cols-2">
      {briefs.map((brief) => (
        <article key={brief.id} className="rounded-lg border border-gold/20 bg-panel p-5">
          <p className="text-xs font-semibold uppercase tracking-[0.2em] text-gold">{brief.category}</p>
          <h2 className="mt-2 text-xl font-semibold text-gold-soft">{brief.title}</h2>
          <p className="mt-2 text-sm leading-6 text-neutral-300">{brief.executiveSummary}</p>
          <dl className="mt-4 grid gap-2 text-sm sm:grid-cols-2">
            <Meta label="Date" value={formatDisplayDate(brief.date)} />
            <Meta label="Auteur" value={brief.author} />
            <Meta label="Pays" value={brief.countries.join(", ")} />
            <Meta label="Priorité" value={brief.priority} />
          </dl>
          <button type="button" onClick={() => onSelect(brief.id)} className="mt-4 rounded-md border border-gold/40 bg-gold/10 px-3 py-2 text-sm font-semibold text-gold-soft">
            Ouvrir
          </button>
        </article>
      ))}
    </section>
  );
}

function TableView({ briefs, onSelect }: { briefs: ResearchBriefRecord[]; onSelect: (id: string) => void }) {
  return (
    <section className="overflow-x-auto rounded-lg border border-line bg-panel">
      <table className="w-full min-w-[900px] border-collapse text-sm">
        <thead>
          <tr className="border-b border-line text-left text-xs uppercase tracking-[0.16em] text-neutral-500">
            <th className="px-4 py-3">Titre</th>
            <th className="px-4 py-3">Catégorie</th>
            <th className="px-4 py-3">Pays</th>
            <th className="px-4 py-3">Date</th>
            <th className="px-4 py-3">Priorité</th>
            <th className="px-4 py-3">Statut</th>
          </tr>
        </thead>
        <tbody>
          {briefs.map((brief) => (
            <tr key={brief.id} className="border-b border-line/70 text-neutral-300">
              <td className="px-4 py-3">
                <button type="button" onClick={() => onSelect(brief.id)} className="font-semibold text-neutral-100 hover:text-gold-soft">
                  {brief.title}
                </button>
              </td>
              <td className="px-4 py-3">{brief.category}</td>
              <td className="px-4 py-3">{brief.countries.join(", ")}</td>
              <td className="px-4 py-3">{formatDisplayDate(brief.date)}</td>
              <td className="px-4 py-3">{brief.priority}</td>
              <td className="px-4 py-3">{brief.status}</td>
            </tr>
          ))}
          {!briefs.length ? (
            <tr>
              <td colSpan={6} className="px-4 py-8 text-neutral-400">Aucun Research Brief sourcé disponible.</td>
            </tr>
          ) : null}
        </tbody>
      </table>
    </section>
  );
}

function BriefDetail({ brief }: { brief: ResearchBriefRecord | null }) {
  return (
    <aside className="rounded-lg border border-gold/30 bg-gold/10 p-5">
      <p className="text-xs font-semibold uppercase tracking-[0.22em] text-gold">Page détaillée</p>
      <div className="mt-4 flex flex-wrap gap-2">
        <ActionButton icon={<FileDown size={15} />} label="Export PDF" />
        <ActionButton icon={<FileText size={15} />} label="Export Word" />
        <ActionButton icon={<Printer size={15} />} label="Imprimer" />
        <ActionButton icon={<Copy size={15} />} label="Dupliquer" />
        <ActionButton icon={<Archive size={15} />} label="Archiver" />
      </div>
      {brief ? (
        <>
          <h2 className="mt-2 text-2xl font-semibold text-gold-soft">{brief.title}</h2>
          <div className="mt-5 space-y-4 text-sm text-neutral-300">
            <Section title="Résumé exécutif">{brief.executiveSummary}</Section>
            <Section title="Contexte">{brief.context}</Section>
            <Section title="Acteurs clés"><List values={brief.keyActors} /></Section>
            <Section title="Analyse stratégique">{brief.strategicAnalysis}</Section>
            <Section title="Conséquences pour l'Afrique">{brief.africaConsequences}</Section>
            <Section title="Points à surveiller"><List values={brief.monitoringPoints} /></Section>
            <Section title="Sources à vérifier"><List values={brief.sourcesToVerify} /></Section>
            <Section title="Conclusion stratégique">{brief.strategicConclusion}</Section>
          </div>
        </>
      ) : (
        <div className="mt-4 rounded-md border border-line bg-black/20 p-4 text-sm leading-6 text-neutral-300">
          Aucun brief sélectionné. La fiche détaillée sera disponible lorsqu'un Research Brief sourcé sera ajouté à la bibliothèque.
        </div>
      )}
    </aside>
  );
}

function TagSystem() {
  return (
    <section className="rounded-lg border border-line bg-panel p-5">
      <p className="text-xs font-semibold uppercase tracking-[0.22em] text-gold">Système de tags</p>
      <div className="mt-4 flex flex-wrap gap-2">
        {researchBriefTags.map((tag) => (
          <span key={tag} className="rounded-md border border-line bg-black/20 px-3 py-2 text-sm text-neutral-300">
            {tag}
          </span>
        ))}
      </div>
    </section>
  );
}

function DashboardPanel({ title, rows }: { title: string; rows: string[][] }) {
  return (
    <section className="rounded-lg border border-line bg-panel p-5">
      <p className="text-xs font-semibold uppercase tracking-[0.22em] text-gold">{title}</p>
      <div className="mt-4 space-y-2">
        {rows.map(([label, value]) => (
          <div key={label} className="flex items-center justify-between rounded-md border border-line bg-black/20 px-3 py-2 text-sm">
            <span className="text-neutral-300">{label}</span>
            <span className="font-semibold text-gold-soft">{value}</span>
          </div>
        ))}
      </div>
    </section>
  );
}

function EmptyState() {
  return (
    <section className="rounded-lg border border-line bg-panel p-6 text-sm leading-6 text-neutral-300">
      Aucun Research Brief n'est affiché sans source vérifiée. La bibliothèque est prête pour l'import depuis le Knowledge Hub, les Notes Pays et les workflows de validation.
    </section>
  );
}

function Kpi({ title, value }: { title: string; value: string }) {
  return (
    <article className="rounded-lg border border-gold/20 bg-panel p-5">
      <p className="text-xs font-semibold uppercase tracking-[0.18em] text-gold">{title}</p>
      <p className="mt-2 text-2xl font-semibold text-gold-soft">{value}</p>
      <p className="mt-1 text-sm text-neutral-400">Validation humaine obligatoire</p>
    </article>
  );
}

function Select({ label, value, values, onChange }: { label: string; value: string; values: string[]; onChange: (value: string) => void }) {
  return (
    <select value={value} onChange={(event) => onChange(event.target.value)} aria-label={label} className="rounded-lg border border-line bg-black/25 px-3 py-3 text-sm text-neutral-100 outline-none focus:border-gold">
      {values.map((item) => <option key={item}>{item}</option>)}
    </select>
  );
}

function ActionButton({ icon, label }: { icon: ReactNode; label: string }) {
  return (
    <button type="button" className="inline-flex items-center gap-2 rounded-md border border-gold/40 bg-black/20 px-3 py-2 text-xs font-semibold text-gold-soft transition hover:border-gold hover:bg-gold/10">
      {icon}
      {label}
    </button>
  );
}

function Section({ title, children }: { title: string; children: ReactNode }) {
  return (
    <section>
      <h3 className="text-xs font-semibold uppercase tracking-[0.18em] text-gold">{title}</h3>
      <div className="mt-2 leading-6">{children}</div>
    </section>
  );
}

function Meta({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-md border border-line bg-black/20 p-3">
      <dt className="text-xs uppercase tracking-wide text-neutral-500">{label}</dt>
      <dd className="mt-1 font-medium text-neutral-200">{value}</dd>
    </div>
  );
}

function List({ values }: { values: string[] }) {
  return (
    <ul className="list-inside list-disc space-y-1">
      {values.map((value) => <li key={value}>{value}</li>)}
    </ul>
  );
}

function viewButton(active: boolean) {
  return `rounded-md border px-3 py-2 text-sm font-semibold transition ${
    active ? "border-gold bg-gold/15 text-gold-soft" : "border-line bg-black/20 text-neutral-300 hover:border-gold/50"
  }`;
}

function normalize(value: string) {
  return value
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[’']/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}
