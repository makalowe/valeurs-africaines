export type DiasporaCategory =
  | "chercheur"
  | "scientifique"
  | "ingénieur"
  | "médecin"
  | "économiste"
  | "juriste"
  | "entrepreneur"
  | "investisseur"
  | "diplomate"
  | "haut fonctionnaire"
  | "artiste"
  | "créateur culturel"
  | "expert tech"
  | "professeur d'université"
  | "dirigeant d'entreprise";

export type DiasporaProfile = {
  nom: string;
  pays_origine: string;
  pays_residence: string;
  domaine: string;
  institution: string;
  fonction: string;
  impact_afrique: string;
  sources_a_verifier: string[];
  niveau_confiance: "faible" | "moyen" | "élevé";
  categorie: DiasporaCategory;
};

export type DiasporaInfluenceScore = {
  total: number;
  contributionScientifique: number;
  contributionEconomique: number;
  investissementAfrique: number;
  influenceInstitutionnelle: number;
  transfertCompetences: number;
  impactNarratif: number;
  developpementDurable: number;
};

export type DiasporaSignal = {
  signal: string;
  region: string;
  importance: "faible" | "moyenne" | "élevée";
  horizon: string;
  sources_a_verifier: string[];
};

const profiles: DiasporaProfile[] = [
  {
    nom: "Profil diaspora à documenter - IA médicale",
    pays_origine: "Sénégal",
    pays_residence: "Canada",
    domaine: "intelligence artificielle et santé",
    institution: "université à vérifier",
    fonction: "chercheur ou chercheuse à vérifier",
    impact_afrique: "potentiel transfert de compétences en santé numérique et formation scientifique.",
    sources_a_verifier: ["profil institutionnel", "publications académiques", "entretien ou source officielle"],
    niveau_confiance: "faible",
    categorie: "chercheur"
  },
  {
    nom: "Profil diaspora à documenter - capital-risque",
    pays_origine: "Nigeria",
    pays_residence: "États-Unis",
    domaine: "financement des startups africaines",
    institution: "fonds d'investissement à vérifier",
    fonction: "investisseur ou dirigeant à vérifier",
    impact_afrique: "mobilisation potentielle de capitaux, mentorat et accès aux marchés internationaux.",
    sources_a_verifier: ["registre du fonds", "communiqués d'investissement", "médias économiques vérifiés"],
    niveau_confiance: "faible",
    categorie: "investisseur"
  },
  {
    nom: "Profil diaspora à documenter - gouvernance internationale",
    pays_origine: "Ghana",
    pays_residence: "Suisse",
    domaine: "politiques publiques internationales",
    institution: "organisation internationale à vérifier",
    fonction: "haut fonctionnaire à vérifier",
    impact_afrique: "influence potentielle sur les normes internationales et les programmes de développement.",
    sources_a_verifier: ["biographie officielle", "organigramme institutionnel", "discours ou rapport public"],
    niveau_confiance: "faible",
    categorie: "haut fonctionnaire"
  }
];

export function getDiasporaProfiles(): DiasporaProfile[] {
  console.info("[diasporaObserver] Reading mocked diaspora profiles. All identities remain marked as profiles to verify.");
  return profiles;
}

export function classifyDiasporaProfile(profile: Pick<DiasporaProfile, "domaine" | "fonction">): DiasporaCategory {
  const text = `${profile.domaine} ${profile.fonction}`.toLowerCase();
  if (/invest/.test(text)) return "investisseur";
  if (/entrepreneur|startup|fondateur/.test(text)) return "entrepreneur";
  if (/université|professeur|recherche|chercheur|science/.test(text)) return "chercheur";
  if (/médec|santé/.test(text)) return "médecin";
  if (/juridique|droit|juriste/.test(text)) return "juriste";
  if (/diplomat/.test(text)) return "diplomate";
  if (/organisation internationale|haut fonctionnaire/.test(text)) return "haut fonctionnaire";
  if (/tech|ia|numérique/.test(text)) return "expert tech";
  return "dirigeant d'entreprise";
}

export function calculateDiasporaInfluenceScore(profile: DiasporaProfile): DiasporaInfluenceScore {
  const science = /chercheur|scientifique|professeur|médecin|ingénieur|expert tech/.test(profile.categorie) ? 18 : 8;
  const economy = /entrepreneur|investisseur|dirigeant/.test(profile.categorie) ? 18 : 7;
  const institution = /haut fonctionnaire|diplomate|juriste/.test(profile.categorie) ? 16 : 6;
  const transfer = profile.impact_afrique.toLowerCase().includes("transfert") ? 14 : 8;
  const narrative = /culture|influence|normes|formation/.test(profile.impact_afrique.toLowerCase()) ? 12 : 7;
  const sustainable = /développement|santé|formation|capitaux/.test(profile.impact_afrique.toLowerCase()) ? 10 : 5;
  const investment = /capitaux|investissement|marchés/.test(profile.impact_afrique.toLowerCase()) ? 15 : 6;

  return {
    total: Math.min(100, science + economy + institution + transfer + narrative + sustainable + investment),
    contributionScientifique: science,
    contributionEconomique: economy,
    investissementAfrique: investment,
    influenceInstitutionnelle: institution,
    transfertCompetences: transfer,
    impactNarratif: narrative,
    developpementDurable: sustainable
  };
}

export function detectDiasporaSignals(): DiasporaSignal[] {
  return [
    {
      signal: "hausse des fonds diaspora orientés startups africaines",
      region: "Amérique du Nord - Afrique de l'Ouest",
      importance: "élevée",
      horizon: "6-12 mois",
      sources_a_verifier: ["fonds d'investissement", "bases de levées de fonds", "communiqués startups"]
    },
    {
      signal: "structuration de réseaux scientifiques africains dans les universités européennes",
      region: "Europe",
      importance: "moyenne",
      horizon: "12 mois",
      sources_a_verifier: ["universités", "associations académiques", "conférences scientifiques"]
    }
  ];
}

export function generateDiasporaPortrait(profile: DiasporaProfile): string {
  return `# Portrait diaspora - ${profile.nom}

Pays d'origine : ${profile.pays_origine}
Pays de résidence : ${profile.pays_residence}
Institution : ${profile.institution}
Fonction : ${profile.fonction}
Domaine : ${profile.domaine}

## Parcours
Données à vérifier auprès de sources institutionnelles.

## Contributions
Faits confirmés à établir avant publication. Aucun diplôme, poste, prix ou publication ne doit être ajouté sans source.

## Impact pour l'Afrique
${profile.impact_afrique}

## Sources à vérifier
${profile.sources_a_verifier.map((source) => `- ${source}`).join("\n")}

## Conclusion stratégique
Profil à documenter comme actif potentiel du capital humain africain mondial.

Validation humaine obligatoire. Aucune publication automatique.`;
}

export function mapDiasporaNetworks() {
  return [
    { network: "réseaux scientifiques", hubs: ["Canada", "France", "Royaume-Uni"], status: "à documenter" },
    { network: "réseaux investisseurs", hubs: ["États-Unis", "Royaume-Uni", "Émirats arabes unis"], status: "à vérifier" },
    { network: "institutions internationales", hubs: ["Suisse", "États-Unis", "Kenya"], status: "à documenter" }
  ];
}

export function identifyStrategicInstitutions(): string[] {
  return [
    "universités de recherche à vérifier",
    "organisations internationales",
    "fonds d'investissement diaspora",
    "réseaux scientifiques africains",
    "incubateurs et hubs technologiques"
  ];
}

export function generateDiasporaBrief(): string {
  return `# Observatoire de la Diaspora Africaine

## Résumé exécutif
La diaspora africaine constitue un capital humain, scientifique, économique et narratif stratégique. Les données doivent être vérifiées avant publication.

## Tendances du mois
- mobilisation scientifique à documenter ;
- investissement diaspora à vérifier ;
- influence institutionnelle à cartographier.

## Talents à suivre
Profils à valider par sources institutionnelles.

## Réseaux d'influence
Réseaux universitaires, investisseurs, organisations internationales et hubs technologiques.

## Contributions économiques
Données à vérifier.

## Contributions scientifiques
Publications, laboratoires et postes à confirmer.

## Impact pour l'Afrique
Transfert de compétences, capitaux, normes, souveraineté narrative et innovation.

## Signaux faibles
${detectDiasporaSignals().map((signal) => `- ${signal.signal}`).join("\n")}

## Sources à vérifier
- biographies officielles ;
- publications académiques ;
- registres institutionnels ;
- communiqués d'investissement.

## Conclusion stratégique
L'observatoire doit transformer la diaspora en base de connaissance stratégique sans inventer de faits.

Validation humaine obligatoire. Aucune publication automatique.`;
}

export function exportDiasporaToKnowledgeHub(profile: DiasporaProfile): string {
  return `---
type: diaspora-profile
nom: ${profile.nom}
pays_origine: ${profile.pays_origine}
pays_residence: ${profile.pays_residence}
domaine: ${profile.domaine}
institution: ${profile.institution}
fonction: ${profile.fonction}
themes:
  - Diaspora africaine
  - Capital humain africain
impact_afrique: ${profile.impact_afrique}
sources:
${profile.sources_a_verifier.map((source) => `  - ${source}`).join("\n")}
fiabilite: ${profile.niveau_confiance}
date: ${new Date().toISOString().slice(0, 10)}
---

[[Diaspora africaine]]
[[${profile.pays_origine}]]
[[${profile.pays_residence}]]
[[${profile.institution}]]
[[${profile.domaine}]]
[[Innovation]]
[[Capital humain africain]]

${generateDiasporaPortrait(profile)}`;
}

export function generateDiasporaVisualProposals(profile: DiasporaProfile) {
  return [
    {
      option: "A",
      type: "Portrait photographique institutionnel",
      description: "Photo officielle ou institutionnelle, droits à vérifier avant publication.",
      prompt: `portrait institutionnel sobre de ${profile.nom}, contexte ${profile.domaine}, style magazine think tank`,
      rightsNote: "Vérifier les droits d'utilisation avant publication."
    },
    {
      option: "B",
      type: "Illustration éditoriale premium",
      description: "Illustration sobre valorisant capital humain africain, recherche, innovation et influence.",
      prompt: `illustration éditoriale premium sur la diaspora africaine, ${profile.domaine}, palette noir or blanc, magazine stratégique`,
      rightsNote: "Illustration générable après validation humaine."
    },
    {
      option: "C",
      type: "Carte des flux diaspora Afrique ↔ monde",
      description: "Carte ou diagramme d'influence reliant pays d'origine, pays de résidence, institution et impact Afrique.",
      prompt: `diagramme d'influence diaspora reliant ${profile.pays_origine}, ${profile.pays_residence}, ${profile.institution} et impact pour l'Afrique`,
      rightsNote: "Graphique interne basé sur données vérifiées uniquement."
    }
  ];
}
