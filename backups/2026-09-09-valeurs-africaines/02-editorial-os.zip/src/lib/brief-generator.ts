import { generateWeeklyAfrica2030Report } from "./africa2030";
import { generateCountryBrief, getCountryProfile } from "./atlas";
import { generateBusinessDraft } from "./business";
import { generateMonthlyConflictBrief, getConflictZones } from "./conflictObserver";
import { generatePortraitKnowledgeMarkdown, type PortraitInput } from "./portraits";
import { generateMorningBrief } from "./radar";

export type BriefInput = {
  title: string;
  subject?: string;
  country?: string;
  actors?: string[];
  sources?: string[];
};

export type GeneratedBrief = {
  format: string;
  title: string;
  content: string;
  sources_a_verifier: string[];
  citations_obligatoires: string[];
  validation_humaine_requise: true;
  publication_automatique: false;
};

function wrapBrief(format: string, title: string, content: string, sources?: string[]): GeneratedBrief {
  const checkedSources = sources?.length ? sources : ["sources à vérifier"];
  return {
    format,
    title,
    content: [
      content,
      "",
      "## Séparation faits / analyse",
      "- Faits confirmés : à documenter avec sources vérifiées.",
      "- Analyse : interprétation éditoriale Valeurs Africaines.",
      "- Hypothèses : à signaler explicitement.",
      "",
      "## Citations obligatoires",
      checkedSources.map((source) => `- ${source}`).join("\n"),
      "",
      "Validation humaine obligatoire. Aucune publication automatique."
    ].join("\n"),
    sources_a_verifier: checkedSources,
    citations_obligatoires: checkedSources,
    validation_humaine_requise: true,
    publication_automatique: false
  };
}

export async function generateResearchBrief(input: BriefInput): Promise<GeneratedBrief> {
  const actors = input.actors?.join(", ") || "acteurs à vérifier";
  return wrapBrief("Research Brief", input.title, [
    `# ${input.title}`,
    "",
    "## Résumé exécutif",
    input.subject || "Sujet à documenter.",
    "",
    "## Contexte",
    "Contexte à établir à partir du Radar Afrique, Knowledge Hub et sources vérifiées.",
    "",
    "## Acteurs",
    actors,
    "",
    "## Analyse",
    "Analyse stratégique à produire en distinguant faits et interprétations.",
    "",
    "## Scénarios",
    "- Scénario central",
    "- Scénario de rupture",
    "- Scénario d'opportunité africaine",
    "",
    "## Conséquences pour l’Afrique",
    "Impact Afrique à évaluer.",
    "",
    "## Recommandations",
    "Recommandations éditoriales à valider humainement.",
    "",
    "## Sources à vérifier",
    (input.sources?.length ? input.sources : ["sources à vérifier"]).map((source) => `- ${source}`).join("\n")
  ].join("\n"), input.sources);
}

export async function generateCountryNote(input: BriefInput): Promise<GeneratedBrief> {
  const profile = input.country ? await getCountryProfile(input.country) : null;
  const content = profile ? generateCountryBrief(profile) : "# Note Pays\n\nPays à vérifier.\n\n## Synthèse\n\n## Politique\n\n## Économie\n\n## Géopolitique\n\n## Sécurité\n\n## Innovation\n\n## ODD\n\n## Agenda 2063\n\n## Opportunités\n\n## Risques";
  return wrapBrief("Note Pays", input.title || `Note Pays — ${input.country ?? "pays à vérifier"}`, content, input.sources);
}

export async function generateStrategicDossier(input: BriefInput): Promise<GeneratedBrief> {
  return wrapBrief("Dossier stratégique", input.title, [
    `# ${input.title}`,
    "",
    "## Problématique",
    input.subject || "Problématique à préciser.",
    "",
    "## Contexte historique",
    "Chronologie et antécédents à vérifier.",
    "",
    "## Acteurs",
    input.actors?.join(", ") || "acteurs à vérifier",
    "",
    "## Intérêts",
    "Intérêts politiques, économiques, sécuritaires et narratifs.",
    "",
    "## Rapport de force",
    "Rapports de force à documenter.",
    "",
    "## Scénarios",
    "- continuité",
    "- bascule",
    "- recomposition",
    "",
    "## Perspectives africaines",
    "Lecture souveraine et stratégique pour le continent."
  ].join("\n"), input.sources);
}

export async function generateWeakSignalsReport(input: BriefInput): Promise<GeneratedBrief> {
  const radar = await generateMorningBrief();
  const signals = radar.top5SignauxFaibles.map((topic) => `- ${topic.title} : horizon à vérifier, impact ${topic.scoreVA}/100, attention ${topic.urgency}`).join("\n");
  return wrapBrief("Signaux faibles", input.title || "Signaux faibles", `# Signaux faibles\n\n## Description\n${signals}\n\n## Horizon\nÀ qualifier.\n\n## Impact\nÀ mesurer.\n\n## Niveau d’attention\nÀ valider.`, input.sources);
}

export async function generateConflictReport(input: BriefInput): Promise<GeneratedBrief> {
  const zones = await getConflictZones();
  return wrapBrief("Rapport conflit", input.title || "Observatoire des Conflits — Afrique", generateMonthlyConflictBrief(zones), input.sources);
}

export async function generateSDGProgressReport(input: BriefInput): Promise<GeneratedBrief> {
  return wrapBrief("Rapport ODD", input.title || "Afrique 2030 – État d'avancement", generateWeeklyAfrica2030Report(), input.sources);
}

export async function generateAgenda2063Report(input: BriefInput): Promise<GeneratedBrief> {
  return wrapBrief("Rapport Agenda 2063", input.title || "Agenda 2063 – Suivi stratégique", [
    "# Agenda 2063 – Suivi stratégique",
    "",
    "## Aspirations concernées",
    "À vérifier selon les sources Union africaine.",
    "",
    "## Avancées observables",
    "Résultats à documenter.",
    "",
    "## Retards et risques",
    "Écarts de mise en œuvre à analyser.",
    "",
    "## Perspectives africaines",
    "Lecture stratégique Valeurs Africaines."
  ].join("\n"), input.sources ?? ["Union africaine", "rapports Agenda 2063"]);
}

export async function generateResearchPortrait(input: BriefInput & Partial<PortraitInput>): Promise<GeneratedBrief> {
  const portraitInput: PortraitInput = {
    nom: input.title,
    pays: input.country ?? "à vérifier",
    domaine: input.subject ?? "à vérifier",
    institution: "à vérifier",
    fonction: "à vérifier",
    sources: input.sources ?? []
  };
  return wrapBrief("Portrait chercheur", input.title, generatePortraitKnowledgeMarkdown(portraitInput), input.sources);
}

export async function generateBusinessAnalysis(input: BriefInput): Promise<GeneratedBrief> {
  const business = generateBusinessDraft({
    sujet: input.subject || input.title,
    format: "Analyse de marché",
    secteur: "à vérifier",
    pays: input.country ?? "Afrique",
    acteurs: input.actors ?? [],
    sources: input.sources ?? []
  });
  return wrapBrief("Analyse économique", input.title, business.draft, business.sources_a_verifier);
}

export async function generateInnovationWatch(input: BriefInput): Promise<GeneratedBrief> {
  const radar = await generateMorningBrief();
  const innovation = radar.top10Sujets.filter((topic) => /innovation|technologie|ia|startup|recherche/i.test(`${topic.title} ${topic.summary}`));
  return wrapBrief("Veille innovation", input.title || "Innovation Watch", [
    "# Innovation Watch",
    "",
    "## Sujets à suivre",
    innovation.map((topic) => `- ${topic.title} — score VA ${topic.scoreVA}`).join("\n") || "- sujets à vérifier",
    "",
    "## Impacts potentiels",
    "Souveraineté technologique, recherche, industrie et emploi.",
    "",
    "## Sources à vérifier",
    "Radar Afrique, Knowledge Hub, universités, incubateurs et centres de recherche."
  ].join("\n"), input.sources);
}
