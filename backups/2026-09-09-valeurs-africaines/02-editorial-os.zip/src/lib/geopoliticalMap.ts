export type GeopoliticalLayerId =
  | "organisations-regionales"
  | "zones-conflit"
  | "infrastructures-strategiques"
  | "influence-internationale"
  | "ressources-strategiques";

export type GeopoliticalMapItem = {
  id: string;
  layerId: GeopoliticalLayerId;
  name: string;
  country: string;
  theme: string;
  description: string;
  strategicImportance: string;
  source: string;
  updatedAt: string;
  position: {
    x: number;
    y: number;
  };
};

export type GeopoliticalLayer = {
  id: GeopoliticalLayerId;
  name: string;
  description: string;
  color: string;
  items: GeopoliticalMapItem[];
};

const toVerify = "Donnée à vérifier";
const updateDate = "2026-06-12";

export const geopoliticalLayers: GeopoliticalLayer[] = [
  {
    id: "organisations-regionales",
    name: "Organisations régionales",
    description: "Lecture institutionnelle des ensembles régionaux africains.",
    color: "#d6aa4d",
    items: [
      item("cedeao", "organisations-regionales", "CEDEAO", "Afrique de l'Ouest", "Organisation régionale", 34, 38),
      item("sadc", "organisations-regionales", "SADC", "Afrique Australe", "Organisation régionale", 58, 74),
      item("eac", "organisations-regionales", "EAC", "Afrique de l'Est", "Organisation régionale", 62, 50),
      item("ceeac", "organisations-regionales", "CEEAC", "Afrique Centrale", "Organisation régionale", 49, 50),
      item("uma", "organisations-regionales", "UMA", "Afrique du Nord", "Organisation régionale", 43, 22),
      item("igad", "organisations-regionales", "IGAD", "Corne de l'Afrique", "Organisation régionale", 66, 40)
    ]
  },
  {
    id: "zones-conflit",
    name: "Zones de conflit",
    description: "Zones à suivre par l'Observatoire des Conflits avant toute publication.",
    color: "#ef4444",
    items: [
      item("sahel", "zones-conflit", "Sahel", "Afrique de l'Ouest / Afrique Centrale", "Zone de tension", 42, 34),
      item("est-rdc", "zones-conflit", "Est RDC", "RDC", "Zone de tension", 55, 58),
      item("soudan", "zones-conflit", "Soudan", "Soudan", "Zone de tension", 58, 34),
      item("somalie", "zones-conflit", "Somalie", "Somalie", "Zone de tension", 69, 48),
      item("autres-zones-documentees", "zones-conflit", "Autres zones documentées", "Afrique", "Veille conflit", 50, 43)
    ]
  },
  {
    id: "infrastructures-strategiques",
    name: "Infrastructures stratégiques",
    description: "Ports, corridors, pipelines et câbles à documenter par sources techniques.",
    color: "#38bdf8",
    items: [
      item("ports-majeurs", "infrastructures-strategiques", "Ports majeurs", "Afrique", "Infrastructure", 38, 61),
      item("corridors-logistiques", "infrastructures-strategiques", "Corridors logistiques", "Afrique", "Infrastructure", 48, 56),
      item("pipelines", "infrastructures-strategiques", "Pipelines", "Afrique", "Infrastructure", 52, 42),
      item("cables-sous-marins", "infrastructures-strategiques", "Câbles sous-marins", "Littoraux africains", "Infrastructure numérique", 66, 62)
    ]
  },
  {
    id: "influence-internationale",
    name: "Influence internationale",
    description: "Présences et stratégies extérieures à vérifier par sources diplomatiques.",
    color: "#a78bfa",
    items: [
      item("chine", "influence-internationale", "Chine", "Afrique", "Influence internationale", 57, 46),
      item("etats-unis", "influence-internationale", "États-Unis", "Afrique", "Influence internationale", 45, 45),
      item("union-europeenne", "influence-internationale", "Union européenne", "Afrique", "Influence internationale", 43, 31),
      item("russie", "influence-internationale", "Russie", "Afrique", "Influence internationale", 54, 37),
      item("turquie", "influence-internationale", "Turquie", "Afrique", "Influence internationale", 60, 33),
      item("inde", "influence-internationale", "Inde", "Afrique", "Influence internationale", 65, 57),
      item("etats-du-golfe", "influence-internationale", "États du Golfe", "Afrique", "Influence internationale", 62, 39)
    ]
  },
  {
    id: "ressources-strategiques",
    name: "Ressources stratégiques",
    description: "Ressources à relier aux Notes Pays après vérification documentaire.",
    color: "#22c55e",
    items: [
      item("petrole", "ressources-strategiques", "Pétrole", "Afrique", "Ressource stratégique", 42, 50),
      item("gaz", "ressources-strategiques", "Gaz", "Afrique", "Ressource stratégique", 47, 28),
      item("uranium", "ressources-strategiques", "Uranium", "Afrique", "Ressource stratégique", 44, 35),
      item("cobalt", "ressources-strategiques", "Cobalt", "Afrique", "Ressource stratégique", 54, 61),
      item("cuivre", "ressources-strategiques", "Cuivre", "Afrique", "Ressource stratégique", 55, 66),
      item("lithium", "ressources-strategiques", "Lithium", "Afrique", "Ressource stratégique", 50, 70),
      item("terres-rares", "ressources-strategiques", "Terres rares", "Afrique", "Ressource stratégique", 57, 54)
    ]
  }
];

export const geopoliticalThemes = ["Tous les thèmes", ...geopoliticalLayers.map((layer) => layer.name)];

export const geopoliticalCountries = [
  "Tous les pays",
  "Afrique",
  "Afrique du Nord",
  "Afrique de l'Ouest",
  "Afrique Centrale",
  "Afrique de l'Est",
  "Afrique Australe",
  "RDC",
  "Soudan",
  "Somalie"
];

export function getGeopoliticalMapItems() {
  return geopoliticalLayers.flatMap((layer) => layer.items);
}

function item(
  id: string,
  layerId: GeopoliticalLayerId,
  name: string,
  country: string,
  theme: string,
  x: number,
  y: number
): GeopoliticalMapItem {
  return {
    id,
    layerId,
    name,
    country,
    theme,
    description: toVerify,
    strategicImportance: toVerify,
    source: "Source à vérifier avant publication",
    updatedAt: updateDate,
    position: { x, y }
  };
}
