export type CountryProfile = {
  country: string;
  slug: string;
  region: string;
  flag: string;
  capital: string;
  population: string;
  gdp: string;
  currency: string;
  languages: string[];
  regionalOrganizations: string[];
  strategicPartners: string[];
  risks: string[];
  opportunities: string[];
  odd: string[];
  agenda2063: string[];
  sourcesToVerify: string[];
  lastUpdate: string;
};

export type CountryComparison = {
  countries: string[];
  indicators: Array<{ indicator: string; values: Record<string, string> }>;
  sourcesToVerify: string[];
};

const profiles: CountryProfile[] = [
  {
    country: "Maroc",
    slug: "maroc",
    region: "Afrique du Nord",
    flag: "🇲🇦",
    capital: "Rabat",
    population: "donnée à vérifier",
    gdp: "donnée à vérifier",
    currency: "Dirham marocain",
    languages: ["arabe", "amazigh", "français à vérifier selon usage"],
    regionalOrganizations: ["Union africaine", "UMA"],
    strategicPartners: ["Europe", "Afrique de l'Ouest", "partenaires à vérifier"],
    risks: ["stress hydrique", "dépendances énergétiques à vérifier"],
    opportunities: ["industrie", "hydrogène vert", "ports", "automobile", "phosphates"],
    odd: ["ODD 6", "ODD 7", "ODD 8", "ODD 9"],
    agenda2063: ["industrialisation", "infrastructures", "intégration africaine"],
    sourcesToVerify: ["HCP Maroc", "Banque mondiale", "BAD", "rapports sectoriels"],
    lastUpdate: "2026-06-12"
  },
  {
    country: "Algérie",
    slug: "algerie",
    region: "Afrique du Nord",
    flag: "🇩🇿",
    capital: "donnée à vérifier",
    population: "donnée à vérifier",
    gdp: "donnée à vérifier",
    currency: "donnée à vérifier",
    languages: ["donnée à vérifier"],
    regionalOrganizations: ["Union africaine", "organisations régionales à vérifier"],
    strategicPartners: ["partenaires à vérifier"],
    risks: ["donnée à vérifier"],
    opportunities: ["énergie", "industrie", "corridors régionaux à vérifier"],
    odd: ["ODD à vérifier"],
    agenda2063: ["Agenda 2063 à vérifier"],
    sourcesToVerify: ["Banque mondiale", "FMI", "BAD", "institut statistique national"],
    lastUpdate: "2026-06-12"
  },
  {
    country: "Égypte",
    slug: "egypte",
    region: "Afrique du Nord",
    flag: "🇪🇬",
    capital: "donnée à vérifier",
    population: "donnée à vérifier",
    gdp: "donnée à vérifier",
    currency: "donnée à vérifier",
    languages: ["donnée à vérifier"],
    regionalOrganizations: ["Union africaine", "organisations régionales à vérifier"],
    strategicPartners: ["partenaires à vérifier"],
    risks: ["donnée à vérifier"],
    opportunities: ["infrastructures", "énergie", "commerce à vérifier"],
    odd: ["ODD à vérifier"],
    agenda2063: ["Agenda 2063 à vérifier"],
    sourcesToVerify: ["Banque mondiale", "FMI", "BAD", "institut statistique national"],
    lastUpdate: "2026-06-12"
  },
  {
    country: "Nigeria",
    slug: "nigeria",
    region: "Afrique de l'Ouest",
    flag: "🇳🇬",
    capital: "donnée à vérifier",
    population: "donnée à vérifier",
    gdp: "donnée à vérifier",
    currency: "donnée à vérifier",
    languages: ["donnée à vérifier"],
    regionalOrganizations: ["Union africaine", "CEDEAO à vérifier"],
    strategicPartners: ["partenaires à vérifier"],
    risks: ["donnée à vérifier"],
    opportunities: ["énergie", "technologie", "marché intérieur à vérifier"],
    odd: ["ODD à vérifier"],
    agenda2063: ["Agenda 2063 à vérifier"],
    sourcesToVerify: ["Banque mondiale", "FMI", "BAD", "institut statistique national"],
    lastUpdate: "2026-06-12"
  },
  {
    country: "Afrique du Sud",
    slug: "afrique-du-sud",
    region: "Afrique Australe",
    flag: "🇿🇦",
    capital: "donnée à vérifier",
    population: "donnée à vérifier",
    gdp: "donnée à vérifier",
    currency: "donnée à vérifier",
    languages: ["donnée à vérifier"],
    regionalOrganizations: ["Union africaine", "SADC à vérifier"],
    strategicPartners: ["partenaires à vérifier"],
    risks: ["donnée à vérifier"],
    opportunities: ["industrie", "finance", "recherche à vérifier"],
    odd: ["ODD à vérifier"],
    agenda2063: ["Agenda 2063 à vérifier"],
    sourcesToVerify: ["Banque mondiale", "FMI", "BAD", "institut statistique national"],
    lastUpdate: "2026-06-12"
  },
  {
    country: "Kenya",
    slug: "kenya",
    region: "Afrique de l'Est",
    flag: "🇰🇪",
    capital: "donnée à vérifier",
    population: "donnée à vérifier",
    gdp: "donnée à vérifier",
    currency: "donnée à vérifier",
    languages: ["donnée à vérifier"],
    regionalOrganizations: ["Union africaine", "EAC à vérifier"],
    strategicPartners: ["partenaires à vérifier"],
    risks: ["donnée à vérifier"],
    opportunities: ["innovation", "logistique", "finance à vérifier"],
    odd: ["ODD à vérifier"],
    agenda2063: ["Agenda 2063 à vérifier"],
    sourcesToVerify: ["Banque mondiale", "FMI", "BAD", "institut statistique national"],
    lastUpdate: "2026-06-12"
  },
  {
    country: "Éthiopie",
    slug: "ethiopie",
    region: "Afrique de l'Est",
    flag: "🇪🇹",
    capital: "donnée à vérifier",
    population: "donnée à vérifier",
    gdp: "donnée à vérifier",
    currency: "donnée à vérifier",
    languages: ["donnée à vérifier"],
    regionalOrganizations: ["Union africaine", "organisations régionales à vérifier"],
    strategicPartners: ["partenaires à vérifier"],
    risks: ["donnée à vérifier"],
    opportunities: ["industrie", "énergie", "marché régional à vérifier"],
    odd: ["ODD à vérifier"],
    agenda2063: ["Agenda 2063 à vérifier"],
    sourcesToVerify: ["Banque mondiale", "FMI", "BAD", "institut statistique national"],
    lastUpdate: "2026-06-12"
  },
  {
    country: "RDC",
    slug: "rdc",
    region: "Afrique Centrale",
    flag: "🇨🇩",
    capital: "Kinshasa",
    population: "donnée à vérifier",
    gdp: "donnée à vérifier",
    currency: "Franc congolais",
    languages: ["français", "lingala", "swahili", "kikongo", "tshiluba"],
    regionalOrganizations: ["Union africaine", "SADC", "CEEAC", "EAC"],
    strategicPartners: ["partenaires miniers et régionaux à vérifier"],
    risks: ["conflits à l'Est", "gouvernance minière", "infrastructures"],
    opportunities: ["minerais critiques", "hydroélectricité", "forêt tropicale", "marché intérieur"],
    odd: ["ODD 7", "ODD 8", "ODD 15", "ODD 16"],
    agenda2063: ["ressources naturelles", "industrialisation", "paix et sécurité"],
    sourcesToVerify: ["Banque mondiale", "BAD", "OCHA", "institut statistique national"],
    lastUpdate: "2026-06-12"
  },
  {
    country: "Sénégal",
    slug: "senegal",
    region: "Afrique de l'Ouest",
    flag: "🇸🇳",
    capital: "donnée à vérifier",
    population: "donnée à vérifier",
    gdp: "donnée à vérifier",
    currency: "donnée à vérifier",
    languages: ["donnée à vérifier"],
    regionalOrganizations: ["Union africaine", "CEDEAO à vérifier"],
    strategicPartners: ["partenaires à vérifier"],
    risks: ["donnée à vérifier"],
    opportunities: ["gouvernance", "énergie", "services à vérifier"],
    odd: ["ODD à vérifier"],
    agenda2063: ["Agenda 2063 à vérifier"],
    sourcesToVerify: ["Banque mondiale", "FMI", "BAD", "institut statistique national"],
    lastUpdate: "2026-06-12"
  },
  {
    country: "Côte d'Ivoire",
    slug: "cote-d-ivoire",
    region: "Afrique de l'Ouest",
    flag: "🇨🇮",
    capital: "donnée à vérifier",
    population: "donnée à vérifier",
    gdp: "donnée à vérifier",
    currency: "donnée à vérifier",
    languages: ["donnée à vérifier"],
    regionalOrganizations: ["Union africaine", "CEDEAO à vérifier"],
    strategicPartners: ["partenaires à vérifier"],
    risks: ["donnée à vérifier"],
    opportunities: ["agro-industrie", "infrastructures", "commerce à vérifier"],
    odd: ["ODD à vérifier"],
    agenda2063: ["Agenda 2063 à vérifier"],
    sourcesToVerify: ["Banque mondiale", "FMI", "BAD", "institut statistique national"],
    lastUpdate: "2026-06-12"
  }
];

export async function getCountryProfile(country: string): Promise<CountryProfile | null> {
  const normalized = country.toLowerCase();
  return profiles.find((profile) => profile.slug === normalized || profile.country.toLowerCase() === normalized) ?? null;
}

export async function getAllCountryProfiles(): Promise<CountryProfile[]> {
  return profiles;
}

export function getAllCountryProfilesSync(): CountryProfile[] {
  return profiles;
}

export function getCountryTimeline(country: string): string[] {
  return [`${country}: chronologie à vérifier`, "Indépendance, réformes, crises et jalons économiques à documenter."];
}

export function getCountryRisks(profile: CountryProfile): string[] {
  return profile.risks.length ? profile.risks : ["risques à vérifier"];
}

export function getCountryOpportunities(profile: CountryProfile): string[] {
  return profile.opportunities.length ? profile.opportunities : ["opportunités à vérifier"];
}

export function getCountrySDGs(profile: CountryProfile): string[] {
  return profile.odd;
}

export function getCountryAgenda2063(profile: CountryProfile): string[] {
  return profile.agenda2063;
}

export function getCountryConflictMap(profile: CountryProfile): string[] {
  return profile.risks.filter((risk) => /conflit|sécurité|instabilité|transition/i.test(risk));
}

export function getCountryResearchEcosystem(profile: CountryProfile): string[] {
  return [`Universités et centres de recherche de ${profile.country} à vérifier`, "partenariats scientifiques à documenter"];
}

export function compareCountries(countries: CountryProfile[]): CountryComparison {
  return {
    countries: countries.map((country) => country.country),
    indicators: [
      { indicator: "Population", values: Object.fromEntries(countries.map((country) => [country.country, country.population])) },
      { indicator: "PIB", values: Object.fromEntries(countries.map((country) => [country.country, country.gdp])) },
      { indicator: "Monnaie", values: Object.fromEntries(countries.map((country) => [country.country, country.currency])) },
      { indicator: "ODD prioritaires", values: Object.fromEntries(countries.map((country) => [country.country, country.odd.join(", ")])) }
    ],
    sourcesToVerify: ["Banque mondiale", "BAD", "instituts statistiques nationaux"]
  };
}

export function generateCountryBrief(profile: CountryProfile): string {
  return [
    `# ${profile.flag} ${profile.country}`,
    "",
    `Région : ${profile.region}`,
    `Capitale : ${profile.capital}`,
    `Population : ${profile.population}`,
    `PIB : ${profile.gdp}`,
    `Monnaie : ${profile.currency}`,
    `Langues : ${profile.languages.join(", ")}`,
    "",
    "## Situation politique",
    "Donnée à vérifier auprès de sources institutionnelles et médias locaux fiables.",
    "",
    "## Situation économique",
    "Analyser croissance, dette, commerce, industrie et emploi à partir de données vérifiées.",
    "",
    "## Position géopolitique",
    `Organisations régionales : ${profile.regionalOrganizations.join(", ")}`,
    "",
    "## Sécurité",
    getCountryConflictMap(profile).join(", ") || "donnée à vérifier",
    "",
    "## Innovation",
    "Écosystème tech, recherche et entrepreneuriat à documenter.",
    "",
    "## ODD",
    profile.odd.join(", "),
    "",
    "## Agenda 2063",
    profile.agenda2063.join(", "),
    "",
    "## Entreprises majeures",
    "donnée à vérifier",
    "",
    "## Universités et recherche",
    getCountryResearchEcosystem(profile).join(", "),
    "",
    "## Diaspora",
    "donnée à vérifier",
    "",
    "## Conflits et tensions",
    getCountryRisks(profile).join(", "),
    "",
    "## Relations extérieures",
    profile.strategicPartners.join(", "),
    "",
    "## Chronologie",
    getCountryTimeline(profile.country).join("\n"),
    "",
    "## Sources à vérifier",
    profile.sourcesToVerify.map((source) => `- ${source}`).join("\n"),
    "",
    "Validation humaine obligatoire. Aucune publication automatique."
  ].join("\n");
}
