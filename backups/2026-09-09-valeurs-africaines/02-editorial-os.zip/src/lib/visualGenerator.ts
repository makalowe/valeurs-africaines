export type VisualType =
  | "chronologie"
  | "carte_acteurs"
  | "carte_influence"
  | "carte_pays"
  | "diagramme_strategique"
  | "flux"
  | "infographie_donnees";

export type VisualInput = {
  type: string;
  titre: string;
  contenu: string;
  donnees?: Record<string, unknown>;
};

export type VisualSuggestion = {
  type: VisualType;
  label: string;
  reason: string;
};

export type Visual = {
  id: string;
  type: VisualType;
  titre: string;
  description: string;
  validation_humaine_obligatoire: true;
  publication_automatique: false;
  export_formats: Array<"PNG" | "SVG" | "PDF">;
  resolution: {
    width: number;
    height: number;
  };
  confidence_score: number;
  structure: Array<{
    label: string;
    value: string;
    detail?: string;
  }>;
  suggestions: VisualSuggestion[];
  svg: string;
};

const WIDTH = 1200;
const HEIGHT = 780;

const VISUAL_TYPES: VisualType[] = [
  "chronologie",
  "carte_acteurs",
  "carte_influence",
  "carte_pays",
  "diagramme_strategique",
  "flux",
  "infographie_donnees"
];

export function generateTimeline(input: VisualInput): Visual {
  const structure = extractTimeline(input);
  return buildVisual(input, "chronologie", structure, "Chronologie strategique des faits et jalons editoriaux.");
}

export function generateInfluenceMap(input: VisualInput): Visual {
  const structure = extractList(input, ["Relations", "Alliances", "Concurrences", "Dependances"]);
  return buildVisual(input, "carte_influence", structure, "Carte d'influence montrant rapports de force, dependances et alignements.");
}

export function generateCountryMap(input: VisualInput): Visual {
  const structure = extractList(input, ["Population", "PIB", "Partenaires", "Risques", "Opportunites"]);
  return buildVisual(input, "carte_pays", structure, "Profil pays synthetique pour note pays, brief ou article.");
}

export function generateActorDiagram(input: VisualInput): Visual {
  const structure = extractList(input, ["Etat", "Entreprise", "Organisation", "Media"]);
  return buildVisual(input, "carte_acteurs", structure, "Carte des acteurs impliques et de leur role strategique.");
}

export function generateFlowChart(input: VisualInput): Visual {
  const structure = extractList(input, ["Causes", "Effets", "Consequences"]);
  return buildVisual(input, "diagramme_strategique", structure, "Diagramme causal reliant origine, effets et consequences pour l'Afrique.");
}

export function generateDataInfographic(input: VisualInput): Visual {
  const structure = extractDataPoints(input);
  return buildVisual(input, "infographie_donnees", structure, "Infographie de donnees pour newsletter, rapport ou reseaux sociaux.");
}

export function generateVisual(input: VisualInput): Visual {
  const type = normalizeVisualType(input.type);

  switch (type) {
    case "chronologie":
      return generateTimeline(input);
    case "carte_acteurs":
      return generateActorDiagram(input);
    case "carte_influence":
      return generateInfluenceMap(input);
    case "carte_pays":
      return generateCountryMap(input);
    case "diagramme_strategique":
    case "flux":
      return generateFlowChart({ ...input, type });
    case "infographie_donnees":
      return generateDataInfographic(input);
    default:
      return generateFlowChart(input);
  }
}

function buildVisual(
  input: VisualInput,
  type: VisualType,
  structure: Visual["structure"],
  description: string
): Visual {
  const title = input.titre.trim() || "Visuel strategique Valeurs Africaines";
  const safeStructure = structure.length > 0 ? structure : fallbackStructure(input.contenu);
  const visual: Omit<Visual, "svg"> = {
    id: `VIS-${Date.now()}`,
    type,
    titre: title,
    description,
    validation_humaine_obligatoire: true,
    publication_automatique: false,
    export_formats: ["PNG", "SVG", "PDF"],
    resolution: {
      width: WIDTH,
      height: HEIGHT
    },
    confidence_score: calculateConfidence(input, safeStructure),
    structure: safeStructure,
    suggestions: proposeVisuals(input)
  };

  return {
    ...visual,
    svg: renderSvg(visual)
  };
}

function normalizeVisualType(type: string): VisualType {
  const normalized = type.trim().toLowerCase().replace(/\s+/g, "_").replace(/-/g, "_");
  if (VISUAL_TYPES.includes(normalized as VisualType)) {
    return normalized as VisualType;
  }

  if (normalized.includes("chrono")) return "chronologie";
  if (normalized.includes("acteur")) return "carte_acteurs";
  if (normalized.includes("influence")) return "carte_influence";
  if (normalized.includes("pays")) return "carte_pays";
  if (normalized.includes("data") || normalized.includes("donnee")) return "infographie_donnees";
  if (normalized.includes("flux")) return "flux";

  return "diagramme_strategique";
}

function extractTimeline(input: VisualInput): Visual["structure"] {
  const dataItems = readDataItems(input.donnees);
  if (dataItems.length > 0) return dataItems;

  const years = Array.from(input.contenu.matchAll(/\b(20\d{2}|19\d{2})\b/g)).map((match) => match[1]);
  const uniqueYears = Array.from(new Set(years)).slice(0, 6);

  if (uniqueYears.length > 0) {
    return uniqueYears.map((year) => ({
      label: year,
      value: extractSentence(input.contenu, year) || "Jalon strategique a documenter"
    }));
  }

  return ["2020", "2021", "2022", "2023"].map((year) => ({
    label: year,
    value: "Jalon a verifier et completer"
  }));
}

function extractList(input: VisualInput, labels: string[]): Visual["structure"] {
  const dataItems = readDataItems(input.donnees);
  if (dataItems.length > 0) return dataItems;

  const sentences = splitSentences(input.contenu);
  return labels.map((label, index) => ({
    label,
    value: sentences[index] ?? "Information a completer",
    detail: index === 0 ? "Faits a verifier avant publication" : undefined
  }));
}

function extractDataPoints(input: VisualInput): Visual["structure"] {
  const dataItems = readDataItems(input.donnees);
  if (dataItems.length > 0) return dataItems;

  const numbers = Array.from(input.contenu.matchAll(/(?:\d+[,.]?\d*)\s?(?:%|milliards|millions|km|USD|EUR|FCFA)?/gi))
    .map((match) => match[0])
    .slice(0, 6);

  if (numbers.length > 0) {
    return numbers.map((value, index) => ({
      label: `Indicateur ${index + 1}`,
      value,
      detail: extractSentence(input.contenu, value)
    }));
  }

  return fallbackStructure(input.contenu);
}

function readDataItems(data?: Record<string, unknown>): Visual["structure"] {
  if (!data) return [];

  const entries = Object.entries(data).slice(0, 8);
  return entries.map(([label, rawValue]) => ({
    label,
    value: stringifyValue(rawValue),
    detail: "Donnee fournie par l'utilisateur"
  }));
}

function fallbackStructure(content: string): Visual["structure"] {
  const sentences = splitSentences(content);
  const labels = ["Causes", "Acteurs", "Effets", "Consequences"];
  return labels.map((label, index) => ({
    label,
    value: sentences[index] ?? "Element a documenter"
  }));
}

function splitSentences(content: string): string[] {
  return content
    .split(/(?<=[.!?])\s+|\n+/)
    .map((sentence) => sentence.trim())
    .filter(Boolean)
    .slice(0, 8);
}

function extractSentence(content: string, token: string): string | undefined {
  return splitSentences(content).find((sentence) => sentence.includes(token));
}

function stringifyValue(value: unknown): string {
  if (typeof value === "string") return value;
  if (typeof value === "number" || typeof value === "boolean") return String(value);
  if (value === null || value === undefined) return "";
  return JSON.stringify(value);
}

function proposeVisuals(input: VisualInput): VisualSuggestion[] {
  const content = `${input.titre} ${input.contenu}`.toLowerCase();
  const suggestions: VisualSuggestion[] = [];

  if (/\b(20\d{2}|19\d{2}|annee|chronologie|periode)\b/.test(content)) {
    suggestions.push({ type: "chronologie", label: "Chronologie", reason: "Le contenu contient des jalons temporels." });
  }
  if (/(acteur|etat|entreprise|organisation|media|alliance)/.test(content)) {
    suggestions.push({ type: "carte_acteurs", label: "Carte d'acteurs", reason: "Le contenu met en jeu plusieurs acteurs." });
  }
  if (/(influence|dependance|concurrence|relation|rapport de force)/.test(content)) {
    suggestions.push({ type: "carte_influence", label: "Carte d'influence", reason: "Le contenu porte sur des rapports de force." });
  }
  if (/(pays|population|pib|partenaire|risque|opportunite)/.test(content)) {
    suggestions.push({ type: "carte_pays", label: "Carte pays", reason: "Le contenu se prete a un profil pays." });
  }

  return suggestions.length > 0
    ? suggestions.slice(0, 4)
    : [{ type: "diagramme_strategique", label: "Diagramme strategique", reason: "Format polyvalent pour causes, effets et consequences." }];
}

function calculateConfidence(input: VisualInput, structure: Visual["structure"]): number {
  let score = 55;
  if (input.titre.trim()) score += 10;
  if (input.contenu.trim().length > 160) score += 15;
  if (input.donnees && Object.keys(input.donnees).length > 0) score += 15;
  if (structure.length >= 4) score += 5;
  return Math.min(score, 95);
}

function renderSvg(visual: Omit<Visual, "svg">): string {
  const items = visual.structure.slice(0, 6);
  const itemHeight = 82;
  const startY = 210;
  const centerX = WIDTH / 2;
  const escapedTitle = escapeXml(visual.titre);
  const escapedType = escapeXml(labelForType(visual.type));

  const nodes = items
    .map((item, index) => {
      const y = startY + index * itemHeight;
      const connector = index < items.length - 1 ? `<line x1="${centerX}" y1="${y + 44}" x2="${centerX}" y2="${y + itemHeight - 8}" stroke="#b9975b" stroke-width="3" />` : "";
      return `
        <g>
          <rect x="250" y="${y}" width="700" height="54" rx="8" fill="#181818" stroke="#3a3326" />
          <text x="280" y="${y + 23}" fill="#d5b56e" font-family="Inter, Arial, sans-serif" font-size="18" font-weight="700">${escapeXml(item.label)}</text>
          <text x="280" y="${y + 43}" fill="#f3f0e8" font-family="Inter, Arial, sans-serif" font-size="16">${truncateXml(item.value, 88)}</text>
          ${connector}
        </g>`;
    })
    .join("");

  return `<svg xmlns="http://www.w3.org/2000/svg" width="${WIDTH}" height="${HEIGHT}" viewBox="0 0 ${WIDTH} ${HEIGHT}" role="img" aria-label="${escapedTitle}">
    <rect width="${WIDTH}" height="${HEIGHT}" fill="#0b0b0b" />
    <rect x="34" y="34" width="${WIDTH - 68}" height="${HEIGHT - 68}" rx="16" fill="#111111" stroke="#2b2418" />
    <text x="70" y="88" fill="#b9975b" font-family="Inter, Arial, sans-serif" font-size="18" font-weight="700" letter-spacing="3">VALEURS AFRICAINES</text>
    <text x="70" y="136" fill="#f4deb0" font-family="Inter, Arial, sans-serif" font-size="34" font-weight="800">${truncateXml(visual.titre, 58)}</text>
    <text x="70" y="170" fill="#a7a7a7" font-family="Inter, Arial, sans-serif" font-size="18">${escapedType} · Brouillon visuel · Validation humaine obligatoire</text>
    ${nodes}
    <text x="70" y="730" fill="#777777" font-family="Inter, Arial, sans-serif" font-size="15">Export haute resolution prevu : PNG · SVG · PDF · Publication automatique interdite</text>
  </svg>`;
}

function labelForType(type: VisualType): string {
  const labels: Record<VisualType, string> = {
    chronologie: "Chronologie",
    carte_acteurs: "Carte d'acteurs",
    carte_influence: "Carte d'influence",
    carte_pays: "Carte pays",
    diagramme_strategique: "Diagramme strategique",
    flux: "Flux",
    infographie_donnees: "Infographie de donnees"
  };
  return labels[type];
}

function escapeXml(value: string): string {
  return value
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

function truncateXml(value: string, maxLength: number): string {
  const cleanValue = escapeXml(value.replace(/\s+/g, " ").trim());
  return cleanValue.length > maxLength ? `${cleanValue.slice(0, maxLength - 1)}…` : cleanValue;
}
