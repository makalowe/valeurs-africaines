export type WeakSignalCategory =
  | "Géopolitique"
  | "Diplomatie"
  | "Économie"
  | "Finance"
  | "Sécurité"
  | "Défense"
  | "Énergie"
  | "Technologie"
  | "IA"
  | "Gouvernance"
  | "Médias"
  | "Culture"
  | "Santé"
  | "Climat";

export type AttentionLevel = "Faible" | "Moyen" | "Élevé" | "Critique";
export type WeakSignalStatus = "Détecté" | "En analyse" | "Confirmé" | "Archivé";

export type SignalHistoryEntry = {
  date: string;
  evolution: string;
  attentionChange: string;
  analystComment: string;
};

export type WeakSignal = {
  id: string;
  title: string;
  description: string;
  detectedAt: string;
  actors: string[];
  geographicZone: string;
  region: string;
  category: WeakSignalCategory;
  whyImportant: string;
  africaConsequences: string;
  timeHorizon: string;
  attentionLevel: AttentionLevel;
  sourcesToVerify: string[];
  status: WeakSignalStatus;
  history: SignalHistoryEntry[];
};

export const weakSignalCategories: WeakSignalCategory[] = [
  "Géopolitique",
  "Diplomatie",
  "Économie",
  "Finance",
  "Sécurité",
  "Défense",
  "Énergie",
  "Technologie",
  "IA",
  "Gouvernance",
  "Médias",
  "Culture",
  "Santé",
  "Climat"
];

export const attentionLevels: AttentionLevel[] = ["Faible", "Moyen", "Élevé", "Critique"];
export const weakSignalStatuses: WeakSignalStatus[] = ["Détecté", "En analyse", "Confirmé", "Archivé"];
export const watchRegions = ["Toutes les régions", "Afrique", "Afrique du Nord", "Afrique de l'Ouest", "Afrique Centrale", "Afrique de l'Est", "Afrique Australe"];

export const weakSignals: WeakSignal[] = [];

export function getWeakSignals() {
  return weakSignals;
}

export function sortSignalsByPriority(signals: WeakSignal[]) {
  const order: Record<AttentionLevel, number> = { Critique: 0, Élevé: 1, Moyen: 2, Faible: 3 };
  return [...signals].sort((left, right) => order[left.attentionLevel] - order[right.attentionLevel]);
}

export function getWeakSignalStats() {
  const signals = getWeakSignals();
  return {
    total: signals.length,
    byCategory: weakSignalCategories.map((category) => ({ category, count: signals.filter((signal) => signal.category === category).length })),
    byRegion: watchRegions.filter((region) => region !== "Toutes les régions").map((region) => ({ region, count: signals.filter((signal) => signal.region === region).length })),
    critical: signals.filter((signal) => signal.attentionLevel === "Critique").length,
    confirmed: signals.filter((signal) => signal.status === "Confirmé").length,
    archived: signals.filter((signal) => signal.status === "Archivé").length
  };
}
