export type BusinessFormat =
  | "Entreprise de la semaine"
  | "Entrepreneur du mois"
  | "Analyse de marché"
  | "Levées de fonds"
  | "Success stories africaines"
  | "Business Brief";

export type BusinessInput = {
  sujet: string;
  format: BusinessFormat;
  secteur: string;
  pays: string;
  acteurs: string[];
  sources: string[];
};

export type BusinessDraft = {
  draft: string;
  sources_a_verifier: string[];
  niveau_confiance: "faible" | "moyen" | "élevé";
  validation_humaine_requise: true;
  publication_automatique: false;
};

export const businessAxes = [
  "Champions africains",
  "PME à fort potentiel",
  "Licornes africaines",
  "Fintech",
  "AgriTech",
  "EnergyTech",
  "Industrie",
  "Commerce intra-africain",
  "ZLECAf",
  "Investissements stratégiques",
  "Capital-risque",
  "Diaspora entrepreneuriale"
];

export function generateBusinessDraft(input: BusinessInput): BusinessDraft {
  const sources = input.sources.filter(Boolean);
  const actors = input.acteurs.length ? input.acteurs.join(", ") : "acteurs à identifier";

  return {
    draft: [
      `# ${input.format} — ${input.sujet || "Sujet business à préciser"}`,
      "",
      "Question centrale : Comment créer davantage de richesse et de valeur en Afrique ?",
      "",
      "## Résumé exécutif",
      `Analyse préliminaire du sujet ${input.sujet || "à documenter"} dans le secteur ${input.secteur || "à préciser"}, avec une attention portée aux modèles économiques, aux marchés, aux investisseurs et aux effets de création de valeur.`,
      "",
      "## Marché et contexte",
      `Pays / région : ${input.pays || "à vérifier"}. Décrire la taille du marché, la demande, la concurrence, les contraintes réglementaires et les dynamiques ZLECAf lorsque les sources sont disponibles.`,
      "",
      "## Acteurs clés",
      actors,
      "",
      "## Modèle économique",
      "Identifier revenus, clients, coûts, canaux de distribution, avantage compétitif et dépendances critiques. Ne pas inventer de chiffre d'affaires, valorisation ou levée de fonds.",
      "",
      "## Création de valeur pour l'Afrique",
      "Analyser emplois, industrialisation, inclusion financière, souveraineté productive, transfert technologique, commerce intra-africain et capacité d'exportation.",
      "",
      "## Risques et points à surveiller",
      "- Données financières à vérifier.",
      "- Régulation, concurrence et dépendances technologiques.",
      "- Capacité à passer à l'échelle sur plusieurs marchés africains.",
      "",
      "## Sources à vérifier",
      sources.length ? sources.map((source) => `- ${source}`).join("\n") : "- Sources économiques, rapports investisseurs, communiqués officiels, registres publics et médias spécialisés.",
      "",
      "Conclusion stratégique",
      "Ce contenu est un brouillon business. Il doit être relu, sourcé et validé humainement avant toute publication."
    ].join("\n"),
    sources_a_verifier: sources.length ? sources : ["rapports investisseurs", "communiqués officiels", "médias économiques", "bases entreprises"],
    niveau_confiance: calculateConfidence(input),
    validation_humaine_requise: true,
    publication_automatique: false
  };
}

function calculateConfidence(input: BusinessInput): BusinessDraft["niveau_confiance"] {
  let score = 0;
  if (input.sujet.trim()) score += 20;
  if (input.secteur.trim()) score += 15;
  if (input.pays.trim()) score += 15;
  score += Math.min(25, input.acteurs.length * 8);
  score += Math.min(25, input.sources.length * 8);
  if (score >= 75) return "élevé";
  if (score >= 40) return "moyen";
  return "faible";
}
