import { google } from "googleapis";

/**
 * Authentification Google unifiée :
 * 1. OAuth2 par refresh token (GOOGLE_CLIENT_ID + GOOGLE_CLIENT_SECRET + GOOGLE_REFRESH_TOKEN)
 *    — utilisé quand l'organisation bloque les clés de compte de service.
 * 2. Sinon, compte de service (GOOGLE_SERVICE_ACCOUNT_EMAIL + GOOGLE_PRIVATE_KEY).
 */
export async function getGoogleAuth(scopes: string[]) {
  const clientId = process.env.GOOGLE_CLIENT_ID;
  const clientSecret = process.env.GOOGLE_CLIENT_SECRET;
  const refreshToken = process.env.GOOGLE_REFRESH_TOKEN;

  if (clientId && clientSecret && refreshToken) {
    const oauth = new google.auth.OAuth2({ clientId, clientSecret });
    oauth.setCredentials({ refresh_token: refreshToken });
    return oauth;
  }

  const email = process.env.GOOGLE_SERVICE_ACCOUNT_EMAIL;
  const key = process.env.GOOGLE_PRIVATE_KEY;
  if (!email || !key) {
    throw new Error(
      "Authentification Google absente : renseigner GOOGLE_CLIENT_ID + GOOGLE_CLIENT_SECRET + GOOGLE_REFRESH_TOKEN (OAuth) ou GOOGLE_SERVICE_ACCOUNT_EMAIL + GOOGLE_PRIVATE_KEY (compte de service)."
    );
  }
  return new google.auth.JWT({ email, key: key.replace(/\\n/g, "\n"), scopes });
}
