import OpenAI from "openai";

export type ResearchBriefInput = {
  titre: string;
  categorie: string;
  pays: string;
  resume: string;
};

export type ResearchBrief = {
  titre: string;
  resume_executif: string;
  contexte: string;
  acteurs_cles: string[];
  analyse_strategique: {
    these: string;
    antithese: string;
    synthese: string;
  };
  consequences_pour_afrique: string;
  risques: string[];
  opportunites: string[];
  points_a_surveiller: string[];
  sources_a_verifier: string[];
  conclusion_strategique: string;
  markdown: string;
  metadata: {
    categorie: string;
    pays: string;
    validation_humaine_obligatoire: true;
    publication_automatique: false;
  };
};

function getOpenAIClient(): OpenAI {
  const apiKey = process.env.OPENAI_API_KEY;

  if (!apiKey) {
    throw new Error("Missing required environment variable: OPENAI_API_KEY");
  }

  return new OpenAI({ apiKey });
}

function requireField(value: string, field: keyof ResearchBriefInput): string {
  const clean = value.trim();
  if (!clean) throw new Error(`Missing required research brief field: ${field}`);
  return clean;
}

export function buildExecutiveSummary(input: ResearchBriefInput): string {
  return `Ce Research Brief analyse ${input.titre} sous l'angle ${input.categorie}, avec une attention particuliere aux implications pour ${input.pays || "l'Afrique"}. Les informations non verifiees doivent etre traitees comme hypotheses.`;
}

export function identifyActors(input: ResearchBriefInput): string[] {
  const baseActors = ["Etats africains concernés", "Union africaine", "Organisations régionales", "Acteurs économiques", "Société civile"];
  const text = `${input.titre} ${input.resume}`.toLowerCase();

  if (text.includes("chine")) baseActors.push("Chine");
  if (text.includes("russie")) baseActors.push("Russie");
  if (text.includes("usa") || text.includes("états-unis")) baseActors.push("États-Unis");
  if (text.includes("cedeao") || text.includes("cédéao")) baseActors.push("CEDEAO");

  return [...new Set(baseActors)];
}

export function strategicAnalysis(input: ResearchBriefInput): ResearchBrief["analyse_strategique"] {
  return {
    these: `Le sujet peut renforcer la marge de manoeuvre africaine si les acteurs locaux structurent une reponse coordonnee et documentee.`,
    antithese: `Le sujet peut aussi accroitre les dependances si les donnees, les financements, les infrastructures ou les recits restent controles par des acteurs externes.`,
    synthese: `L'enjeu est de transformer ce signal en strategie : identifier les interets, verifier les faits, comparer les options et proteger les capacites africaines.`
  };
}

export function africaImplications(input: ResearchBriefInput): string {
  return `Pour l'Afrique, l'enjeu principal est d'evaluer les effets sur la souverainete, l'integration regionale, la capacite de decision publique et la production de recits strategiques.`;
}

export function riskAssessment(input: ResearchBriefInput): string[] {
  return [
    "Information incomplete ou non verifiee.",
    "Dependance excessive a des sources externes.",
    "Lecture trop generale d'une situation regionale complexe.",
    "Recuperation politique ou narrative du sujet."
  ];
}

export function monitoringPoints(input: ResearchBriefInput): string[] {
  return [
    "Declarations officielles des acteurs concernes.",
    "Donnees economiques, securitaires ou institutionnelles actualisees.",
    "Reactions des organisations africaines.",
    "Evolution des alliances, financements ou cadres juridiques.",
    "Signaux faibles dans les medias locaux et regionaux."
  ];
}

function buildMarkdown(brief: Omit<ResearchBrief, "markdown">): string {
  return `# ${brief.titre}

## Résumé exécutif

${brief.resume_executif}

## Contexte

${brief.contexte}

## Acteurs clés

${brief.acteurs_cles.map((actor) => `- ${actor}`).join("\n")}

## Analyse stratégique

### Thèse

${brief.analyse_strategique.these}

### Antithèse

${brief.analyse_strategique.antithese}

### Synthèse

${brief.analyse_strategique.synthese}

## Conséquences pour l'Afrique

${brief.consequences_pour_afrique}

## Risques

${brief.risques.map((risk) => `- ${risk}`).join("\n")}

## Opportunités

${brief.opportunites.map((opportunity) => `- ${opportunity}`).join("\n")}

## Points à surveiller

${brief.points_a_surveiller.map((point) => `- ${point}`).join("\n")}

## Sources à vérifier

${brief.sources_a_verifier.map((source) => `- ${source}`).join("\n")}

## Conclusion stratégique

${brief.conclusion_strategique}

---

Validation humaine obligatoire. Aucune publication automatique.`;
}

function buildPrompt(input: ResearchBriefInput): string {
  return `Genere un Research Brief Valeurs Africaines conforme a cette structure :

# Titre
## Résumé exécutif
## Contexte
## Acteurs clés
## Analyse stratégique
### Thèse
### Antithèse
### Synthèse
## Conséquences pour l'Afrique
## Risques
## Opportunités
## Points à surveiller
## Sources à vérifier
## Conclusion stratégique

Contraintes :
- aucune publication automatique ;
- signaler les informations non verifiees ;
- distinguer faits et hypotheses ;
- style think tank ;
- perspective africaine ;
- brouillon pret a etre relu.

Sujet : ${input.titre}
Categorie : ${input.categorie}
Pays / region : ${input.pays}
Resume de depart : ${input.resume}`;
}

function buildDeterministicBrief(input: ResearchBriefInput): ResearchBrief {
  const partial = {
    titre: input.titre,
    resume_executif: buildExecutiveSummary(input),
    contexte: input.resume || "Contexte a completer par la redaction apres verification des sources.",
    acteurs_cles: identifyActors(input),
    analyse_strategique: strategicAnalysis(input),
    consequences_pour_afrique: africaImplications(input),
    risques: riskAssessment(input),
    opportunites: [
      "Transformer le sujet en avantage de connaissance.",
      "Identifier les acteurs africains capables d'agir.",
      "Produire une lecture independante et documentee."
    ],
    points_a_surveiller: monitoringPoints(input),
    sources_a_verifier: [
      "Sources institutionnelles africaines.",
      "Donnees publiques recentes.",
      "Medias locaux et regionaux.",
      "Rapports d'organisations internationales a confronter."
    ],
    conclusion_strategique: "Le sujet doit etre traite comme un brouillon analytique : utile pour cadrer la decision editoriale, mais soumis a verification humaine avant publication.",
    metadata: {
      categorie: input.categorie,
      pays: input.pays,
      validation_humaine_obligatoire: true as const,
      publication_automatique: false as const
    }
  };

  return {
    ...partial,
    markdown: buildMarkdown(partial)
  };
}

export async function generateResearchBrief(input: ResearchBriefInput): Promise<ResearchBrief> {
  const normalized: ResearchBriefInput = {
    titre: requireField(input.titre, "titre"),
    categorie: requireField(input.categorie, "categorie"),
    pays: input.pays.trim() || "Afrique",
    resume: input.resume.trim() || "Résumé de départ non renseigné."
  };

  const fallbackBrief = buildDeterministicBrief(normalized);
  const client = getOpenAIClient();

  console.info(`[researchBrief] Generating Research Brief: ${normalized.titre}`);

  const response = await client.responses.create({
    model: process.env.OPENAI_MODEL || "gpt-4.1-mini",
    input: [
      {
        role: "system",
        content:
          "Tu es l'agent Research Brief IA de Valeurs Africaines. Tu produis uniquement des brouillons structures, jamais de publication. Tu signales les informations non verifiees."
      },
      {
        role: "user",
        content: buildPrompt(normalized)
      }
    ]
  });

  return {
    ...fallbackBrief,
    markdown: response.output_text || fallbackBrief.markdown
  };
}

