export type ConflictLevel = "Stable" | "Vigilance" | "Tension élevée" | "Conflit actif" | "Effondrement critique";

export type ConflictTypology =
  | "conflit armé"
  | "terrorisme / insurrection"
  | "crise électorale"
  | "coup d’État / transition militaire"
  | "conflit communautaire"
  | "conflit frontalier"
  | "conflit lié aux ressources"
  | "crise humanitaire"
  | "médiation / processus de paix";

export type ConflictZone = {
  zone: string;
  pays: string[];
  niveau: ConflictLevel;
  couleur: "vert" | "jaune" | "orange" | "rouge" | "noir";
  evolution: "amélioration" | "stable" | "dégradation";
  typologie: ConflictTypology[];
  acteurs: string[];
  impact_humain: string;
  odd_impactes: string[];
  sources_a_verifier: string[];
  date_mise_a_jour: string;
};

export type ConflictVisualProposal = {
  id: "A" | "B" | "C";
  title: string;
  description: string;
  prompt: string;
};

const sourceChecklist = [
  "Union africaine",
  "CEDEAO",
  "SADC",
  "EAC",
  "ONU",
  "OCHA",
  "ACLED",
  "Crisis Group",
  "instituts de recherche africains",
  "médias locaux vérifiés",
  "rapports humanitaires",
  "communiqués officiels"
];

const zones: ConflictZone[] = [
  {
    zone: "Sahel central",
    pays: ["Mali", "Burkina Faso", "Niger"],
    niveau: "Tension élevée",
    couleur: "orange",
    evolution: "dégradation",
    typologie: ["terrorisme / insurrection", "coup d’État / transition militaire", "crise humanitaire"],
    acteurs: ["acteurs étatiques à vérifier", "groupes armés à documenter", "médiateurs régionaux à confirmer"],
    impact_humain: "donnée à vérifier",
    odd_impactes: ["ODD 16", "ODD 2", "ODD 4", "ODD 1"],
    sources_a_verifier: sourceChecklist,
    date_mise_a_jour: new Date().toISOString().slice(0, 10)
  },
  {
    zone: "Soudan",
    pays: ["Soudan"],
    niveau: "Conflit actif",
    couleur: "rouge",
    evolution: "dégradation",
    typologie: ["conflit armé", "crise humanitaire", "médiation / processus de paix"],
    acteurs: ["acteurs militaires à vérifier", "ONU", "Union africaine"],
    impact_humain: "donnée à vérifier",
    odd_impactes: ["ODD 16", "ODD 3", "ODD 2", "ODD 5"],
    sources_a_verifier: sourceChecklist,
    date_mise_a_jour: new Date().toISOString().slice(0, 10)
  },
  {
    zone: "Est RDC",
    pays: ["RDC"],
    niveau: "Conflit actif",
    couleur: "rouge",
    evolution: "stable",
    typologie: ["conflit armé", "conflit lié aux ressources", "crise humanitaire"],
    acteurs: ["autorités congolaises", "groupes armés à vérifier", "EAC", "SADC"],
    impact_humain: "donnée à vérifier",
    odd_impactes: ["ODD 16", "ODD 1", "ODD 3", "ODD 10"],
    sources_a_verifier: sourceChecklist,
    date_mise_a_jour: new Date().toISOString().slice(0, 10)
  },
  {
    zone: "Mozambique Nord",
    pays: ["Mozambique"],
    niveau: "Vigilance",
    couleur: "jaune",
    evolution: "amélioration",
    typologie: ["terrorisme / insurrection", "conflit lié aux ressources"],
    acteurs: ["autorités nationales", "SADC", "acteurs énergétiques à vérifier"],
    impact_humain: "donnée à vérifier",
    odd_impactes: ["ODD 16", "ODD 8", "ODD 17"],
    sources_a_verifier: sourceChecklist,
    date_mise_a_jour: new Date().toISOString().slice(0, 10)
  }
];

export async function getConflictZones(): Promise<ConflictZone[]> {
  console.info("[conflictObserver] Reading mocked conflict zones. All sensitive figures remain marked as data to verify.");
  return zones;
}

export function classifyConflictLevel(score: number): ConflictLevel {
  if (score >= 90) return "Effondrement critique";
  if (score >= 70) return "Conflit actif";
  if (score >= 50) return "Tension élevée";
  if (score >= 25) return "Vigilance";
  return "Stable";
}

export function calculateStabilityScore(zone: ConflictZone): number {
  const base = zone.niveau === "Stable" ? 85 : zone.niveau === "Vigilance" ? 65 : zone.niveau === "Tension élevée" ? 45 : zone.niveau === "Conflit actif" ? 25 : 10;
  return zone.evolution === "amélioration" ? Math.min(100, base + 10) : zone.evolution === "dégradation" ? Math.max(0, base - 10) : base;
}

export function detectEscalationRisk(zone: ConflictZone): "faible" | "moyen" | "élevé" {
  if (zone.evolution === "dégradation" && (zone.niveau === "Tension élevée" || zone.niveau === "Conflit actif")) return "élevé";
  if (zone.niveau === "Vigilance" || zone.evolution === "stable") return "moyen";
  return "faible";
}

export function identifyActors(zone: ConflictZone): string[] {
  return zone.acteurs.length ? zone.acteurs : ["acteurs à vérifier"];
}

export function mapMediationProcesses(zone: ConflictZone): string[] {
  return zone.typologie.includes("médiation / processus de paix") ? ["processus de paix à documenter", "médiateurs régionaux à vérifier"] : ["aucune médiation confirmée à ce stade"];
}

export function assessHumanImpact(zone: ConflictZone): string {
  return zone.impact_humain || "donnée à vérifier";
}

export function linkToSDGs(zone: ConflictZone): string[] {
  return zone.odd_impactes.length ? zone.odd_impactes : ["ODD 16"];
}

export function generateMonthlyConflictBrief(conflictZones: ConflictZone[] = zones): string {
  return [
    "# Observatoire des Conflits — Afrique",
    "",
    "## Résumé exécutif",
    "Suivi sobre et analytique des conflits, tensions politiques, risques sécuritaires et processus de paix. Aucun bilan humain ne doit être publié sans source fiable.",
    "",
    "## Carte des tensions",
    conflictZones.map((zone) => `- ${zone.zone} : ${zone.niveau} (${zone.evolution})`).join("\n"),
    "",
    "## Zones en dégradation",
    conflictZones.filter((zone) => zone.evolution === "dégradation").map((zone) => `- ${zone.zone}`).join("\n") || "- donnée à vérifier",
    "",
    "## Zones en amélioration",
    conflictZones.filter((zone) => zone.evolution === "amélioration").map((zone) => `- ${zone.zone}`).join("\n") || "- donnée à vérifier",
    "",
    "## Acteurs clés",
    "Acteurs à confirmer par sources fiables avant publication.",
    "",
    "## Impact humain",
    "donnée à vérifier",
    "",
    "## Impacts ODD",
    "ODD 1, ODD 2, ODD 3, ODD 4, ODD 5, ODD 8, ODD 10, ODD 16, ODD 17 selon les zones.",
    "",
    "## Médiations en cours",
    "Processus à documenter à partir de communiqués officiels et sources institutionnelles.",
    "",
    "## Risques à 30 / 90 / 180 jours",
    "- 30 jours : incidents et alertes humanitaires à surveiller.",
    "- 90 jours : dynamique politique et médiations.",
    "- 180 jours : effets régionaux, économiques et institutionnels.",
    "",
    "## Signaux faibles sécuritaires",
    "À compléter par veille ACLED, OCHA, médias locaux vérifiés et institutions africaines.",
    "",
    "## Sources à vérifier",
    sourceChecklist.map((source) => `- ${source}`).join("\n"),
    "",
    "## Conclusion stratégique",
    "L'analyse doit rester digne, factuelle et stratégique. Validation humaine obligatoire. Aucune publication automatique."
  ].join("\n");
}

export function generateConflictVisualProposals(zone = "Afrique"): ConflictVisualProposal[] {
  return [
    {
      id: "A",
      title: "Carte des tensions africaines",
      description: "Carte régionale sobre des niveaux de tension, sans donnée non vérifiée.",
      prompt: `Carte des tensions africaines pour ${zone}, code couleur stable/vigilance/tension/conflit/effondrement, sources à vérifier.`
    },
    {
      id: "B",
      title: "Diagramme des acteurs et médiateurs",
      description: "Schéma des acteurs, médiateurs et institutions impliqués, avec responsabilités non attribuées sans source.",
      prompt: `Diagramme d'acteurs et médiateurs pour ${zone}, distinguer acteurs confirmés et éléments à vérifier.`
    },
    {
      id: "C",
      title: "Timeline du conflit ou graphique d'impact humanitaire",
      description: "Chronologie ou graphique d'impact humain, uniquement avec données vérifiées.",
      prompt: `Timeline analytique ou graphique d'impact humanitaire pour ${zone}, indiquer donnée à vérifier si absence de source.`
    }
  ];
}
