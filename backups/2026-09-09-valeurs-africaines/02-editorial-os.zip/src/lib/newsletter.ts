import OpenAI from "openai";

export type NewsletterInput = {
  periode: string;
  articles: string[];
  briefs: string[];
  signaux: string[];
};

export type Newsletter = {
  titre: string;
  periode: string;
  editorial: string;
  faits_strategiques: string[];
  geopolitique: string;
  economie: string;
  securite: string;
  technologie: string;
  signaux_faibles: string;
  surveillance_semaine_prochaine: string[];
  conclusion: string;
  temps_lecture_minutes: number;
  score_confiance: number;
  priorite_sujets: "faible" | "moyenne" | "haute";
  sources_conservees: string[];
  markdown: string;
  html: string;
  validation_humaine_obligatoire: true;
  publication_automatique: false;
};

function getOpenAIClient(): OpenAI {
  const apiKey = process.env.OPENAI_API_KEY;

  if (!apiKey) {
    throw new Error("Missing required environment variable: OPENAI_API_KEY");
  }

  return new OpenAI({ apiKey });
}

function normalizeItems(items: string[]): string[] {
  return items.map((item) => item.trim()).filter(Boolean);
}

function wordsCount(text: string): number {
  return text.split(/\s+/).filter(Boolean).length;
}

export function buildEditorial(input: NewsletterInput): string {
  return `Cette edition ${input.periode || "hebdomadaire"} met en perspective les dynamiques strategiques issues des articles, Research Briefs et signaux faibles. Les faits doivent etre distingues des analyses et chaque source conservee pour verification.`;
}

export function summarizeArticles(articles: string[]): string[] {
  const clean = normalizeItems(articles);
  return clean.length ? clean.slice(0, 3) : ["Aucun article fourni : synthese editoriale a completer."];
}

export function summarizeBriefs(briefs: string[]): string {
  const clean = normalizeItems(briefs);
  return clean.length
    ? clean.map((brief) => `- ${brief}`).join("\n")
    : "- Aucun Research Brief fourni.";
}

export function summarizeSignals(signaux: string[]): string {
  const clean = normalizeItems(signaux);
  return clean.length
    ? clean.map((signal) => `- ${signal}`).join("\n")
    : "- Aucun signal faible fourni.";
}

export function generateExecutiveInsights(input: NewsletterInput): string[] {
  return [
    "Verifier les sources avant toute validation.",
    "Identifier les sujets qui peuvent devenir des dossiers strategiques.",
    "Prioriser les contenus ayant un impact direct sur la souverainete africaine."
  ];
}

export function generateClosingNote(input: NewsletterInput): string {
  return "Cette newsletter est un brouillon strategique. Elle doit etre relue, sourcee et validee humainement avant toute diffusion.";
}

function estimateReadingTime(markdown: string): number {
  return Math.max(1, Math.ceil(wordsCount(markdown) / 220));
}

function calculateConfidence(input: NewsletterInput): number {
  const totalSources = normalizeItems([...input.articles, ...input.briefs, ...input.signaux]).length;
  return Math.min(95, 55 + totalSources * 5);
}

function calculatePriority(input: NewsletterInput): Newsletter["priorite_sujets"] {
  const text = [...input.articles, ...input.briefs, ...input.signaux].join(" ").toLowerCase();
  if (text.includes("crise") || text.includes("sahel") || text.includes("dette") || text.includes("sécurité")) return "haute";
  if (text.includes("energie") || text.includes("ia") || text.includes("commerce")) return "moyenne";
  return "faible";
}

function buildMarkdown(newsletter: Omit<Newsletter, "markdown" | "html">): string {
  return `# Newsletter Valeurs Africaines

## Édito de la semaine

${newsletter.editorial}

## Les 3 faits stratégiques à retenir

${newsletter.faits_strategiques.map((fact) => `- ${fact}`).join("\n")}

## Géopolitique

${newsletter.geopolitique}

## Économie

${newsletter.economie}

## Sécurité

${newsletter.securite}

## Technologie

${newsletter.technologie}

## Signaux faibles

${newsletter.signaux_faibles}

## Ce qu'il faut surveiller la semaine prochaine

${newsletter.surveillance_semaine_prochaine.map((item) => `- ${item}`).join("\n")}

## Conclusion

${newsletter.conclusion}

---

Temps de lecture estime : ${newsletter.temps_lecture_minutes} min
Score de confiance : ${newsletter.score_confiance}/100
Priorite des sujets : ${newsletter.priorite_sujets}
Validation humaine obligatoire. Aucune publication automatique.`;
}

function markdownToHtml(markdown: string): string {
  return markdown
    .split("\n")
    .map((line) => {
      if (line.startsWith("# ")) return `<h1>${line.slice(2)}</h1>`;
      if (line.startsWith("## ")) return `<h2>${line.slice(3)}</h2>`;
      if (line.startsWith("- ")) return `<li>${line.slice(2)}</li>`;
      if (!line.trim()) return "";
      return `<p>${line}</p>`;
    })
    .join("\n");
}

function buildBaseNewsletter(input: NewsletterInput): Newsletter {
  const partial = {
    titre: "Newsletter Valeurs Africaines",
    periode: input.periode || "Semaine en cours",
    editorial: buildEditorial(input),
    faits_strategiques: summarizeArticles(input.articles),
    geopolitique: summarizeBriefs(input.briefs),
    economie: "Synthese economique a partir des articles et briefs fournis. Distinguer donnees verifiees et hypotheses.",
    securite: "Synthese securitaire a verifier selon les sources disponibles.",
    technologie: "Synthese technologique issue des signaux et briefs disponibles.",
    signaux_faibles: summarizeSignals(input.signaux),
    surveillance_semaine_prochaine: generateExecutiveInsights(input),
    conclusion: generateClosingNote(input),
    temps_lecture_minutes: 1,
    score_confiance: calculateConfidence(input),
    priorite_sujets: calculatePriority(input),
    sources_conservees: normalizeItems([...input.articles, ...input.briefs, ...input.signaux]),
    validation_humaine_obligatoire: true as const,
    publication_automatique: false as const
  };
  const markdown = buildMarkdown(partial);

  return {
    ...partial,
    temps_lecture_minutes: estimateReadingTime(markdown),
    markdown,
    html: markdownToHtml(markdown)
  };
}

function buildPrompt(input: NewsletterInput): string {
  return `Genere une newsletter strategique hebdomadaire Valeurs Africaines.

Structure obligatoire :
# Newsletter Valeurs Africaines
## Édito de la semaine
## Les 3 faits stratégiques à retenir
## Géopolitique
## Économie
## Sécurité
## Technologie
## Signaux faibles
## Ce qu'il faut surveiller la semaine prochaine
## Conclusion

Contraintes :
- aucune publication automatique ;
- validation humaine obligatoire ;
- sources conservees ;
- distinguer faits et analyses ;
- signaler les hypotheses.

Periode : ${input.periode}
Articles : ${normalizeItems(input.articles).join("\n")}
Research Briefs : ${normalizeItems(input.briefs).join("\n")}
Signaux faibles : ${normalizeItems(input.signaux).join("\n")}`;
}

export async function generateNewsletter(input: NewsletterInput): Promise<Newsletter> {
  const normalized: NewsletterInput = {
    periode: input.periode.trim() || "Semaine en cours",
    articles: normalizeItems(input.articles),
    briefs: normalizeItems(input.briefs),
    signaux: normalizeItems(input.signaux)
  };
  const base = buildBaseNewsletter(normalized);
  const client = getOpenAIClient();

  console.info(`[newsletter] Generating weekly newsletter for ${normalized.periode}`);

  const response = await client.responses.create({
    model: process.env.OPENAI_MODEL || "gpt-4.1-mini",
    input: [
      {
        role: "system",
        content:
          "Tu es l'agent Newsletter IA de Valeurs Africaines. Tu produis uniquement des brouillons, jamais de publication. Tu distingues faits, analyses et hypotheses."
      },
      {
        role: "user",
        content: buildPrompt(normalized)
      }
    ]
  });

  const markdown = response.output_text || base.markdown;

  return {
    ...base,
    markdown,
    html: markdownToHtml(markdown),
    temps_lecture_minutes: estimateReadingTime(markdown)
  };
}

