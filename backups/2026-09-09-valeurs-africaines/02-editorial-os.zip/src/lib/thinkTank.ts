export type ThinkTankType =
  | "note-strategique-pays"
  | "barometre-influences"
  | "observatoire-souverainete"
  | "indice-souverainete-narrative"
  | "cartographie-elites"
  | "veille-minerais-critiques"
  | "observatoire-afrique-brics"
  | "scenario";

export type ThinkTankInput = {
  type: string;
  sujet: string;
  pays: string[];
  acteurs: string[];
  themes: string[];
  horizon: string;
};

export type ThinkTankDraft = {
  draft: string;
  sources_a_verifier: string[];
  niveau_confiance: "faible" | "moyen" | "eleve";
  validation_humaine_requise: true;
};

type DraftConfig = {
  label: string;
  angle: string;
  sourceHints: string[];
};

const configs: Record<ThinkTankType, DraftConfig> = {
  "note-strategique-pays": {
    label: "Note stratégique pays",
    angle: "position politique, économique, géopolitique et prospective du pays",
    sourceHints: ["institutions nationales", "Union africaine", "Banque mondiale", "FMI", "sources diplomatiques ouvertes"]
  },
  "barometre-influences": {
    label: "Baromètre des influences étrangères",
    angle: "présence, instruments et trajectoires des puissances extérieures",
    sourceHints: ["communiqués officiels", "données d'investissement", "accords de coopération", "bases commerciales ouvertes"]
  },
  "observatoire-souverainete": {
    label: "Observatoire de la souveraineté africaine",
    angle: "capacités de décision, dépendances critiques et marges d'autonomie",
    sourceHints: ["textes de politique publique", "budgets", "accords internationaux", "rapports institutionnels"]
  },
  "indice-souverainete-narrative": {
    label: "Indice de souveraineté narrative",
    angle: "capacité à produire, maîtriser et diffuser ses propres récits",
    sourceHints: ["données médias", "langues de diffusion", "plateformes numériques", "études d'audience"]
  },
  "cartographie-elites": {
    label: "Cartographie des élites émergentes",
    angle: "réseaux d'acteurs, trajectoires, lieux d'influence et passerelles institutionnelles",
    sourceHints: ["biographies publiques", "organigrammes", "réseaux professionnels", "publications académiques"]
  },
  "veille-minerais-critiques": {
    label: "Veille minerais critiques",
    angle: "chaînes de valeur, dépendances industrielles et compétition stratégique",
    sourceHints: ["USGS", "ITIE", "rapports miniers nationaux", "données douanières", "entreprises cotées"]
  },
  "observatoire-afrique-brics": {
    label: "Observatoire Afrique-BRICS",
    angle: "coopérations Sud-Sud, financements, diplomatie économique et alignements géopolitiques",
    sourceHints: ["déclarations BRICS", "banque NDB", "ministères des affaires étrangères", "données commerciales"]
  },
  scenario: {
    label: "Scénarios prospectifs",
    angle: "trajectoires possibles, ruptures, continuités et variables critiques",
    sourceHints: ["tendances historiques", "données économiques", "rapports sécurité", "projections démographiques"]
  }
};

export function generateCountryStrategicNote(input: ThinkTankInput): ThinkTankDraft {
  return buildDraft(normalizeInput({ ...input, type: "note-strategique-pays" }));
}

export function generateInfluenceBarometer(input: ThinkTankInput): ThinkTankDraft {
  return buildDraft(normalizeInput({ ...input, type: "barometre-influences" }));
}

export function generateSovereigntyObservatory(input: ThinkTankInput): ThinkTankDraft {
  return buildDraft(normalizeInput({ ...input, type: "observatoire-souverainete" }));
}

export function generateNarrativeSovereigntyIndex(input: ThinkTankInput): ThinkTankDraft {
  return buildDraft(normalizeInput({ ...input, type: "indice-souverainete-narrative" }));
}

export function generateEliteMapping(input: ThinkTankInput): ThinkTankDraft {
  return buildDraft(normalizeInput({ ...input, type: "cartographie-elites" }));
}

export function generateCriticalMineralsBrief(input: ThinkTankInput): ThinkTankDraft {
  return buildDraft(normalizeInput({ ...input, type: "veille-minerais-critiques" }));
}

export function generateAfricaBricsBrief(input: ThinkTankInput): ThinkTankDraft {
  return buildDraft(normalizeInput({ ...input, type: "observatoire-afrique-brics" }));
}

export function generateScenarioReport(input: ThinkTankInput): ThinkTankDraft {
  return buildDraft(normalizeInput({ ...input, type: "scenario" }));
}

export function generateThinkTankDraft(input: ThinkTankInput): ThinkTankDraft {
  const normalized = normalizeInput(input);

  switch (normalized.type) {
    case "note-strategique-pays":
      return generateCountryStrategicNote(normalized);
    case "barometre-influences":
      return generateInfluenceBarometer(normalized);
    case "observatoire-souverainete":
      return generateSovereigntyObservatory(normalized);
    case "indice-souverainete-narrative":
      return generateNarrativeSovereigntyIndex(normalized);
    case "cartographie-elites":
      return generateEliteMapping(normalized);
    case "veille-minerais-critiques":
      return generateCriticalMineralsBrief(normalized);
    case "observatoire-afrique-brics":
      return generateAfricaBricsBrief(normalized);
    case "scenario":
      return generateScenarioReport(normalized);
  }
}

export function normalizeThinkTankType(type: string): ThinkTankType {
  const value = type.trim().toLowerCase();
  if (isThinkTankType(value)) return value;
  if (value.includes("pays")) return "note-strategique-pays";
  if (value.includes("influence")) return "barometre-influences";
  if (value.includes("narrative")) return "indice-souverainete-narrative";
  if (value.includes("elite")) return "cartographie-elites";
  if (value.includes("minerai")) return "veille-minerais-critiques";
  if (value.includes("brics")) return "observatoire-afrique-brics";
  if (value.includes("scenario") || value.includes("2030") || value.includes("2050")) return "scenario";
  return "observatoire-souverainete";
}

function buildDraft(input: ThinkTankInput & { type: ThinkTankType }): ThinkTankDraft {
  const config = configs[input.type];
  const title = input.sujet.trim() || config.label;
  const countries = formatList(input.pays, "Afrique");
  const actors = formatList(input.acteurs, "acteurs à identifier");
  const themes = formatList(input.themes, "thèmes à cadrer");
  const horizon = input.horizon.trim() || "3-5 ans";
  const sources = config.sourceHints;
  const niveau_confiance = input.pays.length > 0 && input.themes.length > 0 ? "moyen" : "faible";

  return {
    niveau_confiance,
    sources_a_verifier: sources,
    validation_humaine_requise: true,
    draft: `# ${config.label} — ${title}

## Résumé exécutif

Cette note propose un brouillon analytique sur ${title}. Elle doit être relue, sourcée et validée humainement avant toute diffusion. Les faits doivent être confirmés par des sources ouvertes et institutionnelles.

## Contexte

- Pays / espaces concernés : ${countries}
- Acteurs suivis : ${actors}
- Thèmes : ${themes}
- Horizon prospectif : ${horizon}
- Angle : ${config.angle}

## Acteurs clés

${toBullets(input.acteurs, "Acteurs à confirmer par recherche documentaire.")}

## Analyse stratégique

### Faits

- Les éléments factuels doivent être vérifiés avant publication.
- Les sources listées en fin de note sont des catégories à consulter, pas des sources déjà confirmées.

### Analyses

- Le sujet doit être lu à travers les rapports de force, les dépendances, les capacités institutionnelles et les intérêts économiques.
- L'échelle africaine doit rester centrale : souveraineté, marges de manœuvre, coopération régionale, risques de dépendance.

### Hypothèses

- L'évolution dépendra des décisions des acteurs politiques, économiques et diplomatiques.
- Les dynamiques à ${horizon} peuvent produire des bifurcations selon le contexte sécuritaire, financier et institutionnel.

## Thèse

Le dossier ${title} peut devenir un indicateur stratégique de la capacité africaine à transformer les contraintes externes en marges d'autonomie.

## Antithèse

Les dépendances financières, technologiques, informationnelles ou sécuritaires peuvent limiter cette autonomie si les politiques publiques restent fragmentées.

## Synthèse

La lecture stratégique doit articuler souveraineté, capacité d'exécution, alliances et production de récits africains autonomes.

## Conséquences pour l'Afrique

- Capacité de négociation renforcée ou affaiblie selon les coalitions.
- Risque de dépendance accrue si les infrastructures critiques sont contrôlées de l'extérieur.
- Possibilité de coopération régionale et de montée en compétence institutionnelle.

## Risques

- Données incomplètes ou non vérifiées.
- Instrumentalisation narrative.
- Dépendance à des acteurs extérieurs.
- Fragmentation régionale.

## Opportunités

- Construction d'une expertise africaine indépendante.
- Renforcement des observatoires régionaux.
- Valorisation de données souveraines.
- Création de nouveaux partenariats Sud-Sud.

## Points à surveiller

- Décisions institutionnelles.
- Accords commerciaux, sécuritaires ou technologiques.
- Évolution des récits médiatiques.
- Signaux faibles économiques, diplomatiques et sociaux.

## Sources à vérifier

${toBullets(sources, "Sources à identifier.")}

## Conclusion stratégique

Ce brouillon constitue une base de travail think tank. Il ne doit pas être publié tel quel. La rédaction doit compléter les sources, distinguer les faits établis des hypothèses et valider humainement la version finale.`
  };
}

function normalizeInput(input: ThinkTankInput): ThinkTankInput & { type: ThinkTankType } {
  return {
    type: normalizeThinkTankType(input.type),
    sujet: input.sujet,
    pays: uniqueClean(input.pays),
    acteurs: uniqueClean(input.acteurs),
    themes: uniqueClean(input.themes),
    horizon: input.horizon
  };
}

function isThinkTankType(value: string): value is ThinkTankType {
  return Object.prototype.hasOwnProperty.call(configs, value);
}

function formatList(values: string[], fallback: string): string {
  return values.length > 0 ? values.join(", ") : fallback;
}

function toBullets(values: string[], fallback: string): string {
  return values.length > 0 ? values.map((value) => `- ${value}`).join("\n") : `- ${fallback}`;
}

function uniqueClean(values: string[]): string[] {
  return Array.from(new Set(values.map((value) => value.trim()).filter(Boolean)));
}
