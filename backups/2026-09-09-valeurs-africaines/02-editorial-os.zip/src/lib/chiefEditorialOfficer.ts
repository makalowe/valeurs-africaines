import { getChiefDataSnapshot, type ChiefDataSnapshot } from "@/lib/chiefDataProvider";
import {
  evaluateAfricaImpact,
  evaluateBusinessImpact,
  evaluateConflictRisk,
  evaluateInnovationPotential,
  evaluateNarrativeInfluence,
  evaluateSDGImpact,
  evaluateStrategicValue,
  scoreTopic
} from "@/lib/editorialCompass";

const URGENCY_KEYWORDS = ["urgent", "aujourd'hui", "alerte", "rupture", "attaque", "sommet", "élection", "sanction"];

export type ChiefAgent = "Watcher" | "Veritas" | "Strategos" | "Editor" | "Archivist" | "Sentinel";
export type EditorialFormat = "article" | "brève" | "research brief" | "note pays" | "éditorial" | "infographie" | "newsletter" | "post LinkedIn" | "fil X" | "carrousel Instagram";
export type ChiefPriority = "critique" | "élevée" | "moyenne" | "faible";
export type PlanningPeriod = "aujourd'hui" | "cette semaine" | "ce mois";
export type ChiefDecision = "À prioriser" | "À produire" | "À vérifier" | "À reporter" | "À abandonner";
export type PublicationBlock = { blocked: true; reason: string };

export type ChiefScores = {
  urgence: number;
  impactAfricain: number;
  qualiteSources: number;
  risqueEditorial: number;
  adequationLigneVA: number;
};

export type ChiefSubject = {
  id: string;
  title: string;
  summary: string;
  source: string;
  formats: EditorialFormat[];
  score: number;
  priority: ChiefPriority;
  rubric: string;
  countries: string[];
  status: "brouillon" | "à vérifier" | "en validation";
  responsibleAgent: ChiefAgent;
  validationRequired: true;
  sourcesMissing: string[];
  duplicateRisk: string;
  scores: ChiefScores;
  decision: ChiefDecision;
  nextAction: string;
  humanValidated: boolean;
  publicationBlocked: PublicationBlock | null;
};

export type ChiefPlanningRow = {
  period: PlanningPeriod;
  subject: string;
  format: EditorialFormat;
  priority: ChiefPriority;
  rubric: string;
  countries: string[];
  status: "brouillon" | "à vérifier" | "en validation";
  responsibleAgent: ChiefAgent;
  validationRequired: true;
};

export type AgentCoordination = {
  agent: ChiefAgent;
  role: string;
  currentTask: string;
  status: "en attente" | "prêt" | "bloqué";
};

export type ChiefStatus = {
  activeSources: string[];
  missingSources: string[];
  contentCount: number;
  coveredCountries: string[];
  coveredRubrics: string[];
  alerts: string[];
};

export type ChiefEditorialState = {
  snapshot: ChiefDataSnapshot;
  dailyPriorities: ChiefSubject[];
  secondarySubjects: ChiefSubject[];
  weakSignalToWatch: ChiefSubject | null;
  leadingSubject: ChiefSubject | null;
  strongRecommendation: string;
  planning: ChiefPlanningRow[];
  alerts: string[];
  pendingValidation: number;
  agents: AgentCoordination[];
  sourcesMissing: string[];
  publicationBlocked: PublicationBlock | null;
  status: ChiefStatus;
};

export async function getChiefEditorialState(): Promise<ChiefEditorialState> {
  const snapshot = await getChiefDataSnapshot();
  const subjects = buildSubjectsFromSnapshot(snapshot);
  const ordered = subjects.map(withPublicationBlock).sort((left, right) => right.score - left.score);
  const dailyPriorities = ordered.slice(0, 3).map(withTopPriority);
  const secondarySubjects = ordered.slice(3, 5);
  const weakSignalToWatch = ordered.find((subject) => subject.source === "Signaux Faibles") ?? null;
  const leadingSubject = dailyPriorities[0] ?? null;
  const planning = buildPlanning(dailyPriorities, secondarySubjects);
  const alerts = buildAlerts(snapshot);
  const pendingValidation = snapshot.editorialPipeline.filter((row) => row.statut.toLowerCase().includes("validation")).length;
  const status = buildChiefStatus(snapshot, alerts);
  const publicationBlocked = [...dailyPriorities, ...secondarySubjects].some((subject) => !subject.humanValidated)
    ? { blocked: true as const, reason: "Aucune validation humaine enregistrée : la publication reste bloquée tant que les sujets prioritaires ne sont pas validés." }
    : null;

  return {
    snapshot,
    dailyPriorities,
    secondarySubjects,
    weakSignalToWatch,
    leadingSubject,
    strongRecommendation: buildRecommendation(snapshot, subjects.length, leadingSubject),
    planning,
    alerts,
    pendingValidation,
    agents: buildAgents(subjects.length, snapshot.missingSources.length),
    sourcesMissing: snapshot.missingSources,
    publicationBlocked,
    status
  };
}

export async function runChiefBriefCommand(): Promise<string> {
  const state = await getChiefEditorialState();
  return `# Brief Directeur de Rédaction

## Priorités du jour

${formatSubjectList(state.dailyPriorities, "Aucune priorité issue de données réelles disponible.")}

## Décision du Directeur

${formatLeadingDecision(state.leadingSubject)}

## Sujets à produire

${formatPlanning(state.planning.filter((row) => row.period === "aujourd'hui"))}

## Sujets à différer

${formatSubjectList(state.secondarySubjects, "Aucun sujet secondaire issu de données réelles disponible.")}

## Risques éditoriaux

${state.alerts.map((alert) => `- ${alert}`).join("\n")}

## Opportunités

- Exploiter les sources connectées : ${state.snapshot.connectedSources.join(", ") || "Source non connectée"}.
- Renforcer les sources manquantes avant toute recommandation nominative.
- Transformer uniquement les contenus sourcés en brouillons éditoriaux.

## Validation requise

- Validation humaine obligatoire avant toute rédaction finale.
- Publication automatique interdite.
- Sources non connectées : ${state.sourcesMissing.join("; ") || "Aucune source manquante détectée."}

## Recommandations

- ${state.strongRecommendation}
`;
}

export async function runChiefWeeklyCommand(): Promise<string> {
  const state = await getChiefEditorialState();
  return `# Revue éditoriale hebdomadaire

## Production réalisée

- Knowledge Hub : ${state.snapshot.knowledgeHub.length}
- Research Briefs : ${state.snapshot.researchBriefs.length}
- Notes Pays : ${state.snapshot.countryNotes.length}
- Signaux faibles : ${state.snapshot.weakSignals.length}
- Observatoires : ${state.snapshot.observatories.length}
- Planning éditorial : ${state.snapshot.editorialPipeline.length}

## Couverture Afrique

- Pays couverts : ${state.snapshot.coverageReport.coveredCountries.join(", ") || "Source non connectée"}
- Pays absents : ${state.snapshot.coverageReport.absentCountries.join(", ") || "Aucun pays absent détecté"}

## Rubriques sous-couvertes

${state.snapshot.coverageReport.underrepresentedCategories.map((category) => `- ${category}`).join("\n") || "- Source non connectée"}

## Pays sous-couverts

${state.snapshot.coverageReport.absentCountries.map((country) => `- ${country}`).join("\n") || "- Aucun pays sous-couvert détecté"}

## Observatoires actifs

${state.snapshot.observatories.length > 0 ? state.snapshot.observatories.map((item) => `- ${item.name} — sources à vérifier : ${item.sourcesToVerify.join(", ")}`).join("\n") : "- Source non connectée"}

## Signaux faibles

${formatSubjectList(state.dailyPriorities.filter((subject) => subject.source === "Signaux Faibles"), "Aucun signal faible réel disponible.")}

## Priorités semaine suivante

- Connecter les sources manquantes.
- Réduire les alertes stratégiques.
- Compléter les Notes Pays et Research Briefs actifs.
- Maintenir validation humaine obligatoire avant publication.
`;
}

export async function runChiefStatusCommand(): Promise<ChiefStatus> {
  const state = await getChiefEditorialState();
  return state.status;
}

export async function getChiefStatusJsonExample(): Promise<string> {
  const status = await runChiefStatusCommand();
  return JSON.stringify(status, null, 2);
}

function buildSubjectsFromSnapshot(snapshot: ChiefDataSnapshot): ChiefSubject[] {
  const weakSignalSubjects = snapshot.weakSignals.map((signal) => toSubject({
    id: signal.id,
    title: signal.title,
    summary: signal.description,
    source: "Signaux Faibles",
    countries: signal.geographicZone ? [signal.geographicZone] : [],
    tags: [signal.category, signal.attentionLevel, signal.status],
    sources: signal.sourcesToVerify
  }));

  const briefSubjects = snapshot.researchBriefs.map((brief) => toSubject({
    id: brief.id,
    title: brief.title,
    summary: brief.executiveSummary,
    source: "Research Briefs",
    countries: brief.countries,
    tags: [brief.category, brief.priority, ...brief.tags],
    sources: brief.sourcesToVerify
  }));

  const countryNoteSubjects = snapshot.countryNotes.map((note) => toSubject({
    id: note.slug,
    title: note.titre,
    summary: note.contenu.slice(0, 240),
    source: "Notes Pays",
    countries: note.pays,
    tags: [note.categorie, note.rubrique, ...note.themes],
    sources: note.sources
  }));

  return [...weakSignalSubjects, ...briefSubjects, ...countryNoteSubjects].filter((subject) => subject.sourcesMissing.length === 0 || subject.source !== "Source non connectée");
}

function toSubject(input: { id: string; title: string; summary: string; source: string; countries: string[]; tags: string[]; sources: string[] }): ChiefSubject {
  const score = scoreTopic({
    title: input.title,
    summary: input.summary,
    region: input.countries.join(", "),
    sources: input.sources,
    tags: input.tags
  });
  const hasSources = input.sources.length > 0;
  const decision = buildDecision(score.score, hasSources);

  return {
    id: input.id,
    title: input.title,
    summary: input.summary || "Source non connectée",
    source: input.source,
    formats: recommendFormats(score.recommendation),
    score: score.score,
    priority: score.urgency,
    rubric: score.category,
    countries: input.countries,
    status: "brouillon",
    responsibleAgent: buildAgentForCategory(score.category),
    validationRequired: true,
    sourcesMissing: hasSources ? [] : ["Source non connectée"],
    duplicateRisk: "À vérifier via Knowledge Hub, Research Briefs, Notes Pays et planning éditorial.",
    scores: buildScores({ title: input.title, summary: input.summary, region: input.countries.join(", "), sources: input.sources, tags: input.tags }),
    decision,
    nextAction: buildNextAction(decision, hasSources),
    humanValidated: false,
    publicationBlocked: { blocked: true, reason: "Validation humaine absente : sujet encore en brouillon." }
  };
}

function buildScores(input: { title: string; summary: string; region: string; sources: string[]; tags: string[] }): ChiefScores {
  const qualiteSources = Math.min(20, Math.round((input.sources?.length ?? 0) * 4));
  return {
    urgence: Math.min(20, Math.round(evaluateUrgencyLocal(input) * 4)),
    impactAfricain: evaluateAfricaImpact(input),
    qualiteSources,
    risqueEditorial: Math.min(20, Math.round(evaluateConflictRisk(input) * 0.9) + (qualiteSources < 12 ? 5 : 0)),
    adequationLigneVA: Math.min(20, Math.round((evaluateStrategicValue(input) + evaluateBusinessImpact(input) + evaluateInnovationPotential(input) + evaluateSDGImpact(input) + evaluateNarrativeInfluence(input)) / 3))
  };
}

function evaluateUrgencyLocal(input: { title: string; summary: string; region: string; sources: string[]; tags: string[] }): number {
  const text = `${input.title} ${input.summary ?? ""} ${input.region ?? ""} ${(input.tags ?? []).join(" ")}`.toLowerCase();
  const matches = URGENCY_KEYWORDS.filter((keyword) => text.includes(keyword.toLowerCase())).length;
  return Math.min(5, Math.round((matches / Math.max(1, URGENCY_KEYWORDS.length)) * 5 * 2));
}

function buildDecision(score: number, hasSources: boolean): ChiefDecision {
  if (!hasSources) return "À vérifier";
  if (score >= 75) return "À prioriser";
  if (score >= 50) return "À produire";
  if (score >= 35) return "À reporter";
  return "À abandonner";
}

function buildNextAction(decision: ChiefDecision, hasSources: boolean): string {
  if (!hasSources) return "Connecter les sources, puis déclencher Veritas avant toute priorisation.";
  switch (decision) {
    case "À prioriser":
      return "Déclencher Veritas (fact-check), valider l'angle avec Strategos, puis rédaction Editor après validation humaine.";
    case "À produire":
      return "Passer au brief Editor avec validation humaine avant rédaction finale.";
    case "À reporter":
      return "Reporter au prochain comité de rédaction.";
    case "À abandonner":
      return "Abandonner ou archiver (18_ARCHIVES).";
    case "À vérifier":
      return "Vérifier sources et statut avant toute décision.";
  }
}

function buildAgentForCategory(category: string): ChiefAgent {
  if (category.includes("Sécurité")) return "Veritas";
  if (category.includes("Économie")) return "Strategos";
  if (category.includes("Technologie")) return "Editor";
  if (category.includes("Médias")) return "Editor";
  if (category.includes("Afrique 2030")) return "Watcher";
  return "Strategos";
}

function withPublicationBlock(subject: ChiefSubject): ChiefSubject {
  return subject.humanValidated
    ? { ...subject, publicationBlocked: null }
    : { ...subject, publicationBlocked: { blocked: true, reason: "Validation humaine absente : sujet encore en brouillon." } };
}

function withTopPriority(subject: ChiefSubject): ChiefSubject {
  if (subject.sourcesMissing.length > 0) return subject;
  return {
    ...subject,
    decision: "À prioriser",
    nextAction: "Déclencher Veritas (fact-check), valider l'angle avec Strategos, puis rédaction Editor après validation humaine."
  };
}

function buildPlanning(daily: ChiefSubject[], secondary: ChiefSubject[]): ChiefPlanningRow[] {
  return [
    ...daily.map((subject) => toPlanningRow(subject, "aujourd'hui")),
    ...secondary.map((subject) => toPlanningRow(subject, "cette semaine"))
  ];
}

function toPlanningRow(subject: ChiefSubject, period: PlanningPeriod): ChiefPlanningRow {
  return {
    period,
    subject: subject.title,
    format: subject.formats[0] ?? "article",
    priority: subject.priority,
    rubric: subject.rubric,
    countries: subject.countries,
    status: "brouillon",
    responsibleAgent: subject.responsibleAgent,
    validationRequired: true
  };
}

function buildAlerts(snapshot: ChiefDataSnapshot): string[] {
  return [
    "Aucune publication automatique autorisée.",
    "Validation humaine obligatoire avant passage en production.",
    ...snapshot.strategicAlerts.map((alert) => `${alert.label} : ${alert.detail}`),
    ...snapshot.missingSources.map((source) => `Source non connectée : ${source}`)
  ];
}

function buildRecommendation(snapshot: ChiefDataSnapshot, subjectCount: number, leading: ChiefSubject | null): string {
  if (snapshot.missingSources.length > 0) return "Connecter les sources manquantes avant toute priorisation éditoriale automatisée.";
  if (subjectCount === 0) return "Aucune donnée réelle exploitable ne permet de produire une priorisation aujourd'hui.";
  if (!leading) return "Prioriser les contenus disposant de sources vérifiées, puis déclencher Veritas avant toute rédaction.";
  return `Sujet prioritaire : ${leading.title}. Décision recommandée : ${leading.decision}. Agent responsable : ${leading.responsibleAgent}. Prochaine action : ${leading.nextAction}`;
}

function buildChiefStatus(snapshot: ChiefDataSnapshot, alerts: string[]): ChiefStatus {
  return {
    activeSources: snapshot.connectedSources,
    missingSources: snapshot.missingSources,
    contentCount: snapshot.knowledgeHub.length + snapshot.researchBriefs.length + snapshot.countryNotes.length + snapshot.weakSignals.length + snapshot.editorialPipeline.length + snapshot.observatories.length,
    coveredCountries: snapshot.coverageReport.coveredCountries,
    coveredRubrics: snapshot.coverageReport.coveredThemes,
    alerts
  };
}

function recommendFormats(recommendation: string): EditorialFormat[] {
  if (recommendation.includes("Dossier")) return ["research brief", "infographie", "newsletter"];
  if (recommendation.includes("conflits")) return ["research brief", "infographie", "fil X"];
  if (recommendation.includes("innovation")) return ["article", "post LinkedIn", "carrousel Instagram"];
  if (recommendation.includes("économique")) return ["article", "research brief", "post LinkedIn"];
  if (recommendation.includes("Afrique 2030")) return ["article", "infographie", "newsletter"];
  if (recommendation.includes("Portrait")) return ["article", "post LinkedIn", "carrousel Instagram"];
  return ["article", "brève", "post LinkedIn"];
}

function buildAgents(subjectCount: number, missingSourceCount: number): AgentCoordination[] {
  const hasSubjects = subjectCount > 0;
  const blockedBySources = missingSourceCount > 0;
  return [
    { agent: "Watcher", role: "veille stratégique", currentTask: hasSubjects ? "Classer les sujets réels entrants" : "Attente de données réelles", status: blockedBySources ? "bloqué" : "prêt" },
    { agent: "Veritas", role: "fact-checking", currentTask: "Vérifier sources, chiffres, dates et citations", status: hasSubjects ? "prêt" : "en attente" },
    { agent: "Strategos", role: "analyse stratégique", currentTask: "Analyser uniquement les contenus sourcés", status: hasSubjects ? "prêt" : "en attente" },
    { agent: "Editor", role: "rédaction", currentTask: "Transformer les analyses validées en brouillons", status: "en attente" },
    { agent: "Archivist", role: "Knowledge Hub", currentTask: "Relier contenus, pays, acteurs, thèmes et sources", status: "en attente" },
    { agent: "Sentinel", role: "risques stratégiques", currentTask: "Qualifier les alertes issues du snapshot", status: snapshotStatus(hasSubjects, blockedBySources) }
  ];
}

function snapshotStatus(hasSubjects: boolean, blockedBySources: boolean): AgentCoordination["status"] {
  if (blockedBySources) return "bloqué";
  return hasSubjects ? "prêt" : "en attente";
}

function formatSubjectList(subjects: ChiefSubject[], emptyText: string): string {
  if (subjects.length === 0) return `- ${emptyText}`;
  return subjects.map((subject) => `- ${subject.title} — source ${subject.source}, score ${subject.score}/100, priorité ${subject.priority}, décision ${subject.decision}, agent ${subject.responsibleAgent}, prochaine action : ${subject.nextAction}`).join("\n");
}

function formatLeadingDecision(leading: ChiefSubject | null): string {
  if (!leading) return "- Aucun sujet prioritaire identifiable.";
  return [
    `- Sujet prioritaire : ${leading.title}`,
    `- Décision recommandée : ${leading.decision}`,
    `- Agent responsable : ${leading.responsibleAgent}`,
    `- Prochaine action : ${leading.nextAction}`,
    `- Publication : bloquée en attendant la validation humaine (${leading.publicationBlocked?.reason ?? "validation enregistrée"})`
  ].join("\n");
}

function formatPlanning(rows: ChiefPlanningRow[]): string {
  if (rows.length === 0) return "- Source non connectée";
  return rows.map((row) => `- ${row.subject} | ${row.format} | ${row.priority} | ${row.rubric} | ${row.responsibleAgent} | validation requise`).join("\n");
}
