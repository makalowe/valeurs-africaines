"use client";

import { createElement as h, useEffect, useState, type ReactNode } from "react";

export type WorkflowStatus = "Idees" | "Selection" | "Redaction" | "Revision" | "Validation" | "Pret a publier" | "Publie" | "Archive";
export type SubjectDecision = "A decider" | "Retenir" | "Reporter" | "Abandonner";

export type VisualDecision = "" | "demandee" | "recue" | "validee" | "refusee" | "aucune";

export type VisualWorkflowState = {
  decision: VisualDecision;
  kind: string;
  file: string;
  prompt: string;
  updatedAt: string;
};

export type EditorialWorkflowState = {
  workflow: WorkflowStatus;
  rhythm: "Quotidien" | "Hebdomadaire";
  decisions: Record<string, SubjectDecision>;
  humanValidation: Record<string, boolean>;
  updatedAt: string | null;
  visuals?: Record<string, VisualWorkflowState>;
};

export type WorkflowSubjectRef = { id: string; title: string };

export type WorkflowStateSource = "server" | "localStorage" | "none";

export const EDITORIAL_WORKFLOW_STORAGE_KEY = "va-editorial-workflow-state";
const LEGACY_STORAGE_KEY = "va-comite-redaction-2026-09-01";
const API_PATH = "/api/editorial-workflow";

export const DEFAULT_EDITORIAL_WORKFLOW: EditorialWorkflowState = {
  workflow: "Validation",
  rhythm: "Quotidien",
  decisions: {},
  humanValidation: {},
  updatedAt: null,
  visuals: {}
};

export function readEditorialWorkflowState(): EditorialWorkflowState {
  if (typeof window === "undefined") return DEFAULT_EDITORIAL_WORKFLOW;
  try {
    const raw = window.localStorage.getItem(EDITORIAL_WORKFLOW_STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw) as Partial<EditorialWorkflowState>;
      return { ...DEFAULT_EDITORIAL_WORKFLOW, ...parsed };
    }
    return migrateLegacyState();
  } catch {
    return DEFAULT_EDITORIAL_WORKFLOW;
  }
}

function migrateLegacyState(): EditorialWorkflowState {
  if (typeof window === "undefined") return DEFAULT_EDITORIAL_WORKFLOW;
  try {
    const legacy = window.localStorage.getItem(LEGACY_STORAGE_KEY);
    if (!legacy) return DEFAULT_EDITORIAL_WORKFLOW;
    const parsed = JSON.parse(legacy) as {
      workflow?: WorkflowStatus;
      rhythm?: "Quotidien" | "Hebdomadaire";
      subjects?: Record<string, { decision?: SubjectDecision }>;
      checks?: Record<string, boolean>;
    };
    return {
      workflow: parsed.workflow ?? DEFAULT_EDITORIAL_WORKFLOW.workflow,
      rhythm: parsed.rhythm ?? DEFAULT_EDITORIAL_WORKFLOW.rhythm,
      decisions: Object.fromEntries(Object.entries(parsed.subjects ?? {}).map(([id, subject]) => [id, subject.decision ?? "A decider"])),
      humanValidation: parsed.checks ?? {},
      updatedAt: "migré"
    };
  } catch {
    return DEFAULT_EDITORIAL_WORKFLOW;
  }
}

export function writeEditorialWorkflowState(state: EditorialWorkflowState): void {
  if (typeof window === "undefined") return;
  window.localStorage.setItem(EDITORIAL_WORKFLOW_STORAGE_KEY, JSON.stringify(state));
}

export async function fetchEditorialWorkflowState(): Promise<{ state: EditorialWorkflowState; source: WorkflowStateSource }> {
  try {
    const response = await fetch(API_PATH, { cache: "no-store" });
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    const state = (await response.json()) as EditorialWorkflowState;
    return { state: { ...DEFAULT_EDITORIAL_WORKFLOW, ...state }, source: "server" };
  } catch {
    const cached = readEditorialWorkflowState();
    return { state: cached, source: cached.updatedAt ? "localStorage" : "none" };
  }
}

export async function saveEditorialWorkflowState(state: EditorialWorkflowState): Promise<boolean> {
  writeEditorialWorkflowState(state);
  try {
    const response = await fetch(API_PATH, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(state)
    });
    return response.ok;
  } catch {
    return false;
  }
}

export function isHumanValidationComplete(state: EditorialWorkflowState): boolean {
  return Boolean(state.humanValidation["Validation humaine faite"]);
}

export function isPublicationUnlocked(state: EditorialWorkflowState): boolean {
  return state.workflow === "Pret a publier" && isHumanValidationComplete(state);
}

export function workflowNextAction(workflow: WorkflowStatus, unlocked: boolean): string {
  switch (workflow) {
    case "Idees":
      return "Collecter et sélectionner les sujets candidats (Watcher).";
    case "Selection":
      return "Confirmer les 3 sujets retenus : décisions du comité attendues.";
    case "Redaction":
      return "Rédaction en cours : agent Editor sur les brouillons validés par Strategos.";
    case "Revision":
      return "Révision : vérifier faits, contrepoints et biais avant validation.";
    case "Validation":
      return "Soumettre à la validation humaine : checklist qualité + feu vert comité.";
    case "Pret a publier":
      return unlocked
        ? "Feu vert humain acquis : publication MANUELLE autorisée (jamais automatique)."
        : "Compléter la validation humaine pour lever le verrou de publication.";
    case "Publie":
      return "Contenu publié — prévoir archivage Obsidian, Drive et Git.";
    case "Archive":
      return "Archivé — bilan, mémorisation et alimentation du Knowledge Hub.";
  }
}

const DECISION_TONE: Record<SubjectDecision, string> = {
  "Retenir": "border-gold/40 bg-gold/10 text-gold-soft",
  "Reporter": "border-amber-400/40 bg-amber-400/10 text-amber-100",
  "Abandonner": "border-red-400/40 bg-red-400/10 text-red-100",
  "A decider": "border-line bg-black/20 text-neutral-400"
};

function box(className: string, children: ReactNode) {
  return h("div", { className: `rounded-md border p-3 ${className}` }, children);
}

function label(text: string) {
  return h("p", { className: "text-[11px] font-semibold uppercase tracking-[0.16em] text-gold" }, text);
}

export function WorkflowBridge({ subjects }: { subjects: WorkflowSubjectRef[] }) {
  const [state, setState] = useState<EditorialWorkflowState>(DEFAULT_EDITORIAL_WORKFLOW);
  const [source, setSource] = useState<WorkflowStateSource>("none");

  useEffect(() => {
    let cancelled = false;
    const syncLocal = () => setState(readEditorialWorkflowState());
    syncLocal();
    const loadServer = async () => {
      const result = await fetchEditorialWorkflowState();
      if (cancelled) return;
      setState(result.state);
      setSource(result.source);
    };
    void loadServer();
    window.addEventListener("storage", syncLocal);
    return () => {
      cancelled = true;
      window.removeEventListener("storage", syncLocal);
    };
  }, []);

  const unlocked = isPublicationUnlocked(state);
  const validationDone = isHumanValidationComplete(state);
  const sourceLabel =
    source === "server" ? "Serveur (fichier JSON)" : source === "localStorage" ? "localStorage (cache — API indisponible)" : "Aucun état enregistré";

  const decisionRows = subjects.map((subject) => {
    const decision = state.decisions[subject.id] ?? "A decider";
    return h(
      "div",
      { key: subject.id, className: "flex items-center justify-between gap-3 text-sm" },
      h("span", { className: "text-neutral-300" }, subject.title),
      h("span", { className: `shrink-0 rounded-md border px-2 py-1 text-xs font-semibold ${DECISION_TONE[decision]}` }, decision)
    );
  });

  return h(
    "div",
    { className: "space-y-4" },
    h(
      "div",
      { className: "grid gap-3 md:grid-cols-3" },
      box("border-line bg-black/20", [label("Workflow courant"), h("p", { className: "mt-1 text-sm font-semibold text-neutral-100" }, state.workflow)]),
      box("border-line bg-black/20", [label("Rythme actif"), h("p", { className: "mt-1 text-sm font-semibold text-neutral-100" }, state.rhythm)]),
      box("border-line bg-black/20", [label("Source de l'état"), h("p", { className: "mt-1 text-sm font-semibold text-neutral-100" }, sourceLabel), h("p", { className: "mt-1 text-xs text-neutral-500" }, state.updatedAt ?? "jamais enregistré")])
    ),
    h(
      "div",
      { className: "grid gap-3 md:grid-cols-2" },
      box("border-line bg-black/20", [
        label("Décisions réelles du comité"),
        h("div", { className: "mt-2 space-y-2" }, subjects.length > 0 ? decisionRows : h("p", { className: "text-xs text-neutral-500" }, "Aucun sujet transmis."))
      ]),
      h(
        "div",
        { className: "space-y-3" },
        box("border-line bg-black/20", [
          label("Validation humaine"),
          h("p", { className: "mt-1 text-sm text-neutral-300" }, validationDone ? "Checklist « Validation humaine faite » cochée par le comité." : "Validation humaine NON enregistrée — verrou de publication actif.")
        ]),
        h(
          "div",
          { className: `rounded-md border p-3 text-sm font-semibold ${unlocked ? "border-emerald-400/40 bg-emerald-400/10 text-emerald-100" : "border-red-400/40 bg-red-400/10 text-red-100"}` },
          unlocked ? "Verrou levé : publication manuelle autorisée." : "Verrou actif : publication bloquée sans validation humaine."
        ),
        h("div", { className: "rounded-md border border-line bg-black/20 p-3 text-xs leading-5 text-neutral-500" }, "Publication automatique interdite : le Directeur IA ne publie jamais seul, un acte humain reste requis.")
      )
    ),
    h(
      "div",
      { className: "rounded-md border border-gold/25 bg-gold/5 p-3 text-sm text-neutral-200" },
      h("span", { className: "font-semibold text-gold-soft" }, "Prochaine action ajustée au workflow : "),
      workflowNextAction(state.workflow, unlocked)
    )
  );
}
