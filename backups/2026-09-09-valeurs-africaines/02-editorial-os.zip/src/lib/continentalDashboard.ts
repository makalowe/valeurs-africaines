export type ContinentalDashboardSection =
  | "Géopolitique"
  | "Économie"
  | "Sécurité"
  | "Énergie"
  | "Mines et ressources"
  | "Commerce"
  | "Infrastructures"
  | "Technologie"
  | "Gouvernance"
  | "Influence internationale";

export type StrategicAlertLevel = "Vert" | "Jaune" | "Orange" | "Rouge" | "À vérifier";

export type ContinentalIndicator = {
  id: string;
  section: ContinentalDashboardSection;
  name: string;
  currentValue: string;
  evolution: string;
  trend: string;
  riskLevel: StrategicAlertLevel;
  opportunityLevel: StrategicAlertLevel;
  source: string;
  updatedAt: string;
  region: string;
  country: string;
};

const unknown = "Donnée à vérifier";
const sourceRequired = "Source à vérifier avant publication";
const updatedAt = "2026-06-12";

export const continentalSections: ContinentalDashboardSection[] = [
  "Géopolitique",
  "Économie",
  "Sécurité",
  "Énergie",
  "Mines et ressources",
  "Commerce",
  "Infrastructures",
  "Technologie",
  "Gouvernance",
  "Influence internationale"
];

export const continentalRegions = [
  "Toutes les régions",
  "Afrique",
  "Afrique du Nord",
  "Afrique de l'Ouest",
  "Afrique Centrale",
  "Afrique de l'Est",
  "Afrique Australe"
];

export const continentalCountries = [
  "Tous les pays",
  "Afrique",
  "Maroc",
  "Algérie",
  "Égypte",
  "Nigeria",
  "Afrique du Sud",
  "Kenya",
  "Éthiopie",
  "RDC",
  "Sénégal",
  "Côte d'Ivoire"
];

export const continentalIndicators: ContinentalIndicator[] = [
  indicator("elections-a-venir", "Géopolitique", "Élections à venir"),
  indicator("crises-diplomatiques", "Géopolitique", "Crises diplomatiques"),
  indicator("changements-gouvernement", "Géopolitique", "Changements de gouvernement"),
  indicator("sanctions", "Géopolitique", "Sanctions"),
  indicator("accords-regionaux", "Géopolitique", "Nouveaux accords régionaux"),
  indicator("croissance-regionale", "Économie", "Croissance régionale"),
  indicator("inflation", "Économie", "Inflation"),
  indicator("dette", "Économie", "Dette"),
  indicator("ide", "Économie", "IDE"),
  indicator("commerce-intra-africain", "Économie", "Commerce intra-africain"),
  indicator("conflits", "Sécurité", "Conflits"),
  indicator("coups-etat", "Sécurité", "Coups d'État"),
  indicator("terrorisme", "Sécurité", "Terrorisme"),
  indicator("criminalite-organisee", "Sécurité", "Criminalité organisée"),
  indicator("risques-maritimes", "Sécurité", "Risques maritimes"),
  indicator("petrole", "Énergie", "Pétrole"),
  indicator("gaz", "Énergie", "Gaz"),
  indicator("renouvelables", "Énergie", "Renouvelables"),
  indicator("projets-energetiques", "Énergie", "Projets stratégiques"),
  indicator("connectivite", "Technologie", "Connectivité"),
  indicator("ia", "Technologie", "IA"),
  indicator("cybersecurite", "Technologie", "Cybersécurité"),
  indicator("infrastructures-numeriques", "Technologie", "Infrastructures numériques")
];

export function getContinentalIndicators() {
  return continentalIndicators;
}

export function getAlertInterpretation(level: StrategicAlertLevel) {
  switch (level) {
    case "Vert":
      return "Situation normale documentée.";
    case "Jaune":
      return "Vigilance éditoriale recommandée.";
    case "Orange":
      return "Risque ou opportunité significative à analyser.";
    case "Rouge":
      return "Alerte stratégique critique.";
    default:
      return "Niveau impossible à qualifier sans sources vérifiées.";
  }
}

function indicator(id: string, section: ContinentalDashboardSection, name: string): ContinentalIndicator {
  return {
    id,
    section,
    name,
    currentValue: unknown,
    evolution: unknown,
    trend: unknown,
    riskLevel: "À vérifier",
    opportunityLevel: "À vérifier",
    source: sourceRequired,
    updatedAt,
    region: "Afrique",
    country: "Afrique"
  };
}
