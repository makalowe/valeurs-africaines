import { identifySDGs } from "./africa2030";
import { scoreTopic as scoreWithCompass, type EditorialScore } from "./editorialCompass";

export type RadarSourceGroup = {
  group: string;
  sources: string[];
};

export type RadarTopic = {
  title: string;
  summary: string;
  category: string;
  urgency: EditorialScore["urgency"];
  scoreVA: number;
  oddConcernes: string[];
  paysConcernes: string[];
  acteursConcernes: string[];
  sourcesAVerifier: string[];
};

export type MorningBrief = {
  top10Sujets: RadarTopic[];
  top5SignauxFaibles: RadarTopic[];
  top3AlertesStrategiques: RadarTopic[];
  top3Personnalites: RadarTopic[];
  top3Pays: Array<{ pays: string; score: number; raison: string }>;
  validation_humaine_requise: true;
  publication_automatique: false;
};

export const radarSources: RadarSourceGroup[] = [
  { group: "Institutions africaines", sources: ["Union Africaine", "BAD", "Afreximbank", "CEDEAO", "SADC", "EAC"] },
  { group: "Institutions internationales", sources: ["ONU", "UNICEF", "PNUD", "Banque mondiale", "FMI", "OMC"] },
  { group: "Recherche", sources: ["universités africaines", "Harvard", "MIT", "Oxford", "Cambridge", "Stanford", "CNRS", "Nature", "Science"] },
  { group: "Innovation", sources: ["incubateurs", "startups", "centres de recherche", "hubs technologiques"] },
  { group: "Business", sources: ["levées de fonds", "investissements", "industrie", "énergie", "infrastructures"] },
  { group: "Sécurité", sources: ["Union Africaine", "ACLED", "OCHA", "Crisis Group"] }
];

const seedTopics = [
  {
    title: "Hydrogène vert et industrialisation en Afrique du Nord",
    summary: "Énergie, souveraineté industrielle, investissements et emplois potentiels.",
    region: "Afrique du Nord",
    tags: ["énergie", "industrie", "climat", "investissement"]
  },
  {
    title: "Tensions sécuritaires au Sahel central",
    summary: "Dégradation sécuritaire, médiations régionales, ODD 16 et impact humain à vérifier.",
    region: "Sahel",
    tags: ["conflit", "sécurité", "ODD 16", "gouvernance"]
  },
  {
    title: "Nouvelle levée de fonds fintech en Afrique de l'Ouest",
    summary: "Fintech, inclusion financière, capital-risque et marchés régionaux.",
    region: "Afrique de l'Ouest",
    tags: ["fintech", "business", "investissement", "innovation"]
  },
  {
    title: "Chercheuse africaine primée en intelligence artificielle médicale",
    summary: "Recherche, santé, diaspora académique et rayonnement scientifique africain.",
    region: "Diaspora",
    tags: ["chercheur", "ia", "santé", "diaspora"]
  },
  {
    title: "Corridors commerciaux et ZLECAf",
    summary: "Commerce intra-africain, infrastructures, douanes et souveraineté économique.",
    region: "Afrique",
    tags: ["zlecaf", "commerce", "infrastructure", "économie"]
  },
  {
    title: "Désinformation et récits internationaux sur les transitions africaines",
    summary: "Influence narrative, médias, souveraineté informationnelle et diplomatie.",
    region: "Afrique",
    tags: ["média", "désinformation", "influence", "souveraineté narrative"]
  },
  {
    title: "Agriculture durable et sécurité alimentaire",
    summary: "Adaptation climatique, production locale, ODD 2 et souveraineté alimentaire.",
    region: "Afrique de l'Est",
    tags: ["agriculture", "climat", "ODD 2", "sécurité alimentaire"]
  },
  {
    title: "Afreximbank et financement industriel africain",
    summary: "Industrie, export, chaînes de valeur et financement stratégique.",
    region: "Afrique",
    tags: ["industrie", "Afreximbank", "business", "souveraineté"]
  },
  {
    title: "Élections et stabilité institutionnelle",
    summary: "Gouvernance, institutions, risques politiques et observation électorale.",
    region: "Afrique centrale",
    tags: ["élection", "gouvernance", "institutions", "ODD 16"]
  },
  {
    title: "Hubs technologiques et IA en langues africaines",
    summary: "Innovation, données, souveraineté numérique et recherche appliquée.",
    region: "Afrique",
    tags: ["ia", "langues africaines", "innovation", "souveraineté numérique"]
  }
];

export async function scanSources(): Promise<RadarTopic[]> {
  console.info("[radar] Scanning prepared source groups with mocked watchlist.");
  return seedTopics.map((topic) => classifyTopic(topic));
}

export function classifyTopic(topic: { title: string; summary: string; region?: string; tags?: string[] }): RadarTopic {
  const scored = scoreTopic(topic);
  return {
    title: topic.title,
    summary: topic.summary,
    category: scored.category,
    urgency: scored.urgency,
    scoreVA: scored.score,
    oddConcernes: identifySDGs({ titre: topic.title, rubrique: scored.category, contenu: topic.summary, themes: topic.tags }).map((odd) => odd.odd),
    paysConcernes: mapAffectedCountries(topic),
    acteursConcernes: identifyKeyActors(topic),
    sourcesAVerifier: scored.sources_a_verifier
  };
}

export function scoreTopic(topic: { title: string; summary?: string; region?: string; tags?: string[] }): EditorialScore {
  return scoreWithCompass({
    title: topic.title,
    summary: topic.summary,
    region: topic.region,
    tags: topic.tags,
    sources: ["sources à vérifier"]
  });
}

export function detectWeakSignals(topics: RadarTopic[]): RadarTopic[] {
  return topics.filter((topic) => topic.scoreVA >= 35 && topic.scoreVA < 70).slice(0, 5);
}

export function detectStrategicAlerts(topics: RadarTopic[]): RadarTopic[] {
  return topics.filter((topic) => topic.urgency === "critique" || topic.scoreVA >= 75).slice(0, 3);
}

export function identifyKeyActors(topic: { title: string; summary?: string; tags?: string[] }): string[] {
  const text = `${topic.title} ${topic.summary ?? ""} ${(topic.tags ?? []).join(" ")}`.toLowerCase();
  const actors: string[] = [];
  if (text.includes("afreximbank")) actors.push("Afreximbank");
  if (text.includes("zlecaf")) actors.push("ZLECAf");
  if (text.includes("sahel")) actors.push("Union africaine", "CEDEAO");
  if (text.includes("ia") || text.includes("chercheuse")) actors.push("universités", "centres de recherche");
  if (text.includes("fintech")) actors.push("startups", "investisseurs");
  return actors.length ? actors : ["acteurs à vérifier"];
}

export function mapAffectedCountries(topic: { region?: string; title: string }): string[] {
  const text = `${topic.region ?? ""} ${topic.title}`.toLowerCase();
  if (text.includes("sahel")) return ["Mali", "Burkina Faso", "Niger"];
  if (text.includes("afrique du nord")) return ["Maroc", "Algérie", "Égypte"];
  if (text.includes("afrique de l'ouest")) return ["Sénégal", "Côte d'Ivoire", "Nigeria"];
  if (text.includes("afrique de l'est")) return ["Kenya", "Éthiopie", "Tanzanie"];
  return ["Afrique"];
}

export async function generateMorningBrief(): Promise<MorningBrief> {
  const topics = (await scanSources()).sort((a, b) => b.scoreVA - a.scoreVA);
  const countryScores = new Map<string, number>();
  topics.forEach((topic) => topic.paysConcernes.forEach((country) => countryScores.set(country, (countryScores.get(country) ?? 0) + topic.scoreVA)));

  return {
    top10Sujets: topics.slice(0, 10),
    top5SignauxFaibles: detectWeakSignals(topics),
    top3AlertesStrategiques: detectStrategicAlerts(topics),
    top3Personnalites: topics.filter((topic) => /chercheur|chercheuse|talent|diaspora/i.test(`${topic.title} ${topic.summary}`)).slice(0, 3),
    top3Pays: [...countryScores.entries()]
      .sort((a, b) => b[1] - a[1])
      .slice(0, 3)
      .map(([pays, score]) => ({ pays, score, raison: "Présence dans les sujets Radar Afrique du jour." })),
    validation_humaine_requise: true,
    publication_automatique: false
  };
}
