export type SDGImpact = {
  odd: string;
  label: string;
  impactsPositifs: string[];
  impactsNegatifs: string[];
  indicateursMesurables: string[];
  resultatsObservables: string[];
};

export type Africa2030Input = {
  titre: string;
  rubrique: string;
  contenu: string;
  pays?: string[];
  themes?: string[];
};

export type Africa2030Analysis = {
  questionCentrale: string;
  questionsStrategiques: string[];
  impactAfriqueScore: number;
  oddConcernes: SDGImpact[];
  lectureStrategique: string;
  validation_humaine_requise: true;
  publication_automatique: false;
};

export type Africa2030CoverageMetric = {
  axis: string;
  coverage: number;
  relatedODD: string[];
};

export function getAfrica2030CoverageMetrics(): Africa2030CoverageMetric[] {
  return [
    { axis: "Éducation", coverage: 70, relatedODD: ["ODD 4"] },
    { axis: "Santé", coverage: 60, relatedODD: ["ODD 3"] },
    { axis: "Énergie", coverage: 80, relatedODD: ["ODD 7", "ODD 13"] },
    { axis: "Innovation", coverage: 90, relatedODD: ["ODD 9"] },
    { axis: "Gouvernance", coverage: 50, relatedODD: ["ODD 16", "ODD 17"] },
    { axis: "Égalité", coverage: 40, relatedODD: ["ODD 5", "ODD 10"] },
    { axis: "Climat", coverage: 60, relatedODD: ["ODD 13", "ODD 15"] }
  ];
}

const ODD = [
  { odd: "ODD 1", label: "Pas de pauvreté", keywords: ["pauvreté", "revenu", "emploi", "inclusion"] },
  { odd: "ODD 2", label: "Faim zéro", keywords: ["agriculture", "sécurité alimentaire", "nutrition", "céréales"] },
  { odd: "ODD 3", label: "Bonne santé et bien-être", keywords: ["santé", "médecine", "hôpital", "vaccin"] },
  { odd: "ODD 4", label: "Éducation de qualité", keywords: ["éducation", "université", "formation", "chercheur"] },
  { odd: "ODD 5", label: "Égalité entre les sexes", keywords: ["femmes", "genre", "leadership féminin"] },
  { odd: "ODD 6", label: "Eau propre et assainissement", keywords: ["eau", "assainissement", "hydrique"] },
  { odd: "ODD 7", label: "Énergie propre et abordable", keywords: ["énergie", "renouvelable", "hydrogène", "solaire"] },
  { odd: "ODD 8", label: "Travail décent et croissance économique", keywords: ["business", "entreprise", "pme", "croissance", "investissement"] },
  { odd: "ODD 9", label: "Industrie, innovation et infrastructure", keywords: ["industrie", "innovation", "infrastructure", "technologie"] },
  { odd: "ODD 10", label: "Inégalités réduites", keywords: ["inégalités", "diaspora", "inclusion"] },
  { odd: "ODD 11", label: "Villes et communautés durables", keywords: ["ville", "urbanisation", "logement", "transport"] },
  { odd: "ODD 12", label: "Consommation et production responsables", keywords: ["déchets", "recyclage", "économie circulaire"] },
  { odd: "ODD 13", label: "Lutte contre les changements climatiques", keywords: ["climat", "adaptation", "reforestation"] },
  { odd: "ODD 14", label: "Vie aquatique", keywords: ["océan", "maritime", "pêche", "littoral"] },
  { odd: "ODD 15", label: "Vie terrestre", keywords: ["biodiversité", "forêt", "terres", "désertification"] },
  { odd: "ODD 16", label: "Paix, justice et institutions efficaces", keywords: ["gouvernance", "sécurité", "justice", "institutions"] },
  { odd: "ODD 17", label: "Partenariats pour la réalisation des objectifs", keywords: ["partenariat", "onu", "banque mondiale", "bad", "coopération"] }
];

export function identifySDGs(input: Africa2030Input): SDGImpact[] {
  const text = `${input.titre} ${input.rubrique} ${input.contenu} ${(input.themes ?? []).join(" ")}`.toLowerCase();
  const matched = ODD.filter((odd) => odd.keywords.some((keyword) => text.includes(keyword.toLowerCase()))).slice(0, 5);
  const selected = matched.length > 0 ? matched : [ODD[7], ODD[8], ODD[16]];

  return selected.map((odd) => ({
    odd: odd.odd,
    label: odd.label,
    impactsPositifs: [`Effets positifs potentiels à documenter pour ${odd.label}.`],
    impactsNegatifs: [`Risques, effets pervers ou angles morts à vérifier pour ${odd.label}.`],
    indicateursMesurables: ["budget engagé", "population concernée", "emplois créés", "taux d'accès", "résultats publiés"],
    resultatsObservables: ["projets réalisés", "services effectivement disponibles", "données publiques actualisées", "témoignages et évaluations indépendantes"]
  }));
}

export function buildAfrica2030Analysis(input: Africa2030Input): Africa2030Analysis {
  const oddConcernes = identifySDGs(input);

  return {
    questionCentrale: "Les engagements de développement sont-ils réellement appliqués en Afrique et produisent-ils des résultats mesurables ?",
    questionsStrategiques: getAfrica2030StrategicQuestions(),
    impactAfriqueScore: calculateImpactAfriqueScore(input, oddConcernes),
    oddConcernes,
    lectureStrategique: "Les ODD servent de grille transversale. Ils ne remplacent pas l'analyse géopolitique, économique, stratégique et souveraine de Valeurs Africaines.",
    validation_humaine_requise: true,
    publication_automatique: false
  };
}

export function calculateImpactAfriqueScore(input: Africa2030Input, oddConcernes = identifySDGs(input)): number {
  let score = 10;
  if (input.contenu.length > 300) score += 8;
  if ((input.pays ?? []).length > 0) score += 6;
  if ((input.themes ?? []).length > 0) score += 6;
  score += Math.min(10, oddConcernes.length * 2);
  if (/souverain|industrie|innovation|emploi|santé|éducation|énergie|gouvernance/i.test(input.contenu)) score += 10;
  return Math.min(50, score);
}

export function getAfrica2030StrategicQuestions(): string[] {
  return [
    "Quel intérêt stratégique pour l'Afrique ?",
    "Quel impact sur la souveraineté ?",
    "Quel impact économique ?",
    "Quel impact humain ?",
    "Quel(s) ODD concerné(s) ?",
    "Peut-on mesurer les résultats ?"
  ];
}

export function generateWeeklyAfrica2030Report(): string {
  return [
    "# Afrique 2030 – État d'avancement",
    "",
    "## Question centrale",
    "Les engagements de développement sont-ils réellement appliqués en Afrique et produisent-ils des résultats mesurables ?",
    "",
    "## Grille d'analyse obligatoire",
    ...getAfrica2030StrategicQuestions().map((question, index) => `${index + 1}. ${question}`),
    "",
    "## Score transversal",
    "Impact Afrique : XX / 50",
    "",
    "## ODD en progression",
    "À documenter à partir de données publiques, rapports institutionnels et observations de terrain.",
    "",
    "## ODD en retard",
    "Identifier les écarts entre annonces, financements, mise en œuvre et résultats mesurables.",
    "",
    "## Impacts positifs",
    "Résultats observables, politiques efficaces, innovations utiles et coopérations productives.",
    "",
    "## Impacts négatifs",
    "Risques de dépendance, projets non exécutés, coûts sociaux, effets environnementaux et angles morts de gouvernance.",
    "",
    "## Indicateurs à suivre",
    "- budgets exécutés",
    "- infrastructures livrées",
    "- accès réel aux services",
    "- emplois créés",
    "- données indépendantes disponibles",
    "",
    "## Lecture Valeurs Africaines",
    "Les ODD sont un fil rouge éditorial, mais l'analyse reste géopolitique, économique, stratégique et souveraine.",
    "",
    "Validation humaine obligatoire avant publication."
  ].join("\n");
}
