import { mkdir, readFile, writeFile } from "node:fs/promises";
import path from "node:path";
import { readDailyReview, DAILY_REVIEW_DATE, type DailyReviewSubject } from "@/lib/dailyReview";

export const DRAFTS_DIR = path.join(process.cwd(), "..", "02-EDITION-HEBDOMADAIRE", "Brouillons");
const WORKFLOW_STATE_PATH = path.join(process.cwd(), "data", "editorial-workflow.json");
const SUBJECT_IDS_BY_INDEX: Record<number, string> = {
  1: "ua-luanda",
  2: "senegal-fmi",
  3: "chine-afrique-ia"
};

export type DraftArticleResult = {
  ok: true;
  filename: string;
  filePath: string;
  subjectIndex: number;
  subjectTitle: string;
};

export async function draftArticle(input: { date?: string; subjectIndex: number }): Promise<DraftArticleResult> {
  const date = input.date ?? DAILY_REVIEW_DATE;
  const review = await readDailyReview(date);
  const subject = review.subjects.find((entry) => entry.index === input.subjectIndex);
  if (!subject) {
    throw new Error(`Index de sujet invalide : ${input.subjectIndex} (revue du ${date} : ${review.subjects.length} sujets).`);
  }
  await assertSubjectRetained(subject.index);

  const filename = `${date}-sujet-${subject.index}-${slugify(subject.title)}.md`;
  const filePath = path.join(DRAFTS_DIR, filename);
  const content = buildDraftMarkdown(date, subject);

  await mkdir(DRAFTS_DIR, { recursive: true });
  try {
    await writeFile(filePath, content, { encoding: "utf-8", flag: "wx" });
  } catch (error) {
    const code = (error as { code?: string })?.code;
    if (code === "EEXIST") {
      throw new Error(`Brouillon existe déjà : ${filename}. Aucun écrasement automatique.`);
    }
    throw error;
  }

  return { ok: true, filename, filePath, subjectIndex: subject.index, subjectTitle: subject.title };
}

async function assertSubjectRetained(subjectIndex: number): Promise<void> {
  const subjectId = SUBJECT_IDS_BY_INDEX[subjectIndex];
  if (!subjectId) {
    throw new Error(`Sujet ${subjectIndex} non reconnu par le workflow editorial.`);
  }

  const raw = await readFile(WORKFLOW_STATE_PATH, "utf-8");
  const state = JSON.parse(raw) as { decisions?: Record<string, string> };
  if (state.decisions?.[subjectId] !== "Retenir") {
    throw new Error(`Sujet ${subjectIndex} non retenu par le comité : décision Retenir requise avant rédaction.`);
  }
}

function buildDraftMarkdown(date: string, subject: DailyReviewSubject): string {
  const frontmatter = [
    "---",
    `title: "${escapeFrontmatter(subject.title)}"`,
    "aliases: []",
    'type: "article"',
    'status: "draft"',
    `source_review: "Aujourd'hui en Afrique ${date}"`,
    `rubrique: "${escapeFrontmatter(subject.rubric)}"`,
    `created: "${date}"`,
    `updated: "${date}"`,
    'country: ""',
    'region: "Afrique"',
    "actors: []",
    "themes: []",
    'tags: ["brouillon", "edition-hebdomadaire", "source-revue-quotidienne"]',
    'confidence: "low"',
    "reviewed: false",
    "---",
    ""
  ].join("\n");

  const bullets = (items: string[]): string => (items.length > 0 ? items.map((item) => `- ${item}`).join("\n") : "- _À compléter_");

  return [
    frontmatter,
    `# ${subject.title}`,
    "",
    `> Rubrique : ${subject.rubric} — Source : Aujourd'hui en Afrique ${date} (sujet ${subject.index}) — Validé pour rédaction par le comité de rédaction.`,
    "",
    "## Chapo (à compléter)",
    "",
    "> _Rédiger ici le chapo : 2-3 phrases qui donnent l'angle Valeurs Africaines et l'envie de lire._",
    "",
    "## Faits établis",
    "",
    bullets(subject.faitsEtablis),
    "",
    "## Analyse Valeurs Africaines",
    "",
    subject.analyse.trim() || "_À compléter._",
    "",
    "## Incertitudes / hypothèses",
    "",
    bullets(subject.incertitudes),
    "",
    "## Sources",
    "",
    bullets(subject.sources),
    "",
    "## Checklist relecture",
    "",
    "- [ ] Faits vérifiés",
    "- [ ] Sources vérifiées et complètes",
    "- [ ] Contrepoint ajouté si sujet sensible",
    "- [ ] Chapo rédigé",
    "- [ ] Charte éditoriale respectée",
    "- [ ] Validation humaine faite",
    ""
  ].join("\n");
}

function slugify(value: string): string {
  const slug = value
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "");
  return slug.slice(0, 70) || "sujet";
}

function escapeFrontmatter(value: string): string {
  return value.replace(/"/g, "'");
}
