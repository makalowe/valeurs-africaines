import { readFile } from "node:fs/promises";
import path from "node:path";
import { dailyReviewFilePath } from "@/lib/dailyReview";

const INBOX_DIR = path.join(process.cwd(), "..", "00-INBOX");

export type WatchReviewSubject = {
  index: number;
  rubric: string;
  title: string;
  pourquoi: string;
  faits: string[];
  angle: string;
  hypotheses: string[];
  sources: string[];
};

export async function readWatchSubjects(date: string): Promise<WatchReviewSubject[]> {
  const filePath = path.join(INBOX_DIR, `Veille - ${date}.md`);
  const raw = await readFile(filePath, "utf-8");
  return parseWatchSubjects(raw);
}

export function parseWatchSubjects(raw: string): WatchReviewSubject[] {
  const sections = raw.split(/^##\s+/m).map((section) => section.trim()).filter(Boolean);
  const subjects: WatchReviewSubject[] = [];
  for (const section of sections) {
    const firstLine = section.split("\n", 1)[0] ?? "";
    const headingMatch = firstLine.match(/^Sujet\s*(\d+)\s*[-–—:]\s*(.+)$/i);
    if (!headingMatch) continue;
    const index = Number(headingMatch[1]);
    const { rubric, title } = splitRubricTitle(headingMatch[2].trim());
    subjects.push(parseSubject(section, index, rubric, title));
  }
  return subjects;
}

export function buildReviewMarkdown(date: string, subjects: WatchReviewSubject[]): string {
  const frontmatter = [
    "---",
    `title: "Aujourd'hui en Afrique - ${date}"`,
    "aliases: []",
    'type: "note"',
    'status: "draft"',
    `created: "${date}"`,
    `updated: "${date}"`,
    'source: "Veille 00-INBOX"',
    'country: ""',
    'region: "Afrique"',
    "actors: []",
    'themes: ["actualite", "veille", "analyse", "VAIS"]',
    'tags: ["revue-quotidienne", "aujourdhui-en-afrique", "veille", "VAIS"]',
    'confidence: "low"',
    "reviewed: false",
    "---",
    ""
  ].join("\n");

  const blocks: string[] = [frontmatter, `# Aujourd'hui en Afrique - ${date}`, "", "## Statut", "", "- [x] Brouillon", "- [ ] En validation", "- [ ] Valide", "- [ ] Publie", "- [ ] Archive", ""];

  subjects.forEach((subject, position) => {
    blocks.push(`## Sujet ${position + 1} - ${subject.rubric}`, "", `**Titre : ${subject.title}**`, "", "### Pourquoi maintenant", "", subject.pourquoi || "À compléter.", "", "### Faits etablis", "", bullets(subject.faits, "Faits à vérifier et compléter."), "", "### Analyse Valeurs Africaines", "", subject.angle || "À compléter.", "", "### Incertitudes / hypotheses", "", bullets(subject.hypotheses, "Hypothèses à signaler."), "", "### Sources", "", bullets(subject.sources, "Sources à compléter."), "", "### Decision editoriale", "", "- [x] Retenir", "- [ ] Reporter", "- [ ] Abandonner", "");
  });

  blocks.push("## Checklist finale", "", "- [ ] Sources verifiees", "- [x] Faits separes de l'analyse", "- [x] Hypotheses signalees explicitement", "- [ ] Validation humaine faite", "- [ ] Archive Obsidian preparee", "- [ ] Commit Git prepare", "");

  return blocks.join("\n");
}

export async function reviewTargetPath(date: string): Promise<string> {
  return dailyReviewFilePath(date);
}

export function buildArticleMarkdown(date: string, subject: WatchReviewSubject, reviewPosition: number): string {
  const imageProposal = buildImageProposal(subject, reviewPosition);
  const introduction = subject.pourquoi || "Donnée à vérifier.";
  const facts = subject.faits.length > 0 ? subject.faits : ["Donnée à vérifier."];
  const watchPoints = subject.hypotheses.length > 0 ? subject.hypotheses : ["Donnée à vérifier."];
  const analysis =
    subject.angle?.trim() ||
    "Analyse Valeurs Africaines à rédiger par le comité à partir des faits et sources ci-dessus (distinguer faits, analyse et hypothèses).";
  const frontmatter = [
    "---",
    `title: "${escapeFrontmatter(subject.title)}"`,
    "aliases: []",
    'type: "article"',
    'status: "draft"',
    `source_review: "Aujourd'hui en Afrique ${date} (sujet ${reviewPosition})"`,
    `rubrique: "${escapeFrontmatter(subject.rubric)}"`,
    `created: "${date}"`,
    `updated: "${date}"`,
    'country: ""',
    'region: "Afrique"',
    "actors: []",
    "themes: []",
    'tags: ["brouillon", "edition-hebdomadaire", "source-revue-quotidienne"]',
    'confidence: "low"',
    "reviewed: false",
    "---",
    ""
  ].join("\n");

  const body = [
    `# ${subject.title}`,
    "",
    `> Rubrique : ${subject.rubric} — Source : Revue Aujourd'hui en Afrique ${date} (sujet ${reviewPosition}) — Canevas généré automatiquement : rédaction complète requise avant validation (aucune publication possible en l'état).`,
    "",
    "## Introduction",
    "",
    introduction,
    "",
    "## Faits établis",
    "",
    bullets(facts, "Donnée à vérifier."),
    "",
    "## Analyse Valeurs Africaines",
    "",
    analysis,
    "",
    "## Incertitudes / hypothèses",
    "",
    bullets(watchPoints, "Donnée à vérifier."),
    "",
    "## Conclusion",
    "",
    "Conclusion à rédiger par le comité à partir de l'analyse ci-dessus.",
    "",
    "## Sources",
    "",
    bullets(subject.sources, "Sources à compléter."),
    "",
    "## Image proposée",
    "",
    imageProposal,
    "",
    "## Checklist relecture",
    "",
    "- [ ] Faits vérifiés",
    "- [ ] Sources vérifiées et complètes",
    "- [ ] Contrepoint ajouté si sujet sensible",
    "- [ ] Chapo rédigé",
    "- [ ] Charte éditoriale respectée",
    "- [ ] Validation humaine faite",
    ""
  ].join("\n");

  return `${frontmatter}${body}`;
}

export function buildImageProposal(subject: WatchReviewSubject, reviewPosition: number): string {
  const pays = subject.title.split(",")[0]?.trim() ?? "Afrique";
  return [
    `> Illustration proposée automatiquement pour le sujet ${reviewPosition} (« ${subject.title.slice(0, 80)} »).`,
    "",
    "**Description visuelle** : fresque éditoriale panafricaine autour de « " + pays + " » — motifs géométriques africains en filigrane, palette or/terre/vert VA, composition sobre type presse magazine.",
    "",
    "**Éléments suggérés** : carte ou silhouette du pays / région, symbole du sujet (urnes, institutions, produits agricoles, drapeaux), un détail humain (main, foule, scrutin) pour l'incarnation.",
    "",
    "**Format** : 16:9 (une) ou 4:5 (réseaux). **Style** : illustration vectorielle éditoriale, sans photo d'archive non sourcée.",
    "",
    "> À générer ou commander après validation humaine de l'article (voir 15_VISUELS / VISUELS-PROPOSES).",
    ""
  ].join("\n");
}

export function slugifyArticleTitle(value: string): string {
  const slug = value
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "");
  return slug.slice(0, 70) || "sujet";
}

function escapeFrontmatter(value: string): string {
  return value.replace(/"/g, "'");
}

function splitRubricTitle(remainder: string): { rubric: string; title: string } {
  const separator = remainder.indexOf(" : ");
  if (separator > 0 && separator < 70) {
    return { rubric: remainder.slice(0, separator).trim(), title: remainder.slice(separator + 3).trim() };
  }
  return { rubric: "À déterminer", title: remainder };
}

function parseSubject(section: string, index: number, rubric: string, title: string): WatchReviewSubject {
  const subject: WatchReviewSubject = { index, rubric, title, pourquoi: "", faits: [], angle: "", hypotheses: [], sources: [] };
  let current: keyof WatchReviewSubject | null = null;
  for (const line of section.split("\n")) {
    const heading = line.match(/^###\s+(.+)$/);
    if (heading) {
      current = mapSubheading(norm(heading[1]));
      continue;
    }
    const text = line.trim();
    if (!text || !current) continue;
    if (current === "pourquoi" || current === "angle") {
      const paragraph = text.replace(/^[-*]\s+/, "");
      const previous = subject[current] as string;
      subject[current] = previous ? `${previous} ${paragraph}` : paragraph;
    } else {
      const bullet = text.replace(/^[-*]\s*/, "").trim();
      if (bullet.startsWith("http")) {
        if (current === "sources") subject.sources.push(bullet);
      } else if (bullet) {
        (subject[current] as string[]).push(bullet);
      }
    }
  }
  return subject;
}

function mapSubheading(heading: string): keyof WatchReviewSubject | null {
  if (heading.includes("pourquoi maintenant")) return "pourquoi";
  if (heading === "faits") return "faits";
  if (heading.includes("angle valeurs africaines") || heading.includes("analyse valeurs africaines")) return "angle";
  if (heading.includes("hypothese") || heading.includes("a verifier") || heading.includes("risque")) return "hypotheses";
  if (heading === "sources") return "sources";
  return null;
}

function bullets(items: string[], fallback: string): string {
  return items.length > 0 ? items.map((item) => `- ${item}`).join("\n") : `- ${fallback}`;
}

function norm(value: string): string {
  return value.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().trim();
}
