/**
 * Publication locale des articles Valeurs Africaines vers le site Flask.
 * Miroir TypeScript de scripts/publication-quotidienne/publish_daily.py (modèle 44-48).
 * Serveur uniquement (fs). Utilisé par /api/publish.
 */
import { promises as fs } from "fs";
import path from "path";

const CWD = process.cwd();
const VA_ROOT = path.join(CWD, "..");
export const DRAFTS_DIR = path.join(VA_ROOT, "02-EDITION-HEBDOMADAIRE", "Brouillons");
export const CLASSIFIED_ARTICLES_DIR = path.join(VA_ROOT, "01-ACTUALITE-QUOTIDIENNE", "Aujourd'hui en Afrique");
export const SITE_STORE = path.join(VA_ROOT, "site-public-flask", "app", "data_store.json");
export const SITE_IMG_DIR = path.join(VA_ROOT, "site-public-flask", "app", "static", "img");
export const PROPOSITIONS_DIR = path.join(CWD, "public", "propositions");
const BACKUP_DIR = path.join(CWD, "data", "backups");

export type StoreEntry = {
  id: number;
  slug: string;
  title: string;
  status: string;
  published_at: string | null;
  rubrique?: string;
  image?: string;
};

export type DayArticleInfo = {
  filename: string;
  title: string;
  slug: string;
  ready: boolean;
  country: string;
  imageFile: string | null;
  publishedId: number | null;
  publishedAt: string | null;
  publishedSlug: string | null;
};

/** Slug de publication d'un brouillon : partie du nom de fichier après « AAAA-MM-JJ-sujet-N- ». */
export function draftFilenameSlug(filename: string): string {
  return filename.replace(/^\d{4}-\d{2}-\d{2}-(?:sujet-\d+-)?/, "").replace(/\.md$/, "");
}

/** Slug du site Flask (data.py _slugify) : NFKD ascii, minuscules, tirets. */
export function slugifyStoreTitle(value: string): string {
  return (
    value
      .normalize("NFKD")
      .replace(/[\u0300-\u036f]/g, "")
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, "-")
      .replace(/^-+|-+$/g, "") || "article"
  );
}

export function localDateString(date: Date = new Date()): string {
  const shifted = new Date(date.getTime() - date.getTimezoneOffset() * 60000);
  return shifted.toISOString().slice(0, 10);
}

export function draftFilenamePattern(date: string): RegExp {
  return new RegExp(`^${date}-(?:sujet-\\d+-)?[a-z0-9-]+\\.md$`);
}

export function siteUrl(slug: string): string {
  return `http://127.0.0.1:5000/articles/${encodeURIComponent(slug)}`;
}

export type SiteStoreSummary = {
  total: number;
  published: number;
  publishedToday: number;
  rubriques: Array<{ rubrique: string; count: number }>;
  latest: Array<{ id: number; title: string; slug: string; published_at: string | null }>;
};

/** Résumé du store du site Flask (articles publiés, du jour, rubriques, derniers). */
export async function readSiteStoreSummary(): Promise<SiteStoreSummary> {
  const payload = await readStorePayload();
  const today = localDateString();
  const publishedRows = payload.articles.filter((entry) => entry.status === "published");
  const rubriqueCounts = new Map<string, number>();
  for (const row of publishedRows) {
    const rubrique = row.rubrique ?? "?";
    rubriqueCounts.set(rubrique, (rubriqueCounts.get(rubrique) ?? 0) + 1);
  }
  return {
    total: payload.articles.length,
    published: publishedRows.length,
    publishedToday: publishedRows.filter((entry) => entry.published_at === today).length,
    rubriques: [...rubriqueCounts.entries()]
      .map(([rubrique, count]) => ({ rubrique, count }))
      .sort((left, right) => right.count - left.count),
    latest: [...publishedRows]
      .sort((left, right) => right.id - left.id)
      .slice(0, 5)
      .map((entry) => ({ id: entry.id, title: entry.title, slug: entry.slug, published_at: entry.published_at }))
  };
}

async function readStorePayload(): Promise<{ articles: StoreEntry[] }> {
  const raw = await fs.readFile(SITE_STORE, "utf-8");
  return JSON.parse(raw) as { articles: StoreEntry[] };
}

/** Fichiers brouillons du jour, triés par sujet. */
export async function listDraftFiles(date: string): Promise<string[]> {
  const files = await listPublishableArticleFiles(date);
  return files
    .map((file) => file.filename)
    .sort((a, b) => {
      const numA = Number(a.match(/sujet-(\d+)/)?.[1] ?? 0);
      const numB = Number(b.match(/sujet-(\d+)/)?.[1] ?? 0);
      return numA - numB || a.localeCompare(b);
    });
}

async function listPublishableArticleFiles(date: string): Promise<Array<{ filename: string; filePath: string }>> {
  const pattern = draftFilenamePattern(date);
  const files: Array<{ filename: string; filePath: string }> = [];
  try {
    const entries = await fs.readdir(DRAFTS_DIR);
    for (const entry of entries) {
      if (pattern.test(entry)) files.push({ filename: entry, filePath: path.join(DRAFTS_DIR, entry) });
    }
  } catch {
    // dossier historique absent : on continue avec les articles classes
  }
  const classified = await listMarkdownFilesRecursive(CLASSIFIED_ARTICLES_DIR).catch(() => []);
  for (const filePath of classified) {
    const filename = path.basename(filePath);
    if (pattern.test(filename) && !files.some((file) => file.filename === filename)) {
      files.push({ filename, filePath });
    }
  }
  return files;
}

async function findPublishableArticleFile(date: string, filename: string): Promise<string> {
  const match = (await listPublishableArticleFiles(date)).find((file) => file.filename === filename);
  if (!match) throw new Error("Article introuvable dans les brouillons ou les articles classés du jour.");
  return match.filePath;
}

async function listMarkdownFilesRecursive(dir: string): Promise<string[]> {
  const entries = await fs.readdir(dir, { withFileTypes: true });
  const files: string[] = [];
  for (const entry of entries) {
    const fullPath = path.join(dir, entry.name);
    if (entry.isDirectory()) {
      files.push(...(await listMarkdownFilesRecursive(fullPath)));
    } else if (entry.isFile() && entry.name.endsWith(".md")) {
      files.push(fullPath);
    }
  }
  return files;
}

export function parseFrontmatter(content: string): Record<string, string> {
  const fields: Record<string, string> = {};
  const lines = content.split("\n");
  if (lines[0]?.trim() !== "---") return fields;
  for (const line of lines.slice(1)) {
    if (line.trim() === "---") break;
    const match = line.match(/^([a-z_]+):\s*"?([^"]*?)"?\s*$/);
    if (match) fields[match[1]] = match[2].trim();
  }
  return fields;
}

export function isDraftReady(content: string): boolean {
  const body = content.replace(/^---[\s\S]*?---/, "");
  if (/à compléter/i.test(body)) return false;
  if (/\[x\]\s*Chapo rédigé/i.test(body)) return true;
  return /^##\s+Chapeau\s*$/im.test(body) && /^##\s+Sources\s*$/im.test(body);
}

/** Nom de fichier image mentionné dans la section « Image proposée / retenue » du brouillon. */
export function extractImageFileFromMarkdown(content: string): string | null {
  const section = content.match(/^## Image (?:proposée|retenue)[^\n]*\s*\n([\s\S]*?)(?=^## |\z)/im);
  if (!section) return null;
  const names = [...section[1].matchAll(/`([^`]+)`|"([^"]+)"|([A-Za-z0-9_][A-Za-z0-9._-]*\.(?:png|jpe?g|svg|webp))/gi)];
  for (const match of names) {
    const candidate = (match[1] ?? match[2] ?? match[3] ?? "").trim();
    const basename = candidate.split(/[\\/]/).pop() ?? "";
    if (/^[A-Za-z0-9][A-Za-z0-9._-]*\.(png|jpe?g|svg|webp)$/i.test(basename)) return basename.toLowerCase();
  }
  return null;
}

async function findConventionImage(filename: string): Promise<string | null> {
  const slug = draftFilenameSlug(filename);
  for (const extension of ["png", "jpg", "jpeg", "webp", "svg"]) {
    const imageFile = `${slug}.${extension}`;
    try {
      await fs.access(path.join(SITE_IMG_DIR, imageFile));
      return imageFile;
    } catch {
      // image non présente côté site : on vérifie les propositions locales
    }
    try {
      await fs.access(path.join(PROPOSITIONS_DIR, imageFile));
      return imageFile;
    } catch {
      // extension suivante
    }
  }
  return null;
}

/** Découpe le brouillon en corps « web » conforme au modèle 44-48. */
export function buildWebBody(content: string): { body: string; excerpt: string; sources: string[] } {
  const lines = content.split("\n");
  let i = 0;
  if (lines[0]?.trim() === "---") {
    i = 1;
    while (i < lines.length && lines[i].trim() !== "---") i += 1;
    i += 1;
  }
  const title = parseFrontmatter(content).title ?? "";
  const bodyLines: string[] = [];
  for (; i < lines.length; i += 1) {
    const line = lines[i].trimEnd();
    const heading = line.match(/^(#{1,6})\s+(.*)$/);
    if (heading) {
      const head = heading[2].trim();
      const low = head.toLowerCase();
      if (low.startsWith("image proposée") || low.startsWith("image retenue") || low.includes("checklist")) break;
      if (head === title || title.startsWith(head) || head.startsWith(title.slice(0, 40))) continue;
      bodyLines.push(head);
      continue;
    }
    if (line.startsWith("> ")) continue;
    bodyLines.push(line);
  }
  const blocks: string[] = [];
  let current: string[] = [];
  for (const line of bodyLines) {
    if (line.trim() === "") {
      if (current.length > 0) {
        blocks.push(current.join("\n"));
        current = [];
      }
    } else {
      current.push(line);
    }
  }
  if (current.length > 0) blocks.push(current.join("\n"));
  let body = blocks
    .map((block) => block.trim())
    .filter(Boolean)
    .join("\n\n")
    .replace(/\*\*/g, "");
  body = body.replace(/\n{3,}/g, "\n\n");
  let excerpt = "";
  for (let index = 0; index < blocks.length - 1; index += 1) {
    const label = blocks[index].trim();
    if (label === "Introduction" || label === "Chapeau") {
      excerpt = blocks[index + 1].trim().replace(/\*\*/g, "");
      break;
    }
  }
  if (!excerpt && blocks.length > 0) excerpt = blocks[0].trim().replace(/\*\*/g, "");
  const sources: string[] = [];
  for (let index = blocks.length - 1; index >= 0; index -= 1) {
    const urls: string[] = [];
    for (const line of blocks[index].split("\n")) {
      const found = line.match(/https?:\/\/[^\s")\]}>]+/g);
      if (found) urls.push(...found);
    }
    if (urls.length > 0) {
      sources.push(...urls.map((url) => url.replace(/[.,;:]+$/, "")));
      break;
    }
  }
  return { body, excerpt, sources };
}

/** Publication d'un brouillon du jour dans data_store.json (site Flask local).
 * Publication unitaire possible : chaque article est publié dès qu'il est prêt,
 * visuel tranché et validé humainement — sans attendre les 3 sujets du jour. */
export async function publishDraftToStore(options: {
  date: string;
  filename: string;
  author?: string;
  image?: string;
  visualDecision?: string;
  visualFile?: string;
  humanConfirmed: boolean;
  allSubjectsRetained?: boolean;
  publishedAt?: string;
}): Promise<{ id: number; slug: string; title: string }> {
  if (!options.humanConfirmed) throw new Error("Validation humaine requise : cocher « Je valide la publication » avant de publier.");
  if (options.visualDecision !== "validee" && options.visualDecision !== "aucune") {
    throw new Error("Publication bloquée : illustration validée ou décision « aucun visuel » requise.");
  }
  const pattern = draftFilenamePattern(options.date);
  if (!pattern.test(options.filename)) throw new Error("Nom de brouillon invalide.");
  const filePath = await findPublishableArticleFile(options.date, options.filename);
  const content = await fs.readFile(filePath, "utf-8");
  if (!isDraftReady(content)) throw new Error("Brouillon non prêt : le chapo doit être rédigé ([x]) et le texte ne doit plus contenir « à compléter ».");
  const frontmatter = parseFrontmatter(content);
  const title = frontmatter.title?.trim();
  if (!title) throw new Error("Titre absent du frontmatter du brouillon.");
  const web = buildWebBody(content);
  if (web.sources.length === 0) throw new Error("Aucune source détectée dans le brouillon.");
  const filenameSlug = draftFilenameSlug(options.filename);
  const titleSlug = slugifyStoreTitle(title);
  const publishedAt = options.publishedAt ?? localDateString();

  const payload = await readStorePayload();
  const normalizedTitle = title.toLowerCase();
  const collision = payload.articles.find(
    (entry) =>
      entry.slug === filenameSlug ||
      (titleSlug !== filenameSlug && entry.slug === titleSlug) ||
      (entry.title ?? "").trim().toLowerCase() === normalizedTitle
  );
  if (collision) {
    throw new Error(
      `Article déjà publié avec ce slug : ${filenameSlug}${collision.status !== "published" ? ` (entrée id ${collision.id} en statut « ${collision.status} » dans le store — à retirer ou publier d'abord)` : ""}`
    );
  }

  let image: string | undefined;
  if (options.image) {
    const basename = options.image.split(/[\\/]/).pop() ?? "";
    if (!/^[A-Za-z0-9][A-Za-z0-9._-]*\.(png|jpe?g|svg|webp)$/i.test(basename)) throw new Error("Nom d'image invalide.");
    if (options.visualDecision === "validee" && options.visualFile) {
      const visualBasename = options.visualFile.split(/[\\/]/).pop() ?? "";
      if (basename !== visualBasename) throw new Error("Image incohérente : le fichier publié doit être le visuel validé.");
    }
    const target = path.join(SITE_IMG_DIR, basename);
    try {
      await fs.access(target);
    } catch {
      const propositions = path.join(PROPOSITIONS_DIR, basename);
      try {
        await fs.copyFile(propositions, target);
      } catch {
        throw new Error(`Fichier image introuvable : ${basename} (ni dans static/img du site ni dans public/propositions).`);
      }
    }
    image = basename;
  }

  await fs.mkdir(BACKUP_DIR, { recursive: true });
  await fs.copyFile(SITE_STORE, path.join(BACKUP_DIR, `data_store-${publishedAt}-${Date.now()}.json`));

  const wordCount = Math.max(1, web.body.split(/\s+/).length);
  const readingMinutes = Math.max(4, Math.round(wordCount / 170));
  const nextId = payload.articles.reduce((max, entry) => Math.max(max, entry.id), 0) + 1;

  const entry = {
    id: nextId,
    rubrique: "Aujourd'hui en Afrique",
    theme: frontmatter.themes?.split(",")[0]?.trim() || frontmatter.rubrique || "Actualité stratégique",
    title,
    excerpt: web.excerpt,
    status: "published",
    is_featured: 0,
    published_at: publishedAt,
    slug: filenameSlug,
    format: "article",
    format_label: "Aujourd'hui en Afrique",
    author: (options.author?.trim() || "Redaction VA").slice(0, 80),
    created_at: frontmatter.created?.trim() || publishedAt,
    reading_time: `${readingMinutes} min de lecture`,
    body: web.body,
    sources: web.sources,
    tags: [frontmatter.country?.trim() || "Afrique", "Aujourd'hui en Afrique"].filter(Boolean),
    country: frontmatter.country?.trim() || "Afrique",
    ...(image ? { image } : {}),
    confidence_level: "Moyen",
    notes_label: "Sources",
    citation_style: "french-footnotes",
    strategic_question: frontmatter.title ? `Quelle lecture stratégique de l'actualité « ${title} » pour l'Afrique ?` : "",
    key_points: [],
    methodology: {
      question: `Analyse de l'actualité « ${title} » sous l'angle stratégique.`,
      scope: `${frontmatter.country?.trim() || "Afrique"} et contexte régional`,
      period: publishedAt,
      sources: "Sources citées dans l'article ; validation humaine requise avant publication finale.",
      assumptions: "L'analyse distingue les faits rapportés, les interprétations et les incertitudes.",
      limits: "Les éléments annoncés doivent rester suivis auprès de sources primaires."
    },
    implications: [],
    limitations: "Article publié localement pour inspection ; validation humaine finale obligatoire avant diffusion externe.",
    verification_checklist: {
      sources_verified: true,
      facts_checked: true,
      peer_reviewed: false,
      human_validation_required: true
    }
  } as Record<string, unknown>;

  payload.articles.push(entry as unknown as StoreEntry);
  await fs.writeFile(SITE_STORE, `${JSON.stringify(payload, null, 2)}\n`, "utf-8");
  return { id: nextId, slug: filenameSlug, title };
}

/** État « publié ou non » des brouillons du jour, croisé avec le store du site. */
export async function listDayArticles(date: string): Promise<DayArticleInfo[]> {
  const files = await listPublishableArticleFiles(date);
  let storeEntries: StoreEntry[] = [];
  try {
    const payload = await readStorePayload();
    storeEntries = payload.articles;
  } catch {
    // store illisible : on renvoie l'état brouillons sans croisement
  }
  const infos: DayArticleInfo[] = [];
  for (const { filename, filePath } of files) {
    try {
      const content = await fs.readFile(filePath, "utf-8");
      const frontmatter = parseFrontmatter(content);
      const title = frontmatter.title?.trim() || filename;
      const filenameSlug = draftFilenameSlug(filename);
      const titleSlug = slugifyStoreTitle(title);
      const normalizedTitle = title.toLowerCase();
      // Correspondance par slug dérivable OU par titre exact (les slugs tiers peuvent diverger).
      const match = storeEntries.find(
        (entry) =>
          entry.status === "published" &&
          (entry.slug === filenameSlug || entry.slug === titleSlug || (entry.title ?? "").trim().toLowerCase() === normalizedTitle)
      );
      infos.push({
        filename,
        title,
        slug: filenameSlug,
        ready: isDraftReady(content),
        country: frontmatter.country?.trim() || "",
        imageFile: extractImageFileFromMarkdown(content) ?? (await findConventionImage(filename)),
        publishedId: match?.id ?? null,
        publishedSlug: match?.slug ?? null,
        publishedAt: match?.published_at ?? null
      });
    } catch {
      // fichier illisible : ignoré
    }
  }
  return infos;
}
