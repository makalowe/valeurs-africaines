import { getAllCountryProfilesSync } from "@/lib/atlas";

export type PowerPillar =
  | "Économie"
  | "Démographie"
  | "Défense"
  | "Diplomatie"
  | "Ressources stratégiques"
  | "Technologie"
  | "Infrastructures";

export type PowerTrend = "hausse" | "stable" | "baisse" | "à vérifier";

export type PowerIndexCountry = {
  country: string;
  slug: string;
  flag: string;
  region: string;
  rank: number | null;
  totalScore: number | null;
  annualEvolution: number | null;
  trend: PowerTrend;
  pillarScores: Record<PowerPillar, number | null>;
  strengths: string[];
  vulnerabilities: string[];
  strategicAnalysis: string;
  sources: string[];
  status: "non_calculé" | "à_vérifier" | "validé";
};

export type PowerPillarWeight = {
  pillar: PowerPillar;
  weight: number;
  variables: string[];
};

export const powerPillarWeights: PowerPillarWeight[] = [
  { pillar: "Économie", weight: 20, variables: ["PIB", "PIB PPA", "croissance", "industrialisation"] },
  { pillar: "Démographie", weight: 12, variables: ["population", "population active", "urbanisation"] },
  { pillar: "Défense", weight: 14, variables: ["dépenses militaires", "capacités opérationnelles", "industries de défense"] },
  { pillar: "Diplomatie", weight: 14, variables: ["influence régionale", "participation multilatérale", "médiation internationale"] },
  { pillar: "Ressources stratégiques", weight: 14, variables: ["énergie", "minerais critiques", "ressources agricoles"] },
  { pillar: "Technologie", weight: 12, variables: ["innovation", "numérique", "recherche"] },
  { pillar: "Infrastructures", weight: 14, variables: ["transport", "énergie", "connectivité"] }
];

export function getAfricanPowerIndexCountries(): PowerIndexCountry[] {
  return getAllCountryProfilesSync().map((profile) => ({
    country: profile.country,
    slug: profile.slug,
    flag: profile.flag,
    region: profile.region,
    rank: null,
    totalScore: null,
    annualEvolution: null,
    trend: "à vérifier",
    pillarScores: {
      Économie: null,
      Démographie: null,
      Défense: null,
      Diplomatie: null,
      "Ressources stratégiques": null,
      Technologie: null,
      Infrastructures: null
    },
    strengths: profile.opportunities.length ? profile.opportunities : ["Donnée à vérifier"],
    vulnerabilities: profile.risks.length ? profile.risks : ["Donnée à vérifier"],
    strategicAnalysis: "Analyse stratégique à produire après collecte et validation des sources chiffrées.",
    sources: [
      ...profile.sourcesToVerify,
      "Banque mondiale à vérifier",
      "FMI à vérifier",
      "BAD à vérifier",
      "SIPRI à vérifier",
      "ONU / PNUD à vérifier",
      "Instituts nationaux de statistique à vérifier"
    ],
    status: "non_calculé"
  }));
}

export function calculatePowerScore(pillarScores: Record<PowerPillar, number | null>): number | null {
  const hasMissingScore = powerPillarWeights.some(({ pillar }) => pillarScores[pillar] === null);
  if (hasMissingScore) return null;

  const score = powerPillarWeights.reduce((total, { pillar, weight }) => {
    const value = pillarScores[pillar] ?? 0;
    return total + value * (weight / 100);
  }, 0);

  return Number(score.toFixed(1));
}

export function getPowerIndexMethodology() {
  return {
    formula: "Score total = somme des scores de piliers normalisés sur 100, pondérés selon leur poids méthodologique.",
    scale: "Chaque pilier doit être normalisé de 0 à 100 à partir de sources vérifiées.",
    validation: "Aucun score ne doit être publié sans validation humaine et traçabilité des sources."
  };
}
