export type SDGSheet = {
  id: string;
  title: string;
  objectifs: string[];
  indicateurs: string[];
  paysConcernes: string[];
  projetsIdentifies: string[];
  acteursImpliques: string[];
  progres: string;
  blocages: string[];
  scoreAvancement: number;
};

export type Agenda2063Aspiration = {
  id: string;
  description: string;
  objectifs: string[];
  projetsAssocies: string[];
  etatAvancement: string;
  score: number;
};

export type CoverageScore = {
  id: string;
  label: string;
  coverage: number;
  articlesCount: number;
};

export type SDGAgendaAnalysis = {
  impactODD: string[];
  impactAgenda2063: string[];
  priorite: "Faible" | "Moyenne" | "Élevée" | "Critique";
  faits: string[];
  analyse: string[];
  hypotheses: string[];
  validation_humaine_requise: true;
  publication_automatique: false;
};

const sdgTitles = [
  "Pas de pauvreté",
  "Faim zéro",
  "Bonne santé",
  "Éducation de qualité",
  "Égalité des sexes",
  "Eau propre",
  "Énergie propre",
  "Travail décent",
  "Industrie et innovation",
  "Réduction des inégalités",
  "Villes durables",
  "Consommation responsable",
  "Action climatique",
  "Vie aquatique",
  "Vie terrestre",
  "Paix et institutions",
  "Partenariats"
];

const aspirationDescriptions = [
  "Une Afrique prospère fondée sur la croissance inclusive et le développement durable.",
  "Un continent intégré, politiquement uni et fondé sur les idéaux du panafricanisme.",
  "Une Afrique de bonne gouvernance, de démocratie, de respect des droits humains et d'État de droit.",
  "Une Afrique pacifique et sûre.",
  "Une Afrique avec une identité culturelle forte, un patrimoine commun et des valeurs partagées.",
  "Une Afrique dont le développement est axé sur les populations, notamment les femmes et les jeunes.",
  "Une Afrique acteur et partenaire mondial fort, uni, résilient et influent."
];

export function getAllSDGSheets(): SDGSheet[] {
  return sdgTitles.map((title, index) => {
    const id = `ODD ${index + 1}`;
    return {
      id,
      title,
      objectifs: [`Objectifs ${id} à documenter avec sources ONU et données nationales.`],
      indicateurs: ["budget engagé", "population concernée", "taux d'accès", "résultats observables"],
      paysConcernes: ["Afrique"],
      projetsIdentifies: ["projets à vérifier"],
      acteursImpliques: ["ONU", "Union africaine", "États", "acteurs à vérifier"],
      progres: "donnée à vérifier",
      blocages: ["financement", "gouvernance", "données incomplètes"],
      scoreAvancement: defaultCoverageForSDG(index + 1)
    };
  });
}

export function getAgenda2063Aspirations(): Agenda2063Aspiration[] {
  return aspirationDescriptions.map((description, index) => ({
    id: `Aspiration ${index + 1}`,
    description,
    objectifs: ["objectifs à vérifier dans la documentation Union africaine"],
    projetsAssocies: ["projets Agenda 2063 à documenter"],
    etatAvancement: "donnée à vérifier",
    score: [58, 62, 49, 54, 43, 61, 52][index]
  }));
}

export function analyzeArticleAgainstSDGAgenda(input: { title: string; content: string; themes?: string[] }): SDGAgendaAnalysis {
  const text = `${input.title} ${input.content} ${(input.themes ?? []).join(" ")}`.toLowerCase();
  const impactODD = detectSDGs(text);
  const impactAgenda2063 = detectAgendaAspirations(text);
  const score = impactODD.length * 10 + impactAgenda2063.length * 8 + (text.includes("souverain") ? 10 : 0);

  return {
    impactODD,
    impactAgenda2063,
    priorite: score >= 50 ? "Critique" : score >= 35 ? "Élevée" : score >= 20 ? "Moyenne" : "Faible",
    faits: ["faits à confirmer par sources vérifiées"],
    analyse: ["analyse stratégique Valeurs Africaines à produire"],
    hypotheses: ["hypothèses à signaler explicitement"],
    validation_humaine_requise: true,
    publication_automatique: false
  };
}

export function getSDGCoverageScores(): CoverageScore[] {
  return getAllSDGSheets().map((sdg, index) => ({
    id: sdg.id,
    label: sdg.title,
    coverage: defaultCoverageForSDG(index + 1),
    articlesCount: Math.round(defaultCoverageForSDG(index + 1) / 10)
  }));
}

export function getAgendaCoverageScores(): CoverageScore[] {
  return getAgenda2063Aspirations().map((aspiration) => ({
    id: aspiration.id,
    label: aspiration.description,
    coverage: aspiration.score,
    articlesCount: Math.round(aspiration.score / 12)
  }));
}

export function getSDGAgendaAlerts(): string[] {
  const sdgAlerts = getSDGCoverageScores()
    .filter((item) => item.coverage <= 30)
    .map((item) => `ALERTE : ${item.id} sous-couvert ou jamais couvert récemment.`);
  const agendaAlerts = getAgendaCoverageScores()
    .filter((item) => item.coverage <= 50)
    .map((item) => `ALERTE : ${item.id} peu couverte.`);
  return [
    ...sdgAlerts,
    ...agendaAlerts,
    "ALERTE : Aucun contenu lié à l’ODD 14 depuis 90 jours."
  ];
}

function detectSDGs(text: string): string[] {
  const matches: string[] = [];
  if (/pauvreté|revenu|social/.test(text)) matches.push("ODD 1");
  if (/agriculture|faim|alimentaire/.test(text)) matches.push("ODD 2");
  if (/santé|médecine|hôpital/.test(text)) matches.push("ODD 3");
  if (/éducation|université|formation|recherche/.test(text)) matches.push("ODD 4");
  if (/femme|genre|égalité/.test(text)) matches.push("ODD 5");
  if (/eau|hydrique/.test(text)) matches.push("ODD 6");
  if (/énergie|solaire|hydrogène/.test(text)) matches.push("ODD 7");
  if (/emploi|travail|croissance|business/.test(text)) matches.push("ODD 8");
  if (/industrie|innovation|infrastructure|technologie/.test(text)) matches.push("ODD 9");
  if (/inégalité|diaspora|inclusion/.test(text)) matches.push("ODD 10");
  if (/ville|urbain|transport/.test(text)) matches.push("ODD 11");
  if (/déchet|circulaire|consommation/.test(text)) matches.push("ODD 12");
  if (/climat|adaptation/.test(text)) matches.push("ODD 13");
  if (/océan|pêche|maritime/.test(text)) matches.push("ODD 14");
  if (/biodiversité|forêt|terre/.test(text)) matches.push("ODD 15");
  if (/paix|gouvernance|institution|conflit/.test(text)) matches.push("ODD 16");
  if (/partenariat|coopération|union africaine/.test(text)) matches.push("ODD 17");
  return matches.length ? matches : ["ODD à vérifier"];
}

function detectAgendaAspirations(text: string): string[] {
  const matches: string[] = [];
  if (/croissance|développement|durable|économie/.test(text)) matches.push("Aspiration 1");
  if (/intégration|zlecaf|panafricain/.test(text)) matches.push("Aspiration 2");
  if (/gouvernance|démocratie|institution/.test(text)) matches.push("Aspiration 3");
  if (/paix|sécurité|conflit/.test(text)) matches.push("Aspiration 4");
  if (/culture|patrimoine|identité/.test(text)) matches.push("Aspiration 5");
  if (/jeunesse|femme|diaspora|talent/.test(text)) matches.push("Aspiration 6");
  if (/influence|international|partenaire|brics/.test(text)) matches.push("Aspiration 7");
  return matches.length ? matches : ["Aspiration à vérifier"];
}

function defaultCoverageForSDG(number: number): number {
  const values = [50, 20, 60, 70, 40, 35, 80, 65, 90, 45, 38, 30, 60, 10, 25, 70, 55];
  return values[number - 1] ?? 0;
}
