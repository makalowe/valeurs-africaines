export function buildHarnessWatchPrompt(date: string): string {
  return `Objectif: créer une veille Valeurs Africaines avec EXACTEMENT 6 sujets candidats pour préparer la sélection des 3 publications « Aujourd'hui en Afrique » du ${date}.

Workspace: C:\\Users\\MIMBI\\OneDrive\\Documents\\VA

Fichiers autorisés:
- 00-INBOX/
- 00-INBOX/Veille - ${date}.md

Contraintes:
- Mode rapide: ne scanne pas tout le workspace
- Ne lis que 00-INBOX et les fichiers de veille récents nécessaires
- Ne fais pas de recherche web large
- Si une source manque, écris "Source non connectée" au lieu de chercher longtemps
- EXACTEMENT 6 sujets candidats, un par rubrique:
  1. Actualité stratégique
  2. Économie, sécurité et diplomatie
  3. Innovation, gouvernance, culture et médias
  4. Géopolitique
  5. Business & économie
  6. Innovation / Recherche / Diaspora
- Sources obligatoires avec URL complète quand elles existent déjà dans l'inbox (sinon "Source non connectée")
- Faits distincts de l'analyse et des hypothèses
- Ne modifie aucun autre fichier
- Ne publie rien
- Ne fais pas de commit
- Réponse courte et orientée action
- Temps cible: moins de 5 minutes

Rapporte seulement:
- les 6 sujets candidats (avec rubrique)
- sources disponibles
- sources non connectées ou manquantes
- risques / points à valider humainement
- prochaine action

FORMAT DE SORTIE OBLIGATOIRE (lisible par le parser de l'OS — sections ### impératives) dans 00-INBOX/Veille - ${date}.md:

# Veille Valeurs Africaines — ${date}

## Sujet 1 — Actualité stratégique : [titre]

### Pourquoi maintenant
[2-3 phrases]

### Faits
- [fait vérifié]

### Sources
- https://...

### Risque à valider
- [point à valider]

(… répéter pour les sujets 2 à 6 avec leur rubrique respective …)

Validation humaine obligatoire avant publication.`;
}

export function formatLocalDate(date: Date): string {
  const month = `${date.getMonth() + 1}`.padStart(2, "0");
  const day = `${date.getDate()}`.padStart(2, "0");
  return `${date.getFullYear()}-${month}-${day}`;
}

export const CODEX_DRAFT_THREAD_URL = "codex://threads/019ded01-3e19-75d0-926b-f973dd518a72";

export function buildCodexDraftPrompt(input: {
  date: string;
  title: string;
  rubric: string;
  pourquoi: string;
  countries: string[];
  sourceUrls: string[];
  risk: string;
}): string {
  return `Objectif: rédiger un brouillon d'article Valeurs Africaines (édition hebdomadaire) à partir du sujet retenu par la veille du ${input.date}.

Sujet:
- Titre : ${input.title}
- Rubrique : ${input.rubric}
- Pourquoi maintenant : ${input.pourquoi}
- Pays / région : ${input.countries.length > 0 ? input.countries.join(", ") : "À préciser"}
- Source(s) : ${input.sourceUrls.join(" · ") || "À compléter"}
- Risque identifié : ${input.risk}

Contraintes:
- Garder faits / analyse / hypothèses clairement séparés
- Conserver les sources avec URL complète
- Ne publie rien
- Ne fais pas de commit
- Réponse courte et orientée action

Rapporte seulement:
- fichier brouillon créé (chemin exact)
- points à valider humainement`;
}
