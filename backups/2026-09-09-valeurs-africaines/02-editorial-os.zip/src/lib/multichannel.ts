import type { PlanningRow } from "@/lib/googleSheets";

export type MultichannelChannel = "linkedin" | "x" | "newsletter" | "instagram";

export type MultichannelInput = {
  row: PlanningRow;
  sourceContent?: string;
  sources?: string[];
};

export type MultichannelDrafts = {
  linkedin: string;
  x: string[];
  newsletter: string;
  instagram: string[];
  markdown: string;
  html: string;
  sources: string[];
  validation_humaine_obligatoire: true;
  publication_automatique: false;
};

export function generateLinkedInPost(input: MultichannelInput): string {
  const { row } = input;
  return `# ${row.sujet}

${row.angle_strategique}

Ce qu'il faut retenir :
- Faits : le sujet doit etre relu et source avant diffusion.
- Analyse : l'enjeu porte sur ${row.rubrique}.
- Hypothese : les consequences dependront des decisions des acteurs concernes.

Pour l'Afrique, l'enjeu est de transformer l'information en lecture strategique, sans confondre signal faible, fait etabli et projection.

Sources internes a verifier :
${formatSources(input.sources)}

#ValeursAfricaines #Afrique #Geopolitique #Strategie`;
}

export function generateXThread(input: MultichannelInput): string[] {
  const { row } = input;
  return [
    `1/ ${row.sujet}\n\nAngle : ${row.angle_strategique}`,
    `2/ Faits a verifier : le contenu source provient du planning editorial ${row.id}. Aucune diffusion sans validation humaine.`,
    `3/ Analyse : ce sujet releve de ${row.rubrique}. Il doit etre lu dans une perspective africaine et strategique.`,
    `4/ Hypothese : l'impact dependra du rapport de force, des acteurs impliques et du calendrier politique/economique.`,
    `5/ Sources internes : ${input.sources?.length ? input.sources.join(" | ") : "sources a verifier"}`
  ];
}

export function generateNewsletterBlock(input: MultichannelInput): string {
  const { row } = input;
  return `## ${row.sujet}

**Rubrique :** ${row.rubrique}

**Faits.** Le sujet est identifie dans le planning editorial sous l'ID ${row.id}. Les donnees doivent etre verifiees avant diffusion.

**Analyse.** ${row.angle_strategique}

**Hypotheses.** Les effets a moyen terme restent conditionnes par les arbitrages politiques, economiques et diplomatiques.

**Sources conservees.** ${input.sources?.length ? input.sources.join(" ; ") : "Sources a verifier."}`;
}

export function generateInstagramCarousel(input: MultichannelInput): string[] {
  const { row } = input;
  return [
    `Slide 1 — ${row.sujet}`,
    `Slide 2 — Le fait\nSujet identifie : ${row.format} / ${row.rubrique}`,
    `Slide 3 — L'enjeu strategique\n${row.angle_strategique}`,
    "Slide 4 — Ce qui est certain\nDistinguer les faits verifies des interpretations.",
    "Slide 5 — Ce qui reste a surveiller\nActeurs, calendrier, effets regionaux, risques.",
    `Slide 6 — Sources\n${input.sources?.length ? input.sources.join("\n") : "Sources a verifier avant diffusion."}`
  ];
}

export function exportMarkdown(drafts: Omit<MultichannelDrafts, "markdown" | "html">): string {
  return `# Déclinaisons multicanales

> Brouillons uniquement. Validation humaine obligatoire. Aucune publication automatique.

## LinkedIn

${drafts.linkedin}

## X / Twitter

${drafts.x.map((post) => `- ${post.replace(/\n/g, "\n  ")}`).join("\n\n")}

## Newsletter

${drafts.newsletter}

## Instagram carousel

${drafts.instagram.map((slide) => `- ${slide.replace(/\n/g, "\n  ")}`).join("\n\n")}

## Sources conservées

${drafts.sources.length ? drafts.sources.map((source) => `- ${source}`).join("\n") : "- Sources a verifier."}
`;
}

export function exportHtml(markdown: string): string {
  const lines = markdown.split("\n");
  return lines
    .map((line) => {
      if (line.startsWith("# ")) return `<h1>${escapeHtml(line.slice(2))}</h1>`;
      if (line.startsWith("## ")) return `<h2>${escapeHtml(line.slice(3))}</h2>`;
      if (line.startsWith("> ")) return `<blockquote>${escapeHtml(line.slice(2))}</blockquote>`;
      if (line.startsWith("- ")) return `<li>${escapeHtml(line.slice(2))}</li>`;
      if (!line.trim()) return "";
      return `<p>${escapeHtml(line)}</p>`;
    })
    .join("\n");
}

export function generateMultichannelDrafts(input: MultichannelInput, channels: MultichannelChannel[]): MultichannelDrafts {
  const selected = new Set(channels);
  const base = {
    linkedin: selected.has("linkedin") ? generateLinkedInPost(input) : "",
    x: selected.has("x") ? generateXThread(input) : [],
    newsletter: selected.has("newsletter") ? generateNewsletterBlock(input) : "",
    instagram: selected.has("instagram") ? generateInstagramCarousel(input) : [],
    sources: input.sources ?? [],
    validation_humaine_obligatoire: true as const,
    publication_automatique: false as const
  };
  const markdown = exportMarkdown(base);

  return {
    ...base,
    markdown,
    html: exportHtml(markdown)
  };
}

export function isHumanValidated(row: PlanningRow): boolean {
  const status = row.statut.trim().toLowerCase();
  return row.validation_humaine.trim().toLowerCase() === "oui" || status.includes("valid");
}

function formatSources(sources?: string[]): string {
  return sources?.length ? sources.map((source) => `- ${source}`).join("\n") : "- Sources a verifier.";
}

function escapeHtml(value: string): string {
  return value
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}
