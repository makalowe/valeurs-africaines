export type SustainableFormat =
  | "Green Brief"
  | "Analyse sectorielle"
  | "Projet innovant"
  | "Initiative locale"
  | "Cartographie environnementale";

export type SustainableInput = {
  sujet: string;
  format: SustainableFormat;
  axe: string;
  pays: string;
  acteurs: string[];
  sources: string[];
};

export type SustainableDraft = {
  draft: string;
  sources_a_verifier: string[];
  niveau_confiance: "faible" | "moyen" | "élevé";
  validation_humaine_requise: true;
  publication_automatique: false;
};

export const sustainableAxes = [
  "Transition énergétique",
  "Énergies renouvelables",
  "Eau",
  "Agriculture durable",
  "Gestion des déchets",
  "Reforestation",
  "Adaptation climatique",
  "Économie circulaire",
  "Finance verte",
  "Hydrogène vert",
  "Biodiversité",
  "Villes durables"
];

export function generateSustainableDraft(input: SustainableInput): SustainableDraft {
  const sources = input.sources.filter(Boolean);
  const actors = input.acteurs.length ? input.acteurs.join(", ") : "acteurs publics, privés et scientifiques à identifier";

  return {
    draft: [
      `# ${input.format} — ${input.sujet || "Sujet environnemental à préciser"}`,
      "",
      "Question centrale : Comment concilier développement économique, croissance démographique et durabilité ?",
      "",
      "## Résumé exécutif",
      `Analyse de ${input.sujet || "l'enjeu à documenter"} sous l'angle ${input.axe || "écologie et économie durable"}, en reliant environnement, souveraineté, développement et opportunités africaines.`,
      "",
      "## Faits scientifiques",
      "Présenter uniquement des données climatiques, énergétiques, hydriques, agricoles ou écologiques vérifiées. Signaler toute donnée manquante ou incertaine.",
      "",
      "## Politiques publiques",
      `Pays / région : ${input.pays || "à vérifier"}. Identifier lois, stratégies nationales, engagements internationaux, financements publics et cadres réglementaires.`,
      "",
      "## Impacts économiques",
      "Analyser coûts, investissements, emplois, productivité, souveraineté industrielle, risques pour les ménages et effets sur les entreprises.",
      "",
      "## Opportunités africaines",
      "Identifier les opportunités : énergies renouvelables, chaînes de valeur locales, agriculture résiliente, finance verte, infrastructures, innovation et coopération intra-africaine.",
      "",
      "## Acteurs clés",
      actors,
      "",
      "## Points à surveiller",
      "- Données scientifiques à confirmer.",
      "- Financement et gouvernance des projets.",
      "- Effets sociaux et territoriaux.",
      "- Capacité à créer de la valeur locale.",
      "",
      "## Sources à vérifier",
      sources.length ? sources.map((source) => `- ${source}`).join("\n") : "- Sources scientifiques, rapports institutionnels, données publiques, projets locaux, bailleurs et médias spécialisés.",
      "",
      "Conclusion stratégique",
      "Ce contenu est un brouillon. Il doit être relu, sourcé, complété par des propositions visuelles et validé humainement avant publication."
    ].join("\n"),
    sources_a_verifier: sources.length ? sources : ["données scientifiques", "rapports institutionnels", "politiques publiques", "projets locaux"],
    niveau_confiance: calculateConfidence(input),
    validation_humaine_requise: true,
    publication_automatique: false
  };
}

function calculateConfidence(input: SustainableInput): SustainableDraft["niveau_confiance"] {
  let score = 0;
  if (input.sujet.trim()) score += 20;
  if (input.axe.trim()) score += 20;
  if (input.pays.trim()) score += 15;
  score += Math.min(20, input.acteurs.length * 6);
  score += Math.min(25, input.sources.length * 8);
  if (score >= 75) return "élevé";
  if (score >= 40) return "moyen";
  return "faible";
}
