export type StrategicActorCategory =
  | "États africains"
  | "Organisations régionales"
  | "Union africaine"
  | "Institutions financières"
  | "Entreprises stratégiques"
  | "Acteurs miniers"
  | "Acteurs énergétiques"
  | "Acteurs technologiques"
  | "Médias et influence"
  | "Fondations et ONG"
  | "Puissances extérieures"
  | "Organisations de sécurité et défense";

export type InfluenceLevel = "faible" | "moyen" | "élevé" | "critique" | "à vérifier";
export type RiskLevel = "faible" | "moyen" | "élevé" | "critique" | "à vérifier";
export type ActorVerificationStatus = "source_absente" | "à_vérifier" | "vérifié";

export type StrategicActor = {
  id: string;
  name: string;
  type: string;
  category: StrategicActorCategory;
  originCountry: string;
  headquarters: string;
  createdAt: string;
  influenceZones: string[];
  sector: string;
  description: string;
  strategicInterests: string[];
  interests: {
    economic: string[];
    security: string[];
    diplomatic: string[];
    technological: string[];
  };
  partners: string[];
  competitors: string[];
  partnerships: {
    allies: string[];
    competitors: string[];
  };
  influenceLevel: InfluenceLevel;
  riskLevel: RiskLevel;
  sources: string[];
  verificationStatus: ActorVerificationStatus;
  africaImpact: string;
  detailedProfile: {
    executiveSummary: string;
    objectives: string[];
    capabilities: string[];
    influenceNetworks: string[];
    presenceInAfrica: string;
    recentEvolution: string;
    africaImplications: string;
  };
  networkPosition: {
    x: number;
    y: number;
  };
};

export type StrategicActorRelationType = "alliance" | "rivalité" | "dépendance" | "coopération";

export type StrategicActorRelation = {
  id: string;
  sourceId: string;
  targetId: string;
  type: StrategicActorRelationType;
  intensity: "faible" | "moyenne" | "forte" | "à vérifier";
  source: string;
  verificationStatus: ActorVerificationStatus;
};

const unavailable = "Donnée à vérifier";
const sourceRequired = "Source obligatoire à vérifier avant publication";

export const strategicActors: StrategicActor[] = [
  actor("union-africaine", "Union Africaine", "Union africaine", "Organisation continentale", "Afrique", "Institutions et gouvernance", 52, 28),
  actor("cedeao", "CEDEAO", "Organisations régionales", "Organisation régionale", "Afrique de l'Ouest", "Gouvernance régionale", 32, 42),
  actor("sadc", "SADC", "Organisations régionales", "Organisation régionale", "Afrique Australe", "Gouvernance régionale", 58, 72),
  actor("bad", "BAD", "Institutions financières", "Institution financière", "Afrique", "Finance du développement", 44, 46),
  actor("afreximbank", "Afreximbank", "Institutions financières", "Institution financière", "Afrique", "Commerce et financement", 48, 52),
  actor("onu", "ONU", "Organisations de sécurité et défense", "Organisation internationale", "International", "Paix, sécurité et développement", 62, 36),
  actor("chine", "Chine", "Puissances extérieures", "État", "Chine", "Diplomatie, économie et technologie", 68, 50),
  actor("union-europeenne", "Union européenne", "Puissances extérieures", "Organisation internationale", "Europe", "Diplomatie, normes et financement", 40, 34),
  actor("etats-unis", "États-Unis", "Puissances extérieures", "État", "États-Unis", "Diplomatie, sécurité et technologie", 36, 50),
  actor("russie", "Russie", "Puissances extérieures", "État", "Russie", "Diplomatie, sécurité et influence", 56, 40)
];

export const strategicActorRelations: StrategicActorRelation[] = [];

export const strategicActorCategories: StrategicActorCategory[] = [
  "États africains",
  "Organisations régionales",
  "Union africaine",
  "Institutions financières",
  "Entreprises stratégiques",
  "Acteurs miniers",
  "Acteurs énergétiques",
  "Acteurs technologiques",
  "Médias et influence",
  "Fondations et ONG",
  "Puissances extérieures",
  "Organisations de sécurité et défense"
];

export const strategicActorZones = [
  "Afrique",
  "Afrique du Nord",
  "Afrique de l'Ouest",
  "Afrique Centrale",
  "Afrique de l'Est",
  "Afrique Australe",
  "International",
  "Chine",
  "Europe",
  "États-Unis",
  "Russie"
];

export const strategicActorSectors = [
  "Tous les secteurs",
  "Institutions et gouvernance",
  "Gouvernance régionale",
  "Finance du développement",
  "Commerce et financement",
  "Paix, sécurité et développement",
  "Diplomatie, économie et technologie",
  "Diplomatie, normes et financement",
  "Diplomatie, sécurité et technologie",
  "Diplomatie, sécurité et influence"
];

function actor(
  id: string,
  name: string,
  category: StrategicActorCategory,
  type: string,
  originCountry: string,
  sector: string,
  x: number,
  y: number
): StrategicActor {
  return {
    id,
    name,
    type,
    category,
    originCountry,
    headquarters: unavailable,
    createdAt: unavailable,
    influenceZones: ["Afrique", originCountry, "zones précises à vérifier"],
    sector,
    description: "Fiche structurelle à documenter par sources traçables avant toute publication.",
    strategicInterests: [unavailable],
    interests: {
      economic: [unavailable],
      security: [unavailable],
      diplomatic: [unavailable],
      technological: [unavailable]
    },
    partners: [unavailable],
    competitors: [unavailable],
    partnerships: {
      allies: [unavailable],
      competitors: [unavailable]
    },
    influenceLevel: "à vérifier",
    riskLevel: "à vérifier",
    sources: [sourceRequired],
    verificationStatus: "à_vérifier",
    africaImpact: "Impact à analyser après collecte de sources vérifiées et validation éditoriale.",
    detailedProfile: {
      executiveSummary: "Résumé exécutif à produire après vérification documentaire.",
      objectives: [unavailable],
      capabilities: [unavailable],
      influenceNetworks: [unavailable],
      presenceInAfrica: unavailable,
      recentEvolution: unavailable,
      africaImplications: "Implications pour l'Afrique à analyser après vérification des faits."
    },
    networkPosition: { x, y }
  };
}
