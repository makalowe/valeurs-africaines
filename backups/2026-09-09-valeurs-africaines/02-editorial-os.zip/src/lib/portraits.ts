export type PortraitInput = {
  nom: string;
  pays: string;
  domaine: string;
  institution: string;
  fonction?: string;
  sources: string[];
};

export type PortraitResult = {
  portrait: string;
  sources_a_verifier: string[];
  niveau_confiance: "faible" | "moyen" | "élevé";
  validation_humaine_requise: true;
};

export type PortraitVisualProposal = {
  id: string;
  type: "photo" | "illustration" | "diagramme";
  title: string;
  description: string;
  prompt: string;
  rightsNote: string;
};

export function generatePortraitKnowledgeMarkdown(input: PortraitInput & { diaspora?: boolean; themes?: string[]; fiabilite?: string }): string {
  const date = new Date().toISOString().slice(0, 10);
  const themes = input.themes?.length ? input.themes : [input.domaine, "Innovation", "Diaspora africaine"].filter(Boolean);
  const sources = input.sources.length ? input.sources : ["sources à vérifier"];

  return [
    "---",
    "type: portrait",
    `nom: ${input.nom}`,
    `pays: ${input.pays}`,
    `domaine: ${input.domaine}`,
    `institution: ${input.institution}`,
    `themes: [${themes.join(", ")}]`,
    `diaspora: ${input.diaspora ? "oui" : "à vérifier"}`,
    `sources: [${sources.join(", ")}]`,
    `fiabilite: ${input.fiabilite ?? "à vérifier"}`,
    `date: ${date}`,
    "---",
    "",
    `# ${input.nom}`,
    "",
    `Liens : [[${input.pays || "Pays à vérifier"}]] [[${input.institution || "Institution à vérifier"}]] [[${input.domaine || "Domaine à vérifier"}]] [[Innovation]] [[Diaspora africaine]]`,
    "",
    generateAcademicProfile(input).portrait
  ].join("\n");
}

export function generateResearcherPortrait(input: PortraitInput): PortraitResult {
  return buildPortrait(input, "chercheur ou chercheuse");
}

export function generateInnovatorPortrait(input: PortraitInput): PortraitResult {
  return buildPortrait(input, "innovateur ou innovatrice");
}

export function generateAcademicProfile(input: PortraitInput): PortraitResult {
  return buildPortrait(input, "profil académique");
}

export function extractKeyAchievements(input: PortraitInput): string[] {
  return input.sources.length > 0
    ? ["Contributions à documenter à partir des sources fournies", "Publications, prix ou postes à vérifier avant mention"]
    : ["Contributions majeures à vérifier", "Prix, publications et fonctions à ne pas attribuer sans source"];
}

export function identifyResearchImpact(input: PortraitInput): string {
  return `Impact potentiel dans le domaine ${input.domaine || "à préciser"} : formation, production de savoirs, innovation et influence institutionnelle à documenter.`;
}

export function generateAfricaImpactSection(input: PortraitInput): string {
  return `L'intérêt pour l'Afrique doit être établi à partir de faits confirmés : contribution scientifique, transfert de compétences, réseaux académiques, innovation utile au continent ou rôle dans la diaspora africaine. Pour ${input.nom}, cette section doit rester prudente tant que les sources ne sont pas complètes.`;
}

export function generatePortraitVisualProposals(input: PortraitInput): PortraitVisualProposal[] {
  const subject = input.nom || "profil africain à documenter";

  return [
    {
      id: "portrait-visual-1",
      type: "photo",
      title: "Option A - Portrait photographique professionnel",
      description: "Portrait professionnel issu d'une université, institution, laboratoire ou conférence, uniquement avec droits et crédit vérifiés.",
      prompt: `Rechercher un portrait photographique professionnel de ${subject}, ${input.institution || "institution à vérifier"}, contexte académique, scientifique ou technologique.`,
      rightsNote: "Vérifier les droits d'utilisation, le crédit et l'autorisation avant publication."
    },
    {
      id: "portrait-visual-2",
      type: "illustration",
      title: "Option B - Illustration éditoriale premium",
      description: "Illustration valorisante, premium et non sensationnaliste, qui représente le domaine de recherche sans inventer de scène réelle.",
      prompt: `Illustration éditoriale premium de ${subject}, domaine ${input.domaine || "savoirs africains"}, esthétique magazine panafricain, noir blanc or, symboles académiques génériques.`,
      rightsNote: "Illustration générable uniquement après validation humaine."
    },
    {
      id: "portrait-visual-3",
      type: "diagramme",
      title: "Option C - Infographie de carrière",
      description: "Infographie formation -> recherche -> publications -> innovation -> impact, basée uniquement sur des éléments vérifiés.",
      prompt: `Infographie de carrière pour ${subject}: formation -> recherche -> publications -> innovation -> impact. Marquer les zones non vérifiées comme à documenter.`,
      rightsNote: "Graphique interne fondé sur sources vérifiées uniquement."
    }
  ];
}

function buildPortrait(input: PortraitInput, profileType: string): PortraitResult {
  const sources = input.sources.filter(Boolean);
  const sourceText = sources.length > 0 ? sources.map((source) => `- ${source}`).join("\n") : "- Sources à vérifier";
  const confiance = calculateConfidence(input);
  const title = "Portrait de la semaine";

  return {
    portrait: [
      `# ${title}`,
      "",
      `Nom : ${input.nom || "à vérifier"}`,
      `Pays d'origine : ${input.pays || "à vérifier"}`,
      `Institution : ${input.institution || "à vérifier"}`,
      `Fonction : ${input.fonction || "à vérifier"}`,
      `Domaine : ${input.domaine || "à vérifier"}`,
      "",
      "Chapeau :",
      `${input.nom || "Ce profil"} est un ${profileType} dont le parcours doit être présenté avec rigueur, sans attribuer de diplôme, poste, prix, publication ou découverte sans source vérifiée. L'enjeu éditorial est de comprendre pourquoi cette personnalité africaine ou afro-descendante compte pour les savoirs, l'innovation ou la gouvernance.`,
      "",
      "## Parcours académique",
      `Éléments confirmés à établir : pays (${input.pays || "à vérifier"}), institution (${input.institution || "à vérifier"}), formations, postes et affiliations. Ne mentionner aucun diplôme non sourcé.`,
      "",
      "## Travaux majeurs",
      `${input.domaine || "Domaine à vérifier"}. Distinguer les travaux confirmés, les hypothèses éditoriales et les informations encore à documenter.`,
      "",
      "## Contributions scientifiques ou technologiques",
      extractKeyAchievements(input).map((item) => `- ${item}`).join("\n"),
      "",
      "## Impact international",
      "Évaluer la portée internationale à partir de publications, citations, collaborations, institutions, prix ou responsabilités confirmés par des sources vérifiées.",
      "",
      "## Pourquoi cette personnalité compte pour l'Afrique",
      generateAfricaImpactSection(input),
      "",
      "## Ce qu’il faut retenir",
      "- Quelle connaissance cette personne produit-elle ?",
      "- Quel problème cherche-t-elle à résoudre ?",
      "- Pourquoi ses travaux sont-ils importants ?",
      "- Quel bénéfice potentiel pour l'Afrique ?",
      "- Quel rôle joue-t-elle dans le rayonnement scientifique africain ?",
      "",
      "## Sources à vérifier",
      sourceText,
      "",
      "Conclusion stratégique",
      "Ce portrait doit valoriser le capital intellectuel africain sans exagération, en montrant l'apport potentiel du profil aux savoirs, à l'innovation et au rayonnement scientifique africain.",
      "",
      "Portrait prêt.",
      "Veux-tu le publier ?",
      "Réponds OUI ou NON.",
      "",
      "Si OUI :",
      "Validation humaine requise avant publication finale."
    ].join("\n"),
    sources_a_verifier: sources.length > 0 ? sources : ["CV institutionnel", "page université/laboratoire", "publications", "interviews ou communiqués officiels"],
    niveau_confiance: confiance,
    validation_humaine_requise: true
  };
}

function calculateConfidence(input: PortraitInput): PortraitResult["niveau_confiance"] {
  let score = 0;
  if (input.nom.trim()) score += 20;
  if (input.pays.trim()) score += 15;
  if (input.domaine.trim()) score += 15;
  if (input.institution.trim()) score += 20;
  score += Math.min(30, input.sources.length * 10);

  if (score >= 80) return "élevé";
  if (score >= 45) return "moyen";
  return "faible";
}
