"use client";

import { useEffect, useState } from "react";
import type { EditorialDashboardData } from "@/lib/editorialDashboardData";

export type DayArticleClient = {
  filename: string;
  title: string;
  slug: string;
  ready: boolean;
  publishedId: number | null;
  publishedAt: string | null;
  imageFile: string | null;
  publishedSlug: string | null;
};

export type StoreSummary = {
  total: number;
  published: number;
  publishedToday: number;
  rubriques: Array<{ rubrique: string; count: number }>;
  latest: Array<{ id: number; title: string; slug: string; published_at: string | null }>;
};

export type PilotageData = {
  loading: boolean;
  error: string | null;
  dashboard: EditorialDashboardData | null;
  store: StoreSummary | null;
  day: DayArticleClient[] | null;
  refresh: () => void;
};

/** Charge les vraies données du pilotage : dashboard fichiers réels + résumé du store Flask + état du jour. */
export function usePilotageData(): PilotageData {
  const [nonce, setNonce] = useState(0);
  const [data, setData] = useState<{ dashboard: EditorialDashboardData | null; store: StoreSummary | null; day: DayArticleClient[] | null; error: string | null }>({
    dashboard: null,
    store: null,
    day: null,
    error: null
  });

  useEffect(() => {
    let cancelled = false;
    async function load() {
      try {
        const dashboardResponse = await fetch("/api/editorial-dashboard", { cache: "no-store" });
        if (!dashboardResponse.ok) throw new Error(`Dashboard HTTP ${dashboardResponse.status}`);
        const dashboard = (await dashboardResponse.json()) as EditorialDashboardData;
        const storeResponse = await fetch("/api/publish", { cache: "no-store" });
        const store = storeResponse.ok
          ? ((await storeResponse.json()) as { ok: boolean; summary: StoreSummary }).summary
          : null;
        let day: DayArticleClient[] | null = null;
        const date = dashboard?.review?.date ?? dashboard?.watch.date ?? "";
        if (date) {
          const dayResponse = await fetch(`/api/publish?date=${encodeURIComponent(date)}`, { cache: "no-store" });
          if (dayResponse.ok) {
            day = ((await dayResponse.json()) as { ok: boolean; articles: DayArticleClient[] }).articles;
          }
        }
        if (!cancelled) setData({ dashboard, store, day, error: null });
      } catch (error) {
        if (!cancelled) setData((current) => ({ ...current, error: error instanceof Error ? error.message : "Erreur inconnue" }));
      }
    }
    void load();
    return () => {
      cancelled = true;
    };
  }, [nonce]);

  return { loading: data.dashboard === null && data.error === null, ...data, refresh: () => setNonce((value) => value + 1) };
}

/** Alertes réelles du pilotage (mêmes règles que le poste de pilotage). */
export function buildPilotageAlerts(dashboard: EditorialDashboardData | null, day: DayArticleClient[] | null, retainedCount: number): string[] {
  const alerts: string[] = [];
  const date = dashboard?.review?.date ?? dashboard?.watch.date ?? "";
  if (date && (dashboard?.watch.subjects.length ?? 0) > 0 && retainedCount < 3) {
    alerts.push(`Moins de 3 sujets retenus (${retainedCount}/3) pour ${date}.`);
  }
  for (const article of day ?? []) {
    if (article.publishedId !== null) continue;
    const label = article.slug;
    if (!article.ready) {
      alerts.push(`Brouillon non prêt : ${label} (chapo / « à compléter »).`);
    } else {
      alerts.push(`Article prêt non publié : ${label}.`);
    }
  }
  if ((dashboard?.watch.subjects.length ?? 0) === 0) alerts.push("Aucun sujet de veille détecté pour le jour.");
  if ((dashboard?.draftsForToday.length ?? 0) === 0 && (dashboard?.review?.present ?? false)) {
    alerts.push(`Aucun brouillon produit pour la revue du ${date}.`);
  }
  if (!dashboard?.workflow.humanValidation["Validation humaine faite"]) {
    alerts.push("Checklist « Validation humaine faite » non cochée (verrou global de publication).");
  }
  if (alerts.length === 0) alerts.push("Aucune alerte — chaîne du jour cohérente.");
  return alerts;
}
