import { readFile } from "node:fs/promises";
import path from "node:path";
import OpenAI from "openai";
import type { PlanningRow } from "@/lib/googleSheets";

export type DraftResult = {
  editorialId: string;
  format: "article" | "research_brief";
  draft: string;
  generatedAt: string;
  validationRequired: true;
};

type PromptKind = "article-complet" | "research-brief";

type AiProvider = { client: OpenAI; model: string; provider: "openai" | "deepseek" };

/**
 * Fournisseur IA : DeepSeek (DEEPSEEK_API_KEY, base https://api.deepseek.com,
 * modèle deepseek-chat) ou OpenAI (OPENAI_API_KEY, modèle gpt-4.1-mini par défaut).
 * L'API DeepSeek étant compatible OpenAI, le même SDK est utilisé.
 */
function getProvider(): AiProvider {
  const deepseekKey = process.env.DEEPSEEK_API_KEY?.trim();
  const openaiKey = process.env.OPENAI_API_KEY?.trim();
  const apiKey = deepseekKey || openaiKey;

  if (!apiKey) {
    const error = new Error(
      "Aucune clé IA configurée — ajoute DEEPSEEK_API_KEY (DeepSeek, https://platform.deepseek.com) ou OPENAI_API_KEY (OpenAI) dans valeurs-africaines-editorial-os/.env.local."
    ) as Error & { code?: string };
    error.code = "AI_API_KEY_MISSING";
    throw error;
  }

  const useDeepSeek = Boolean(deepseekKey);
  const baseURL = useDeepSeek ? "https://api.deepseek.com" : (process.env.OPENAI_BASE_URL?.trim() || undefined);

  return {
    client: new OpenAI({ apiKey, ...(baseURL ? { baseURL } : {}) }),
    model: process.env.OPENAI_MODEL?.trim() || (useDeepSeek ? "deepseek-chat" : "gpt-4.1-mini"),
    provider: useDeepSeek ? "deepseek" : "openai"
  };
}

async function loadPromptTemplate(kind: PromptKind): Promise<string> {
  const promptPath = path.join(process.cwd(), "prompts", `${kind}.md`);
  return readFile(promptPath, "utf8");
}

function fillPrompt(template: string, row: PlanningRow): string {
  return template
    .replaceAll("{{sujet}}", row.sujet || "Sujet non renseigne")
    .replaceAll("{{rubrique}}", row.rubrique || "Rubrique non renseignee")
    .replaceAll("{{format}}", row.format || "Format non renseigne")
    .replaceAll("{{angle_strategique}}", row.angle_strategique || "Angle strategique non renseigne")
    .replaceAll("{{priorite}}", row.priorite || "Priorite non renseignee");
}

async function generateDraft(row: PlanningRow, kind: PromptKind): Promise<DraftResult> {
  const { client, model, provider } = getProvider();
  const template = await loadPromptTemplate(kind);
  const prompt = fillPrompt(template, row);

  console.info(`[openai] Generating ${kind} draft for editorial row ${row.id} (provider: ${provider}, model: ${model})`);

  // chat.completions est supporté par OpenAI et DeepSeek (compatibilité).
  const response = await client.chat.completions.create({
    model,
    messages: [
      {
        role: "system",
        content:
          "Tu produis uniquement des brouillons editoriaux pour Valeurs Africaines. Tu ne publies jamais. Tu rappelles toujours que la validation humaine est obligatoire."
      },
      {
        role: "user",
        content: prompt
      }
    ]
  });

  return {
    editorialId: row.id,
    format: kind === "research-brief" ? "research_brief" : "article",
    draft: response.choices[0]?.message?.content ?? "",
    generatedAt: new Date().toISOString(),
    validationRequired: true
  };
}

export async function generateArticleDraft(row: PlanningRow): Promise<DraftResult> {
  return generateDraft(row, "article-complet");
}

export async function generateResearchBriefDraft(row: PlanningRow): Promise<DraftResult> {
  return generateDraft(row, "research-brief");
}

