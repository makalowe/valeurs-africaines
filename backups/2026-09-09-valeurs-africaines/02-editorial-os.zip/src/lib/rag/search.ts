import { createEmbeddings, cosineSimilarity } from "@/lib/rag/embed";
import { applyFilters, buildCitations, buildExcerpt, filterScore, lexicalScore, rankResults } from "@/lib/rag/rank";
import type { IndexedDocument, RagFilters, SearchResult } from "@/lib/rag/types";

export function semanticSearch(query: string, documents: IndexedDocument[], filters: RagFilters = {}, limit = 8): SearchResult[] {
  const queryEmbedding = createEmbeddings(query);
  const results = documents
    .filter((document) => applyFilters(document, filters))
    .map((document) => {
      const semanticScore = cosineSimilarity(queryEmbedding, document.embedding);
      const lexical = lexicalScore(query, document);
      const filtersMatched = filterScore(document, filters);
      return toResult(document, query, semanticScore, semanticScore, lexical, filtersMatched);
    })
    .filter((result) => result.score > 0);

  return rankResults(results).slice(0, limit);
}

export function hybridSearch(query: string, documents: IndexedDocument[], filters: RagFilters = {}, limit = 8): SearchResult[] {
  const queryEmbedding = createEmbeddings(query);
  const results = documents
    .filter((document) => applyFilters(document, filters))
    .map((document) => {
      const semantic = cosineSimilarity(queryEmbedding, document.embedding);
      const lexical = lexicalScore(query, document);
      const filtersMatched = filterScore(document, filters);
      const score = semantic * 0.55 + lexical * 0.35 + filtersMatched * 0.1;
      return toResult(document, query, score, semantic, lexical, filtersMatched);
    })
    .filter((result) => result.score > 0);

  return rankResults(results).slice(0, limit);
}

export function fullTextSearch(query: string, documents: IndexedDocument[], filters: RagFilters = {}, limit = 8): SearchResult[] {
  const results = documents
    .filter((document) => applyFilters(document, filters))
    .map((document) => {
      const lexical = lexicalScore(query, document);
      const filtersMatched = filterScore(document, filters);
      const score = lexical * 0.9 + filtersMatched * 0.1;
      return toResult(document, query, score, 0, lexical, filtersMatched);
    })
    .filter((result) => result.score > 0);

  return rankResults(results).slice(0, limit);
}

function toResult(
  document: IndexedDocument,
  query: string,
  score: number,
  semanticScore: number,
  lexical: number,
  filtersMatched: number
): SearchResult {
  return {
    document,
    score: Number(score.toFixed(4)),
    semanticScore: Number(semanticScore.toFixed(4)),
    lexicalScore: Number(lexical.toFixed(4)),
    filterScore: Number(filtersMatched.toFixed(4)),
    excerpt: buildExcerpt(document, query),
    citations: buildCitations(document)
  };
}
