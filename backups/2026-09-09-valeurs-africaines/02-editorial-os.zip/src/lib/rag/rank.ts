import { normalizeText, tokenize } from "@/lib/rag/embed";
import type { IndexedDocument, RagFilters, SearchResult } from "@/lib/rag/types";

export function rankResults(results: SearchResult[]): SearchResult[] {
  return [...results]
    .sort((left, right) => {
      if (right.score !== left.score) return right.score - left.score;
      return right.document.date.localeCompare(left.document.date);
    })
    .map((result, index) => ({
      ...result,
      score: Number((result.score - index * 0.0001).toFixed(4))
    }));
}

export function lexicalScore(query: string, document: IndexedDocument): number {
  const queryTokens = new Set(tokenize(query));
  if (queryTokens.size === 0) return 0;

  const docTokens = new Set(tokenize(document.text));
  let matches = 0;
  for (const token of queryTokens) {
    if (docTokens.has(token)) matches += 1;
  }

  const titleBoost = normalizeText(document.titre).includes(normalizeText(query)) ? 0.35 : 0;
  return Math.min(matches / queryTokens.size + titleBoost, 1);
}

export function filterScore(document: IndexedDocument, filters: RagFilters): number {
  const activeFilters = Object.entries(filters).filter(([, value]) => Boolean(value?.trim()));
  if (activeFilters.length === 0) return 1;

  let matches = 0;
  if (matchesValue(document.pays, filters.pays)) matches += 1;
  if (matchesValue([...document.acteurs, ...document.organisations], filters.acteur)) matches += 1;
  if (matchesValue(document.themes, filters.theme)) matches += 1;
  if (filters.date && document.date.startsWith(filters.date.trim())) matches += 1;
  if (filters.categorie && normalizeText(document.categorie).includes(normalizeText(filters.categorie))) matches += 1;

  return matches / activeFilters.length;
}

export function applyFilters(document: IndexedDocument, filters: RagFilters): boolean {
  if (filters.pays && !matchesValue(document.pays, filters.pays)) return false;
  if (filters.acteur && !matchesValue([...document.acteurs, ...document.organisations], filters.acteur)) return false;
  if (filters.theme && !matchesValue(document.themes, filters.theme)) return false;
  if (filters.date && !document.date.startsWith(filters.date.trim())) return false;
  if (filters.categorie && !normalizeText(document.categorie).includes(normalizeText(filters.categorie))) return false;
  return true;
}

export function buildExcerpt(document: IndexedDocument, query: string): string {
  const cleanMarkdown = document.markdown
    .replace(/^---\n[\s\S]*?\n---/, "")
    .replace(/\[\[|\]\]/g, "")
    .replace(/[#>*_-]/g, " ")
    .replace(/\s+/g, " ")
    .trim();
  const normalizedQueryTokens = tokenize(query);
  const normalizedText = normalizeText(cleanMarkdown);
  const firstHit = normalizedQueryTokens
    .map((token) => normalizedText.indexOf(token))
    .filter((index) => index >= 0)
    .sort((left, right) => left - right)[0] ?? 0;
  const start = Math.max(0, firstHit - 120);
  return cleanMarkdown.slice(start, start + 420).trim();
}

export function buildCitations(document: IndexedDocument): string[] {
  return [
    document.obsidianPath,
    ...document.sources.map((source) => `${document.obsidianPath} | ${source}`)
  ];
}

function matchesValue(values: string[], expected?: string): boolean {
  if (!expected?.trim()) return false;
  const normalizedExpected = normalizeText(expected);
  return values.some((value) => normalizeText(value).includes(normalizedExpected));
}
