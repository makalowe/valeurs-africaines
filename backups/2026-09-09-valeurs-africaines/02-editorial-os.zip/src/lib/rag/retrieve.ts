import { indexDocument } from "@/lib/rag/ingest";
import { fullTextSearch, hybridSearch, semanticSearch } from "@/lib/rag/search";
import type { RagFilters, RetrievedContext, SearchMode } from "@/lib/rag/types";

export async function retrieveContext(
  question: string,
  mode: SearchMode = "hybrid",
  filters: RagFilters = {},
  limit = 6
): Promise<RetrievedContext> {
  const documents = await indexDocument();
  const results =
    mode === "semantic"
      ? semanticSearch(question, documents, filters, limit)
      : mode === "fulltext"
        ? fullTextSearch(question, documents, filters, limit)
        : hybridSearch(question, documents, filters, limit);

  const citations = Array.from(new Set(results.flatMap((result) => result.citations)));
  const context = results
    .map((result, index) => {
      return `Source ${index + 1}: ${result.document.obsidianPath}\nTitre: ${result.document.titre}\nCategorie: ${result.document.categorie}\nDate: ${result.document.date}\nFiabilite: ${result.document.fiabilite}\nExtrait: ${result.excerpt}`;
    })
    .join("\n\n---\n\n");

  return {
    question,
    results,
    context,
    citations,
    instruction: "Repondre uniquement avec les informations du contexte interne cite. Signaler explicitement toute information absente ou non verifiee. Ne rien inventer."
  };
}
