import { getKnowledgeEntries } from "@/lib/knowledgeHub";
import { createEmbeddings, normalizeText } from "@/lib/rag/embed";
import type { IndexedDocument } from "@/lib/rag/types";

export async function indexDocument(): Promise<IndexedDocument[]> {
  const entries = await getKnowledgeEntries();

  return entries.map((entry) => {
    const text = [
      entry.titre,
      entry.categorie,
      entry.rubrique,
      ...entry.pays,
      ...entry.acteurs,
      ...entry.organisations,
      ...entry.themes,
      entry.markdown
    ].join("\n");

    return {
      id: entry.obsidianPath,
      titre: entry.titre,
      type: entry.type,
      date: entry.date,
      categorie: entry.categorie,
      rubrique: entry.rubrique,
      pays: entry.pays,
      acteurs: entry.acteurs,
      organisations: entry.organisations,
      themes: entry.themes,
      sources: entry.sources,
      fiabilite: entry.fiabilite,
      obsidianPath: entry.obsidianPath,
      markdown: entry.markdown,
      text: normalizeText(text),
      embedding: createEmbeddings(text)
    };
  });
}
