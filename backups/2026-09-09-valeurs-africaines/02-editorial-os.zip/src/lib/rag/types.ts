import type { KnowledgeEntryType } from "@/lib/knowledgeHub";

export type RagFilters = {
  pays?: string;
  acteur?: string;
  theme?: string;
  date?: string;
  categorie?: string;
};

export type IndexedDocument = {
  id: string;
  titre: string;
  type: KnowledgeEntryType;
  date: string;
  categorie: string;
  rubrique: string;
  pays: string[];
  acteurs: string[];
  organisations: string[];
  themes: string[];
  sources: string[];
  fiabilite: string;
  obsidianPath: string;
  markdown: string;
  text: string;
  embedding: number[];
};

export type SearchMode = "fulltext" | "semantic" | "hybrid";

export type SearchResult = {
  document: IndexedDocument;
  score: number;
  semanticScore: number;
  lexicalScore: number;
  filterScore: number;
  excerpt: string;
  citations: string[];
};

export type RetrievedContext = {
  question: string;
  results: SearchResult[];
  context: string;
  citations: string[];
  instruction: string;
};
