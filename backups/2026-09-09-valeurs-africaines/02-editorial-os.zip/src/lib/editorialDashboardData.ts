import { readdir, readFile, stat } from "node:fs/promises";
import path from "node:path";
import { parseDailyReview } from "@/lib/dailyReview";
import { readLatestDailyWatch, type DailyWatch, type DailyWatchSubject } from "@/lib/dailyWatch";
import { scoreEditorialRelevance, type EditorialRelevance } from "@/lib/editorialRelevance";
import type { EditorialWorkflowState, WorkflowStatus } from "@/lib/editorialWorkflowState";

export type WatchSubjectWithRelevance = DailyWatchSubject & { relevance: EditorialRelevance };

export type ScoredWatch = {
  present: boolean;
  date: string | null;
  file: string | null;
  fileModifiedAt: string | null;
  subjects: WatchSubjectWithRelevance[];
};

export type DraftFileInfo = {
  filename: string;
  filePath: string;
  subjectIndex: number | null;
  sizeBytes: number;
  modifiedAt: string;
};

export type ReviewInfo = {
  date: string;
  present: boolean;
  title: string | null;
  subjectCount: number;
};

export type EditorialDashboardData = {
  review: ReviewInfo | null;
  drafts: DraftFileInfo[];
  draftsForToday: DraftFileInfo[];
  obsidianArchive: { present: boolean; count: number; path: string };
  driveExport: { present: boolean; count: number; path: string };
  workflow: EditorialWorkflowState;
  workflowPresent: boolean;
  watch: ScoredWatch;
  progress: { daily: number; weekly: number };
  nextAction: { daily: string; weekly: string };
  generatedAt: string;
};

const VA_ROOT = path.join(process.cwd(), "..");
const REVIEW_DIR = path.join(VA_ROOT, "01-ACTUALITE-QUOTIDIENNE", "Aujourd'hui en Afrique");
const DRAFTS_DIR = path.join(VA_ROOT, "02-EDITION-HEBDOMADAIRE", "Brouillons");
const OBSIDIAN_ARCHIVE_DIR = path.join(VA_ROOT, "VALEURS_AFRICAINES", "01_ACTUALITES");
const DRIVE_EXPORT_DIR = path.join(VA_ROOT, "google-drive-export");
const WORKFLOW_FILE = path.join(process.cwd(), "data", "editorial-workflow.json");

// Cible hebdomadaire indicative : 6 contenus produits dans l'édition (brouillons + notes + briefs).
const WEEKLY_TARGET = 6;

const DEFAULT_WORKFLOW: EditorialWorkflowState = {
  workflow: "Validation",
  rhythm: "Quotidien",
  decisions: {},
  humanValidation: {},
  updatedAt: null
};

export async function getEditorialDashboardData(): Promise<EditorialDashboardData> {
  const review = await readLatestReview();
  const drafts = await readDrafts();
  const draftsForToday = review ? drafts.filter((draft) => draft.filename.startsWith(review.date)) : [];
  const obsidianArchive = await readDirectoryStats(OBSIDIAN_ARCHIVE_DIR, "Obsidian");
  const driveExport = await readDirectoryStats(DRIVE_EXPORT_DIR, "Drive");
  const { state: workflow, present: workflowPresent } = await readWorkflowState();
  const watch = await buildScoredWatch();

  const subjectCount = review?.subjectCount ?? 0;
  const daily = review?.present && subjectCount > 0 ? Math.min(100, Math.round((draftsForToday.length / subjectCount) * 100)) : 0;
  const weekly = Math.min(100, Math.round((drafts.length / WEEKLY_TARGET) * 100));

  return {
    review,
    drafts,
    draftsForToday,
    obsidianArchive,
    driveExport,
    workflow,
    workflowPresent,
    watch,
    progress: { daily, weekly },
    nextAction: {
      daily: buildDailyNextAction(review, draftsForToday.length, subjectCount, workflow.workflow),
      weekly: buildWeeklyNextAction(drafts.length)
    },
    generatedAt: new Date().toISOString()
  };
}

async function buildScoredWatch(): Promise<ScoredWatch> {
  const watch = await readLatestDailyWatch();
  const subjects: WatchSubjectWithRelevance[] = watch.subjects
    .map((subject) => ({ ...subject, relevance: scoreEditorialRelevance(subject) }))
    .sort((left, right) => right.relevance.score - left.relevance.score || left.index - right.index);
  return { present: watch.present, date: watch.date, file: watch.file, fileModifiedAt: watch.fileModifiedAt, subjects };
}

async function readLatestReview(): Promise<ReviewInfo | null> {
  try {
    const entries = await readdir(REVIEW_DIR);
    const reviewFiles = entries
      .filter((entry) => /^\d{4}-\d{2}-\d{2}\.md$/.test(entry))
      .sort()
      .reverse();
    if (reviewFiles.length === 0) return null;
    const date = reviewFiles[0].slice(0, 10);
    const raw = await readFile(path.join(REVIEW_DIR, reviewFiles[0]), "utf-8");
    const parsed = parseDailyReview(raw, date);
    return { date, present: true, title: parsed.title, subjectCount: parsed.subjects.length };
  } catch {
    return null;
  }
}

async function readDrafts(): Promise<DraftFileInfo[]> {
  const files: DraftFileInfo[] = [];
  try {
    const entries = await readdir(DRAFTS_DIR);
    for (const entry of entries) {
      if (!entry.endsWith(".md")) continue;
      const filePath = path.join(DRAFTS_DIR, entry);
      try {
        const info = await stat(filePath);
        files.push({
          filename: entry,
          filePath,
          subjectIndex: parseSubjectIndex(entry),
          sizeBytes: info.size,
          modifiedAt: info.mtime.toISOString()
        });
      } catch {
        // fichier disparu entre la lecture et le stat : ignoré
      }
    }
  } catch {
    // dossier historique absent : les articles classes restent utilisables
  }
  files.push(...(await readClassifiedArticleDrafts()));
  return files.sort((left, right) => left.filename.localeCompare(right.filename));
}

async function readClassifiedArticleDrafts(): Promise<DraftFileInfo[]> {
  const filePaths = await listMarkdownFilesRecursive(REVIEW_DIR).catch(() => []);
  const files: DraftFileInfo[] = [];
  for (const filePath of filePaths) {
    const filename = path.basename(filePath);
    if (!/^\d{4}-\d{2}-\d{2}-.+\.md$/.test(filename) || /^\d{4}-\d{2}-\d{2}\.md$/.test(filename)) continue;
    try {
      const raw = await readFile(filePath, "utf-8");
      if (!/^status:\s*"?draft"?\s*$/m.test(raw)) continue;
      const info = await stat(filePath);
      files.push({
        filename,
        filePath,
        subjectIndex: parseSubjectIndex(filename),
        sizeBytes: info.size,
        modifiedAt: info.mtime.toISOString()
      });
    } catch {
      // fichier disparu ou illisible entre la lecture et le stat : ignoré
    }
  }
  return files;
}

async function listMarkdownFilesRecursive(dir: string): Promise<string[]> {
  const entries = await readdir(dir, { withFileTypes: true });
  const files: string[] = [];
  for (const entry of entries) {
    const fullPath = path.join(dir, entry.name);
    if (entry.isDirectory()) {
      files.push(...(await listMarkdownFilesRecursive(fullPath)));
    } else if (entry.isFile() && entry.name.endsWith(".md")) {
      files.push(fullPath);
    }
  }
  return files;
}

async function readDirectoryStats(dir: string, label: string): Promise<{ present: boolean; count: number; path: string }> {
  try {
    const entries = await readdir(dir);
    const files = entries.filter((entry) => entry !== ".gitkeep");
    return { present: files.length > 0, count: files.length, path: dir };
  } catch {
    console.warn(`[editorialDashboardData] ${label} directory unavailable: ${dir}`);
    return { present: false, count: 0, path: dir };
  }
}

async function readWorkflowState(): Promise<{ state: EditorialWorkflowState; present: boolean }> {
  try {
    const raw = await readFile(WORKFLOW_FILE, "utf-8");
    const parsed = JSON.parse(raw) as Partial<EditorialWorkflowState>;
    return { state: { ...DEFAULT_WORKFLOW, ...parsed }, present: true };
  } catch {
    return { state: DEFAULT_WORKFLOW, present: false };
  }
}

function parseSubjectIndex(filename: string): number | null {
  const match = filename.match(/sujet-(\d+)/);
  return match ? Number(match[1]) : null;
}

function buildDailyNextAction(review: ReviewInfo | null, draftsForToday: number, subjectCount: number, workflow: WorkflowStatus): string {
  if (!review?.present) return "Créer la revue du jour dans 01-ACTUALITE-QUOTIDIENNE/Aujourd'hui en Afrique/.";
  if (subjectCount === 0) return "La revue du jour ne contient aucun sujet exploitable.";
  if (draftsForToday < subjectCount) return `Rédiger les brouillons manquants (${subjectCount - draftsForToday} sujet(s) restant(s)).`;
  if (workflow === "Pret a publier") return "Feu vert humain obtenu : publication manuelle possible, puis archivage.";
  if (workflow === "Archive") return "Contenu archivé : préparer le bilan et la prochaine revue.";
  return "Brouillons produits : soumettre à la validation humaine (checklist + feu vert comité).";
}

function buildWeeklyNextAction(draftCount: number): string {
  if (draftCount === 0) return "Produire les premiers brouillons de la semaine.";
  if (draftCount < WEEKLY_TARGET) return `Consolider les brouillons existants (${draftCount}/${WEEKLY_TARGET}) : compléter la production hebdomadaire.`;
  return "Assez de contenus produits : consolider l'édition hebdomadaire et lancer le comité de lecture.";
}
