import { readFile } from "node:fs/promises";
import path from "node:path";

export type DailyReviewSubject = {
  index: number;
  rubric: string;
  title: string;
  pourquoisMaintenant: string;
  faitsEtablis: string[];
  analyse: string;
  incertitudes: string[];
  sources: string[];
  decisionEditoriale: string[];
};

export type DailyReview = {
  date: string;
  title: string;
  status: string[];
  subjects: DailyReviewSubject[];
};

export const DAILY_REVIEW_DATE = "2026-09-01";
const REVIEW_ROOT = path.join(process.cwd(), "..", "01-ACTUALITE-QUOTIDIENNE", "Aujourd'hui en Afrique");

export function dailyReviewFilePath(date: string): string {
  return path.join(REVIEW_ROOT, `${date}.md`);
}

export async function readDailyReview(date = DAILY_REVIEW_DATE): Promise<DailyReview> {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) {
    throw new Error(`Date invalide : ${date}`);
  }
  const filePath = dailyReviewFilePath(date);
  const raw = await readFile(filePath, "utf-8");
  return parseDailyReview(raw, date);
}

export function parseDailyReview(raw: string, date: string): DailyReview {
  const titleMatch = raw.match(/^#\s+(.+)$/m);
  const title = titleMatch ? titleMatch[1].trim() : `Revue quotidienne ${date}`;

  const status: string[] = [];
  const subjects: DailyReviewSubject[] = [];
  const topSections = raw.split(/^##\s+/m).map((section) => section.trim()).filter(Boolean);

  for (const section of topSections) {
    const firstLine = section.split("\n", 1)[0] ?? "";
    if (/^Statut/i.test(firstLine)) {
      for (const line of section.split("\n")) {
        const match = line.match(/^[-*]\s+\[([ xX])\]\s*(.+)$/);
        if (match) status.push(`${match[1].toLowerCase() === "x" ? "✔" : "☐"} ${match[2].trim()}`);
      }
      continue;
    }
    const subjectMatch = firstLine.match(/^Sujet\s+(\d+)\s*-\s*(.+)$/i);
    if (subjectMatch) {
      subjects.push(parseSubject(section, Number(subjectMatch[1]), subjectMatch[2].trim()));
    }
  }

  return { date, title, status, subjects };
}

function parseSubject(section: string, index: number, rubric: string): DailyReviewSubject {
  const lines = section.split("\n");
  const subject: DailyReviewSubject = {
    index,
    rubric,
    title: "",
    pourquoisMaintenant: "",
    faitsEtablis: [],
    analyse: "",
    incertitudes: [],
    sources: [],
    decisionEditoriale: []
  };

  let current: keyof DailyReviewSubject | null = null;
  for (const line of lines) {
    const heading = line.match(/^###\s+(.+)$/);
    if (heading) {
      current = mapHeading(norm(heading[1]));
      continue;
    }
    const titleLine = line.match(/^\*\*Titre\s*:\s*(.+?)\*\*\s*$/i);
    if (titleLine) {
      subject.title = titleLine[1].trim();
      continue;
    }
    if (!current) continue;

    const text = line.trim();
    if (!text) continue;

    if (Array.isArray(subject[current])) {
      const bullet = text.match(/^[-*]\s+(.+)$/);
      if (bullet) (subject[current] as string[]).push(bullet[1].trim());
    } else if (current === "pourquoisMaintenant" || current === "analyse") {
      const previous = (subject[current] as string).trim();
      subject[current] = previous ? `${previous} ${text}` : text;
    }
  }

  return subject;
}

function mapHeading(heading: string): keyof DailyReviewSubject | null {
  switch (heading) {
    case "pourquoi maintenant":
      return "pourquoisMaintenant";
    case "faits etablis":
      return "faitsEtablis";
    case "analyse valeurs africaines":
      return "analyse";
    case "incertitudes / hypotheses":
      return "incertitudes";
    case "sources":
      return "sources";
    case "decision editoriale":
      return "decisionEditoriale";
    default:
      return null;
  }
}

function norm(value: string): string {
  return value.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().trim();
}
