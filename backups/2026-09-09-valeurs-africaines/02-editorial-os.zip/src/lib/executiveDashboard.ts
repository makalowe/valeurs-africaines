export type ExecutivePriority = "critique" | "élevée" | "moyenne" | "faible";

export const editorialActivity = {
  articlesToday: 0,
  drafts: 0,
  inValidation: 0,
  scheduled: 0,
  newslettersPrepared: 0,
  weeklyEditorials: 0,
  sevenDays: [0, 0, 0, 0, 0, 0, 0],
  thirtyDays: Array.from({ length: 30 }, () => 0)
};

export const researchActivity = [
  { label: "Notes Pays", total: 0, newThisWeek: 0, inValidation: 0, archived: 0 },
  { label: "Research Briefs", total: 0, newThisWeek: 0, inValidation: 0, archived: 0 },
  { label: "Signaux faibles", total: 0, newThisWeek: 0, inValidation: 0, archived: 0 },
  { label: "Rapports stratégiques", total: 0, newThisWeek: 0, inValidation: 0, archived: 0 },
  { label: "Dossiers thématiques", total: 0, newThisWeek: 0, inValidation: 0, archived: 0 }
];

export const executiveCountries = [
  "Maroc",
  "Algérie",
  "Égypte",
  "Nigeria",
  "Afrique du Sud",
  "Kenya",
  "Éthiopie",
  "RDC",
  "Sénégal",
  "Côte d'Ivoire"
].map((country, index) => ({
  country,
  articles: 0,
  countryNotes: 0,
  researchBriefs: 0,
  weakSignals: 0,
  activityLevel: "faible",
  x: [34, 43, 59, 40, 55, 63, 63, 52, 29, 34][index],
  y: [23, 27, 26, 45, 77, 52, 42, 57, 39, 48][index]
}));

export const strategicIndicators = {
  mostCoveredCountries: [],
  mostTreatedTopics: [],
  mostActiveRegions: [],
  dominantCategories: [],
  top10: ["géopolitique", "économie", "sécurité", "technologie", "gouvernance"].map((topic) => ({ topic, count: 0 }))
};

export const executiveAlerts = [
  { label: "Signaux critiques", count: 0, priority: "critique" as ExecutivePriority },
  { label: "Contenus à valider", count: 0, priority: "élevée" as ExecutivePriority },
  { label: "Contenus expirés", count: 0, priority: "moyenne" as ExecutivePriority },
  { label: "Tâches en retard", count: 0, priority: "moyenne" as ExecutivePriority },
  { label: "Sources à vérifier", count: 0, priority: "élevée" as ExecutivePriority }
];

export function generateExecutiveSummary() {
  return [
    "Aucune donnée de production réelle n'est encore connectée à ce tableau de bord exécutif.",
    "Le système est prêt à agréger activité éditoriale, recherche, signaux faibles, cartographie pays, alertes et validation.",
    "Les risques éditoriaux prioritaires concernent la validation humaine, la traçabilité des sources et l'absence de publication automatique.",
    "Les opportunités immédiates consistent à connecter les Notes Pays, Research Briefs, Signaux faibles et workflows de validation au tableau de bord.",
    "Les sujets à surveiller seront alimentés après connexion aux flux de veille, aux observatoires et au Knowledge Hub."
  ];
}
