import { google } from "googleapis";
import { getGoogleAuth } from "@/lib/googleAuth";
import { mkdir, readFile, readdir, writeFile } from "node:fs/promises";
import path from "node:path";
import { DRAFTS_DIR, SITE_STORE, isDraftReady, parseFrontmatter } from "@/lib/siteStore";

export type PlanningRow = {
  id: string;
  date: string;
  sujet: string;
  rubrique: string;
  format: string;
  angle_strategique: string;
  statut: string;
  priorite: string;
  echeance: string;
  validation_humaine: string;
  visuel_propose?: string;
  visuel_choisi?: string;
  type_visuel?: string;
  prompt_visuel?: string;
  date_selection?: string;
  droits_visuels_verifies?: string;
  validation_visuelle_humaine?: string;
};

type PlanningColumn = keyof PlanningRow;

const PLANNING_RANGE = "Planning!A2:Q";
const STATUS_COLUMN = "G";
const VALIDATION_COLUMN = "J";
const VISUAL_METADATA_RANGE_START_COLUMN = "K";
const COLUMN_ORDER: PlanningColumn[] = [
  "id",
  "date",
  "sujet",
  "rubrique",
  "format",
  "angle_strategique",
  "statut",
  "priorite",
  "echeance",
  "validation_humaine",
  "visuel_propose",
  "visuel_choisi",
  "type_visuel",
  "prompt_visuel",
  "date_selection",
  "droits_visuels_verifies",
  "validation_visuelle_humaine"
];

function getRequiredEnv(name: string): string {
  const value = process.env[name];

  if (!value) {
    throw new Error(`Missing required environment variable: ${name}`);
  }

  return value;
}

function getSpreadsheetId(): string {
  return getRequiredEnv("GOOGLE_SHEETS_ID");
}

function getPrivateKey(): string {
  return getRequiredEnv("GOOGLE_PRIVATE_KEY").replace(/\\n/g, "\n");
}

function mapSheetRow(values: string[], rowNumber: number): PlanningRow {
  const row = Object.fromEntries(
    COLUMN_ORDER.map((column, index) => [column, values[index] ?? ""])
  ) as PlanningRow;

  if (!row.id) {
    console.warn(`[googleSheets] Planning row ${rowNumber} has no editorial id.`);
  }

  return row;
}

async function getSheetsClient() {
  const auth = await getGoogleAuth(["https://www.googleapis.com/auth/spreadsheets"]);
  return google.sheets({ version: "v4", auth });
}

/**
 * Reads every planning row from the editorial Google Sheet.
 * Expected sheet structure: Planning!A:J using schemas/planning-row.schema.json.
 */
let planningUnavailableUntil = 0;
const PLANNING_RETRY_MS = 10 * 60 * 1000;

// --- Repli local : quand la feuille « Planning » est absente, les lignes de
// planning sont construites depuis les vrais brouillons du dossier VA, et les
// mises à jour de statut sont persistées dans data/planning-local-state.json. ---
let planningLocalMode = false;
const LOCAL_STATE_FILE = path.join(process.cwd(), "data", "planning-local-state.json");
let localRowsCache: { at: number; rows: PlanningRow[] } | null = null;
const LOCAL_CACHE_MS = 5000;

async function readLocalPlanningState(): Promise<Record<string, Record<string, string>>> {
  try {
    return JSON.parse(await readFile(LOCAL_STATE_FILE, "utf-8")) as Record<string, Record<string, string>>;
  } catch {
    return {};
  }
}

async function writeLocalPlanningState(state: Record<string, Record<string, string>>): Promise<void> {
  await mkdir(path.dirname(LOCAL_STATE_FILE), { recursive: true });
  await writeFile(LOCAL_STATE_FILE, `${JSON.stringify(state, null, 2)}\n`, "utf-8");
}

async function readPublishedTitles(): Promise<Set<string>> {
  try {
    const payload = JSON.parse(await readFile(SITE_STORE, "utf-8")) as { articles?: Array<{ status?: string; title?: string }> };
    return new Set((payload.articles ?? []).filter((article) => article.status === "published").map((article) => (article.title ?? "").trim().toLowerCase()));
  } catch {
    return new Set();
  }
}

/** Construit les lignes de planning depuis les vrais brouillons du dossier Valeurs Africaines. */
async function getLocalPlanningRows(): Promise<PlanningRow[]> {
  const now = Date.now();
  if (localRowsCache !== null && now - localRowsCache.at < LOCAL_CACHE_MS) return localRowsCache.rows;
  try {
    const entries = await readdir(DRAFTS_DIR);
    const mdFiles = entries.filter((name) => name.endsWith(".md")).sort().reverse();
    const localState = await readLocalPlanningState();
    const publishedTitles = await readPublishedTitles();
    const rows: PlanningRow[] = [];
    for (const filename of mdFiles) {
      try {
        const raw = await readFile(path.join(DRAFTS_DIR, filename), "utf-8");
        const frontmatter = parseFrontmatter(raw);
        const id = filename.replace(/\.md$/, "");
        const title = frontmatter.title?.trim() || filename;
        const isPublished = publishedTitles.has(title.toLowerCase());
        const ready = isDraftReady(raw);
        const local = localState[id] ?? {};
        const statut = local.statut ?? (isPublished ? "Publié" : ready ? "Prêt à publier" : "Brouillon");
        rows.push({
          id,
          date: filename.match(/^\d{4}-\d{2}-\d{2}/)?.[0] ?? frontmatter.created ?? "",
          sujet: title,
          rubrique: frontmatter.rubrique ?? "Aujourd'hui en Afrique",
          format: "article",
          angle_strategique: frontmatter.risk ?? "",
          statut,
          priorite: local.priorite ?? "",
          echeance: local.echeance ?? "",
          validation_humaine: local.validation_humaine ?? (isPublished ? "oui" : "non"),
          visuel_propose: local.visuel_propose ?? "",
          visuel_choisi: local.visuel_choisi ?? "",
          type_visuel: local.type_visuel ?? "",
          prompt_visuel: local.prompt_visuel ?? "",
          date_selection: local.date_selection ?? "",
          droits_visuels_verifies: local.droits_visuels_verifies ?? "",
          validation_visuelle_humaine: local.validation_visuelle_humaine ?? ""
        });
      } catch {
        // brouillon illisible : ignoré
      }
    }
    localRowsCache = { at: Date.now(), rows };
    return rows;
  } catch {
    return [];
  }
}

/** Persiste localement une mise à jour de champ pour une ligne-brouillon. */
async function saveLocalPlanningField(id: string, patch: Record<string, string>): Promise<PlanningRow | null> {
  const state = await readLocalPlanningState();
  state[id] = { ...(state[id] ?? {}), ...patch, updatedAt: new Date().toISOString() };
  await writeLocalPlanningState(state);
  const rows = await getLocalPlanningRows();
  const row = rows.find((candidate) => candidate.id === id) ?? null;
  return row ? { ...row, ...patch } : null;
}

/** Indique si le planning fonctionne en repli local (feuille Sheets absente). */
export function isPlanningLocalMode(): boolean {
  return planningLocalMode;
}

export async function getPlanningRows(): Promise<PlanningRow[]> {
  // Cache d'échec : si la feuille « Planning » est absente/non configurée, on ne
  // relance pas l'appel réseau (lent) avant la prochaine fenêtre de 10 minutes.
  if (Date.now() < planningUnavailableUntil) {
    return planningLocalMode ? getLocalPlanningRows() : [];
  }
  try {
    console.info("[googleSheets] Reading planning rows.");
    const sheets = await getSheetsClient();
    const response = await sheets.spreadsheets.values.get({
      spreadsheetId: getSpreadsheetId(),
      range: PLANNING_RANGE
    });

    const values = response.data.values ?? [];
    return values.map((row, index) => mapSheetRow(row as string[], index + 2));
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    // Feuille « Planning » absente, spreadsheet non configuré ou accès refusé :
    // bascule sur le planning local (vrais brouillons) — signalé une fois par fenêtre.
    if (/Unable to parse range|INVALID_ARGUMENT|PERMISSION_DENIED|not ?found|NOT_FOUND|403|404|401/i.test(message)) {
      planningUnavailableUntil = Date.now() + PLANNING_RETRY_MS;
      planningLocalMode = true;
      console.warn(`[googleSheets] Planning Sheets indisponible — bascule sur le planning local (brouillons VA) : ${message.slice(0, 140)}`);
      return getLocalPlanningRows();
    }
    console.error("[googleSheets] Failed to read planning rows.", error);
    throw new Error("Unable to read planning rows from Google Sheets.");
  }
}

/**
 * Finds one planning row by its editorial id.
 */
export async function getPlanningRowById(id: string): Promise<PlanningRow | null> {
  if (!id.trim()) {
    throw new Error("Planning row id is required.");
  }

  try {
    console.info(`[googleSheets] Reading planning row by id: ${id}`);
    const rows = await getPlanningRows();
    return rows.find((row) => row.id === id) ?? null;
  } catch (error) {
    console.error(`[googleSheets] Failed to read planning row by id: ${id}`, error);
    throw new Error(`Unable to read planning row with id "${id}".`);
  }
}

/**
 * Updates only the status cell for a planning row.
 * This function never publishes content; it only changes editorial workflow state.
 */
export async function updatePlanningStatus(id: string, status: string): Promise<PlanningRow> {
  if (!id.trim()) {
    throw new Error("Planning row id is required.");
  }

  if (!status.trim()) {
    throw new Error("Planning status is required.");
  }

  try {
    if (planningLocalMode) {
      const row = await saveLocalPlanningField(id, { statut: status });
      if (row) return row;
    }
    console.info(`[googleSheets] Updating status for planning row ${id} -> ${status}`);
    const rows = await getPlanningRows();
    const rowIndex = rows.findIndex((row) => row.id === id);

    if (rowIndex === -1) {
      throw new Error(`Planning row not found: ${id}`);
    }

    const sheetRowNumber = rowIndex + 2;
    const sheets = await getSheetsClient();
    await sheets.spreadsheets.values.update({
      spreadsheetId: getSpreadsheetId(),
      range: `Planning!${STATUS_COLUMN}${sheetRowNumber}`,
      valueInputOption: "RAW",
      requestBody: {
        values: [[status]]
      }
    });

    return {
      ...rows[rowIndex],
      statut: status
    };
  } catch (error) {
    if (planningLocalMode) {
      const row = await saveLocalPlanningField(id, { statut: status });
      if (row) return row;
    }
    console.error(`[googleSheets] Failed to update status for planning row ${id}.`, error);
    throw new Error(`Unable to update planning status for id "${id}".`);
  }
}

/**
 * Updates the human validation cell for a planning row.
 * This records editorial validation only; it does not publish content.
 */
export async function updatePlanningHumanValidation(id: string, validation: string): Promise<PlanningRow> {
  if (!id.trim()) {
    throw new Error("Planning row id is required.");
  }

  if (!validation.trim()) {
    throw new Error("Human validation value is required.");
  }

  try {
    if (planningLocalMode) {
      const row = await saveLocalPlanningField(id, { validation_humaine: validation });
      if (row) return row;
    }
    console.info(`[googleSheets] Updating human validation for planning row ${id} -> ${validation}`);
    const rows = await getPlanningRows();
    const rowIndex = rows.findIndex((row) => row.id === id);

    if (rowIndex === -1) {
      throw new Error(`Planning row not found: ${id}`);
    }

    const sheetRowNumber = rowIndex + 2;
    const sheets = await getSheetsClient();
    await sheets.spreadsheets.values.update({
      spreadsheetId: getSpreadsheetId(),
      range: `Planning!${VALIDATION_COLUMN}${sheetRowNumber}`,
      valueInputOption: "RAW",
      requestBody: {
        values: [[validation]]
      }
    });

    return {
      ...rows[rowIndex],
      validation_humaine: validation
    };
  } catch (error) {
    if (planningLocalMode) {
      const row = await saveLocalPlanningField(id, { validation_humaine: validation });
      if (row) return row;
    }
    console.error(`[googleSheets] Failed to update human validation for planning row ${id}.`, error);
    throw new Error(`Unable to update human validation for id "${id}".`);
  }
}

/**
 * Stores visual review metadata for a planning row.
 * Columns K:O are reserved for visual proposal and human visual choice.
 */
export async function updatePlanningVisualMetadata(
  id: string,
    metadata: {
    visuel_propose: string;
    visuel_choisi: string;
    type_visuel: string;
    prompt_visuel: string;
    date_selection: string;
    droits_visuels_verifies: string;
    validation_visuelle_humaine: string;
  }
): Promise<PlanningRow> {
  if (!id.trim()) {
    throw new Error("Planning row id is required.");
  }

  try {
    if (planningLocalMode) {
      const row = await saveLocalPlanningField(id, { ...metadata });
      if (row) return row;
    }
    console.info(`[googleSheets] Updating visual metadata for planning row ${id}.`);
    const rows = await getPlanningRows();
    const rowIndex = rows.findIndex((row) => row.id === id);

    if (rowIndex === -1) {
      throw new Error(`Planning row not found: ${id}`);
    }

    const sheetRowNumber = rowIndex + 2;
    const sheets = await getSheetsClient();
    await sheets.spreadsheets.values.update({
      spreadsheetId: getSpreadsheetId(),
      range: `Planning!${VISUAL_METADATA_RANGE_START_COLUMN}${sheetRowNumber}:Q${sheetRowNumber}`,
      valueInputOption: "RAW",
      requestBody: {
        values: [[
          metadata.visuel_propose,
          metadata.visuel_choisi,
          metadata.type_visuel,
          metadata.prompt_visuel,
          metadata.date_selection,
          metadata.droits_visuels_verifies,
          metadata.validation_visuelle_humaine
        ]]
      }
    });

    return {
      ...rows[rowIndex],
      ...metadata
    };
  } catch (error) {
    if (planningLocalMode) {
      const row = await saveLocalPlanningField(id, { ...metadata });
      if (row) return row;
    }
    console.error(`[googleSheets] Failed to update visual metadata for planning row ${id}.`, error);
    throw new Error(`Unable to update visual metadata for id "${id}".`);
  }
}
