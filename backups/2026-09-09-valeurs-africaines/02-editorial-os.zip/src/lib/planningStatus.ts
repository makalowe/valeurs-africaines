export const ALLOWED_PLANNING_STATUSES = [
  "Idee",
  "Veille",
  "Recherche",
  "Rédaction",
  "Rédaction en cours",
  "Relecture",
  "À corriger",
  "Validation humaine",
  "Validé",
  "Archivé"
] as const;

export type PlanningStatus = (typeof ALLOWED_PLANNING_STATUSES)[number];

export function isAllowedPlanningStatus(status: string): status is PlanningStatus {
  return ALLOWED_PLANNING_STATUSES.includes(status as PlanningStatus);
}
