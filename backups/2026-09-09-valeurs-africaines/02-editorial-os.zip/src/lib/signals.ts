export type SignalImportance = "faible" | "moyenne" | "forte";

export type WeakSignal = {
  signal: string;
  region: string;
  acteurs: string;
  importance: SignalImportance;
  horizon: string;
  source: string;
  date: string;
  scoreConfiance: number;
  priorite: number;
};

export type SignalInput = {
  signal: string;
  region: string;
  acteurs: string;
  source: string;
  date: string;
  horizon?: string;
};

const seedSignals: SignalInput[] = [
  {
    signal: "Multiplication des initiatives de souverainete des donnees publiques",
    region: "Afrique",
    acteurs: "Etats, agences numeriques, banques centrales",
    source: "Veille institutionnelle",
    date: "2026-06-11",
    horizon: "6 mois"
  },
  {
    signal: "Recomposition des corridors commerciaux vers les pays saheliens",
    region: "Afrique de l'Ouest",
    acteurs: "CEDEAO, AES, ports, transporteurs",
    source: "Veille logistique regionale",
    date: "2026-06-11",
    horizon: "12 mois"
  },
  {
    signal: "Hausse des partenariats IA autour des langues africaines",
    region: "Afrique",
    acteurs: "Universites, startups IA, diasporas scientifiques",
    source: "Veille technologique",
    date: "2026-06-11",
    horizon: "6 mois"
  }
];

function assertRequiredSignalFields(input: SignalInput): void {
  if (!input.signal.trim()) throw new Error("Signal is required.");
  if (!input.source.trim()) throw new Error("Signal source is required.");
  if (!input.date.trim()) throw new Error("Signal date is required.");
}

export function classifySignal(input: SignalInput): SignalImportance {
  assertRequiredSignalFields(input);

  const text = `${input.signal} ${input.acteurs} ${input.region}`.toLowerCase();

  if (text.includes("crise") || text.includes("militaire") || text.includes("rupture") || text.includes("corridor")) {
    return "forte";
  }

  if (text.includes("ia") || text.includes("donnees") || text.includes("finance") || text.includes("energie")) {
    return "moyenne";
  }

  return "faible";
}

export function calculatePriority(importance: SignalImportance, scoreConfiance: number): number {
  const base = importance === "forte" ? 70 : importance === "moyenne" ? 45 : 25;
  return Math.min(100, Math.round(base + scoreConfiance * 0.3));
}

export function generateWeakSignal(input: SignalInput): WeakSignal {
  assertRequiredSignalFields(input);

  const importance = classifySignal(input);
  const scoreConfiance = input.source.toLowerCase().includes("institution") ? 80 : 65;

  return {
    signal: input.signal,
    region: input.region,
    acteurs: input.acteurs,
    importance,
    horizon: input.horizon ?? "6 mois",
    source: input.source,
    date: input.date,
    scoreConfiance,
    priorite: calculatePriority(importance, scoreConfiance)
  };
}

export async function collectSignals(): Promise<WeakSignal[]> {
  console.info("[signals] Collecting weak signals from local watchlist.");
  return seedSignals.map(generateWeakSignal);
}

