import type { EditorialFormat, EditorialStatus } from "@/types/editorial";

export const statusLabel: Record<EditorialStatus, string> = {
  idea: "Idee",
  drafting: "A rediger",
  review: "A verifier",
  validation: "A valider",
  approved: "Valide",
  archived: "Archive"
};

export const formatLabel: Record<EditorialFormat, string> = {
  article: "Article",
  editorial: "Edito",
  research_brief: "Research Brief",
  country_note: "Note pays",
  map_infographic: "Infographie / Carte",
  weak_signals: "Signaux faibles",
  newsletter: "Newsletter"
};

