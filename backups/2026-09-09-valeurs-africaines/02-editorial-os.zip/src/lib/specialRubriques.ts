export type SpecialRubriqueId =
  | "elles-de-la-semaine"
  | "entrepreneuriat-feminin"
  | "initiatives-innovation"
  | "pulse-des-jeunes"
  | "afrique-creative"
  | "afrique-diaspora"
  | "analyse-independante"
  | "souverainete-narrative";

export type SpecialRubriqueInput = {
  rubrique: SpecialRubriqueId;
  sujet: string;
  sources?: string[];
  pays?: string[];
  acteurs?: string[];
};

export type SpecialRubriqueProposal = {
  rubrique: SpecialRubriqueId;
  title: string;
  objective: string;
  angle: string;
  requiredChecks: string[];
  draftStructure: string;
  validation_humaine_requise: true;
  publication_automatique: false;
};

const RUBRIQUES: Record<SpecialRubriqueId, { title: string; objective: string; angle: string }> = {
  "elles-de-la-semaine": {
    title: "Elles de la semaine",
    objective: "Mettre en lumière les femmes africaines inspirantes.",
    angle: "Parcours, impact, leadership et portée panafricaine."
  },
  "entrepreneuriat-feminin": {
    title: "Entrepreneuriat féminin",
    objective: "Valoriser les initiatives économiques portées par les femmes.",
    angle: "Modèle économique, marché, financement, obstacles et potentiel de passage à l'échelle."
  },
  "initiatives-innovation": {
    title: "Initiatives & Innovation",
    objective: "Mettre en avant startups, innovations et technologies africaines.",
    angle: "Problème traité, solution, adoption, souveraineté technologique et impact."
  },
  "pulse-des-jeunes": {
    title: "Pulse des Jeunes",
    objective: "Identifier les tendances émergentes portées par les jeunes.",
    angle: "Signaux culturels, économiques, politiques ou numériques à surveiller."
  },
  "afrique-creative": {
    title: "Afrique Créative",
    objective: "Valoriser les industries culturelles africaines.",
    angle: "Création, marché, influence culturelle, propriété intellectuelle et récits."
  },
  "afrique-diaspora": {
    title: "Afrique Diaspora",
    objective: "Connecter diaspora et continent.",
    angle: "Talents, investissements, réseaux scientifiques, influence et transferts de compétences."
  },
  "analyse-independante": {
    title: "Analyse indépendante",
    objective: "Produire une contre-analyse des récits dominants.",
    angle: "Comparer faits établis, cadrages médiatiques, angles morts et intérêts en jeu."
  },
  "souverainete-narrative": {
    title: "Souveraineté narrative",
    objective: "Analyser les récits médiatiques concernant l'Afrique.",
    angle: "Qui raconte, avec quelles sources, quels mots, quels effets politiques et économiques."
  }
};

export function listSpecialRubriques(): SpecialRubriqueProposal[] {
  return (Object.keys(RUBRIQUES) as SpecialRubriqueId[]).map((rubrique) =>
    generateSpecialRubriqueProposal({ rubrique, sujet: "Sujet à sélectionner" })
  );
}

export function generateSpecialRubriqueProposal(input: SpecialRubriqueInput): SpecialRubriqueProposal {
  const definition = RUBRIQUES[input.rubrique];

  if (!definition) {
    throw new Error("Unknown special rubrique.");
  }

  const sources = input.sources?.length ? input.sources.join(", ") : "sources à vérifier";
  const actors = input.acteurs?.length ? input.acteurs.join(", ") : "acteurs à identifier";
  const countries = input.pays?.length ? input.pays.join(", ") : "pays ou régions à préciser";

  return {
    rubrique: input.rubrique,
    title: `${definition.title} - ${input.sujet}`,
    objective: definition.objective,
    angle: definition.angle,
    requiredChecks: [
      "ne pas inventer de faits, chiffres, citations ou sources",
      "distinguer faits, analyses et hypothèses",
      "vérifier les sources primaires disponibles",
      "présenter plusieurs points de vue lorsque le sujet est controversé",
      "prévoir trois propositions visuelles avant validation finale"
    ],
    draftStructure: [
      `# ${definition.title}`,
      "",
      `Sujet: ${input.sujet}`,
      `Pays / régions: ${countries}`,
      `Acteurs: ${actors}`,
      `Sources à vérifier: ${sources}`,
      "",
      "## Titre",
      "## Chapeau",
      "## Faits établis",
      "## Analyse",
      "## Points de vue et angles morts",
      "## Impacts pour l'Afrique",
      "## Conclusion",
      "## Tags",
      "## Sources à vérifier"
    ].join("\n"),
    validation_humaine_requise: true,
    publication_automatique: false
  };
}
