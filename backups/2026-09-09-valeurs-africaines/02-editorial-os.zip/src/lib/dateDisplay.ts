export function formatDisplayDate(value: string | Date | null | undefined): string {
  if (!value) return "";
  if (value instanceof Date) return formatDateParts(value.getFullYear(), value.getMonth() + 1, value.getDate());

  const isoMatch = value.match(/^(\d{4})-(\d{2})-(\d{2})/);
  if (isoMatch) return `${isoMatch[3]}/${isoMatch[2]}/${isoMatch[1]}`;

  return value;
}

export function formatDisplayDateTime(value: string | Date | null | undefined): string {
  if (!value) return "";
  const date = value instanceof Date ? value : new Date(value);
  if (Number.isNaN(date.getTime())) return typeof value === "string" ? formatDisplayDate(value) : "";

  const day = formatDateParts(date.getFullYear(), date.getMonth() + 1, date.getDate());
  const hours = `${date.getHours()}`.padStart(2, "0");
  const minutes = `${date.getMinutes()}`.padStart(2, "0");
  return `${day} ${hours}:${minutes}`;
}

function formatDateParts(year: number, month: number, day: number): string {
  return `${`${day}`.padStart(2, "0")}/${`${month}`.padStart(2, "0")}/${year}`;
}
