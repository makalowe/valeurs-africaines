export type ObservatoryOverview = {
  name: string;
  href: string;
  score: number;
  status: "stable" | "à surveiller" | "prioritaire";
  latestUpdate: string;
  sourcesToVerify: string[];
};

export type StrategicAlert = {
  level: "critique" | "attention" | "normal";
  observatory: string;
  message: string;
};

export type LatestReport = {
  title: string;
  observatory: string;
  date: string;
  status: "brouillon" | "validation humaine" | "archivé";
};

export type MonthlyTrend = {
  observatory: string;
  current: number;
  previous: number;
  evolution: number;
};

const observatories: ObservatoryOverview[] = [
  { name: "Observatoire des Conflits et de la Stabilité", href: "/conflits", score: 64, status: "prioritaire", latestUpdate: "2026-06-12", sourcesToVerify: ["ACLED", "OCHA", "Union africaine"] },
  { name: "Observatoire de la Souveraineté africaine", href: "/think-tank", score: 72, status: "à surveiller", latestUpdate: "2026-06-12", sourcesToVerify: ["Union africaine", "instituts africains"] },
  { name: "Observatoire Afrique–BRICS", href: "/think-tank", score: 68, status: "à surveiller", latestUpdate: "2026-06-12", sourcesToVerify: ["BRICS", "BAD", "communiqués officiels"] },
  { name: "Observatoire des Influences étrangères", href: "/think-tank", score: 61, status: "prioritaire", latestUpdate: "2026-06-12", sourcesToVerify: ["ONU", "think tanks", "médias vérifiés"] },
  { name: "Observatoire ODD / Afrique 2030", href: "/afrique-2030", score: 74, status: "à surveiller", latestUpdate: "2026-06-12", sourcesToVerify: ["ONU", "Banque mondiale", "BAD"] },
  { name: "Observatoire Business & Industrie", href: "/business", score: 80, status: "stable", latestUpdate: "2026-06-12", sourcesToVerify: ["rapports investisseurs", "médias économiques"] },
  { name: "Observatoire Écologie & Économie durable", href: "/sustainable-economy", score: 70, status: "à surveiller", latestUpdate: "2026-06-12", sourcesToVerify: ["rapports climat", "données publiques"] },
  { name: "Observatoire Diaspora & Influence", href: "/special-rubriques", score: 48, status: "prioritaire", latestUpdate: "2026-06-12", sourcesToVerify: ["réseaux diaspora", "universités", "institutions"] }
];

export async function getObservatoryOverview(): Promise<ObservatoryOverview[]> {
  console.info("[observatories] Reading strategic observatory overview.");
  return observatories;
}

export async function getStrategicAlerts(): Promise<StrategicAlert[]> {
  return [
    { level: "critique", observatory: "Diaspora & Influence", message: "Couverture faible et sources encore dispersées." },
    { level: "attention", observatory: "Conflits et Stabilité", message: "Zones en dégradation à documenter sans bilan humain non vérifié." },
    { level: "attention", observatory: "Influences étrangères", message: "Besoin de distinguer faits, hypothèses et récits d'influence." },
    { level: "normal", observatory: "Business & Industrie", message: "Couverture éditoriale robuste cette semaine." }
  ];
}

export async function getLatestReports(): Promise<LatestReport[]> {
  return [
    { title: "Observatoire des Conflits — Afrique", observatory: "Conflits et Stabilité", date: "2026-06-12", status: "brouillon" },
    { title: "Afrique 2030 – État d'avancement", observatory: "ODD / Afrique 2030", date: "2026-06-12", status: "validation humaine" },
    { title: "Business & Industrie — signaux d'investissement", observatory: "Business & Industrie", date: "2026-06-12", status: "brouillon" }
  ];
}

export function calculateObservatoryHealth(items: ObservatoryOverview[]): number {
  if (items.length === 0) return 0;
  return Math.round(items.reduce((sum, item) => sum + item.score, 0) / items.length);
}

export async function getMonthlyTrends(): Promise<MonthlyTrend[]> {
  return observatories.map((item, index) => {
    const previous = Math.max(0, item.score - [4, -2, 5, 1, 3, 6, -1, 7][index]);
    return {
      observatory: item.name,
      current: item.score,
      previous,
      evolution: item.score - previous
    };
  });
}
