import { getAllCountryProfilesSync, type CountryProfile } from "@/lib/atlas";
import { getDashboardData, type DashboardData } from "@/lib/dashboard";
import { getEditorialDashboardData, type WatchSubjectWithRelevance } from "@/lib/editorialDashboardData";
import { getPlanningRows, type PlanningRow } from "@/lib/googleSheets";
import { getKnowledgeEntries, type KnowledgeEntry } from "@/lib/knowledgeHub";
import { getObservatoryOverview, type ObservatoryOverview } from "@/lib/observatories";
import { getResearchBriefs, type ResearchBriefRecord } from "@/lib/researchBriefLibrary";
import { getWeakSignals, type AttentionLevel, type WeakSignal, type WeakSignalCategory } from "@/lib/strategicWatchCenter";

export interface ChiefDataSnapshot {
  knowledgeHub: KnowledgeEntry[];
  researchBriefs: ResearchBriefRecord[];
  countryNotes: KnowledgeEntry[];
  weakSignals: WeakSignal[];
  atlasEntries: CountryProfile[];
  observatories: ObservatoryOverview[];
  editorialPipeline: PlanningRow[];
  executiveMetrics: DashboardData | null;
  missingSources: string[];
  coverageReport: CoverageReport;
  strategicAlerts: StrategicAlert[];
  connectedSources: string[];
  mockData: boolean;
}

export type CoverageReport = {
  coveredCountries: string[];
  absentCountries: string[];
  coveredThemes: string[];
  absentThemes: string[];
  underrepresentedCategories: string[];
};

export type StrategicAlert = {
  level: "critique" | "élevée" | "moyenne" | "faible";
  label: string;
  detail: string;
};

const SOURCE_NON_CONNECTEE = "Source non connectée";

const EXPECTED_COUNTRIES = [
  "Maroc",
  "Algérie",
  "Égypte",
  "Nigeria",
  "Afrique du Sud",
  "Kenya",
  "Éthiopie",
  "RDC",
  "Sénégal",
  "Côte d'Ivoire"
];

const EXPECTED_THEMES = [
  "géopolitique",
  "économie",
  "sécurité",
  "technologie",
  "gouvernance",
  "souveraineté",
  "développement",
  "diaspora",
  "innovation",
  "ODD"
];

let snapshotCache: { at: number; value: ChiefDataSnapshot } | null = null;
const SNAPSHOT_CACHE_MS = 5000;

export async function getChiefDataSnapshot(): Promise<ChiefDataSnapshot> {
  if (snapshotCache !== null && Date.now() - snapshotCache.at < SNAPSHOT_CACHE_MS) {
    return snapshotCache.value;
  }
  const value = await buildChiefDataSnapshot();
  snapshotCache = { at: Date.now(), value };
  return value;
}

async function buildChiefDataSnapshot(): Promise<ChiefDataSnapshot> {
  const missingSources: string[] = [];
  const connectedSources: string[] = [];

  const knowledgeHub = await readSource("Knowledge Hub", () => getKnowledgeEntries(), missingSources, connectedSources);
  const researchBriefs = await readSource("Research Briefs", () => Promise.resolve(getResearchBriefs()), missingSources, connectedSources);
  const weakSignals = await readSource("Signaux Faibles", () => Promise.resolve(getWeakSignals()), missingSources, connectedSources);
  const atlasEntries = await readSource("Atlas Afrique", () => Promise.resolve(getAllCountryProfilesSync()), missingSources, connectedSources);
  const observatories = await readSource("Observatoires", () => getObservatoryOverview(), missingSources, connectedSources);
  const editorialPipeline = await readSource("Planning éditorial", () => getPlanningRows(), missingSources, connectedSources);
  const rawExecutiveMetrics = await readNullableSource("Dashboard exécutif", () => getDashboardData(), missingSources, connectedSources);
  const executiveMetrics = rawExecutiveMetrics?.isMock ? null : rawExecutiveMetrics;
  if (rawExecutiveMetrics?.isMock) {
    missingSources.push(`Dashboard exécutif: ${SOURCE_NON_CONNECTEE}`);
    removeValue(connectedSources, "Dashboard exécutif");
  }

  const countryNotes = knowledgeHub.filter((entry) => entry.type === "note-pays" || entry.type === "country-profile" || entry.type === "fiche-pays");
  connectedSources.push("Notes Pays");

  // --- Branchement réel : veille, revue et brouillons du jour (dossier Valeurs Africaines) ---
  const liveSignals: WeakSignal[] = [];
  const liveEditorialSources: string[] = [];
  try {
    const dashboard = await getEditorialDashboardData();
    const date = dashboard.watch.date ?? dashboard.review?.date ?? "";
    if (dashboard.watch.present && dashboard.watch.subjects.length > 0) {
      liveSignals.push(...dashboard.watch.subjects.map((subject) => toWeakSignalFromWatch(subject, date)));
      liveEditorialSources.push(`Veille du jour (${dashboard.watch.subjects.length} sujets, ${date})`);
    }
    if (dashboard.review?.present) liveEditorialSources.push(`Revue quotidienne (${dashboard.review.date})`);
    if (dashboard.draftsForToday.length > 0) liveEditorialSources.push(`Brouillons du jour (${dashboard.draftsForToday.length})`);
  } catch (error) {
    console.warn("[chiefDataProvider] Données éditoriales réelles indisponibles.", error);
  }

  const hasRealContent = liveSignals.length > 0 || knowledgeHub.length > 0 || researchBriefs.length > 0 || weakSignals.length > 0;
  const mockContent = hasRealContent ? null : buildMockContent();
  const mockData = mockContent !== null && liveSignals.length === 0;
  if (mockData) {
    connectedSources.push("Données locales (mock)");
  }
  for (const source of liveEditorialSources) connectedSources.push(source);

  const effectiveResearchBriefs = mockContent?.researchBriefs ?? researchBriefs;
  // La veille réelle du jour fait foi pour les signaux ; sinon sources lib, sinon mock.
  const effectiveWeakSignals = liveSignals.length > 0 ? liveSignals : mockContent?.weakSignals ?? weakSignals;

  const snapshotBase = {
    knowledgeHub,
    researchBriefs: effectiveResearchBriefs,
    countryNotes,
    weakSignals: effectiveWeakSignals,
    atlasEntries,
    observatories,
    editorialPipeline,
    executiveMetrics,
    missingSources: unique(missingSources),
    connectedSources: unique(connectedSources),
    mockData
  };

  const coverageReport = buildCoverageReport(snapshotBase);
  const strategicAlerts = buildStrategicAlerts(snapshotBase, coverageReport);

  return {
    ...snapshotBase,
    coverageReport,
    strategicAlerts
  };
}

function buildMockContent(): { weakSignals: WeakSignal[]; researchBriefs: ResearchBriefRecord[] } {
  return {
    weakSignals: [
      {
        id: "ua-luanda",
        title: "UA / Luanda / sécurité africaine",
        description: "La 21ème session extraordinaire de l'UA (clôturée le 30 août 2026 à Luanda) acte le renforcement de l'Architecture africaine de paix et de sécurité : alerte précoce, diplomatie préventive, financement durable, prérogatives accrues du CPS.",
        detectedAt: "2026-09-01",
        actors: ["UA", "CPS", "Commission UA", "Angola"],
        geographicZone: "Afrique",
        region: "Afrique",
        category: "Géopolitique",
        whyImportant: "Réforme majeure de l'architecture de paix continentale",
        africaConsequences: "Renforcement de la souveraineté sécuritaire africaine",
        timeHorizon: "12-36 mois",
        attentionLevel: "Critique",
        sourcesToVerify: ["https://africa24tv.com/afrique-lua-acte-le-renforcement-des-mecanismes-de-prevention-et-de-resolution-des-conflits/"],
        status: "En analyse",
        history: [{ date: "2026-09-01", evolution: "Détection", attentionChange: "Critique", analystComment: "Réformes adoptées, financement concret à confirmer" }]
      },
      {
        id: "chine-afrique-ia",
        title: "Chine-Afrique / médias / IA",
        description: "Le 7ème Forum de coopération médiatique Chine-Afrique (Pékin, 20 août 2026) place l'IA au cœur de la souveraineté narrative : Déclaration conjointe adoptée, ~400 délégués de 45 pays africains.",
        detectedAt: "2026-09-01",
        actors: ["AUB", "SABC", "Sierra Leone", "The Sun Nigeria"],
        geographicZone: "Chine-Afrique",
        region: "Afrique",
        category: "Médias",
        whyImportant: "Coopération IA médiatique en accélération",
        africaConsequences: "Souveraineté numérique et narrative africaines",
        timeHorizon: "6-24 mois",
        attentionLevel: "Moyen",
        sourcesToVerify: ["https://en.people.cn/n3/2026/0821/c90000-20490845.html", "https://thesun.ng/african-media-professionals-call-for-increased-practical-cooperation-with-chinese-counterparts/"],
        status: "En analyse",
        history: [{ date: "2026-09-01", evolution: "Détection", attentionChange: "Moyen", analystComment: "Contrepoint africain ajouté (The Sun Nigeria)" }]
      },
      {
        id: "libye-elections",
        title: "Libye : accord ONU pour relancer les élections",
        description: "Accord signé à Tripoli sous l'égide de l'ONU pour relancer le processus électoral libyen.",
        detectedAt: "2026-09-01",
        actors: ["ONU", "Libye"],
        geographicZone: "Libye",
        region: "Afrique du Nord",
        category: "Diplomatie",
        whyImportant: "Déblocage potentiel du processus politique libyen",
        africaConsequences: "Stabilité régionale Afrique du Nord / Sahel",
        timeHorizon: "3-12 mois",
        attentionLevel: "Moyen",
        sourcesToVerify: ["https://africa24tv.com/libye-accord-signe-a-tripoli-sous-legide-de-lonu-pour-relancer-les-elections-2/"],
        status: "Détecté",
        history: [{ date: "2026-09-01", evolution: "Détection", attentionChange: "Moyen", analystComment: "Suivre la feuille de route électorale" }]
      }
    ],
    researchBriefs: [
      {
        id: "senegal-fmi",
        title: "Sénégal / FMI / accord technique ECF",
        executiveSummary: "Staff-Level Agreement entre le Sénégal et le FMI sur un programme ECF de 36 mois d'environ 2,2 Md$ (1 537,1 M DTS), soumis à l'approbation du Conseil d'administration.",
        date: "2026-09-01",
        author: "VAIS",
        category: "Économie & Développement",
        region: "Afrique de l'Ouest",
        countries: ["Sénégal"],
        priority: "Haute",
        status: "Brouillon",
        tags: ["FMI", "dette", "UEMOA", "financement"],
        context: "Programme de remplacement du prêt de 1,8 Md$ suspendu en 2024 après divulgation d'une dette sous-déclarée.",
        keyActors: ["FMI", "Sénégal", "Moody's"],
        strategicAnalysis: "Test continental de crédibilité financière et de souveraineté économique.",
        africaConsequences: "Signal pour les marchés régionaux UEMOA.",
        monitoringPoints: ["Approbation du Conseil d'administration du FMI", "Trajectoire de la note souveraine"],
        sourcesToVerify: ["https://www.imf.org/en/news/articles/2026/09/01/pr26282-senegal-imf-reaches-sla-ecf-arrangement"],
        strategicConclusion: "Fenêtre de 12-18 mois pour stabiliser les finances publiques sénégalaises."
      },
      {
        id: "cemac-dette",
        title: "Dette publique CEMAC : 10 560 Mds FCFA fin juillet",
        executiveSummary: "La dette publique de la CEMAC atteint 10 560 milliards de francs CFA à fin juillet 2026.",
        date: "2026-09-01",
        author: "VAIS",
        category: "Économie & Développement",
        region: "Afrique centrale",
        countries: ["Cameroun", "Congo", "Gabon", "Guinée Équatoriale", "RCA", "Tchad"],
        priority: "Moyenne",
        status: "Brouillon",
        tags: ["CEMAC", "dette", "FCFA"],
        context: "Suivi de la soutenabilité de la dette en zone CEMAC.",
        keyActors: ["CEMAC", "BEAC"],
        strategicAnalysis: "Soutenabilité budgétaire à surveiller au niveau régional.",
        africaConsequences: "Coût du financement et marges budgétaires des États membres.",
        monitoringPoints: ["Émissions régionales", "Taux directeurs BEAC"],
        sourcesToVerify: ["https://africa24tv.com/la-dette-publique-de-la-cemac-atteint-10-560-milliards-de-francs-cfa-a-fin-juillet/"],
        strategicConclusion: "Suivre la trajectoire de la dette régionale sur 2026-2027."
      }
    ]
  };
}

function mapRubricToCategory(rubric: string): WeakSignalCategory {
  const value = rubric.toLowerCase();
  if (value.includes("économie") || value.includes("finance")) return "Économie";
  if (value.includes("sécurité") || value.includes("défense")) return "Sécurité";
  if (value.includes("diplomatie")) return "Diplomatie";
  if (value.includes("média")) return "Médias";
  if (value.includes("innovation") || value.includes("technologie")) return "Technologie";
  if (value.includes("gouvernance")) return "Gouvernance";
  if (value.includes("culture")) return "Culture";
  if (value.includes("santé")) return "Santé";
  return "Géopolitique";
}

function attentionFromScore(score: number): AttentionLevel {
  if (score >= 4) return "Critique";
  if (score >= 3) return "Élevé";
  if (score >= 2) return "Moyen";
  return "Faible";
}

/** Convertit un sujet de la veille réelle du jour en signal faible exploitable par le Chief Editor. */
function toWeakSignalFromWatch(subject: WatchSubjectWithRelevance, date: string): WeakSignal {
  const countries = subject.countries.length > 0 ? subject.countries.join(", ") : "Afrique";
  const attentionLevel = attentionFromScore(subject.relevance.score);
  return {
    id: `veille-${date}-${subject.index}`,
    title: subject.title,
    description: subject.pourquoi || subject.risk || "Sujet de la veille du jour.",
    detectedAt: date,
    actors: [],
    geographicZone: countries,
    region: "Afrique",
    category: mapRubricToCategory(subject.rubric),
    whyImportant: subject.risk || "Sujet sélectionné par la veille quotidienne.",
    africaConsequences: "",
    timeHorizon: "Court terme",
    attentionLevel,
    sourcesToVerify: subject.sourceUrls,
    status: "En analyse",
    history: [{ date, evolution: "Détection", attentionChange: attentionLevel, analystComment: "Sujet de la veille du jour (Valeurs Africaines)." }]
  };
}

async function readSource<T>(
  name: string,
  loader: () => Promise<T[]>,
  missingSources: string[],
  connectedSources: string[]
): Promise<T[]> {
  try {
    const data = await loader();
    connectedSources.push(name);
    return Array.isArray(data) ? data : [];
  } catch (error) {
    console.warn(`[chiefDataProvider] ${name} unavailable.`, error);
    missingSources.push(`${name}: ${SOURCE_NON_CONNECTEE}`);
    return [];
  }
}

async function readNullableSource<T>(
  name: string,
  loader: () => Promise<T>,
  missingSources: string[],
  connectedSources: string[]
): Promise<T | null> {
  try {
    const data = await loader();
    connectedSources.push(name);
    return data;
  } catch (error) {
    console.warn(`[chiefDataProvider] ${name} unavailable.`, error);
    missingSources.push(`${name}: ${SOURCE_NON_CONNECTEE}`);
    return null;
  }
}

function buildCoverageReport(snapshot: Omit<ChiefDataSnapshot, "coverageReport" | "strategicAlerts">): CoverageReport {
  const coveredCountries = unique([
    ...snapshot.knowledgeHub.flatMap((entry) => entry.pays),
    ...snapshot.researchBriefs.flatMap((brief) => brief.countries),
    ...snapshot.weakSignals.map((signal) => signal.geographicZone).filter(Boolean),
    ...snapshot.atlasEntries.map((entry) => entry.country)
  ]).sort();

  const coveredThemes = unique([
    ...snapshot.knowledgeHub.flatMap((entry) => entry.themes),
    ...snapshot.researchBriefs.flatMap((brief) => brief.tags),
    ...snapshot.researchBriefs.map((brief) => brief.category),
    ...snapshot.weakSignals.map((signal) => signal.category),
    ...snapshot.atlasEntries.flatMap((entry) => [...entry.odd, ...entry.agenda2063, ...entry.opportunities])
  ].map((theme) => theme.toLowerCase())).sort();

  const absentCountries = EXPECTED_COUNTRIES.filter((country) => !coveredCountries.includes(country));
  const absentThemes = EXPECTED_THEMES.filter((theme) => !coveredThemes.some((covered) => covered.includes(theme.toLowerCase())));
  const underrepresentedCategories = EXPECTED_THEMES.filter((theme) => {
    const occurrences = coveredThemes.filter((covered) => covered.includes(theme.toLowerCase())).length;
    return occurrences <= 1;
  });

  return {
    coveredCountries,
    absentCountries,
    coveredThemes,
    absentThemes,
    underrepresentedCategories
  };
}

function buildStrategicAlerts(
  snapshot: Omit<ChiefDataSnapshot, "coverageReport" | "strategicAlerts">,
  coverageReport: CoverageReport
): StrategicAlert[] {
  const alerts: StrategicAlert[] = [];

  if (snapshot.knowledgeHub.length === 0) {
    alerts.push({ level: "élevée", label: "Knowledge Hub vide", detail: "Aucune fiche de connaissance active n'est disponible." });
  }

  if (snapshot.countryNotes.length === 0) {
    alerts.push({ level: "élevée", label: "Aucune Note Pays active", detail: "Le Directeur IA ne peut pas prioriser par pays depuis les Notes Pays." });
  }

  if (snapshot.weakSignals.length === 0) {
    alerts.push({ level: "moyenne", label: "Aucun signal faible récent", detail: "La veille ne fournit aucun signal faible exploitable." });
  }

  if (coverageReport.absentCountries.includes("Afrique du Sud")) {
    alerts.push({ level: "moyenne", label: "Faible couverture Afrique australe", detail: "Aucun contenu actif ne couvre suffisamment l'Afrique australe hors Atlas." });
  }

  if (snapshot.missingSources.length > 0) {
    alerts.push({ level: "critique", label: "Sources non connectées", detail: snapshot.missingSources.join("; ") });
  }

  if (alerts.length === 0) {
    alerts.push({ level: "faible", label: "Aucune alerte stratégique", detail: "Les sources connectées ne signalent pas de blocage immédiat." });
  }

  return alerts;
}

function unique(values: string[]): string[] {
  return Array.from(new Set(values.map((value) => value.trim()).filter(Boolean)));
}

function removeValue(values: string[], value: string): void {
  const index = values.indexOf(value);
  if (index >= 0) values.splice(index, 1);
}
