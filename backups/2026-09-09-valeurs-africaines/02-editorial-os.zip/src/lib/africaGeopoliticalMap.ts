import { getAllCountryProfilesSync } from "@/lib/atlas";

export type GeoRiskColor = "Vert" | "Jaune" | "Orange" | "Rouge" | "À vérifier";

export type GeopoliticalCountryMapProfile = {
  slug: string;
  officialName: string;
  flag: string;
  capital: string;
  population: string;
  gdp: string;
  politicalRegime: string;
  regionalOrganizations: string[];
  riskNote: string;
  opportunityNote: string;
  geopoliticalStatus: string;
  region: string;
  riskColor: GeoRiskColor;
  strategicSummary: string;
  strengths: string[];
  vulnerabilities: string[];
  opportunities: string[];
  risks: string[];
  weakSignals: string[];
  layers: {
    geopolitics: string[];
    economy: string[];
    security: string[];
    resources: string[];
    influence: string[];
  };
  mapPosition: {
    x: number;
    y: number;
  };
};

export const geopoliticalMapLayers = [
  "Géopolitique",
  "Économie",
  "Sécurité",
  "Ressources",
  "Influence"
];

const fallback = "Donnée à vérifier";

const positions: Record<string, { x: number; y: number }> = {
  maroc: { x: 34, y: 23 },
  algerie: { x: 43, y: 27 },
  egypte: { x: 59, y: 26 },
  nigeria: { x: 40, y: 45 },
  "afrique-du-sud": { x: 55, y: 77 },
  kenya: { x: 63, y: 52 },
  ethiopie: { x: 63, y: 42 },
  rdc: { x: 52, y: 57 },
  senegal: { x: 29, y: 39 },
  "cote-d-ivoire": { x: 34, y: 48 }
};

export function getAfricaGeopoliticalMapProfiles(): GeopoliticalCountryMapProfile[] {
  return getAllCountryProfilesSync().map((country) => ({
    slug: country.slug,
    officialName: country.country,
    flag: country.flag,
    capital: country.capital || fallback,
    population: country.population || fallback,
    gdp: country.gdp || fallback,
    politicalRegime: fallback,
    regionalOrganizations: country.regionalOrganizations.length ? country.regionalOrganizations : [fallback],
    riskNote: fallback,
    opportunityNote: fallback,
    geopoliticalStatus: fallback,
    region: country.region,
    riskColor: "À vérifier",
    strategicSummary: "Résumé stratégique à produire après validation des données pays.",
    strengths: country.opportunities.length ? country.opportunities : [fallback],
    vulnerabilities: country.risks.length ? country.risks : [fallback],
    opportunities: country.opportunities.length ? country.opportunities : [fallback],
    risks: country.risks.length ? country.risks : [fallback],
    weakSignals: [fallback],
    layers: {
      geopolitics: [...country.regionalOrganizations, ...country.strategicPartners],
      economy: [country.gdp, "commerce à vérifier", "corridors économiques à vérifier", "zones industrielles à vérifier"],
      security: [...country.risks, "conflits à vérifier", "zones de tension à vérifier"],
      resources: [...country.opportunities, "ressources stratégiques à vérifier"],
      influence: [...country.strategicPartners, "médias et réseaux diplomatiques à vérifier"]
    },
    mapPosition: positions[country.slug] ?? { x: 50, y: 50 }
  }));
}

export function getRiskColorClass(color: GeoRiskColor) {
  switch (color) {
    case "Vert":
      return "bg-emerald-500";
    case "Jaune":
      return "bg-yellow-400";
    case "Orange":
      return "bg-orange-500";
    case "Rouge":
      return "bg-red-500";
    default:
      return "bg-neutral-500";
  }
}
