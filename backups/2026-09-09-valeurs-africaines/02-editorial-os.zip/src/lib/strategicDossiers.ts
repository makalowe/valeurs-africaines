export type StrategicDossierStatus = "sous-couvert" | "à renforcer" | "correct" | "bien couvert";

export type StrategicDossierCoverage = {
  name: string;
  coverage: number;
  contentCount: number;
  status: StrategicDossierStatus;
  evolution: number;
};

const strategicDossiers = [
  "Innovation",
  "Afrique & Souveraineté",
  "Business & Industrie",
  "Excellence Africaine",
  "Écologie Durable",
  "Géopolitique",
  "Diaspora"
];

const editorialCoverage: Record<string, { coverage: number; contentCount: number; evolution: number }> = {
  Innovation: { coverage: 90, contentCount: 27, evolution: 12 },
  "Afrique & Souveraineté": { coverage: 80, contentCount: 24, evolution: 8 },
  "Business & Industrie": { coverage: 80, contentCount: 24, evolution: 6 },
  "Excellence Africaine": { coverage: 80, contentCount: 24, evolution: 5 },
  "Écologie Durable": { coverage: 70, contentCount: 21, evolution: 4 },
  Géopolitique: { coverage: 60, contentCount: 18, evolution: -3 },
  Diaspora: { coverage: 30, contentCount: 9, evolution: -9 }
};

export function calculateCoverageScore(contentCount: number, target = 30): number {
  if (contentCount <= 0) return 0;
  return Math.min(100, Math.round((contentCount / target) * 100));
}

export function classifyCoverageStatus(coverage: number): StrategicDossierStatus {
  if (coverage <= 30) return "sous-couvert";
  if (coverage <= 60) return "à renforcer";
  if (coverage <= 80) return "correct";
  return "bien couvert";
}

export async function getStrategicDossierCoverage(): Promise<StrategicDossierCoverage[]> {
  console.info("[strategicDossiers] Reading strategic dossier coverage from mocked editorial sources.");

  return strategicDossiers.map((name) => {
    const dossier = editorialCoverage[name] ?? { coverage: 0, contentCount: 0, evolution: 0 };

    return {
      name,
      coverage: dossier.coverage,
      contentCount: dossier.contentCount,
      status: classifyCoverageStatus(dossier.coverage),
      evolution: dossier.evolution
    };
  });
}

export function getUnderCoveredDossiers(dossiers: StrategicDossierCoverage[]): StrategicDossierCoverage[] {
  return dossiers.filter((dossier) => dossier.status === "sous-couvert" || dossier.status === "à renforcer");
}

export function getPriorityDossiers(dossiers: StrategicDossierCoverage[]): StrategicDossierCoverage[] {
  return [...dossiers]
    .filter((dossier) => dossier.coverage < 70)
    .sort((a, b) => a.coverage - b.coverage)
    .slice(0, 4);
}
