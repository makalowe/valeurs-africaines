import { getPlanningRows, type PlanningRow } from "@/lib/googleSheets";
import { getKnowledgeEntries } from "@/lib/knowledgeHub";
import { collectSignals, type WeakSignal } from "@/lib/signals";
import { getEditorialDashboardData } from "@/lib/editorialDashboardData";
import { readSiteStoreSummary } from "@/lib/siteStore";

export type EditorialStats = {
  total: number;
  generated: number;
  validation: number;
  archives: number;
  en_retard: number;
  haute_priorite: number;
};

export type StatusDistribution = {
  idees: number;
  recherche: number;
  redactionIA: number;
  validation: number;
  pret: number;
  archive: number;
};

export type PriorityDistribution = {
  haute: number;
  moyenne: number;
  faible: number;
};

export type DeadlineStats = {
  en_retard: number;
  aujourd_hui: number;
  cette_semaine: number;
};

export type EditorialOverview = {
  contenusPublies: number;
  contenusEnAttente: number;
  contenusEnValidation: number;
  contenusProgrammes: number;
};

export type EditorialKpis = {
  articlesSemaine: number;
  articlesMois: number;
  articlesAnnee: number;
};

export type CountryCoverage = {
  pays: string;
  frequence: number;
  niveau: "faible" | "moyen" | "fort";
};

export type TopicDistribution = {
  theme: string;
  total: number;
};

export type DashboardAlert = {
  type: "retard" | "validation" | "priorite";
  titre: string;
  niveau: "faible" | "moyen" | "haut";
  detail: string;
};

export type DashboardData = {
  stats: EditorialStats;
  statusDistribution: StatusDistribution;
  priorityDistribution: PriorityDistribution;
  deadlines: DeadlineStats;
  overview: EditorialOverview;
  kpis: EditorialKpis;
  countryCoverage: CountryCoverage[];
  topicDistribution: TopicDistribution[];
  alerts: DashboardAlert[];
  weakSignals: WeakSignal[];
  isMock: boolean;
};

function normalize(value: string): string {
  return value.trim().toLowerCase();
}

function isGenerated(row: PlanningRow): boolean {
  const status = normalize(row.statut);
  return status.includes("rédaction") || status.includes("redaction") || status.includes("validation") || status.includes("valid") || status.includes("archiv");
}

function isValidated(row: PlanningRow): boolean {
  return normalize(row.validation_humaine) === "oui" || normalize(row.statut).includes("valid");
}

function isArchived(row: PlanningRow): boolean {
  return normalize(row.statut).includes("archiv");
}

function parseDeadline(value: string): Date | null {
  if (!value.trim()) return null;

  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return null;

  return new Date(date.getFullYear(), date.getMonth(), date.getDate());
}

function today(): Date {
  const now = new Date();
  return new Date(now.getFullYear(), now.getMonth(), now.getDate());
}

function addDays(date: Date, days: number): Date {
  const next = new Date(date);
  next.setDate(next.getDate() + days);
  return next;
}

export async function getEditorialStats(rowsInput?: PlanningRow[]): Promise<EditorialStats> {
  const rows = rowsInput ?? await getPlanningRows();
  const deadlines = getDeadlinesFromRows(rows);

  return {
    total: rows.length,
    generated: rows.filter(isGenerated).length,
    validation: rows.filter(isValidated).length,
    archives: rows.filter(isArchived).length,
    en_retard: deadlines.en_retard,
    haute_priorite: rows.filter((row) => normalize(row.priorite).includes("haute")).length
  };
}

export async function getStatusDistribution(rowsInput?: PlanningRow[]): Promise<StatusDistribution> {
  const rows = rowsInput ?? await getPlanningRows();

  return rows.reduce<StatusDistribution>(
    (acc, row) => {
      const status = normalize(row.statut);

      if (status.includes("idee") || status.includes("idée")) acc.idees += 1;
      else if (status.includes("recherche")) acc.recherche += 1;
      else if (status.includes("rédaction") || status.includes("redaction")) acc.redactionIA += 1;
      else if (status.includes("validation") || status.includes("verifier") || status.includes("vérifier")) acc.validation += 1;
      else if (status.includes("valid") || status.includes("prêt") || status.includes("pret")) acc.pret += 1;
      else if (status.includes("archiv")) acc.archive += 1;
      else acc.idees += 1;

      return acc;
    },
    { idees: 0, recherche: 0, redactionIA: 0, validation: 0, pret: 0, archive: 0 }
  );
}

export async function getPriorityDistribution(rowsInput?: PlanningRow[]): Promise<PriorityDistribution> {
  const rows = rowsInput ?? await getPlanningRows();

  return rows.reduce<PriorityDistribution>(
    (acc, row) => {
      const priority = normalize(row.priorite);

      if (priority.includes("haute")) acc.haute += 1;
      else if (priority.includes("faible")) acc.faible += 1;
      else acc.moyenne += 1;

      return acc;
    },
    { haute: 0, moyenne: 0, faible: 0 }
  );
}

function getDeadlinesFromRows(rows: PlanningRow[]): DeadlineStats {
  const start = today();
  const weekEnd = addDays(start, 7);

  return rows.reduce<DeadlineStats>(
    (acc, row) => {
      const deadline = parseDeadline(row.echeance);
      if (!deadline) return acc;

      if (deadline < start) acc.en_retard += 1;
      else if (deadline.getTime() === start.getTime()) acc.aujourd_hui += 1;
      else if (deadline <= weekEnd) acc.cette_semaine += 1;

      return acc;
    },
    { en_retard: 0, aujourd_hui: 0, cette_semaine: 0 }
  );
}

export async function getDeadlines(rowsInput?: PlanningRow[]): Promise<DeadlineStats> {
  const rows = rowsInput ?? await getPlanningRows();
  return getDeadlinesFromRows(rows);
}

export async function getDashboardData(): Promise<DashboardData> {
  const rows = await safeGetPlanningRows();
  const knowledgeEntries = await safeGetKnowledgeEntries();
  const weakSignals = (await collectSignals()).slice(0, 6);

  // Fallback explicite pour permettre de tester l'interface sans exposer de cles Google Sheets.
  if (rows.length === 0 && knowledgeEntries.length === 0) {
    const real = await getRealEditorialDashboardData();
    if (real) return real;
    return getMockDashboardData(weakSignals);
  }

  const [stats, statusDistribution, priorityDistribution, deadlines] = await Promise.all([
    getEditorialStats(rows),
    getStatusDistribution(rows),
    getPriorityDistribution(rows),
    getDeadlines(rows)
  ]);

  return {
    stats,
    statusDistribution,
    priorityDistribution,
    deadlines,
    overview: getOverview(rows, knowledgeEntries.length),
    kpis: getKpis(rows, knowledgeEntries),
    countryCoverage: getCountryCoverage(rows, knowledgeEntries),
    topicDistribution: getTopicDistribution(rows, knowledgeEntries),
    alerts: getAlerts(rows, deadlines),
    weakSignals,
    isMock: false
  };
}

/**
 * Construit le DashboardData depuis la réalité éditoriale (veille, brouillons,
 * revue, workflow, store du site Flask). Retourne null si aucune donnée réelle.
 */
async function getRealEditorialDashboardData(): Promise<DashboardData | null> {
  try {
    const editorial = await getEditorialDashboardData();
    const store = await readSiteStoreSummary();
    const watchSubjects = editorial.watch.subjects;
    const hasRealContent = watchSubjects.length > 0 || editorial.drafts.length > 0 || store.published > 0;
    if (!hasRealContent) return null;

    const watchDate = editorial.watch.date ?? "";
    const decisions = editorial.workflow.decisions ?? {};
    const retained = watchSubjects.length > 0
      ? Object.entries(decisions).filter(([key, value]) => key.startsWith(`veille-${watchDate}-`) && value === "Retenir").length
      : 0;
    const publishedToday = store.publishedToday;

    const countryMap = new Map<string, number>();
    for (const subject of watchSubjects) {
      for (const country of subject.countries) countryMap.set(country, (countryMap.get(country) ?? 0) + 1);
    }
    const countryCoverage: CountryCoverage[] = [...countryMap.entries()]
      .map(([pays, frequence]) => ({
        pays,
        frequence,
        niveau: (frequence >= 3 ? "fort" : frequence === 2 ? "moyen" : "faible") as CountryCoverage["niveau"]
      }))
      .sort((a, b) => b.frequence - a.frequence);

    const topicMap = new Map<string, number>();
    for (const subject of watchSubjects) topicMap.set(subject.rubric, (topicMap.get(subject.rubric) ?? 0) + 1);
    const topicDistribution: TopicDistribution[] = [...topicMap.entries()]
      .map(([theme, total]) => ({ theme, total }))
      .sort((a, b) => b.total - a.total);

    const alerts: DashboardAlert[] = [];
    if (watchSubjects.length > 0 && retained < 3) {
      alerts.push({ type: "validation", titre: "Sélection incomplète", niveau: "haut", detail: `${retained}/3 sujets retenus pour ${watchDate || "aujourd'hui"}.` });
    }
    if (editorial.draftsForToday.length === 0 && editorial.review?.present) {
      alerts.push({ type: "retard", titre: "Aucun brouillon du jour", niveau: "haut", detail: `Aucun brouillon produit pour la revue du ${editorial.review.date}.` });
    }
    if (!editorial.workflow.humanValidation["Validation humaine faite"]) {
      alerts.push({ type: "validation", titre: "Validation humaine absente", niveau: "moyen", detail: "La checklist « Validation humaine faite » n'est pas cochée." });
    }
    if (alerts.length === 0) {
      alerts.push({ type: "validation", titre: "Aucune alerte", niveau: "faible", detail: "La chaîne du jour est cohérente." });
    }

    const weakSignals: WeakSignal[] = watchSubjects.map((subject, index) => ({
      signal: subject.title,
      region: subject.countries.length > 0 ? subject.countries.join(", ") : "Afrique",
      acteurs: "",
      importance: subject.relevance.score >= 3 ? "forte" : "moyenne",
      horizon: "court terme",
      source: subject.sourceUrls[0] ?? "Veille quotidienne",
      date: watchDate || editorial.review?.date || "",
      scoreConfiance: Math.min(100, subject.relevance.score * 20),
      priorite: index + 1
    }));

    return {
      stats: {
        total: store.total,
        generated: editorial.drafts.length,
        validation: editorial.draftsForToday.length,
        archives: editorial.obsidianArchive?.count ?? 0,
        en_retard: 0,
        haute_priorite: retained
      },
      statusDistribution: {
        idees: Math.max(0, watchSubjects.length - retained),
        recherche: retained,
        redactionIA: editorial.draftsForToday.length,
        validation: publishedToday,
        pret: 0,
        archive: editorial.obsidianArchive?.count ?? 0
      },
      priorityDistribution: {
        haute: retained,
        moyenne: Math.max(0, watchSubjects.length - retained),
        faible: 0
      },
      deadlines: {
        en_retard: 0,
        aujourd_hui: publishedToday,
        cette_semaine: editorial.drafts.length
      },
      overview: {
        contenusPublies: store.published,
        contenusEnAttente: editorial.drafts.length,
        contenusEnValidation: editorial.draftsForToday.length,
        contenusProgrammes: watchSubjects.length
      },
      kpis: {
        articlesSemaine: publishedToday,
        articlesMois: store.published,
        articlesAnnee: store.published
      },
      countryCoverage,
      topicDistribution,
      alerts,
      weakSignals,
      isMock: false
    };
  } catch (error) {
    console.warn("[dashboard] Données éditoriales réelles indisponibles, bascule sur le mock.", error);
    return null;
  }
}

export function getMockDashboardData(weakSignals: WeakSignal[] = []): DashboardData {
  return {
    stats: {
      total: 18,
      generated: 9,
      validation: 4,
      archives: 6,
      en_retard: 2,
      haute_priorite: 5
    },
    statusDistribution: {
      idees: 4,
      recherche: 3,
      redactionIA: 4,
      validation: 3,
      pret: 2,
      archive: 2
    },
    priorityDistribution: {
      haute: 5,
      moyenne: 9,
      faible: 4
    },
    deadlines: {
      en_retard: 2,
      aujourd_hui: 1,
      cette_semaine: 5
    },
    overview: {
      contenusPublies: 6,
      contenusEnAttente: 7,
      contenusEnValidation: 3,
      contenusProgrammes: 8
    },
    kpis: {
      articlesSemaine: 9,
      articlesMois: 24,
      articlesAnnee: 126
    },
    countryCoverage: [
      { pays: "Niger", frequence: 7, niveau: "fort" },
      { pays: "Mali", frequence: 6, niveau: "fort" },
      { pays: "Sénégal", frequence: 4, niveau: "moyen" },
      { pays: "Nigeria", frequence: 4, niveau: "moyen" },
      { pays: "Kenya", frequence: 2, niveau: "faible" }
    ],
    topicDistribution: [
      { theme: "Géopolitique & Diplomatie", total: 7 },
      { theme: "Économie & Développement", total: 5 },
      { theme: "Sécurité & Défense", total: 4 },
      { theme: "Technologie & Souveraineté numérique", total: 3 },
      { theme: "Gouvernance & Politiques publiques", total: 2 }
    ],
    alerts: [
      {
        type: "retard",
        titre: "Contenus en retard",
        niveau: "haut",
        detail: "2 contenus de démonstration ont une échéance dépassée."
      },
      {
        type: "validation",
        titre: "Validation manquante",
        niveau: "haut",
        detail: "3 contenus de démonstration attendent une validation humaine."
      },
      {
        type: "priorite",
        titre: "Événements prioritaires",
        niveau: "moyen",
        detail: "5 sujets de démonstration sont marqués en priorité haute."
      }
    ],
    weakSignals,
    isMock: true
  };
}

async function safeGetPlanningRows(): Promise<PlanningRow[]> {
  try {
    return await getPlanningRows();
  } catch (error) {
    console.warn("[dashboard] Planning source unavailable. Using empty planning dataset.", error);
    return [];
  }
}

async function safeGetKnowledgeEntries() {
  try {
    return await getKnowledgeEntries();
  } catch (error) {
    console.warn("[dashboard] Knowledge Hub source unavailable. Using empty knowledge dataset.", error);
    return [];
  }
}

function getOverview(rows: PlanningRow[], archivedKnowledgeCount: number): EditorialOverview {
  return {
    contenusPublies: archivedKnowledgeCount + rows.filter(isArchived).length,
    contenusEnAttente: rows.filter((row) => {
      const status = normalize(row.statut);
      return status.includes("idee") || status.includes("idée") || status.includes("recherche") || status.includes("veille");
    }).length,
    contenusEnValidation: rows.filter((row) => normalize(row.statut).includes("validation")).length,
    contenusProgrammes: rows.filter((row) => Boolean(parseDeadline(row.echeance))).length
  };
}

function getKpis(rows: PlanningRow[], entries: Awaited<ReturnType<typeof safeGetKnowledgeEntries>>): EditorialKpis {
  const now = today();
  const weekStart = addDays(now, -7);
  const monthStart = new Date(now.getFullYear(), now.getMonth(), 1);
  const yearStart = new Date(now.getFullYear(), 0, 1);
  const dates = [
    ...rows.map((row) => parseDeadline(row.date) ?? parseDeadline(row.echeance)).filter((date): date is Date => Boolean(date)),
    ...entries.map((entry) => parseDeadline(entry.date)).filter((date): date is Date => Boolean(date))
  ];

  return {
    articlesSemaine: dates.filter((date) => date >= weekStart).length,
    articlesMois: dates.filter((date) => date >= monthStart).length,
    articlesAnnee: dates.filter((date) => date >= yearStart).length
  };
}

function getCountryCoverage(rows: PlanningRow[], entries: Awaited<ReturnType<typeof safeGetKnowledgeEntries>>): CountryCoverage[] {
  const counts = new Map<string, number>();
  const add = (country: string) => {
    const clean = country.trim();
    if (!clean) return;
    counts.set(clean, (counts.get(clean) ?? 0) + 1);
  };

  for (const row of rows) {
    extractCommaList(row.rubrique).forEach(add);
  }
  for (const entry of entries) {
    entry.pays.forEach(add);
  }

  return Array.from(counts.entries())
    .map(([pays, frequence]) => ({
      pays,
      frequence,
      niveau: frequence >= 6 ? "fort" as const : frequence >= 3 ? "moyen" as const : "faible" as const
    }))
    .sort((left, right) => right.frequence - left.frequence)
    .slice(0, 12);
}

function getTopicDistribution(rows: PlanningRow[], entries: Awaited<ReturnType<typeof safeGetKnowledgeEntries>>): TopicDistribution[] {
  const counts = new Map<string, number>();
  const add = (theme: string) => {
    const clean = theme.trim();
    if (!clean) return;
    counts.set(clean, (counts.get(clean) ?? 0) + 1);
  };

  rows.forEach((row) => add(row.rubrique || row.format));
  entries.forEach((entry) => {
    if (entry.themes.length > 0) entry.themes.forEach(add);
    else add(entry.categorie);
  });

  return Array.from(counts.entries())
    .map(([theme, total]) => ({ theme, total }))
    .sort((left, right) => right.total - left.total)
    .slice(0, 10);
}

function getAlerts(rows: PlanningRow[], deadlines: DeadlineStats): DashboardAlert[] {
  const alerts: DashboardAlert[] = [];
  const missingValidation = rows.filter((row) => isGenerated(row) && !isValidated(row)).length;
  const highPriority = rows.filter((row) => normalize(row.priorite).includes("haute")).length;

  if (deadlines.en_retard > 0) {
    alerts.push({
      type: "retard",
      titre: "Contenus en retard",
      niveau: "haut",
      detail: `${deadlines.en_retard} contenu(s) ont une echeance depassee.`
    });
  }

  if (missingValidation > 0) {
    alerts.push({
      type: "validation",
      titre: "Validation manquante",
      niveau: "haut",
      detail: `${missingValidation} contenu(s) generes ou rediges attendent une validation humaine.`
    });
  }

  if (highPriority > 0) {
    alerts.push({
      type: "priorite",
      titre: "Evenements prioritaires",
      niveau: highPriority >= 3 ? "haut" : "moyen",
      detail: `${highPriority} sujet(s) sont marques en priorite haute.`
    });
  }

  return alerts;
}

function extractCommaList(value: string): string[] {
  return value.split(/[,;|]/).map((item) => item.trim()).filter(Boolean);
}
