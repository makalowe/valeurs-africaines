import { readFile, readdir, stat } from "node:fs/promises";
import path from "node:path";

export type DailyWatchSubject = {
  index: number;
  title: string;
  rubric: string;
  pourquoi: string;
  countries: string[];
  sourceUrls: string[];
  risk: string;
  completeArticle?: DailyWatchArticle;
};

export type DailyWatchArticle = {
  title: string;
  body: string;
};

export type DailyWatch = {
  present: boolean;
  date: string | null;
  file: string | null;
  fileModifiedAt: string | null;
  subjects: DailyWatchSubject[];
};

const WATCH_DIR = path.join(process.cwd(), "..", "00-INBOX");

const KNOWN_COUNTRIES = [
  "Zambie",
  "Sénégal",
  "Burkina",
  "RDC",
  "Congo",
  "Tchad",
  "Égypte",
  "Egypte",
  "Maroc",
  "Afrique du Sud",
  "Kenya",
  "Nigeria",
  "Éthiopie",
  "Mali",
  "Niger",
  "Libye",
  "Soudan",
  "Angola",
  "Ghana",
  "Gabon",
  "Côte d'Ivoire",
  "Cameroun",
  "Rwanda",
  "Ouganda",
  "Mozambique",
  "Tanzanie",
  "Algérie",
  "Tunisie",
  "Guinée",
  "Somalie"
];

const GENERIC_TITLE_WORDS = new Set([
  "afrique",
  "africain",
  "actualite",
  "strategique",
  "economie",
  "securite",
  "diplomatie",
  "innovation",
  "gouvernance",
  "culture",
  "medias",
  "stabilite",
  "summit",
  "media",
  "sommet"
]);

export async function readLatestDailyWatch(): Promise<DailyWatch> {
  try {
    const entries = await readdir(WATCH_DIR);
    const files = entries.filter((entry) => /^Veille - \d{4}-\d{2}-\d{2}\.md$/.test(entry)).sort().reverse();
    if (files.length === 0) return { present: false, date: null, file: null, fileModifiedAt: null, subjects: [] };
    const file = files[0];
    const date = file.replace(/^Veille - /, "").replace(/\.md$/, "");
    const filePath = path.join(WATCH_DIR, file);
    const raw = await readFile(filePath, "utf-8");
    const fileInfo = await stat(filePath).catch(() => null);
    return { present: true, date, file, fileModifiedAt: fileInfo ? fileInfo.mtime.toISOString() : null, subjects: parseWatch(raw) };
  } catch {
    return { present: false, date: null, file: null, fileModifiedAt: null, subjects: [] };
  }
}

export function parseWatch(raw: string): DailyWatchSubject[] {
  const sections = parseSubjectSections(raw);
  const subjects: DailyWatchSubject[] = [];

  for (const section of sections) {
    const firstLine = section.split("\n", 1)[0] ?? "";
    const headingMatch = firstLine.match(/^Sujet\s*(\d+)\s*[-–—:]\s*(.+)$/i);
    if (!headingMatch) continue;
    const index = Number(headingMatch[1]);
    const { rubric, title } = splitRubricTitle(headingMatch[2].trim());
    const parsed = parseSubjectBody(section, index, title, rubric);
    subjects.push(parsed);
  }

  return attachCompleteArticles(subjects, parseCompleteArticles(raw));
}

function parseSubjectSections(raw: string): string[] {
  const matches = Array.from(raw.matchAll(/^##\s+Sujet\s*\d+\s*[-–—:]/gm));
  return matches
    .map((match, index) => {
      const start = match.index ?? 0;
      const nextSubject = matches[index + 1]?.index ?? raw.length;
      const nextTopLevel = raw.slice(start + 1).search(/\n#\s+/);
      const end = nextTopLevel >= 0 ? Math.min(nextSubject, start + 1 + nextTopLevel) : nextSubject;
      return raw.slice(start + 3, end).trim();
    })
    .filter(Boolean);
}

function splitRubricTitle(remainder: string): { rubric: string; title: string } {
  const separator = remainder.indexOf(" : ");
  if (separator > 0 && separator < 70) {
    return { rubric: remainder.slice(0, separator).trim(), title: remainder.slice(separator + 3).trim() };
  }
  return { rubric: "À déterminer", title: remainder };
}

function parseSubjectBody(section: string, index: number, title: string, rubric: string): DailyWatchSubject {
  const subject: DailyWatchSubject = {
    index,
    title,
    rubric,
    pourquoi: "",
    countries: [],
    sourceUrls: [],
    risk: ""
  };

  let current: "pourquoi" | "risk" | "sources" | null = null;
  const riskBullets: string[] = [];
  for (const line of section.split("\n")) {
    const heading = line.match(/^###\s+(.+)$/);
    if (heading) {
      current = mapSubheading(norm(heading[1]));
      continue;
    }
    const text = line.trim();
    if (!text) continue;

    if (current === "pourquoi") {
      const paragraph = text.replace(/^[-*]\s+/, "").trim();
      subject.pourquoi = subject.pourquoi ? `${subject.pourquoi} ${paragraph}` : paragraph;
    } else if (current === "sources") {
      const url = text.replace(/^[-*]\s*/, "").trim();
      if (url.startsWith("http")) subject.sourceUrls.push(url);
    } else if (current === "risk") {
      const bullet = text.replace(/^[-*]\s*/, "").trim();
      if (bullet && !bullet.startsWith("http")) riskBullets.push(bullet);
    }
  }

  subject.risk = riskBullets[0] ?? "À qualifier au comité";
  subject.countries = detectCountries(section);
  return subject;
}

function mapSubheading(heading: string): "pourquoi" | "risk" | "sources" | null {
  if (heading.includes("pourquoi maintenant")) return "pourquoi";
  if (heading.includes("hypothese") || heading.includes("a verifier") || heading.includes("risque")) return "risk";
  if (heading === "sources") return "sources";
  return null;
}

function detectCountries(text: string): string[] {
  const normalized = norm(text);
  const found = KNOWN_COUNTRIES.filter((country) => normalized.includes(norm(country)));
  return Array.from(new Set(found));
}

function parseCompleteArticles(raw: string): DailyWatchArticle[] {
  const blocks = raw.split(/^#\s+Article complet\s*[-–—:]\s*/m).slice(1);
  return blocks
    .map((block) => {
      const nextTopLevel = block.search(/\n#\s+/);
      const content = (nextTopLevel >= 0 ? block.slice(0, nextTopLevel) : block).trim();
      const [marker, ...rest] = content.split("\n");
      const body = rest.join("\n").trim();
      const firstArticleHeading = body.match(/^##\s+(.+)$/m);
      return {
        title: (firstArticleHeading?.[1] ?? marker ?? "Article complet").trim(),
        body
      };
    })
    .filter((article) => article.body.length > 0);
}

function attachCompleteArticles(subjects: DailyWatchSubject[], articles: DailyWatchArticle[]): DailyWatchSubject[] {
  if (articles.length === 0) return subjects;
  return subjects.map((subject) => {
    const article = articles.find((candidate) => articleMatchesSubject(candidate, subject));
    return article ? { ...subject, completeArticle: article } : subject;
  });
}

function articleMatchesSubject(article: DailyWatchArticle, subject: DailyWatchSubject): boolean {
  const haystack = norm(`${article.title} ${article.body.slice(0, 500)}`);
  if (subject.countries.some((country) => haystack.includes(norm(country)))) return true;
  const titleWords = norm(subject.title)
    .split(/\s+/)
    .filter((word) => word.length > 5 && !GENERIC_TITLE_WORDS.has(word));
  const matches = titleWords.filter((word) => haystack.includes(word)).length;
  return matches >= 2;
}

function norm(value: string): string {
  return value.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase();
}
