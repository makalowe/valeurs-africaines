import { mkdir, readdir, readFile, writeFile } from "node:fs/promises";
import path from "node:path";
import type { PlanningRow } from "@/lib/googleSheets";

export type KnowledgeEntryType =
  | "article"
  | "research-brief"
  | "note-pays"
  | "signal-faible"
  | "infographie"
  | "fiche-pays"
  | "fiche-acteur"
  | "fiche-entreprise"
  | "fiche-organisation"
  | "fiche-theme"
  | "think-tank"
  | "observatoire"
  | "scenario"
  | "portrait"
  | "chercheur"
  | "innovateur"
  | "conflict-observer"
  | "country-profile";

export type KnowledgeEntryInput = {
  type: KnowledgeEntryType;
  titre: string;
  date?: string;
  auteur?: string;
  categorie?: string;
  rubrique?: string;
  pays?: string[];
  acteurs?: string[];
  organisations?: string[];
  themes?: string[];
  region?: string;
  observatoire?: string;
  niveau_alerte?: string;
  fiabilite?: string;
  sources?: string[];
  contenu: string;
  validation_humaine?: boolean;
};

export type KnowledgeEntry = Required<Omit<KnowledgeEntryInput, "date" | "auteur" | "categorie" | "rubrique" | "fiabilite" | "sources" | "pays" | "acteurs" | "organisations" | "themes" | "validation_humaine">> & {
  date: string;
  auteur: string;
  categorie: string;
  rubrique: string;
  pays: string[];
  acteurs: string[];
  organisations: string[];
  themes: string[];
  region: string;
  observatoire: string;
  niveau_alerte: string;
  fiabilite: string;
  sources: string[];
  validation_humaine: boolean;
  slug: string;
  directory: string;
  filePath: string;
  obsidianPath: string;
  markdown: string;
  backlinks: string[];
};

const KNOWLEDGE_ROOT = path.join(process.cwd(), "knowledge-hub");

const TYPE_DIRECTORIES: Record<KnowledgeEntryType, string> = {
  article: "articles",
  "research-brief": "research-briefs",
  "note-pays": "notes-pays",
  "signal-faible": "signaux-faibles",
  infographie: "infographies",
  "fiche-pays": "pays",
  "fiche-acteur": "acteurs",
  "fiche-entreprise": "entreprises",
  "fiche-organisation": "organisations",
  "fiche-theme": "themes",
  "think-tank": "think-tank",
  observatoire: "observatoires",
  scenario: "scenarios",
  portrait: "portraits",
  chercheur: "chercheurs",
  innovateur: "innovateurs",
  "conflict-observer": "conflits",
  "country-profile": "countries"
};

export async function createKnowledgeEntry(input: KnowledgeEntryInput | PlanningRow): Promise<KnowledgeEntry> {
  const entryInput = "angle_strategique" in input ? fromPlanningRow(input) : input;

  if (!entryInput.validation_humaine) {
    throw new Error("Knowledge Hub entry requires human validation.");
  }

  const entry = buildEntry(entryInput);
  await ensureKnowledgeHub();
  await writeFile(entry.filePath, entry.markdown, "utf8");
  await generateIndex();
  console.info(`[knowledgeHub] Created Obsidian entry: ${entry.obsidianPath}`);
  return entry;
}

export function linkActors(actors: string[]): string[] {
  return uniqueClean(actors).map((actor) => `[[${actor}]]`);
}

export function linkCountries(countries: string[]): string[] {
  return uniqueClean(countries).map((country) => `[[${country}]]`);
}

export function linkThemes(themes: string[]): string[] {
  return uniqueClean(themes).map((theme) => `[[${theme}]]`);
}

export function generateObsidianLinks(input: Pick<KnowledgeEntryInput, "pays" | "acteurs" | "organisations" | "themes">): string[] {
  return [
    ...linkCountries(input.pays ?? []),
    ...linkActors(input.acteurs ?? []),
    ...uniqueClean(input.organisations ?? []).map((organisation) => `[[${organisation}]]`),
    ...linkThemes(input.themes ?? [])
  ];
}

export function generateBacklinks(entry: Pick<KnowledgeEntry, "pays" | "acteurs" | "organisations" | "themes" | "rubrique" | "categorie">): string[] {
  return uniqueClean([
    ...entry.pays,
    ...entry.acteurs,
    ...entry.organisations,
    ...entry.themes,
    entry.rubrique,
    entry.categorie
  ]).map((item) => `[[${item}]]`);
}

export async function generateIndex(): Promise<string> {
  await ensureKnowledgeHub();
  const sections = await Promise.all(
    Object.entries(TYPE_DIRECTORIES).map(async ([type, directory]) => {
      const dirPath = path.join(KNOWLEDGE_ROOT, directory);
      const files = await safeReadMarkdownFiles(dirPath);
      const lines = files.map((file) => `- [[${file.replace(/\.md$/, "")}]]`);
      return `## ${directory}\n\n${lines.length > 0 ? lines.join("\n") : "- Aucun contenu pour le moment."}`;
    })
  );
  const markdown = `# Knowledge Hub Valeurs Africaines\n\nDerniere mise a jour : ${new Date().toISOString()}\n\n${sections.join("\n\n")}\n`;
  await writeFile(path.join(KNOWLEDGE_ROOT, "index.md"), markdown, "utf8");
  return markdown;
}

export async function getKnowledgeEntries(): Promise<KnowledgeEntry[]> {
  await ensureKnowledgeHub();
  const entries: KnowledgeEntry[] = [];

  for (const directory of uniqueClean(Object.values(TYPE_DIRECTORIES))) {
    const dirPath = path.join(KNOWLEDGE_ROOT, directory);
    const files = await safeReadMarkdownFiles(dirPath);

    for (const file of files) {
      const markdown = await readFile(path.join(dirPath, file), "utf8");
      entries.push(parseMarkdownEntry(markdown, directory, file));
    }
  }

  return entries.sort((a, b) => b.date.localeCompare(a.date));
}

export function buildEntry(input: KnowledgeEntryInput): KnowledgeEntry {
  const slug = slugify(input.titre);
  const directory = TYPE_DIRECTORIES[input.type];
  const filePath = path.join(KNOWLEDGE_ROOT, directory, `${slug}.md`);
  const normalized = {
    type: input.type,
    titre: input.titre.trim(),
    date: input.date || new Date().toISOString().slice(0, 10),
    auteur: input.auteur || "Redaction Valeurs Africaines",
    categorie: input.categorie || input.rubrique || "Base de connaissances",
    rubrique: input.rubrique || input.categorie || "Base de connaissances",
    pays: uniqueClean(input.pays ?? []),
    acteurs: uniqueClean(input.acteurs ?? []),
    organisations: uniqueClean(input.organisations ?? []),
    themes: uniqueClean(input.themes ?? []),
    region: input.region || inferRegion(input.pays ?? [], input.rubrique || input.categorie || ""),
    observatoire: input.observatoire || inferObservatoire(input.type, input.rubrique || input.categorie || ""),
    niveau_alerte: input.niveau_alerte || "à vérifier",
    fiabilite: input.fiabilite || "A verifier",
    sources: uniqueClean(input.sources ?? []),
    contenu: input.contenu.trim(),
    validation_humaine: input.validation_humaine ?? false,
    slug,
    directory,
    filePath,
    obsidianPath: `${directory}/${slug}.md`
  };
  const backlinks = generateBacklinks(normalized);
  const markdown = renderMarkdown({ ...normalized, backlinks });

  return {
    ...normalized,
    backlinks,
    markdown
  };
}

function fromPlanningRow(row: PlanningRow): KnowledgeEntryInput {
  return {
    type: inferType(row.format),
    titre: row.sujet,
    date: new Date().toISOString().slice(0, 10),
    auteur: "Redaction Valeurs Africaines",
    categorie: row.rubrique,
    rubrique: row.rubrique,
    pays: extractCommaList(row.rubrique),
    acteurs: [],
    organisations: [],
    themes: extractCommaList(row.format),
    fiabilite: "A verifier",
    sources: [],
    contenu: row.angle_strategique,
    validation_humaine: row.validation_humaine.trim().toLowerCase() === "oui" || row.statut === "Validé"
  };
}

function inferType(format: string): KnowledgeEntryType {
  const value = format.toLowerCase();
  if (value.includes("brief")) return "research-brief";
  if (value.includes("note pays") || value.includes("pays")) return "note-pays";
  if (value.includes("signal")) return "signal-faible";
  if (value.includes("infographie") || value.includes("carte")) return "infographie";
  return "article";
}

function renderMarkdown(entry: Omit<KnowledgeEntry, "markdown">): string {
  const links = generateObsidianLinks(entry);
  const actorRows = entry.acteurs.length > 0
    ? entry.acteurs.map((actor) => `| [[${actor}]] | A verifier | A verifier | A verifier | A verifier |`).join("\n")
    : "| Donnee a verifier | A verifier | A verifier | A verifier | A verifier |";
  const countryRows = entry.pays.length > 0
    ? entry.pays.map((country) => `| [[${country}]] | A verifier |`).join("\n")
    : "| Donnee a verifier | A verifier |";
  const themeList = entry.themes.length > 0
    ? entry.themes.map((theme) => `- [[${theme}]]`).join("\n")
    : "- Themes a verifier.";
  const indexedKeywords = uniqueClean([
    ...entry.themes,
    ...entry.pays,
    ...entry.acteurs,
    ...entry.organisations,
    entry.categorie,
    entry.rubrique,
    entry.observatoire
  ]);

  return `---\ntitre: ${quoteYaml(entry.titre)}\ntype: ${entry.type}\ndate: ${entry.date}\npays: ${yamlList(entry.pays)}\nregion: ${quoteYaml(entry.region)}\nobservatoire: ${quoteYaml(entry.observatoire)}\nmots_cles: ${yamlList(indexedKeywords)}\nacteurs: ${yamlList(entry.acteurs)}\nniveau_alerte: ${quoteYaml(entry.niveau_alerte)}\nsources: ${yamlList(entry.sources)}\nauteur: ${quoteYaml(entry.auteur)}\ncategorie: ${quoteYaml(entry.categorie)}\nrubrique: ${quoteYaml(entry.rubrique)}\norganisations: ${yamlList(entry.organisations)}\nfiabilite: ${quoteYaml(entry.fiabilite)}\nvalidation_humaine: ${entry.validation_humaine}\n---\n\n# ${entry.titre}\n\n> Actif documentaire interne. Validation humaine requise avant integration definitive, publication ou reutilisation externe.\n\n## 1. Fiche synthese\n\n### Titre\n\n${entry.titre}\n\n### Type\n\n${entry.type}\n\n### Date\n\n${entry.date}\n\n### Resume executif\n\n${entry.contenu || "Resume executif a completer a partir de sources verifiees."}\n\n## 2. Acteurs cles\n\n| Acteur | Type | Role | Interets | Influence |\n|---|---|---|---|---|\n${actorRows}\n\n## 3. Thematiques associees\n\n${themeList}\n\n## 4. Pays concernes\n\n| Pays | Niveau d'implication |\n|---|---|\n${countryRows}\n\n## 5. Enjeux strategiques\n\n### Enjeux economiques\n\nDonnee a verifier.\n\n### Enjeux geopolitiques\n\nDonnee a verifier.\n\n### Enjeux securitaires\n\nDonnee a verifier.\n\n### Enjeux technologiques\n\nDonnee a verifier.\n\n### Enjeux de gouvernance\n\nDonnee a verifier.\n\n### Enjeux narratifs\n\nDonnee a verifier.\n\n## 6. Faits cles\n\n1. Donnee a verifier.\n2. Donnee a verifier.\n3. Donnee a verifier.\n4. Donnee a verifier.\n5. Donnee a verifier.\n\n## 7. Chronologie\n\n| Date | Evenement |\n|---|---|\n| Donnee a verifier | Donnee a verifier |\n\n## 8. Consequences pour l'Afrique\n\n### Court terme\n\nDonnee a verifier.\n\n### Moyen terme\n\nDonnee a verifier.\n\n### Long terme\n\nDonnee a verifier.\n\n## 9. Risques\n\n| Risque | Probabilite | Impact |\n|---|---|---|\n| Donnee a verifier | A verifier | A verifier |\n\n## 10. Opportunites\n\n| Opportunite | Horizon |\n|---|---|\n| Donnee a verifier | A verifier |\n\n## 11. Signaux a surveiller\n\n- Signal a verifier.\n- Signal a verifier.\n- Signal a verifier.\n- Signal a verifier.\n- Signal a verifier.\n\n## 12. Connexions avec la base\n\n### Pays\n\n${entry.pays.length > 0 ? entry.pays.map((country) => `- [[${country}]]`).join("\n") : "- Aucun pays confirme."}\n\n### Organisations\n\n${entry.organisations.length > 0 ? entry.organisations.map((organisation) => `- [[${organisation}]]`).join("\n") : "- Aucune organisation confirmee."}\n\n### Personnalites\n\n${entry.acteurs.length > 0 ? entry.acteurs.map((actor) => `- [[${actor}]]`).join("\n") : "- Aucune personnalite confirmee."}\n\n### Thematiques\n\n${themeList}\n\n### Dossiers lies\n\n${links.length > 0 ? links.map((link) => `- ${link}`).join("\n") : "- Aucun dossier lie identifie."}\n\n## 13. Mots-cles indexes\n\n${indexedKeywords.length > 0 ? indexedKeywords.map((keyword) => `- ${keyword}`).join("\n") : "- Mots-cles a verifier."}\n\n## 14. Metadonnees\n\n| Champ | Valeur |\n|---|---|\n| Categorie | ${entry.categorie || "A verifier"} |\n| Rubrique | ${entry.rubrique || "A verifier"} |\n| Region | ${entry.region || "A verifier"} |\n| Niveau strategique | A verifier |\n| Sensibilite | A verifier |\n| Source principale | ${entry.sources[0] || "A verifier"} |\n| Sources a verifier | ${entry.sources.length > 0 ? entry.sources.join(", ") : "Sources a verifier"} |\n\n## 15. Questions de recherche futures\n\n1. Quels interets sont en jeu ?\n2. Quels acteurs gagnent ou perdent en influence ?\n3. Quelles consequences directes pour les Etats africains ?\n4. Quels indicateurs suivre dans les prochains mois ?\n5. Quels scenarios alternatifs sont plausibles ?\n6. Quels risques doivent etre documentes avant publication ?\n7. Quelles sources independantes peuvent confirmer les donnees ?\n8. Quelle infographie ou carte permettrait de rendre le sujet exploitable ?\n\n## Methode d'analyse\n\n### Faits\n\nInformations confirmees uniquement. Donnees a verifier avant toute reutilisation editoriale.\n\n### Analyse\n\nInterpretation argumentee a completer par la redaction.\n\n### Hypotheses\n\nScenarios possibles a documenter avec prudence.\n\n### Incertitudes\n\nSources, chiffres, dates et responsabilites a verifier.\n\n## Backlinks proposes\n\n${entry.backlinks.length > 0 ? entry.backlinks.map((link) => `- ${link}`).join("\n") : "- Aucun backlink propose."}\n\n## Sources\n\n${entry.sources.length > 0 ? entry.sources.map((source) => `- ${source}`).join("\n") : "- Sources a verifier."}\n`;
}

async function ensureKnowledgeHub(): Promise<void> {
  await mkdir(KNOWLEDGE_ROOT, { recursive: true });
  await Promise.all(uniqueClean(Object.values(TYPE_DIRECTORIES)).map((directory) => mkdir(path.join(KNOWLEDGE_ROOT, directory), { recursive: true })));
}

async function safeReadMarkdownFiles(directory: string): Promise<string[]> {
  try {
    const files = await readdir(directory);
    return files.filter((file) => file.endsWith(".md")).sort();
  } catch {
    return [];
  }
}

function parseMarkdownEntry(markdown: string, directory: string, file: string): KnowledgeEntry {
  const yaml = markdown.match(/^---\n([\s\S]*?)\n---/)?.[1] ?? "";
  const get = (field: string) => yaml.match(new RegExp(`^${field}:\\s*(.*)$`, "m"))?.[1]?.replace(/^"|"$/g, "") ?? "";
  const getList = (field: string) => parseYamlInlineList(get(field));
  const type = (get("type") || "article") as KnowledgeEntryType;
  const titre = get("titre") || file.replace(/\.md$/, "");
  const entryBase = {
    type,
    titre,
    date: get("date") || "",
    auteur: get("auteur") || "",
    categorie: get("categorie") || "",
    rubrique: get("rubrique") || "",
    pays: getList("pays"),
    acteurs: getList("acteurs"),
    organisations: getList("organisations"),
    themes: getList("themes").length > 0 ? getList("themes") : getList("mots_cles"),
    region: get("region") || "",
    observatoire: get("observatoire") || "",
    niveau_alerte: get("niveau_alerte") || "",
    fiabilite: get("fiabilite") || "",
    sources: getList("sources"),
    contenu: markdown.replace(/^---\n[\s\S]*?\n---/, "").trim(),
    validation_humaine: true,
    slug: file.replace(/\.md$/, ""),
    directory,
    filePath: path.join(KNOWLEDGE_ROOT, directory, file),
    obsidianPath: `${directory}/${file}`
  };
  const backlinks = generateBacklinks(entryBase);
  return { ...entryBase, backlinks, markdown };
}

function extractCommaList(value: string): string[] {
  return value.split(/[,;|]/).map((item) => item.trim()).filter(Boolean);
}

function uniqueClean(values: string[]): string[] {
  return Array.from(new Set(values.map((value) => value.trim()).filter(Boolean)));
}

function yamlList(values: string[]): string {
  return `[${values.map(quoteYaml).join(", ")}]`;
}

function quoteYaml(value: string): string {
  return `"${value.replace(/"/g, '\\"')}"`;
}

function parseYamlInlineList(value: string): string[] {
  return value
    .replace(/^\[|\]$/g, "")
    .split(",")
    .map((item) => item.trim().replace(/^"|"$/g, ""))
    .filter(Boolean);
}

function inferRegion(pays: string[], fallback: string): string {
  if (fallback.toLowerCase().includes("diaspora")) return "Diaspora mondiale";
  if (fallback.toLowerCase().includes("sahel")) return "Sahel";
  if (pays.length > 1) return "Afrique";
  return pays[0] || "à vérifier";
}

function inferObservatoire(type: KnowledgeEntryType, fallback: string): string {
  const value = `${type} ${fallback}`.toLowerCase();
  if (value.includes("conflict") || value.includes("conflit")) return "Observatoire des Conflits Africains";
  if (value.includes("diaspora")) return "Observatoire de la Diaspora Africaine";
  if (value.includes("odd") || value.includes("agenda 2063")) return "Observatoire du Développement Durable & ODD";
  if (value.includes("business") || value.includes("entreprise")) return "Observatoire Business & Investissements";
  if (value.includes("écologie") || value.includes("ecologie") || value.includes("climat")) return "Observatoire Écologie & Ressources";
  if (value.includes("narrative") || value.includes("média")) return "Observatoire de la Souveraineté Narrative";
  if (value.includes("chercheur") || value.includes("portrait")) return "Observatoire des Chercheurs Africains";
  if (value.includes("innovation") || value.includes("tech")) return "Observatoire de l'Innovation Africaine";
  return "VAIS";
}

function slugify(value: string): string {
  return value
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-|-$/g, "")
    .slice(0, 90) || "fiche";
}
