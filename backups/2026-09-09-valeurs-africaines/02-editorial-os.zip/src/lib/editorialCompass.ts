export interface EditorialScore {
  score: number;
  urgency: "faible" | "moyenne" | "élevée" | "critique";
  category: string;
  recommendation: string;
  sources_a_verifier: string[];
  validation_humaine_requise: true;
  publication_automatique: false;
}

export type TopicInput = {
  title: string;
  summary?: string;
  region?: string;
  sources?: string[];
  tags?: string[];
};

type ScoreBreakdown = {
  africaImpact: number;
  strategicValue: number;
  businessImpact: number;
  innovationPotential: number;
  conflictRisk: number;
  sdgImpact: number;
  narrativeInfluence: number;
  urgency: number;
};

export function scoreTopic(input: TopicInput): EditorialScore {
  const breakdown: ScoreBreakdown = {
    africaImpact: evaluateAfricaImpact(input),
    strategicValue: evaluateStrategicValue(input),
    businessImpact: evaluateBusinessImpact(input),
    innovationPotential: evaluateInnovationPotential(input),
    conflictRisk: evaluateConflictRisk(input),
    sdgImpact: evaluateSDGImpact(input),
    narrativeInfluence: evaluateNarrativeInfluence(input),
    urgency: evaluateUrgency(input)
  };
  const score = calculateFinalPriority(breakdown);

  return {
    score,
    urgency: classifyUrgency(score, breakdown.urgency),
    category: inferCategory(input, breakdown),
    recommendation: recommendFormat(input, breakdown, score),
    sources_a_verifier: input.sources?.length ? input.sources : ["sources à vérifier"],
    validation_humaine_requise: true,
    publication_automatique: false
  };
}

export function evaluateAfricaImpact(input: TopicInput): number {
  return boundedScore(input, 20, ["afrique", "africain", "continent", "panafricain", "emplois", "jeunesse", "santé", "éducation"]);
}

export function evaluateStrategicValue(input: TopicInput): number {
  return boundedScore(input, 15, ["souveraineté", "stratégique", "défense", "énergie", "ressources", "infrastructure", "gouvernance"]);
}

export function evaluateInnovationPotential(input: TopicInput): number {
  return boundedScore(input, 10, ["innovation", "technologie", "ia", "startup", "fintech", "agritech", "healthtech", "spatial"]);
}

export function evaluateConflictRisk(input: TopicInput): number {
  return boundedScore(input, 15, ["conflit", "sécurité", "terrorisme", "insurrection", "coup d'état", "crise", "sahel", "médiation"]);
}

export function evaluateBusinessImpact(input: TopicInput): number {
  return boundedScore(input, 15, ["business", "industrie", "investissement", "commerce", "zlecaf", "pme", "capital-risque", "marché"]);
}

export function evaluateSDGImpact(input: TopicInput): number {
  return boundedScore(input, 10, ["odd", "développement", "climat", "eau", "santé", "éducation", "égalité", "énergie durable"]);
}

export function evaluateNarrativeInfluence(input: TopicInput): number {
  return boundedScore(input, 10, ["récit", "narratif", "média", "désinformation", "influence", "diaspora", "image de l'afrique"]);
}

export function calculateFinalPriority(breakdown: ScoreBreakdown): number {
  return Math.min(100, Object.values(breakdown).reduce((sum, value) => sum + value, 0));
}

function evaluateUrgency(input: TopicInput): number {
  return boundedScore(input, 5, ["urgent", "aujourd'hui", "alerte", "rupture", "attaque", "sommet", "élection", "sanction"]);
}

function recommendFormat(input: TopicInput, breakdown: ScoreBreakdown, score: number): string {
  const text = normalizeTopic(input);
  if (score > 90) return "Dossier stratégique";
  if (breakdown.conflictRisk >= 8 || /conflit|terrorisme|insurrection|sécurité|sahel/.test(text)) return "Observatoire des conflits";
  if (breakdown.innovationPotential >= 6 || /innovation|technologie|ia|startup/.test(text)) return "Article innovation";
  if (breakdown.businessImpact >= 8 || /business|industrie|investissement|zlecaf|marché/.test(text)) return "Analyse économique";
  if (breakdown.sdgImpact >= 6 || /odd|climat|santé|éducation|eau/.test(text)) return "Fil rouge Afrique 2030";
  if (/diaspora|influence|université|chercheur|talent/.test(text)) return "Portrait influence";
  return "Article stratégique";
}

function inferCategory(input: TopicInput, breakdown: ScoreBreakdown): string {
  const candidates = [
    ["Sécurité & Défense", breakdown.conflictRisk],
    ["Économie & Développement", breakdown.businessImpact],
    ["Technologie & Innovation", breakdown.innovationPotential],
    ["Afrique 2030", breakdown.sdgImpact],
    ["Médias & Souveraineté narrative", breakdown.narrativeInfluence],
    ["Géopolitique & Diplomatie", breakdown.strategicValue]
  ] as const;
  const best = [...candidates].sort((a, b) => b[1] - a[1])[0];
  return best[1] > 0 ? best[0] : input.region || "Veille stratégique";
}

function classifyUrgency(score: number, urgencyScore: number): EditorialScore["urgency"] {
  if (score >= 90 || urgencyScore >= 5) return "critique";
  if (score >= 75) return "élevée";
  if (score >= 40) return "moyenne";
  return "faible";
}

function boundedScore(input: TopicInput, max: number, keywords: string[]): number {
  const text = normalizeTopic(input);
  const matches = keywords.filter((keyword) => text.includes(keyword.toLowerCase())).length;
  const sourceBonus = input.sources?.length ? 1 : 0;
  return Math.min(max, Math.round((matches / Math.max(1, keywords.length)) * max * 2) + sourceBonus);
}

function normalizeTopic(input: TopicInput): string {
  return `${input.title} ${input.summary ?? ""} ${input.region ?? ""} ${(input.tags ?? []).join(" ")}`.toLowerCase();
}
