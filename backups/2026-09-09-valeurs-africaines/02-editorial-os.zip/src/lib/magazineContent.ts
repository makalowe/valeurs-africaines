import { readdir, readFile } from "node:fs/promises";
import path from "node:path";

export type MagazineArticle = {
  id: string;
  title: string;
  rubrique: string;
  date: string;
  intro: string;
  sourceFile: string;
  statusLabel: string;
};

const DRAFTS_DIR = path.join(process.cwd(), "..", "02-EDITION-HEBDOMADAIRE", "Brouillons");
const ARCHIVE_DIR = path.join(process.cwd(), "..", "VALEURS_AFRICAINES", "01_ACTUALITES", "Aujourd'hui en Afrique");

export async function getMagazineArticles(): Promise<{ articles: MagazineArticle[]; archiveNames: string[] }> {
  const [draftEntries, archiveEntries] = await Promise.all([readdir(DRAFTS_DIR).catch(() => []), readdir(ARCHIVE_DIR).catch(() => [])]);

  const articles: MagazineArticle[] = [];
  for (const entry of draftEntries.filter((name) => name.endsWith(".md"))) {
    const filePath = path.join(DRAFTS_DIR, entry);
    try {
      const raw = await readFile(filePath, "utf-8");
      const parsed = parseDraft(raw, entry);
      if (parsed) articles.push(parsed);
    } catch {
      // brouillon illisible : ignoré
    }
  }

  const archiveNames = archiveEntries.filter((name) => name.endsWith(".md")).sort().reverse();
  articles.sort((left, right) => right.date.localeCompare(left.date) || left.title.localeCompare(right.title));
  return { articles, archiveNames };
}

function parseDraft(raw: string, filename: string): MagazineArticle | null {
  const frontmatter = raw.match(/^---\n([\s\S]*?)\n---/);
  const fields: Record<string, string> = {};
  if (frontmatter) {
    for (const line of frontmatter[1].split("\n")) {
      const match = line.match(/^([a-zA-Z_]+):\s*"?(.+?)"?\s*$/);
      if (match) fields[match[1].toLowerCase()] = match[2].replace(/"/g, "").trim();
    }
  }
  const title = fields.title ?? filename.replace(/\.md$/, "");
  const rubrique = fields.rubrique ?? "Dossier";
  const dateMatch = filename.match(/^(\d{4}-\d{2}-\d{2})/);
  const date = dateMatch ? dateMatch[1] : (fields.created ?? "date inconnue");
  const intro = extractIntro(raw);

  return {
    id: filename.replace(/\.md$/, ""),
    title: cleanMarkdown(title),
    rubrique: cleanMarkdown(rubrique),
    date,
    intro,
    sourceFile: filename,
    statusLabel: fields.status === "draft" ? "Brouillon · validation en cours" : "En préparation"
  };
}

function extractIntro(raw: string): string {
  const body = raw.replace(/^---\n[\s\S]*?\n---\n/, "");
  const sections = body.split(/^##\s+/m);
  const wanted = ["Introduction", "Chapo", "Faits établis", "Faits etablis", "Faits"];
  for (const wantedTitle of wanted) {
    const section = sections.find((chunk) => chunk.split("\n", 1)[0].trim().toLowerCase() === wantedTitle.toLowerCase());
    if (!section) continue;
    const paragraph = section
      .split("\n")
      .slice(1)
      .map((line) => line.trim())
      .filter((line) => line.length > 40 && !line.startsWith(">") && !line.startsWith("-"))
      .join(" ")
      .trim();
    if (paragraph) return truncate(cleanMarkdown(paragraph), 340);
  }
  const firstParagraph = body
    .split("\n")
    .map((line) => line.trim())
    .find((line) => line.length > 60 && !line.startsWith("-") && !line.startsWith(">") && !line.startsWith("#"));
  return truncate(cleanMarkdown(firstParagraph ?? "Article en cours de rédaction."), 340);
}

function cleanMarkdown(value: string): string {
  return value
    .replace(/\*\*([^*]+)\*\*/g, "$1")
    .replace(/\[([^\]]+)\]\([^)]*\)/g, "$1")
    .replace(/\s+/g, " ")
    .trim();
}

function truncate(value: string, max: number): string {
  return value.length > max ? `${value.slice(0, max).trimEnd()}…` : value;
}
