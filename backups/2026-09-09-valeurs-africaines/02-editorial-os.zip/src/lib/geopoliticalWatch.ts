export type WatchCategory =
  | "Géopolitique"
  | "Diplomatie"
  | "Économie"
  | "Sécurité"
  | "Défense"
  | "Énergie"
  | "Ressources stratégiques"
  | "Technologie"
  | "Gouvernance"
  | "Influence et médias";

export type WatchLevel = "Signal faible" | "Développement important" | "Événement stratégique majeur";
export type VerificationStatus = "source_absente" | "à_vérifier" | "vérifié";

export type GeopoliticalWatchEvent = {
  id: string;
  title: string;
  date: string;
  country: string;
  region: string;
  actors: string[];
  category: WatchCategory;
  summary: string;
  importanceLevel: WatchLevel;
  africaImpactLevel: "faible" | "moyen" | "élevé" | "critique" | "à vérifier";
  sources: string[];
  verificationStatus: VerificationStatus;
  impact: {
    economic: string;
    geopolitical: string;
    security: string;
    opportunities: string;
    risks: string;
  };
  mapPosition: {
    x: number;
    y: number;
  } | null;
};

export const watchCategories: WatchCategory[] = [
  "Géopolitique",
  "Diplomatie",
  "Économie",
  "Sécurité",
  "Défense",
  "Énergie",
  "Ressources stratégiques",
  "Technologie",
  "Gouvernance",
  "Influence et médias"
];

export const watchLevels: WatchLevel[] = ["Signal faible", "Développement important", "Événement stratégique majeur"];

export const watchRegions = [
  "Toutes les régions",
  "Afrique du Nord",
  "Afrique de l'Ouest",
  "Afrique Centrale",
  "Afrique de l'Est",
  "Afrique Australe",
  "Afrique"
];

export const geopoliticalWatchEvents: GeopoliticalWatchEvent[] = [];

export function getGeopoliticalWatchEvents() {
  return geopoliticalWatchEvents;
}

export function getWatchMethodology() {
  return {
    signalFaible: "Indice précoce documenté par au moins une source traçable, sans conclusion définitive.",
    developpementImportant: "Événement confirmé ou en cours de confirmation pouvant modifier une dynamique régionale.",
    evenementStrategiqueMajeur: "Événement à impact continental, régional ou souverain significatif, nécessitant analyse approfondie.",
    publicationRule: "Aucun événement ne peut être publié sans source traçable et validation humaine."
  };
}
