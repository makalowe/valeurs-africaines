export type RelevanceCriterion = "urgence" | "impactAfricain" | "adequationLigneVA" | "qualiteSources" | "potentielAnalyse";

export type EditorialRelevance = {
  score: number;
  stars: string;
  criteria: Record<RelevanceCriterion, number>;
  reason: string[];
};

export type RelevanceInput = {
  title: string;
  rubric: string;
  pourquoi: string;
  countries: string[];
  sourceUrls: string[];
  risk: string;
};

const KEYWORDS: Record<Exclude<RelevanceCriterion, "qualiteSources">, string[]> = {
  urgence: ["aujourd'hui", "hier", "investiture", "serment", "élection", "réélection", "scrutin", "vote", "sommet", "crise", "combats", "attaque", "annonce", "accord", "décision", "sanction", "contestation", "inculpé", "prison", "investi", "mandat", "démission", "nomination"],
  impactAfricain: ["afrique", "africain", "continent", "continental", "régional", "union africaine", "ua", "sadc", "cedeao", "aes", "sahel", "uemoa", "zone", "pays", "états", "australe", "australe", "panafricain"],
  adequationLigneVA: ["géopolitique", "stratégie", "stratégique", "souveraineté", "sécurité", "économie", "finances", "dette", "démocratie", "gouvernance", "diplomatie", "médias", "narratif", "influence", "innovation", "énergie", "marché", "institutions", "institutionnel", "politique"],
  potentielAnalyse: ["enjeu", "test", "paradoxe", "défi", "implication", "conséquences", "analyse", "angle", "démocratique", "stabilité", "crédibilité", "redressement", "transition", "héritage", "équilibre", "tournant", "contraste", "interroge", "à suivre", "surveiller", "contexte"]
};

const TRUSTED_SOURCE_DOMAINS = [
  "imf.org",
  "africanews",
  "afp",
  "reuters",
  "xinhua",
  "xinhuanet",
  "allafrica",
  "angop",
  "jeuneafrique",
  "cnbcafrica",
  "bbc",
  "lemonde",
  "sidwaya",
  "financialafrik"
];

export function scoreEditorialRelevance(input: RelevanceInput): EditorialRelevance {
  const text = norm(`${input.title} ${input.rubric} ${input.pourquoi} ${input.risk} ${input.countries.join(" ")}`);

  const urgence = keywordScore(text, KEYWORDS.urgence);
  const impactAfricain = Math.min(5, keywordScore(text, KEYWORDS.impactAfricain) + (input.countries.length > 0 ? 2 : 0));
  const adequationLigneVA = keywordScore(text, KEYWORDS.adequationLigneVA) + rubricBonus(input.rubric);
  const qualiteSources = sourceScore(input.sourceUrls);
  const potentielAnalyse = keywordScore(text, KEYWORDS.potentielAnalyse);

  const criteria: Record<RelevanceCriterion, number> = {
    urgence: cap5(urgence),
    impactAfricain: cap5(impactAfricain),
    adequationLigneVA: cap5(adequationLigneVA),
    qualiteSources,
    potentielAnalyse
  };

  const rawAverage = (criteria.urgence + criteria.impactAfricain + criteria.adequationLigneVA + criteria.qualiteSources + criteria.potentielAnalyse) / 5;
  const score = Math.round(rawAverage * 10) / 10;
  const rounded = Math.round(score);

  return {
    score,
    stars: "★".repeat(rounded) + "☆".repeat(Math.max(0, 5 - rounded)),
    criteria,
    reason: buildReasons(criteria, input)
  };
}

function cap5(value: number): number {
  return Math.min(5, value);
}

function keywordScore(text: string, keywords: string[]): number {
  const matches = keywords.filter((keyword) => text.includes(norm(keyword))).length;
  if (matches === 0) return 0;
  if (matches >= 3) return 5;
  if (matches === 2) return 4;
  return 2;
}

function rubricBonus(rubric: string): number {
  const normalized = norm(rubric);
  if (["actualite strategique", "strategie"].some((value) => normalized.includes(value))) return 2;
  if (["economie", "securite", "diplomatie", "innovation", "gouvernance", "culture", "medias"].some((value) => normalized.includes(value))) return 1.5;
  return 0;
}

function sourceScore(sourceUrls: string[]): number {
  if (sourceUrls.length === 0) return 0;
  const trusted = sourceUrls.some((url) => TRUSTED_SOURCE_DOMAINS.some((domain) => url.toLowerCase().includes(domain)));
  if (sourceUrls.length >= 3) return trusted ? 5 : 4;
  if (sourceUrls.length === 2) return trusted ? 4 : 3;
  return trusted ? 3 : 2;
}

function buildReasons(criteria: Record<RelevanceCriterion, number>, input: RelevanceInput): string[] {
  const reasons: string[] = [];
  if (criteria.urgence >= 4) reasons.push("Actualité immédiate (événement en cours ou tout récent).");
  else if (criteria.urgence <= 1) reasons.push("Actualité faible : événement daté ou sans élément neuf.");
  if (criteria.impactAfricain >= 4) reasons.push("Impact africain ou continental fort.");
  else if (criteria.impactAfricain <= 1) reasons.push("Portée africaine limitée à préciser.");
  if (criteria.adequationLigneVA >= 4) reasons.push("Très aligné avec la ligne VA (souveraineté, géopolitique, stratégie).");
  else if (criteria.adequationLigneVA <= 1) reasons.push("Adéquation ligne VA faible : angle à construire.");
  if (criteria.qualiteSources >= 4) reasons.push(`Sources multiples ou fiables (${input.sourceUrls.length} URL(s) dont source de référence).`);
  else if (criteria.qualiteSources === 0) reasons.push("Aucune source listée — à compléter avant décision.");
  else reasons.push("Peu de sources : vérification nécessaire.");
  if (criteria.potentielAnalyse >= 4) reasons.push("Fort potentiel d'analyse stratégique (enjeux, implications).");
  else if (criteria.potentielAnalyse <= 1) reasons.push("Potentiel d'analyse à démontrer : risque de simple dépêche.");
  if (input.countries.length > 0) reasons.push(`Pays/région couvert(s) : ${input.countries.join(", ")}.`);
  return reasons;
}

function norm(value: string): string {
  return value.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase();
}
