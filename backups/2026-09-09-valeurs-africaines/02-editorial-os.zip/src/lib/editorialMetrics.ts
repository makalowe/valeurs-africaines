import { getPriorityDossiers, getStrategicDossierCoverage } from "./strategicDossiers";

export type ProductionMetric = {
  label: string;
  current: number;
  target: number;
};

export type ValidationItem = {
  id: string;
  title: string;
  author: string;
  date: string;
  status: "Brouillon" | "Relecture" | "Fact-checking" | "Validation finale";
};

export type PendingVisual = {
  editorialId: string;
  articleTitle: string;
  proposals: Array<{
    id: string;
    type: "Photo" | "Illustration" | "Dessin éditorial" | "Graphique" | "Carte" | "Diagramme";
    title: string;
    status: "En attente" | "Sélectionné" | "Rejeté";
  }>;
};

export type EditorialAlert = {
  level: "critique" | "attention" | "normal";
  title: string;
  detail: string;
};

export type CalendarItem = {
  date: string;
  type: "Article" | "Research Brief" | "Dossier spécial" | "Édition hebdomadaire";
  title: string;
  status: string;
};

export type PortraitCoverageMetric = {
  label: string;
  value: number;
  detail: string;
};

export async function getTodayProduction(): Promise<ProductionMetric[]> {
  return [
    { label: "Articles du jour", current: 3, target: 3 },
    { label: "Research Briefs", current: 1, target: 2 },
    { label: "Notes Pays", current: 0, target: 1 },
    { label: "Signaux faibles", current: 4, target: 5 },
    { label: "Posts LinkedIn", current: 2, target: 3 },
    { label: "Posts X", current: 5, target: 6 }
  ];
}

export async function getWeeklyProduction(): Promise<ProductionMetric[]> {
  return [
    { label: "Articles semaine", current: 12, target: 15 },
    { label: "Research Briefs", current: 3, target: 5 },
    { label: "Note Pays", current: 0, target: 1 },
    { label: "Portraits d'excellence", current: 1, target: 1 },
    { label: "Femmes scientifiques", current: 1, target: 2 },
    { label: "Diaspora académique", current: 1, target: 2 },
    { label: "Newsletter", current: 1, target: 1 }
  ];
}

export async function getPortraitCoverageMetrics(): Promise<PortraitCoverageMetric[]> {
  return [
    { label: "Chercheurs référencés", value: 4, detail: "Recherche fondamentale, sciences sociales, santé, technologie." },
    { label: "Innovateurs référencés", value: 3, detail: "Innovation scientifique, technologique et sociale." },
    { label: "Femmes scientifiques mises en avant", value: 1, detail: "Couverture à renforcer." },
    { label: "Diaspora couverte", value: 1, detail: "Identifier davantage de profils dans les grandes universités." },
    { label: "Domaines scientifiques couverts", value: 6, detail: "Santé, IA, économie, droit, humanités, ingénierie." },
    { label: "Universités représentées", value: 5, detail: "Institutions à documenter avec sources vérifiées." }
  ];
}

export async function getPendingValidations(): Promise<ValidationItem[]> {
  return [
    { id: "VA-142", title: "La nouvelle stratégie maritime du Maroc", author: "Rédaction", date: "2026-06-12", status: "Validation finale" },
    { id: "VA-143", title: "BRICS et financement des infrastructures africaines", author: "Desk économie", date: "2026-06-12", status: "Fact-checking" },
    { id: "VA-144", title: "Souveraineté narrative et médias internationaux", author: "Desk médias", date: "2026-06-13", status: "Relecture" }
  ];
}

export async function getPendingVisuals(): Promise<PendingVisual[]> {
  return [
    {
      editorialId: "VA-142",
      articleTitle: "La nouvelle stratégie maritime du Maroc",
      proposals: [
        { id: "1", type: "Photo", title: "Photo satellite du détroit", status: "En attente" },
        { id: "2", type: "Carte", title: "Carte maritime stratégique", status: "En attente" },
        { id: "3", type: "Graphique", title: "Infographie des routes commerciales", status: "En attente" }
      ]
    },
    {
      editorialId: "VA-143",
      articleTitle: "BRICS et financement des infrastructures africaines",
      proposals: [
        { id: "1", type: "Photo", title: "Sommet diplomatique", status: "Rejeté" },
        { id: "2", type: "Illustration", title: "Illustration multipolaire", status: "Sélectionné" },
        { id: "3", type: "Diagramme", title: "Schéma des flux financiers", status: "En attente" }
      ]
    }
  ];
}

export async function getEditorialAlerts(): Promise<EditorialAlert[]> {
  const dossiers = await getStrategicDossierCoverage();
  const priorityDossiers = getPriorityDossiers(dossiers);

  return [
    { level: "attention", title: "Aucune Note Pays cette semaine", detail: "Prévoir une Note Pays avant la clôture hebdomadaire." },
    { level: "critique", title: "Dossier sous couvert", detail: `${priorityDossiers[0]?.name ?? "Diaspora"} doit être renforcé.` },
    { level: "normal", title: "Production quotidienne tenue", detail: "Objectif de trois articles atteint aujourd'hui." },
    { level: "attention", title: "Concentration thématique", detail: "Plusieurs contenus portent sur les corridors et routes maritimes." }
  ];
}

export async function getCoverageHealthScore(): Promise<number> {
  const dossiers = await getStrategicDossierCoverage();
  const average = dossiers.reduce((sum, dossier) => sum + dossier.coverage, 0) / dossiers.length;
  return Math.round(average);
}

export async function getEditorialCalendar(): Promise<CalendarItem[]> {
  return [
    { date: "2026-06-12", type: "Article", title: "Stratégie maritime du Maroc", status: "Validation" },
    { date: "2026-06-13", type: "Research Brief", title: "Afrique-BRICS et infrastructures", status: "Recherche" },
    { date: "2026-06-14", type: "Dossier spécial", title: "Femmes & Leadership", status: "Programmé" },
    { date: "2026-06-15", type: "Édition hebdomadaire", title: "Newsletter stratégique", status: "À préparer" }
  ];
}
