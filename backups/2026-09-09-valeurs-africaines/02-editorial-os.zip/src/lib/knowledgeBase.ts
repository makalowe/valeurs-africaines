import { google } from "googleapis";
import type { PlanningRow } from "@/lib/googleSheets";

export type KnowledgeRecord = {
  sujet: string;
  paysRegion: string;
  acteurs: string;
  categorie: string;
  motsCles: string;
  syntheseCourte: string;
  lienContenu: string;
  date: string;
  sources: string;
  niveauFiabilite: string;
  aReutiliserPour: string;
};

const KNOWLEDGE_RANGE = "Base de connaissances!A:K";

function getRequiredEnv(name: string): string {
  const value = process.env[name];

  if (!value) {
    throw new Error(`Missing required environment variable: ${name}`);
  }

  return value;
}

function getPrivateKey(): string {
  return getRequiredEnv("GOOGLE_PRIVATE_KEY").replace(/\\n/g, "\n");
}

async function getSheetsClient() {
  const auth = new google.auth.JWT({
    email: getRequiredEnv("GOOGLE_SERVICE_ACCOUNT_EMAIL"),
    key: getPrivateKey(),
    scopes: ["https://www.googleapis.com/auth/spreadsheets"]
  });

  return google.sheets({ version: "v4", auth });
}

function fromPlanningRow(row: PlanningRow): KnowledgeRecord {
  return {
    sujet: row.sujet,
    paysRegion: row.rubrique,
    acteurs: "",
    categorie: row.rubrique,
    motsCles: [row.format, row.priorite].filter(Boolean).join(", "),
    syntheseCourte: row.angle_strategique,
    lienContenu: row.id,
    date: new Date().toISOString().slice(0, 10),
    sources: "",
    niveauFiabilite: "A verifier",
    aReutiliserPour: row.format
  };
}

function toSheetValues(record: KnowledgeRecord): string[] {
  return [
    record.sujet,
    record.paysRegion,
    record.acteurs,
    record.categorie,
    record.motsCles,
    record.syntheseCourte,
    record.lienContenu,
    record.date,
    record.sources,
    record.niveauFiabilite,
    record.aReutiliserPour
  ];
}

export async function createKnowledgeRecord(input: KnowledgeRecord | PlanningRow): Promise<KnowledgeRecord> {
  const record = "angle_strategique" in input ? fromPlanningRow(input) : input;

  try {
    console.info(`[knowledgeBase] Creating knowledge record for: ${record.sujet}`);
    const sheets = await getSheetsClient();
    await sheets.spreadsheets.values.append({
      spreadsheetId: getRequiredEnv("GOOGLE_SHEETS_ID"),
      range: KNOWLEDGE_RANGE,
      valueInputOption: "RAW",
      insertDataOption: "INSERT_ROWS",
      requestBody: {
        values: [toSheetValues(record)]
      }
    });

    return record;
  } catch (error) {
    console.error("[knowledgeBase] Failed to create knowledge record.", error);
    throw new Error("Unable to create knowledge base record.");
  }
}

export async function getKnowledgeRecords(): Promise<KnowledgeRecord[]> {
  try {
    console.info("[knowledgeBase] Reading knowledge records.");
    const sheets = await getSheetsClient();
    const response = await sheets.spreadsheets.values.get({
      spreadsheetId: getRequiredEnv("GOOGLE_SHEETS_ID"),
      range: KNOWLEDGE_RANGE
    });

    const rows = response.data.values ?? [];
    return rows.slice(1).map((row) => ({
      sujet: row[0] ?? "",
      paysRegion: row[1] ?? "",
      acteurs: row[2] ?? "",
      categorie: row[3] ?? "",
      motsCles: row[4] ?? "",
      syntheseCourte: row[5] ?? "",
      lienContenu: row[6] ?? "",
      date: row[7] ?? "",
      sources: row[8] ?? "",
      niveauFiabilite: row[9] ?? "",
      aReutiliserPour: row[10] ?? ""
    }));
  } catch (error) {
    console.error("[knowledgeBase] Failed to read knowledge records.", error);
    throw new Error("Unable to read knowledge base records.");
  }
}

