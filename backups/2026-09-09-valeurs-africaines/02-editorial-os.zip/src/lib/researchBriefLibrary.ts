export type ResearchBriefCategory =
  | "Géopolitique & Diplomatie"
  | "Économie & Développement"
  | "Sécurité & Défense"
  | "Technologie & Souveraineté numérique"
  | "Gouvernance & Politiques publiques";

export type ResearchBriefStatus = "Brouillon" | "En révision" | "Validé" | "Archivé";
export type ResearchBriefPriority = "Faible" | "Moyenne" | "Haute" | "Critique" | "À vérifier";

export type ResearchBriefRecord = {
  id: string;
  title: string;
  executiveSummary: string;
  date: string;
  author: string;
  category: ResearchBriefCategory;
  region: string;
  countries: string[];
  priority: ResearchBriefPriority;
  status: ResearchBriefStatus;
  tags: string[];
  context: string;
  keyActors: string[];
  strategicAnalysis: string;
  africaConsequences: string;
  monitoringPoints: string[];
  sourcesToVerify: string[];
  strategicConclusion: string;
};

export const researchBriefCategories: ResearchBriefCategory[] = [
  "Géopolitique & Diplomatie",
  "Économie & Développement",
  "Sécurité & Défense",
  "Technologie & Souveraineté numérique",
  "Gouvernance & Politiques publiques"
];

export const researchBriefStatuses: ResearchBriefStatus[] = ["Brouillon", "En révision", "Validé", "Archivé"];

export const researchBriefRegions = [
  "Toutes les régions",
  "Afrique",
  "Afrique du Nord",
  "Afrique de l'Ouest",
  "Afrique Centrale",
  "Afrique de l'Est",
  "Afrique Australe"
];

export const researchBriefCountries = [
  "Tous les pays",
  "Maroc",
  "Algérie",
  "Égypte",
  "Nigeria",
  "Afrique du Sud",
  "Kenya",
  "Éthiopie",
  "RDC",
  "Sénégal",
  "Côte d'Ivoire"
];

export const researchBriefTags = [
  "Chine",
  "Russie",
  "États-Unis",
  "UE",
  "BRICS",
  "CEDEAO",
  "UA",
  "Énergie",
  "Défense",
  "IA",
  "Numérique",
  "Finance"
];

export const researchBriefRecords: ResearchBriefRecord[] = [];

export function getResearchBriefs() {
  return researchBriefRecords;
}

export function getResearchBriefById(id: string) {
  return researchBriefRecords.find((brief) => brief.id === id) ?? null;
}

export function getResearchDashboardStats() {
  const briefs = getResearchBriefs();
  return {
    total: briefs.length,
    byCategory: researchBriefCategories.map((category) => ({
      category,
      count: briefs.filter((brief) => brief.category === category).length
    })),
    byRegion: researchBriefRegions
      .filter((region) => region !== "Toutes les régions")
      .map((region) => ({
        region,
        count: briefs.filter((brief) => brief.region === region).length
      })),
    publishedThisMonth: briefs.filter((brief) => brief.status === "Validé").length,
    pendingValidation: briefs.filter((brief) => brief.status === "Brouillon" || brief.status === "En révision").length
  };
}
