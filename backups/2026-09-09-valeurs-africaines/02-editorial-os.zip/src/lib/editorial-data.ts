import type { EditorialItem } from "@/types/editorial";

export const fallbackEditorialItems: EditorialItem[] = [
  {
    id: "VA-D-001",
    date: "2026-06-11",
    rhythm: "daily",
    format: "article",
    title: "Evenement majeur du jour",
    angle: "Faits, acteurs et consequences pour l'Afrique.",
    category: "Geopolitique & Diplomatie",
    countryOrRegion: "Afrique",
    owner: "Redaction",
    status: "drafting",
    sources: "2 sources minimum",
    socialFormats: ["LinkedIn", "X / Twitter"],
    knowledgeBaseTarget: "Fiche ou chronologie"
  },
  {
    id: "VA-D-002",
    date: "2026-06-11",
    rhythm: "daily",
    format: "article",
    title: "Economie, securite ou diplomatie",
    angle: "Decryptage, interets en jeu, rapport de force et perspectives.",
    category: "Economie & Developpement",
    countryOrRegion: "Afrique",
    owner: "Redaction",
    status: "drafting",
    sources: "2 sources minimum",
    socialFormats: ["LinkedIn", "Instagram"],
    knowledgeBaseTarget: "Base documentaire"
  },
  {
    id: "VA-W-001",
    date: "S24-2026",
    rhythm: "weekly",
    format: "editorial",
    title: "Edito de la semaine",
    angle: "Sujet majeur, vision strategique et enjeux pour l'Afrique.",
    category: "Edition hebdomadaire",
    countryOrRegion: "Afrique",
    owner: "Direction publication",
    status: "validation",
    sources: "Sources institutionnelles",
    socialFormats: ["Newsletter", "LinkedIn"],
    knowledgeBaseTarget: "Archive hebdomadaire"
  },
  {
    id: "VA-W-002",
    date: "S24-2026",
    rhythm: "weekly",
    format: "research_brief",
    title: "Research Brief - Sahel 2030",
    angle: "Acteurs cles, analyse strategique, consequences et points a surveiller.",
    category: "Securite & Defense",
    countryOrRegion: "Sahel",
    owner: "Redaction",
    status: "review",
    sources: "3 sources minimum",
    socialFormats: ["LinkedIn"],
    knowledgeBaseTarget: "Chronologie Sahel"
  },
  {
    id: "VA-W-003",
    date: "S24-2026",
    rhythm: "weekly",
    format: "country_note",
    title: "Note pays - Senegal",
    angle: "Politique, economie, position geopolitique et perspectives 3-5 ans.",
    category: "Notes Pays",
    countryOrRegion: "Senegal",
    owner: "Redaction",
    status: "review",
    sources: "Sources pays + donnees",
    socialFormats: ["LinkedIn", "Instagram"],
    knowledgeBaseTarget: "Fiche pays Senegal"
  }
];

