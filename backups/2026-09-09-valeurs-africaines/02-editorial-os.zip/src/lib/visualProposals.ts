import type { PlanningRow } from "./googleSheets";

export type VisualProposalType = "photo" | "illustration" | "diagramme";

export type VisualProposal = {
  id: string;
  type: VisualProposalType;
  title: string;
  description: string;
  imagePrompt?: string;
  previewLabel: string;
  searchKeywords?: string[];
  chartData?: {
    format: string;
    dataNeeded: string[];
    sourcesToVerify: string[];
  };
  sourceNeeded?: boolean;
  rightsNote: string;
};

export type VisualChoice = {
  editorialId: string;
  visualId: string;
  type: VisualProposalType | "aucun";
  prompt_visuel: string;
  date_selection?: string;
  droits_visuels_verifies: boolean;
  validation_visuelle_humaine: boolean;
};

type VisualProposalContext = {
  editorialId: string;
  sujet: string;
  rubrique?: string;
  format?: string;
  angleStrategique?: string;
};

export type VisualProposalResult = {
  editorialId: string;
  workflow: [
    "Article généré",
    "Relecture",
    "Propositions visuelles",
    "Choix humain du visuel",
    "Validation humaine",
    "Archivage",
    "Publication éventuelle"
  ];
  proposals: VisualProposal[];
  requiredFields: {
    visuel_propose: true;
    visuel_choisi: string;
    type_visuel: string;
    prompt_visuel: string;
    date_selection: string;
    droits_visuels_verifies: false;
    validation_visuelle_humaine: false;
  };
  validation_humaine_requise: true;
  publication_automatique: false;
};

export function generateVisualProposals(row: PlanningRow | VisualProposalContext): VisualProposalResult {
  const context = normalizeContext(row);

  return {
    editorialId: context.editorialId,
    workflow: [
      "Article généré",
      "Relecture",
      "Propositions visuelles",
      "Choix humain du visuel",
      "Validation humaine",
      "Archivage",
      "Publication éventuelle"
    ],
    proposals: [
      generatePhotoProposal(context),
      generateIllustrationProposal(context),
      generateChartOrDiagramProposal(context)
    ],
    requiredFields: {
      visuel_propose: true,
      visuel_choisi: "",
      type_visuel: "",
      prompt_visuel: "",
      date_selection: "",
      droits_visuels_verifies: false,
      validation_visuelle_humaine: false
    },
    validation_humaine_requise: true,
    publication_automatique: false
  };
}

export function generatePhotoProposal(context: VisualProposalContext): VisualProposal {
  const keywords = buildKeywords(context);

  return {
    id: "visual-1",
    type: "photo",
    title: `Photo documentaire - ${context.sujet}`,
    description: "Option photo éditoriale à utiliser uniquement après vérification des droits, de la source, du crédit et du contexte.",
    imagePrompt: `Photo documentaire réaliste illustrant ${context.sujet}, angle ${context.angleStrategique || "stratégique"}, composition sobre, style presse géopolitique, aucune mise en scène trompeuse.`,
    previewLabel: "Aperçu photo éditoriale",
    searchKeywords: keywords,
    sourceNeeded: true,
    rightsNote: "Vérifier les droits d’utilisation avant publication."
  };
}

export function generateIllustrationProposal(context: VisualProposalContext): VisualProposal {
  return {
    id: "visual-2",
    type: "illustration",
    title: `Illustration stratégique - ${context.sujet}`,
    description: "Option illustration ou dessin pour représenter les rapports de force sans prétendre documenter une scène réelle.",
    imagePrompt: `Illustration éditoriale professionnelle pour un média panafricain de géopolitique: ${context.sujet}. Montrer les dynamiques de ${context.rubrique || "stratégie africaine"} avec une esthétique sobre, noir et or, symboles institutionnels génériques, pas de logo protégé, pas de représentation trompeuse d'événement réel.`,
    previewLabel: "Aperçu illustration stratégique",
    sourceNeeded: false,
    rightsNote: "Illustration générable après validation humaine."
  };
}

export function generateChartOrDiagramProposal(context: VisualProposalContext): VisualProposal {
  return {
    id: "visual-3",
    type: "diagramme",
    title: `Diagramme d'analyse - ${context.sujet}`,
    description: "Option graphique interne pour structurer les acteurs, flux, risques ou scénarios à partir de données vérifiées.",
    imagePrompt: `Visualisation analytique Valeurs Africaines sur ${context.sujet}: carte d'acteurs, flux, risques et conséquences africaines, uniquement à partir de données vérifiées.`,
    previewLabel: "Aperçu visualisation analytique",
    chartData: {
      format: chooseDiagramFormat(context),
      dataNeeded: [
        "acteurs clés et rôles",
        "pays ou régions concernés",
        "indicateurs chiffrés si disponibles",
        "chronologie des faits établis",
        "risques, opportunités et dépendances"
      ],
      sourcesToVerify: [
        "communiqués institutionnels",
        "bases de données publiques",
        "rapports d'organisations internationales",
        "sources médias primaires ou agences reconnues"
      ]
    },
    rightsNote: "Graphique interne basé sur données vérifiées uniquement."
  };
}

export function validateVisualChoice(choice: VisualChoice): VisualChoice {
  if (!choice.editorialId.trim()) {
    throw new Error("editorialId is required.");
  }

  if (!choice.visualId.trim()) {
    throw new Error("visualId is required. Use a proposal id or the explicit no-visual decision.");
  }

  if (choice.type === "photo" && !choice.droits_visuels_verifies) {
    throw new Error("Photo rights must be verified before editorial validation.");
  }

  if (!choice.validation_visuelle_humaine) {
    throw new Error("Human visual validation is required before final validation.");
  }

  return choice;
}

export function attachVisualToContent(choice: VisualChoice): {
  editorialId: string;
  visuel_choisi: string;
  type_visuel: string;
  prompt_visuel: string;
  date_selection: string;
  droits_visuels_verifies: boolean;
  validation_visuelle_humaine: boolean;
  publication_automatique: false;
} {
  const validChoice = validateVisualChoice(choice);

  return {
    editorialId: validChoice.editorialId,
    visuel_choisi: validChoice.visualId,
    type_visuel: validChoice.type,
    prompt_visuel: validChoice.prompt_visuel,
    date_selection: validChoice.date_selection ?? new Date().toISOString(),
    droits_visuels_verifies: validChoice.droits_visuels_verifies,
    validation_visuelle_humaine: validChoice.validation_visuelle_humaine,
    publication_automatique: false
  };
}

function normalizeContext(row: PlanningRow | VisualProposalContext): VisualProposalContext {
  if ("id" in row) {
    return {
      editorialId: row.id,
      sujet: row.sujet || "Sujet éditorial à préciser",
      rubrique: row.rubrique,
      format: row.format,
      angleStrategique: row.angle_strategique
    };
  }

  return row;
}

function buildKeywords(context: VisualProposalContext): string[] {
  const raw = [
    context.sujet,
    context.rubrique,
    context.format,
    context.angleStrategique,
    "Afrique",
    "géopolitique",
    "actualité stratégique"
  ]
    .filter(Boolean)
    .join(" ")
    .split(/[\s,;:]+/)
    .map((item) => item.trim())
    .filter((item) => item.length > 3);

  return Array.from(new Set(raw)).slice(0, 12);
}

function chooseDiagramFormat(context: VisualProposalContext): string {
  const content = `${context.sujet} ${context.rubrique ?? ""} ${context.angleStrategique ?? ""}`.toLowerCase();

  if (/(commerce|flux|routes|maritime|energie|minerais|infrastructures)/.test(content)) {
    return "carte de flux";
  }

  if (/(acteurs|influence|alliance|diplomatie|brics|cedeao|union africaine)/.test(content)) {
    return "carte d'acteurs et d'influence";
  }

  if (/(risque|securite|defense|conflit|sahel|terrorisme)/.test(content)) {
    return "matrice risques / conséquences";
  }

  return "diagramme stratégique causes / effets / conséquences";
}
