import { google } from "googleapis";
import { getGoogleAuth } from "@/lib/googleAuth";
import type { KnowledgeEntryInput } from "@/lib/knowledgeHub";

export type DriveArchiveType =
  | "article"
  | "research-brief"
  | "note-pays"
  | "observatoire"
  | "portrait"
  | "business"
  | "ecologie"
  | "visuel"
  | "source";

export type DriveArchiveMetadata = {
  rubrique?: string;
  categorie?: string;
  pays?: string[];
  acteurs?: string[];
  themes?: string[];
  odd?: string[];
  agenda2063?: string[];
  sources?: string[];
  validation_humaine?: boolean;
  visuel_choisi?: string;
};

export type DriveArchiveInput = {
  contentId: string;
  type: DriveArchiveType;
  title: string;
  markdown: string;
  metadata: DriveArchiveMetadata;
  obsidianPath?: string;
};

export type DriveArchiveResult = {
  success: true;
  driveFileUrl: string;
  driveFolderPath: string;
  obsidianPath: string;
  knowledgeHubUpdated: boolean;
};

const ROOT_FOLDER_NAME = "Valeurs Africaines";
const FOLDER_STRUCTURE = [
  "Observatoire Conflits",
  "Observatoire Diaspora",
  "Observatoire ODD",
  "Observatoire Innovation",
  "Observatoire Chercheurs",
  "Observatoire Business",
  "Observatoire Ecologie",
  "Observatoire Souveraineté Narrative",
  "Research Briefs",
  "Notes Pays",
  "Articles",
  "Cartes",
  "Infographies",
  "Données",
  "Archives"
];

function getRequiredEnv(name: string): string {
  const value = process.env[name];
  if (!value) throw new Error(`Missing required environment variable: ${name}`);
  return value;
}

function getPrivateKey(): string {
  return getRequiredEnv("GOOGLE_PRIVATE_KEY").replace(/\\n/g, "\n");
}

async function getDriveClient() {
  const auth = await getGoogleAuth(["https://www.googleapis.com/auth/drive"]);
  return google.drive({ version: "v3", auth });
}

export async function createDriveFolder(name: string, parentId: string): Promise<string> {
  const drive = await getDriveClient();
  const existing = await drive.files.list({
    q: `'${parentId}' in parents and name='${escapeDriveQuery(name)}' and mimeType='application/vnd.google-apps.folder' and trashed=false`,
    fields: "files(id,name)",
    spaces: "drive"
  });

  const existingId = existing.data.files?.[0]?.id;
  if (existingId) return existingId;

  console.info(`[googleDrive] Creating folder: ${name}`);
  const created = await drive.files.create({
    requestBody: {
      name,
      mimeType: "application/vnd.google-apps.folder",
      parents: [parentId]
    },
    fields: "id"
  });

  if (!created.data.id) throw new Error(`Unable to create Drive folder: ${name}`);
  return created.data.id;
}

export async function ensureDriveFolderStructure(): Promise<Record<string, string>> {
  const rootId = getRequiredEnv("GOOGLE_DRIVE_ROOT_FOLDER_ID");
  const folders: Record<string, string> = { [ROOT_FOLDER_NAME]: rootId };

  for (const folderName of FOLDER_STRUCTURE) {
    folders[`${ROOT_FOLDER_NAME}/${folderName}`] = await createDriveFolder(folderName, rootId);
  }

  return folders;
}

export async function uploadMarkdownToDrive(input: { title: string; markdown: string; folderId: string }): Promise<{ id: string; webViewLink: string }> {
  const drive = await getDriveClient();
  const fileName = await uniqueFileName(`${safeName(input.title)}.md`, input.folderId);
  console.info(`[googleDrive] Uploading Markdown: ${fileName}`);

  const response = await drive.files.create({
    requestBody: {
      name: fileName,
      parents: [input.folderId],
      mimeType: "text/markdown"
    },
    media: {
      mimeType: "text/markdown",
      body: input.markdown
    },
    fields: "id,webViewLink"
  });

  if (!response.data.id || !response.data.webViewLink) throw new Error("Unable to upload Markdown to Drive.");
  return { id: response.data.id, webViewLink: response.data.webViewLink };
}

export async function uploadArticleToDrive(input: DriveArchiveInput, folderId: string): Promise<{ id: string; webViewLink: string }> {
  return uploadMarkdownToDrive({ title: input.title, markdown: input.markdown, folderId });
}

export async function uploadVisualToDrive(input: { title: string; data: string; folderId: string; mimeType?: string }): Promise<{ id: string; webViewLink: string }> {
  const drive = await getDriveClient();
  const fileName = await uniqueFileName(safeName(input.title), input.folderId);
  console.info(`[googleDrive] Uploading visual: ${fileName}`);

  const response = await drive.files.create({
    requestBody: { name: fileName, parents: [input.folderId], mimeType: input.mimeType ?? "image/svg+xml" },
    media: { mimeType: input.mimeType ?? "image/svg+xml", body: input.data },
    fields: "id,webViewLink"
  });

  if (!response.data.id || !response.data.webViewLink) throw new Error("Unable to upload visual to Drive.");
  return { id: response.data.id, webViewLink: response.data.webViewLink };
}

export async function exportGoogleDoc(input: { title: string; markdown: string; folderId: string }): Promise<{ id: string; webViewLink: string }> {
  const drive = await getDriveClient();
  const fileName = await uniqueFileName(safeName(input.title), input.folderId);
  console.info(`[googleDrive] Creating Google Doc: ${fileName}`);

  const response = await drive.files.create({
    requestBody: {
      name: fileName,
      parents: [input.folderId],
      mimeType: "application/vnd.google-apps.document"
    },
    media: {
      mimeType: "text/plain",
      body: input.markdown
    },
    fields: "id,webViewLink"
  });

  if (!response.data.id || !response.data.webViewLink) throw new Error("Unable to create Google Doc.");
  return { id: response.data.id, webViewLink: response.data.webViewLink };
}

export async function archiveContentToDrive(input: DriveArchiveInput): Promise<DriveArchiveResult> {
  if (!input.metadata.validation_humaine) {
    throw new Error("Drive archive requires human validation.");
  }

  console.info(`[googleDrive] Archiving content to Drive: ${input.contentId} (${input.type})`);
  const folders = await ensureDriveFolderStructure();
  const archivePath = getDriveArchivePath(input);
  const folderId = await ensureNestedArchiveFolder(archivePath, folders);
  const file = await uploadArticleToDrive(input, folderId);

  if (process.env.GOOGLE_DRIVE_CREATE_GOOGLE_DOCS === "true") {
    await exportGoogleDoc({ title: input.title, markdown: input.markdown, folderId });
  }

  await linkDriveFileToKnowledgeEntry(input, file.webViewLink);
  return {
    success: true,
    driveFileUrl: file.webViewLink,
    driveFolderPath: archivePath,
    obsidianPath: input.obsidianPath ?? "",
    knowledgeHubUpdated: true
  };
}

export function getDriveArchivePath(input: DriveArchiveInput, now = new Date()): string {
  const year = String(now.getFullYear());
  const month = String(now.getMonth() + 1).padStart(2, "0");
  const root = ROOT_FOLDER_NAME;

  switch (input.type) {
    case "article":
      return `${root}/Articles/${year}/${month}`;
    case "research-brief":
      return `${root}/Research Briefs/${year}/${month}`;
    case "note-pays":
      return `${root}/Notes Pays/${safeName(input.metadata.pays?.[0] ?? "Pays à vérifier")}`;
    case "observatoire":
      return `${root}/${getObservatoryDriveFolder(input.metadata.rubrique ?? input.metadata.categorie ?? "Observatoire")}/${year}/${month}`;
    case "portrait":
      return `${root}/Observatoire Chercheurs/${year}`;
    case "business":
      return `${root}/Observatoire Business/${year}/${month}`;
    case "ecologie":
      return `${root}/Observatoire Ecologie/${year}/${month}`;
    case "visuel":
      return `${root}/Infographies/${year}/${month}`;
    case "source":
      return `${root}/Données/Sources à vérifier`;
    default:
      return `${root}/Archives/${year}/${month}`;
  }
}

export function generateDriveMetadata(input: DriveArchiveInput): KnowledgeEntryInput {
  return {
    type: mapDriveTypeToKnowledgeType(input.type),
    titre: input.title,
    categorie: input.metadata.categorie ?? input.type,
    rubrique: input.metadata.rubrique ?? "Knowledge Hub",
    pays: input.metadata.pays ?? [],
    acteurs: input.metadata.acteurs ?? [],
    themes: [...(input.metadata.themes ?? []), ...(input.metadata.odd ?? []), ...(input.metadata.agenda2063 ?? [])],
    sources: input.metadata.sources ?? [],
    fiabilite: "A vérifier",
    contenu: input.markdown,
    validation_humaine: input.metadata.validation_humaine === true
  };
}

export async function linkDriveFileToKnowledgeEntry(input: DriveArchiveInput, driveFileUrl: string): Promise<string> {
  const linkedMarkdown = `${input.markdown}\n\n## Google Drive\n\n- Archive Drive : ${driveFileUrl}\n- Date archivage Drive : ${new Date().toISOString()}\n`;
  console.info(`[googleDrive] Drive link prepared for Knowledge Entry ${input.contentId}.`);
  return linkedMarkdown;
}

async function ensureNestedArchiveFolder(archivePath: string, folders: Record<string, string>): Promise<string> {
  const parts = archivePath.split("/");
  let currentPath = parts[0];
  let parentId = folders[currentPath];
  if (!parentId) throw new Error("Drive root folder is missing.");

  for (const part of parts.slice(1)) {
    currentPath = `${currentPath}/${part}`;
    parentId = folders[currentPath] ?? await createDriveFolder(part, parentId);
    folders[currentPath] = parentId;
  }

  return parentId;
}

async function uniqueFileName(fileName: string, folderId: string): Promise<string> {
  const drive = await getDriveClient();
  const parsed = splitFileName(fileName);
  let candidate = fileName;
  let suffix = 1;

  while (await fileExists(candidate, folderId, drive)) {
    candidate = `${parsed.name}-v${suffix}${parsed.ext}`;
    suffix += 1;
  }

  return candidate;
}

async function fileExists(fileName: string, folderId: string, drive: Awaited<ReturnType<typeof getDriveClient>>): Promise<boolean> {
  const response = await drive.files.list({
    q: `'${folderId}' in parents and name='${escapeDriveQuery(fileName)}' and trashed=false`,
    fields: "files(id)",
    spaces: "drive"
  });
  return Boolean(response.data.files?.length);
}

function splitFileName(fileName: string): { name: string; ext: string } {
  const dot = fileName.lastIndexOf(".");
  if (dot <= 0) return { name: fileName, ext: "" };
  return { name: fileName.slice(0, dot), ext: fileName.slice(dot) };
}

function safeName(value: string): string {
  return value.replace(/[\\/:*?"<>|]/g, "-").replace(/\s+/g, " ").trim() || "contenu-a-verifier";
}

function escapeDriveQuery(value: string): string {
  return value.replace(/'/g, "\\'");
}

function mapDriveTypeToKnowledgeType(type: DriveArchiveType): KnowledgeEntryInput["type"] {
  if (type === "research-brief") return "research-brief";
  if (type === "note-pays") return "note-pays";
  if (type === "observatoire") return "observatoire";
  if (type === "portrait") return "portrait";
  if (type === "visuel") return "infographie";
  return "article";
}

function getObservatoryDriveFolder(value: string): string {
  const normalized = value.toLowerCase();
  if (normalized.includes("conflit")) return "Observatoire Conflits";
  if (normalized.includes("diaspora")) return "Observatoire Diaspora";
  if (normalized.includes("odd") || normalized.includes("agenda 2063")) return "Observatoire ODD";
  if (normalized.includes("innovation") || normalized.includes("tech")) return "Observatoire Innovation";
  if (normalized.includes("chercheur") || normalized.includes("portrait")) return "Observatoire Chercheurs";
  if (normalized.includes("business") || normalized.includes("investissement")) return "Observatoire Business";
  if (normalized.includes("ecologie") || normalized.includes("écologie") || normalized.includes("climat")) return "Observatoire Ecologie";
  if (normalized.includes("narrative") || normalized.includes("média")) return "Observatoire Souveraineté Narrative";
  return "Archives";
}
