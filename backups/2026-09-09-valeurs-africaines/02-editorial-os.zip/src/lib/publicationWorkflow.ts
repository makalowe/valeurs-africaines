export type EditorialStatus =
  | "Brouillon"
  | "En révision"
  | "Vérification factuelle"
  | "Validation rédaction"
  | "Validation direction"
  | "Programmé"
  | "Publié"
  | "Archivé";

export type ContentType = "Article" | "Editorial" | "Research Brief" | "Note Pays" | "Signal faible" | "Newsletter" | "Dossier";
export type EditorialRole = "Rédacteur" | "Analyste" | "Éditeur" | "Fact-checker" | "Directeur" | "Administrateur";

export type FactCheckItem = {
  label: string;
  checked: boolean;
};

export type AuditLogEntry = {
  user: string;
  date: string;
  time: string;
  action: string;
  content: string;
  oldValue: string;
  newValue: string;
  comment: string;
};

export const editorialStatuses: EditorialStatus[] = [
  "Brouillon",
  "En révision",
  "Vérification factuelle",
  "Validation rédaction",
  "Validation direction",
  "Programmé",
  "Publié",
  "Archivé"
];

export const contentTypes: ContentType[] = ["Article", "Editorial", "Research Brief", "Note Pays", "Signal faible", "Newsletter", "Dossier"];
export const editorialRoles: EditorialRole[] = ["Rédacteur", "Analyste", "Éditeur", "Fact-checker", "Directeur", "Administrateur"];

export const factCheckingChecklist: FactCheckItem[] = [
  { label: "Sources identifiées", checked: false },
  { label: "Sources vérifiées", checked: false },
  { label: "Chiffres vérifiés", checked: false },
  { label: "Citations vérifiées", checked: false },
  { label: "Dates vérifiées", checked: false },
  { label: "Risques juridiques examinés", checked: false }
];

export const workflowTransitions: Record<EditorialStatus, EditorialStatus[]> = {
  Brouillon: ["En révision"],
  "En révision": ["Vérification factuelle"],
  "Vérification factuelle": ["Validation rédaction"],
  "Validation rédaction": ["Validation direction"],
  "Validation direction": ["Programmé", "Publié"],
  Programmé: ["Publié"],
  Publié: ["Archivé"],
  Archivé: []
};

export const auditLog: AuditLogEntry[] = [];

export function canTransition(from: EditorialStatus, to: EditorialStatus) {
  return workflowTransitions[from].includes(to);
}
