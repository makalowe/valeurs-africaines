---
title: "Runtime Clean Restart"
type: "report"
date: "2026-06-13"
tags:
  - "#VAIS"
  - "#runtime"
  - "#nextjs"
  - "#tailwind"
statut: "draft"
validation_humaine: false
---

# Runtime Clean Restart

## Processus arrêtés

Port contrôlé : `5000`

Processus arrêté :

| PID | Processus | Chemin |
|---:|---|---|
| 14460 | node | `C:\Program Files\nodejs\node.exe` |

Note : un premier contrôle n’a pas correctement parcouru les PID à cause de la variable système PowerShell `$PID`. Le contrôle a été relancé avec une variable neutre, puis le processus Node actif sur le port `5000` a été arrêté.

## Caches supprimés

Caches nettoyés :

| Chemin | Statut |
|---|---|
| `.next` | supprimé |
| `node_modules/.cache` | absent |

`node_modules` n’a pas été supprimé.

## Commande de relance

Commande utilisée :

```bash
npm run dev -- --hostname 127.0.0.1 --port 5000
```

Résultat terminal :

```text
Next.js 15.5.19
Local: http://127.0.0.1:5000
Ready in 1887ms
```

Processus actif après relance :

| Adresse | Port | PID |
|---|---:|---:|
| 127.0.0.1 | 5000 | 2080 |

## URLs testées

| Route | Statut HTTP | H1 détecté |
|---|---:|---|
| `http://127.0.0.1:5000/executive-dashboard` | 200 | Tableau de Bord Stratégique |
| `http://127.0.0.1:5000/publication-workflow` | 200 | Workflow éditorial |
| `http://127.0.0.1:5000/strategic-watch-center` | 200 | Veille & Signaux Faibles |

## Statut CSS

Feuille CSS contrôlée :

`/_next/static/css/app/layout.css`

| Route | CSS | Statut |
|---|---|---:|
| `/executive-dashboard` | `/_next/static/css/app/layout.css` | 200 |
| `/publication-workflow` | `/_next/static/css/app/layout.css` | 200 |
| `/strategic-watch-center` | `/_next/static/css/app/layout.css` | 200 |

Aucun CSS en 404 détecté.

## Statut JS

Tous les chunks JavaScript Next.js détectés dans le HTML des trois routes répondent en `200`.

Chunks vérifiés selon les routes :

- `/_next/static/chunks/main-app.js`
- `/_next/static/chunks/app-pages-internals.js`
- `/_next/static/chunks/app/layout.js`
- `/_next/static/chunks/polyfills.js`
- `/_next/static/chunks/webpack.js`
- `/_next/static/chunks/app/executive-dashboard/page.js`
- `/_next/static/chunks/app/strategic-watch-center/page.js`

Aucun JS en 404 détecté.

## Console navigateur

Pages contrôlées dans le navigateur :

- `/executive-dashboard`
- `/publication-workflow`
- `/strategic-watch-center`

Résultat :

- aucune erreur rouge détectée ;
- aucun avertissement bloquant détecté ;
- CSS attaché au document ;
- feuille `layout.css` présente ;
- composants rendus avec styles calculés.

## État final visuel

État observé après redémarrage propre :

- fond noir Valeurs Africaines appliqué ;
- texte clair appliqué ;
- accent or appliqué ;
- boutons stylisés ;
- bordures et cartes visibles ;
- navigation stylisée ;
- icônes lucide rendues.

Valeurs CSS calculées sur les pages :

| Propriété | Valeur |
|---|---|
| `body background` | `rgb(7, 7, 7)` |
| `body color` | `rgb(245, 239, 226)` |
| `button background` | `rgba(200, 150, 46, 0.1)` |
| `button border-radius` | `6px` |
| `main display` | `block` |

Conclusion : l’interface stylisée réelle est obtenue sur `http://127.0.0.1:5000`.

## Capture

Capture enregistrée :

`Reports/runtime-clean-restart-executive-dashboard.png`

## Recommandation

Pour éviter le retour du rendu HTML brut :

1. utiliser uniquement `http://127.0.0.1:5000/...` ;
2. éviter les anciennes maquettes ouvertes en `file://` ;
3. relancer le serveur après suppression de `.next` si l’interface semble stale ;
4. faire un rafraîchissement forcé du navigateur si les styles ne se mettent pas à jour ;
5. vérifier que `/_next/static/css/app/layout.css` répond en `200`.

Aucune modification de code n’a été effectuée.
