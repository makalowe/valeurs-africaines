---
title: "Chief Editorial Officer IA"
type: "report"
date: "2026-06-13"
tags:
  - "#VAIS"
  - "#direction"
  - "#chief-editor"
  - "#workflow-editorial"
statut: "draft"
validation_humaine: false
---

# Chief Editorial Officer IA

## Architecture

Le module **Chief Editorial Officer IA** ajoute une couche d’orchestration éditoriale au-dessus des modules VAIS existants.

Fichiers créés ou modifiés :

| Fichier | Rôle |
|---|---|
| `src/lib/chiefEditorialOfficer.ts` | Moteur d’orchestration, scoring, planning recommandé, commandes `/chief-brief` et `/chief-weekly`. |
| `src/lib/chiefDataProvider.ts` | Data Layer centralisé pour Knowledge Hub, Research Briefs, Notes Pays, Signaux Faibles, Atlas, planning et dashboard. |
| `src/app/chief-editor/page.tsx` | Interface `Direction → Directeur de Rédaction IA`. |
| `src/app/api/chief-editor/status/route.ts` | API JSON pour la commande `/chief-status`. |
| `src/components/AppShell.tsx` | Ajout du menu `Directeur IA`. |
| `Reports/chief-editorial-officer.md` | Documentation du module. |

## Données utilisées

Le module est prêt à coordonner :

- veille stratégique ;
- signaux faibles ;
- notes pays ;
- Research Briefs ;
- observatoires ;
- dashboard exécutif ;
- planning éditorial ;
- Knowledge Hub ;
- Workflow éditorial ;
- Atlas Afrique.

Dans l’état actuel, seules les sources déjà exposées par les modules internes sont lues. Si une source n’est pas disponible ou si elle retourne un fallback mocké, le module affiche explicitement `Source non connectée` au lieu d’inventer des sujets.

## Data Layer centralisé

Interface principale :

```ts
export interface ChiefDataSnapshot {
  knowledgeHub: any[];
  researchBriefs: any[];
  countryNotes: any[];
  weakSignals: any[];
  atlasEntries: any[];
  editorialPipeline: any[];
  executiveMetrics: any;
  missingSources: string[];
}
```

Implémentation :

```ts
getChiefDataSnapshot()
```

Le provider distingue :

- source connectée avec données ;
- source connectée mais vide ;
- source non connectée ;
- source mockée à ne pas consommer comme donnée réelle.

## Scoring

Le scoring réutilise le moteur `editorialCompass`.

Critères pris en compte :

- impact Afrique ;
- urgence ;
- souveraineté ;
- géopolitique ;
- économie ;
- innovation ;
- ODD ;
- diaspora ;
- influence narrative ;
- risque stratégique.

Sortie :

- score sur 100 ;
- priorité ;
- catégorie ;
- format recommandé ;
- sources à vérifier ;
- validation humaine requise.

## Attribution des formats

Formats supportés :

- article ;
- brève ;
- Research Brief ;
- Note Pays ;
- éditorial ;
- infographie ;
- newsletter ;
- post LinkedIn ;
- fil X ;
- carrousel Instagram.

Les formats sont proposés uniquement comme brouillons éditoriaux. Aucune publication automatique n’est déclenchée.

## Détection des doublons

Le module signale systématiquement que chaque proposition doit être vérifiée contre :

- Knowledge Hub ;
- articles proches ;
- Research Briefs proches ;
- Notes Pays liées ;
- planning éditorial.

La détection automatique complète devra être renforcée par une recherche RAG/hybride sur le corpus.

## Agents coordonnés

| Agent | Rôle |
|---|---|
| Watcher | Surveillance des flux et signaux. |
| Veritas | Vérification des sources, chiffres, citations et dates. |
| Strategos | Analyse stratégique : faits, acteurs, intérêts, scénarios, conséquences Afrique. |
| Editor | Transformation en article, éditorial, note pays, newsletter ou formats sociaux. |
| Archivist | Archivage Knowledge Hub, liens Obsidian, relations acteurs/pays/thèmes. |
| Sentinel | Évaluation des risques stratégiques et niveaux d’alerte. |

## Workflow

```text
veille
↓
vérification
↓
scoring
↓
analyse
↓
rédaction
↓
proposition visuelle
↓
validation humaine
↓
archivage
```

## Commandes

### `/chief-brief`

Produit :

- priorités du jour ;
- sujets à produire ;
- sujets à différer ;
- risques éditoriaux ;
- opportunités ;
- validations requises ;
- recommandations.

### `/chief-weekly`

Produit :

- production réalisée ;
- couverture Afrique ;
- rubriques sous-couvertes ;
- pays sous-couverts ;
- observatoires actifs ;
- signaux faibles ;
- priorités de la semaine suivante.

### `/chief-status`

Retourne :

- sources actives ;
- sources manquantes ;
- nombre de contenus ;
- pays couverts ;
- rubriques couvertes ;
- alertes.

Route API :

```text
/api/chief-editor/status
```

Exemple JSON de sortie :

```json
{
  "activeSources": ["Knowledge Hub", "Research Briefs", "Signaux Faibles", "Atlas Afrique", "Notes Pays"],
  "missingSources": ["Planning éditorial: Source non connectée", "Dashboard exécutif: Source non connectée"],
  "contentCount": 10,
  "coveredCountries": ["Maroc", "Nigeria", "RDC"],
  "coveredRubrics": ["géopolitique", "économie", "sécurité"],
  "alerts": [
    "Aucune publication automatique autorisée.",
    "Validation humaine obligatoire avant passage en production.",
    "Source non connectée : Planning éditorial: Source non connectée"
  ]
}
```

## Interface

Route :

```text
/chief-editor
```

Affiche :

- sources connectées ;
- sources manquantes ;
- couverture éditoriale ;
- alertes stratégiques ;
- contenus prioritaires ;
- priorités du jour ;
- score des sujets ;
- planning recommandé ;
- alertes éditoriales ;
- contenus en validation ;
- recommandations IA ;
- coordination des agents ;
- sorties `/chief-brief` et `/chief-weekly`.

## Limites

- Les sujets nominaux ne sont pas inventés si la veille ou le Knowledge Hub ne fournissent aucune source vérifiée.
- La détection de doublons est préparée mais doit encore être connectée au moteur RAG.
- Les exports, publications et validations restent sous contrôle humain.
- Les formats sociaux sont proposés comme formats de brouillon, pas comme publication.

## Règles de validation

- Aucune publication automatique.
- Validation humaine obligatoire.
- Toute donnée non sourcée reste marquée comme source manquante ou donnée à vérifier.
- Tout contenu reste en statut brouillon avant validation.
- Les agents IA ne prennent pas de décision finale de publication.

## Évolutions futures

1. Connecter les sujets du planning Google Sheets.
2. Connecter le RAG pour la détection de doublons.
3. Ajouter une API `/api/chief-editor/brief`.
4. Ajouter un historique des décisions éditoriales.
5. Ajouter une file de tâches agent par agent.
6. Ajouter une exportation Markdown/PDF des briefs de direction.
