---
title: "Diagnostic UI Style"
type: "report"
date: "2026-06-13"
tags:
  - "#VAIS"
  - "#diagnostic"
  - "#ui"
  - "#tailwind"
statut: "draft"
validation_humaine: false
---

# Diagnostic UI Style

## Stack détectée

- Framework : Next.js 15.5.19
- UI : React 19
- Langage : TypeScript
- Styling : Tailwind CSS 3.4.17
- PostCSS : oui
- Icônes : lucide-react
- Graphiques : Recharts
- shadcn/ui : non détecté
- Vite : non détecté

## Fichiers inspectés

- `package.json`
- `src/app/layout.tsx`
- `src/app/globals.css`
- `tailwind.config.ts`
- `postcss.config.mjs`
- `next.config.ts`
- `src/components/AppShell.tsx`

Fichiers absents ou non concernés :

- `vite.config.ts` : absent, normal pour un projet Next.js.
- `app/layout.tsx` à la racine : absent, le projet utilise `src/app/layout.tsx`.
- `app/globals.css` à la racine : absent, le projet utilise `src/app/globals.css`.

## CSS global importé : OUI

Le fichier `src/app/layout.tsx` importe bien :

```ts
import "./globals.css";
```

Le fichier `src/app/globals.css` contient bien les directives Tailwind :

```css
@tailwind base;
@tailwind components;
@tailwind utilities;
```

## Tailwind configuré : OUI

Le fichier `tailwind.config.ts` existe et scanne :

```ts
content: ["./src/**/*.{ts,tsx}"]
```

Ce chemin couvre les pages, composants et layouts actuellement utilisés dans `src/`.

Le fichier `postcss.config.mjs` charge bien :

```js
tailwindcss: {}
autoprefixer: {}
```

## Erreurs terminal

Commande exécutée :

```bash
npm run build
```

Résultat :

- build Next.js : OK
- compilation : OK
- génération des pages statiques : OK
- routes concernées générées :
  - `/executive-dashboard`
  - `/publication-workflow`
  - `/strategic-watch-center`

Commande exécutée :

```bash
npm run dev -- --hostname 127.0.0.1 --port 5000
```

Résultat :

- serveur lancé : OK
- URL locale : `http://127.0.0.1:5000`
- page `/executive-dashboard` : HTTP 200

Aucune erreur terminal bloquante détectée.

## Erreurs navigateur probables

Contrôle navigateur effectué sur :

- `http://127.0.0.1:5000/executive-dashboard`
- `http://127.0.0.1:5000/publication-workflow`
- `http://127.0.0.1:5000/strategic-watch-center`

Résultat observé :

- feuille CSS attachée : OUI
- fichier CSS chargé : `/_next/static/css/app/layout.css`
- statut CSS : HTTP 200
- taille CSS : environ 45 Ko
- classes Tailwind présentes : OUI
- couleur de fond calculée : `rgb(7, 7, 7)`
- couleur de texte calculée : `rgb(245, 239, 226)`
- boutons stylisés : OUI
- erreurs console navigateur : aucune erreur ou alerte détectée pendant le contrôle.

## Cause probable

Le code actuel ne montre pas de défaut de configuration Tailwind ou Next.js.

La cause la plus probable du rendu en HTML brut est donc externe au code source actuel :

1. Page ouverte via une mauvaise URL, par exemple un ancien fichier `file://` ou une ancienne maquette HTML.
2. Serveur de développement stale lancé avant la création des dernières routes.
3. Cache navigateur conservant une ancienne version sans CSS.
4. Fichier CSS `/_next/static/css/app/layout.css` non chargé ponctuellement pendant l’inspection.
5. Inspection sur une URL différente de `http://127.0.0.1:5000/...`.

Le diagnostic local actuel confirme que Tailwind est bien généré, servi et appliqué.

## Correction recommandée

Sans modifier le code, appliquer dans cet ordre :

1. Fermer l’ancien serveur de développement.
2. Relancer :

```bash
npm run dev -- --hostname 127.0.0.1 --port 5000
```

3. Ouvrir uniquement :

```text
http://127.0.0.1:5000/executive-dashboard
http://127.0.0.1:5000/publication-workflow
http://127.0.0.1:5000/strategic-watch-center
```

4. Faire un rafraîchissement forcé du navigateur.
5. Si le problème revient, vérifier dans l’onglet Network du navigateur que `/_next/static/css/app/layout.css` retourne bien `200`.
6. Ne pas ouvrir les anciennes maquettes en `file://`, car elles ne chargent pas le pipeline Next.js/Tailwind.

Conclusion : aucune correction de code n’est recommandée à ce stade. Le problème semble lié au mode d’accès ou au cache, pas à la configuration Tailwind.
