---
title: "Knowledge Hub — Base de connaissances stratégique"
type: "report"
date: "2026-06-13"
tags:
  - "#VAIS"
  - "#knowledge-hub"
  - "#obsidian"
  - "#rag"
statut: "draft"
validation_humaine: false
---

# Knowledge Hub — Base de connaissances stratégique

## Objectif

Transformer chaque contenu produit par Valeurs Africaines en fiche de connaissance structurée, interconnectée et réutilisable pour :

- la recherche documentaire ;
- la veille stratégique ;
- les Research Briefs ;
- les Notes Pays ;
- les infographies ;
- le RAG éditorial ;
- le Knowledge Graph panafricain.

## Fichiers modifiés

| Fichier | Changement |
|---|---|
| `src/lib/knowledgeHub.ts` | Le rendu Markdown des fiches génère désormais les 15 sections stratégiques obligatoires. |
| `src/app/api/knowledge/create/route.ts` | Les types avancés du Knowledge Hub sont autorisés à la création API. |

## Fichiers créés

| Fichier | Rôle |
|---|---|
| `knowledge-hub/template-fiche-connaissance-strategique.md` | Modèle Obsidian de fiche stratégique complète. |
| `Reports/knowledge-hub-strategic-base.md` | Rapport d’intégration du prompt Codex 18. |

## Structure générée pour chaque fiche

Chaque nouvelle entrée Knowledge Hub contient :

1. Fiche synthèse
2. Acteurs clés
3. Thématiques associées
4. Pays concernés
5. Enjeux stratégiques
6. Faits clés
7. Chronologie
8. Conséquences pour l’Afrique
9. Risques
10. Opportunités
11. Signaux à surveiller
12. Connexions avec la base
13. Mots-clés indexés
14. Métadonnées
15. Questions de recherche futures

## Règles appliquées

- Aucune donnée factuelle n’est inventée.
- Les champs non vérifiés restent marqués `Donnee a verifier` ou `A verifier`.
- Les liens Obsidian sont générés uniquement depuis les pays, acteurs, organisations et thèmes fournis.
- Les mots-clés indexés sont construits à partir des métadonnées déjà disponibles.
- La validation humaine reste obligatoire avant création définitive via l’API.

## Compatibilité

| Système | Statut |
|---|---|
| Obsidian | Compatible Markdown + YAML + wikilinks. |
| RAG | Sections stables pour extraction de contexte. |
| Knowledge Graph | Relations pays / acteurs / organisations / thèmes. |
| Google Drive | Compatible avec l’export Drive existant. |
| Dashboard | Compatible avec les entrées listées par l’API Knowledge. |

## Limites restantes

- L’extraction automatique des faits, acteurs, risques et opportunités depuis un texte brut n’est pas encore branchée à un modèle IA.
- Les champs stratégiques détaillés restent à compléter par la rédaction ou un futur agent d’analyse.
- Le score de niveau stratégique et de sensibilité reste volontairement `A verifier`.

## Recommandations

1. Ajouter ensuite une route API dédiée `analyze-content-to-knowledge-entry`.
2. Connecter le moteur RAG pour suggérer les relations internes existantes.
3. Ajouter un contrôle qualité qui bloque les fiches sans sources vérifiées.
4. Ajouter une vue “Relations” dans l’interface Knowledge Hub.
5. Prévoir une validation éditoriale avant tout export Drive définitif.

Validation humaine requise avant intégration éditoriale définitive.
